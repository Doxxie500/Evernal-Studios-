/* EMPIRE DASH — sw.js (service worker)
   - Game files (same origin): CACHE-FIRST + BACKGROUND REFRESH (stale-while-revalidate). The saved copy answers at once, so the game starts
     fast even on a slow connection, and the newest files are fetched quietly behind it (the player is told when an update is ready).
     The very first visit (nothing saved yet) goes to the network.
   - CDN libraries (Bootstrap, fonts, Babylon.js, Alpine.js): CACHE-FIRST, saved only after a complete, successful download.
   - Only complete 200 responses are ever stored; failures and partial downloads are never cached.
   - Bump VERSION when you add files to CORE or want the CDN copies refreshed; old caches are deleted on activation. */
'use strict';
const VERSION = '1.9.29';
const PREFIX = 'jagun-transporter-';
const CACHE = PREFIX + 'v' + VERSION;
const SLOW_MS = 3500;

const CORE = [
  './', 'index.html', 'css/style.css', 'css/identity.css', 'css/menu.css', 'css/gameover.css', 'css/minimal.css', 'css/icons.css', 'js/boot.js', 'js/pwa.js', 'js/cowry-icon.js', 'js/secure-store.js', 'js/track.js', 'js/admin-gate.js', 'js/freeroam-intro.js', 'assets/art/evernal-logo.jpg', 'manifest.json', 'favicon.ico',
  'js/terrain.js', 'js/veg-models.js', 'js/vegetation.js', 'js/buildings.js', 'js/palace.js', 'js/villagers.js', 'js/oyo-world.js', 'js/oyo-royal.js', 'js/world.js', 'js/rig.js', 'js/horse.js',
  'js/messenger.js', 'js/rideanim.js', 'js/dust.js', 'js/riding.js', 'js/cart.js', 'js/audio.js', 'js/game.js', 'js/missions.js', 'js/roam-fare.js', 'js/dropoff.js', 'js/cowrie-road.js', 'js/obstacles.js', 'js/stamina.js', 'js/ambient.js', 'js/yoruba-music.js', 'js/endless.js', 'js/oja.js', 'js/cart-view.js', 'js/cart-guard.js',
  'fonts/fraunces-latin-600.woff2', 'fonts/nunito.woff2', 'fonts/baloo-2.woff2', 'assets/icons/icon-192.png', 'assets/icons/icon-512.png', 'assets/icons/icon-maskable-192.png', 'assets/icons/icon-maskable-512.png',
  'assets/icons/apple-touch-icon.png', 'assets/icons/favicon.svg', 'assets/icons/favicon-16.png', 'assets/icons/favicon-32.png',
  'assets/art/logo.png', 'assets/art/free-roam.jpg', 'assets/art/sponsor-logo.jpg', 'assets/art/scene-land.jpg', 'assets/art/scene-port.jpg'
];
const FONT_CACHE = 'jagun-fonts-keep';                            // fonts live in their OWN cache: never wiped by a version bump
const FONT_CSS = 'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600..900&display=swap';
const FONT_HOSTS = ['fonts.googleapis.com', 'fonts.gstatic.com'];
const CDN_CSS = ['https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css'];
const CDN_JS = ['https://cdn.babylonjs.com/babylon.js', 'https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js'];
const CDN_HOSTS = ['cdn.jsdelivr.net', 'cdn.babylonjs.com', 'cdnjs.cloudflare.com', 'unpkg.com', 'fonts.googleapis.com', 'fonts.gstatic.com'];
const INDEX = new URL('index.html', self.registration.scope).href;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const good = (res) => res && res.status === 200 && (res.type === 'basic' || res.type === 'cors' || res.type === 'default');

async function cdnStore(cache, url) {                      // complete CORS download only; anything else is skipped
  const res = await fetch(url, { mode: 'cors', credentials: 'omit' });
  if (!good(res)) throw new Error('bad response ' + url);
  await cache.put(url, res.clone());
  return res;
}

async function saveFonts() {
  const fc = await caches.open(FONT_CACHE);
  const res = await fetch(FONT_CSS, { mode: 'cors', credentials: 'omit' });
  if (!good(res)) throw new Error('font css');
  const txt = await res.clone().text(), urls = new Set();
  txt.replace(/url\(\s*["']?([^"')]+)["']?\s*\)/g, (m, g) => { if (!/^data:/.test(g)) urls.add(new URL(g, FONT_CSS).href); return m; });
  await Promise.all([...urls].map(async (u) => { if (await fc.match(u)) return; const r = await fetch(u, { mode: 'cors', credentials: 'omit' }); if (good(r)) await fc.put(u, r); }));
  await fc.put(FONT_CSS, res);
}
self.addEventListener('message', (e) => { if (e.data === 'save-fonts') e.waitUntil(saveFonts().catch(() => {})); });

self.addEventListener('install', (e) => {
  e.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    // 1) the game itself: all-or-nothing. If any file is missing the install fails and the previous version keeps running.
    await cache.addAll(CORE.map((u) => new Request(u, { cache: 'reload' })));
    // 2) CDN libraries: best effort (the game still works online if one of these cannot be saved).
    await Promise.allSettled([
      ...CDN_JS.map((u) => cdnStore(cache, u)),
      ...CDN_CSS.map(async (u) => {
        const res = await cdnStore(cache, u);
        const txt = await res.clone().text();                       // also save the icon font files the stylesheet points at
        const urls = new Set();
        txt.replace(/url\(\s*["']?([^"')]+)["']?\s*\)/g, (m, g) => { if (!/^data:/.test(g)) urls.add(new URL(g, u).href); return m; });
        await Promise.allSettled([...urls].map((x) => cdnStore(cache, x)));
      })
    ]);
    await saveFonts().catch(() => {});                              // fonts: best effort here, retried by the page whenever it is online
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => (k.startsWith(PREFIX) || k.startsWith('jagun-royal-messenger-')) && k !== CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET' || req.headers.has('range')) return;
  const url = new URL(req.url);
  if (url.pathname.indexOf('/api/') === 0) return;                       // server calls (time, cart-link check) always go straight to the network, never the cache
  if (FONT_HOSTS.includes(url.hostname)) { e.respondWith(fontFirst(e, req)); return; }
  if (url.origin === self.location.origin) e.respondWith(networkFirst(e, req, url));
  else if (CDN_HOSTS.includes(url.hostname)) e.respondWith(cacheFirst(req));
});

let told = false;
async function networkFirst(e, req, url) {                                // (name kept) cached copy first, refreshed in the background
  const cache = await caches.open(CACHE);
  const nav = req.mode === 'navigate';
  const key = nav ? INDEX : url.origin + url.pathname;
  const cached = await cache.match(key);
  const sig = (r) => r && (r.headers.get('etag') || r.headers.get('last-modified') || r.headers.get('content-length'));
  const net = (async () => {
    const res = await fetch(new Request(req.url, { cache: 'no-cache', credentials: 'same-origin' }));
    if (good(res)) {
      try { await cache.put(key, res.clone()); } catch (err) { /* quota */ }
      if (cached && !told && sig(cached) && sig(res) && sig(cached) !== sig(res)) {          // a newer file arrived: tell the open page once
        told = true; try { (await self.clients.matchAll()).forEach((c) => c.postMessage('oyo-update')); } catch (err) { /* ok */ }
      }
    }
    return res;
  })();
  if (cached) { e.waitUntil(net.catch(() => {})); return cached; }
  return net.catch(() => fetch(req.url, { cache: 'reload' })).catch(() => new Response('Offline — this file is not saved yet. Open the game once while online.', { status: 503, headers: { 'Content-Type': 'text/plain' } }));
}

async function fontFirst(e, req) {
  const fc = await caches.open(FONT_CACHE);
  const hit = (await fc.match(req.url)) || (await caches.match(req.url));
  if (hit) return hit;
  try { const r = await fetch(req.url, { mode: 'cors', credentials: 'omit' }); if (good(r)) { try { await fc.put(req.url, r.clone()); } catch (err) { /* quota */ } } return r; }
  catch (err) { return new Response('', { status: 200, headers: { 'Content-Type': /css/.test(req.url) || /googleapis/.test(req.url) ? 'text/css' : 'font/woff2' } }); }   // never an error page: the fallback fonts simply take over
}

async function cacheFirst(req) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(req.url);
  if (hit) return hit;
  try { return (await cdnStore(cache, req.url)).clone(); }
  catch (err) { return fetch(req); }                                      // CORS not available: just pass through, do not cache
}
