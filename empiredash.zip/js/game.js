/* EMPIRE DASH — game.js
   Boots Babylon, builds the world, runs the HUD, controls, minimap and Royal Road tour. */
(function () {
  'use strict';

  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const angDiff = (a, b) => { let d = (b - a) % (Math.PI * 2); if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2; return d; };

  const MODES = {
    walk: { speed: 7, run: 13, eye: 1.7, accel: 6 },
    ride: { speed: 22, run: 34, eye: 2.9, accel: 3.2 },
    fly:  { speed: 40, run: 80, eye: 0, accel: 2.6 }
  };

  const P = { x: 0, y: 0, z: 0, yaw: 0, pitch: 0.05, vx: 0, vy: 0, vz: 0, eye: 1.7, bob: 0 };
  const input = { jx: 0, jy: 0, keys: {}, boost: false, jumpAt: 0 };
  const S = { riding: null, engine: null, scene: null, cam: null, world: null, canvas: null, tourS: 0, booted: false, mapCtx: null, frame: 0, lastRoad: '', t: 0 };

  /* ---------- HUD state (Alpine) ---------- */
  const stub = { loading: true, progress: 0, stage: '', fatal: '', roadName: '', roadClass: '', heading: 'N', alt: 0, mode: 'walk', tour: false, hint: true, gait: 'Standing', riderOn: false, pwaCan: false };
  const OYO = window.OYO = {
    hud: stub,
    setMode(m) {
      if (!MODES[m]) return;
      OYO.hud.tour = false;
      const prev = OYO.hud.mode; OYO.hud.mode = m;
      const RD = S.riding;
      if (RD && RD.built) {
        if (m === 'ride' && prev !== 'ride') { RD.place(P.x, P.z, P.yaw); }
        else if (prev === 'ride' && m !== 'ride') { P.x = RD.state.x; P.z = RD.state.z; P.yaw = RD.state.yaw; P.pitch = .05; P.eye = MODES[m].eye || 1.7; P.vx = P.vz = P.vy = 0; }
      }
      if (m === 'fly' && prev !== 'fly') P.eye = Math.max(P.eye, 8);
    },
    toggleTour() { const h = OYO.hud; h.tour = !h.tour; if (h.tour) { S.tourS = nearestRoyalS(); h.hint = false; } },
    fullscreen() {
      const el = document.documentElement;
      try {
        if (!document.fullscreenElement) (el.requestFullscreen || el.webkitRequestFullscreen || function () {}).call(el);
        else (document.exitFullscreen || document.webkitExitFullscreen || function () {}).call(document);
      } catch (e) { /* ignore */ }
      setTimeout(() => S.engine && S.engine.resize(), 300);
    },
    /* pointer movement in the game's own frame (the page is always upright now) */
    pxy(dx, dy) { return [dx, dy]; }
  };

  // Stage 8: small API used by missions.js
  OYO.core = {
    S, P, input,
    tourOn(v) { const h = OYO.hud; h.tour = !!v; if (v) { S.tourS = nearestRoyalS(); h.hint = false; } },
    releaseInput() {
      input.keys = {}; input.boost = false; input.jx = input.jy = 0; input.jumpAt = 0; input.gal = false;
      const kn = document.getElementById('joyKnob'); if (kn) kn.style.transform = '';                 // Stage 9: no stuck stick / pressed buttons after pause or a result screen
      ['btnLeft', 'btnRight', 'btnBrake', 'btnJump'].forEach(id => { const b = document.getElementById(id); if (b) b.classList.remove('on'); });
    }
  };

  window.oyoHud = function () {
    return Object.assign({}, stub, (window.OYOUI && window.OYOUI.state) || {}, {
      init() { OYO.hud = this; try { window.OYOPWA && OYOPWA.sync(); } catch (e) { /* optional */ } start(); }
    });
  };

  /* ---------- helpers ---------- */
  function nearestRoyalS() {
    const r = S.world && S.world.byId.royal; if (!r) return 0;
    let best = 0, bd = 1e12;
    for (let i = 0; i < r.n; i++) { const d = (r.x[i] - P.x) ** 2 + (r.z[i] - P.z) ** 2; if (d < bd) { bd = d; best = r.s[i]; } }
    return best;
  }
  function royalAt(s) {
    const r = S.world.byId.royal, f = clamp(s / r.len, 0, 1) * (r.n - 1), i = Math.min(r.n - 2, Math.floor(f)), k = f - i;
    return {
      x: lerp(r.x[i], r.x[i + 1], k), z: lerp(r.z[i], r.z[i + 1], k),
      tx: lerp(r.tx[i], r.tx[i + 1], k), tz: lerp(r.tz[i], r.tz[i + 1], k), len: r.len
    };
  }
  const HEADS = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  function headingText(yaw) {
    let d = (yaw * 180 / Math.PI) % 360; if (d < 0) d += 360;
    return HEADS[Math.round(d / 45) % 8] + ' ' + Math.round(d) + '°';
  }

  /* ---------- controls ---------- */
  function bindControls() {
    const canvas = S.canvas;

    // Joystick
    const joy = document.getElementById('joy'), knob = document.getElementById('joyKnob');
    if (joy && knob) {
      let jid = null, cx = 0, cy = 0, R = 50;
      const setKnob = (dx, dy) => { knob.style.transform = `translate(${dx}px,${dy}px)`; };
      const move = (e) => {
        let [dx, dy] = OYO.pxy(e.clientX - cx, e.clientY - cy); const l = Math.hypot(dx, dy);
        if (l > R) { dx = dx / l * R; dy = dy / l * R; }
        input.jx = dx / R; input.jy = -dy / R; setKnob(dx, dy);
        if ((Math.abs(input.jx) > .15 || Math.abs(input.jy) > .15) && OYO.hud.tour && OYO.hud.screen !== 'title') OYO.hud.tour = false;
        OYO.hud.hint = false;
      };
      joy.addEventListener('pointerdown', (e) => {
        jid = e.pointerId; try { joy.setPointerCapture(jid); } catch (_) {}
        const r = joy.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2; R = r.width * .38;
        move(e); e.preventDefault();
      });
      joy.addEventListener('pointermove', (e) => { if (e.pointerId === jid) move(e); });
      const end = (e) => { if (e.pointerId !== jid) return; jid = null; input.jx = input.jy = 0; setKnob(0, 0); };
      joy.addEventListener('pointerup', end); joy.addEventListener('pointercancel', end);
    }

    // Look (drag anywhere on the canvas)
    const looks = new Map();
    const rideOn = () => S.riding && S.riding.active;
    canvas.addEventListener('pointerdown', (e) => {
      looks.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (S.riding && S.riding.built && !(OYO.endless && OYO.endless.on)) S.riding.cam.drag = true;
      try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
      OYO.hud.hint = false;
    });
    canvas.addEventListener('pointermove', (e) => {
      const l = looks.get(e.pointerId); if (!l) return;
      const [dx, dy] = OYO.pxy(e.clientX - l.x, e.clientY - l.y); l.x = e.clientX; l.y = e.clientY;
      const k = 0.0042;
      if (OYO.endless && OYO.endless.on) { /* Endless Run: fixed chase camera, swipes change lane (endless.js) */ }
      else if (rideOn()) S.riding.orbit(dx * k, dy * k * .8);
      else { P.yaw += dx * k; P.pitch = clamp(P.pitch + dy * k, -1.3, 1.3); }
    });
    const lend = (e) => { looks.delete(e.pointerId); if (!looks.size && S.riding && S.riding.built) S.riding.cam.drag = false; };
    canvas.addEventListener('pointerup', lend); canvas.addEventListener('pointercancel', lend);
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    // Stage 9: Jump (tap) button — latched so a quick tap is never missed between frames
    const jb = document.getElementById('btnJump');
    if (jb) {
      jb.addEventListener('pointerdown', (e) => { input.jumpAt = performance.now(); input.gal = true; jb.classList.add('on'); try { jb.setPointerCapture(e.pointerId); } catch (_) {} e.preventDefault(); OYO.hud.hint = false; });
      const jup = () => { input.gal = false; jb.classList.remove('on'); };
      jb.addEventListener('pointerup', jup); jb.addEventListener('pointercancel', jup); jb.addEventListener('lostpointercapture', jup);
    }

    // Bell (horn): BELL button / B key rings the brass bell on the cart (swing + sound). Short cooldown so it cannot be machine-gunned.
    let bellAt = 0;
    const ringBell = () => { const n = performance.now(); if (n - bellAt < 420) return; bellAt = n; try { if (S.cart && S.cart.ringBell) S.cart.ringBell(); } catch (_) {} try { window.OYOAudio && OYOAudio.bell && OYOAudio.bell(); } catch (_) {} };
    const bb = document.getElementById('btnBell');
    if (bb) {
      bb.addEventListener('pointerdown', (e) => { bb.classList.add('on'); try { bb.setPointerCapture(e.pointerId); } catch (_) {} e.preventDefault(); OYO.hud.hint = false; ringBell(); });
      const bup = () => bb.classList.remove('on'); bb.addEventListener('pointerup', bup); bb.addEventListener('pointercancel', bup); bb.addEventListener('lostpointercapture', bup);
    }
    window.addEventListener('keydown', (e) => { if (e.code === 'KeyB' && !e.repeat && OYO.hud && (OYO.hud.screen === 'endless' || OYO.hud.screen === 'free')) ringBell(); });

    // Stage 8: on-screen hold buttons (steer / forward / reverse) map onto the keyboard state
    [['btnLeft', 'KeyA'], ['btnRight', 'KeyD'], ['btnBrake', 'KeyS']].forEach(([id, code]) => {
      const b = document.getElementById(id); if (!b) return;
      const up = () => { input.keys[code] = false; b.classList.remove('on'); };
      b.addEventListener('pointerdown', (e) => { input.keys[code] = true; b.classList.add('on'); try { b.setPointerCapture(e.pointerId); } catch (_) {} e.preventDefault(); OYO.hud.hint = false; });
      b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('lostpointercapture', up);
    });

    // Keyboard
    window.addEventListener('keydown', (e) => {
      input.keys[e.code] = true;
      if (!e.repeat && (e.code === 'Space' || e.code === 'KeyW' || e.code === 'ArrowUp')) input.jumpAt = performance.now();   // Stage 9: jump keys
      if (OYO.hud.screen === 'free' && e.code === 'Digit1') OYO.setMode('walk');
      else if (OYO.hud.screen === 'free' && e.code === 'Digit2') OYO.setMode('ride');
      else if (OYO.hud.screen === 'free' && e.code === 'Digit3') OYO.setMode('fly');
      else if (OYO.hud.screen === 'free' && e.code === 'KeyT') OYO.toggleTour();
      else if (e.code === 'KeyF') OYO.fullscreen();
      else if ((e.code === 'Escape' || e.code === 'KeyP') && OYO.mission) OYO.mission.togglePause();
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
      if (OYO.hud.tour && OYO.hud.screen !== 'title' && (e.code === 'KeyW' || e.code === 'KeyS' || e.code === 'ArrowUp' || e.code === 'ArrowDown')) OYO.hud.tour = false;
    });
    window.addEventListener('keyup', (e) => { input.keys[e.code] = false; });
    window.addEventListener('blur', () => { input.keys = {}; });
  }

  /* ---------- per-frame update ---------- */
  function update(dt) {
    if (OYO.mission && OYO.mission.paused) return;   // Stage 8: pause / result screens freeze the simulation
    const W = S.world, h = OYO.hud, k = input.keys, mode = MODES[h.mode];
    S.t += dt;
    const RD = S.riding, ridingNow = !!(RD && RD.built && h.mode === 'ride' && !h.tour);
    const titleShow = !!(RD && RD.built && S.cart && h.tour && h.screen === 'title');      // start-menu clip: the horse and the chosen cart trot along the royal road
    if (RD && RD.built && RD.active !== (ridingNow || titleShow)) { RD.setActive(ridingNow || titleShow); if (ridingNow) RD.cam.snap = true; }
    // start-menu clip: the messenger sits on the cart's driver bench (reins in hand) instead of the horse's back; he returns to the saddle when the clip ends
    if (RD && RD.built) {
      if (titleShow) {
        if ((!RD.driver || RD.driver.cart !== S.cart) && S.cart.state && S.cart.state.hitched) { try { RD.setDriver(S.cart); S.titleDrv = true; } catch (e) { console.warn('Title driver seat skipped', e); } }
      } else if (S.titleDrv) {
        S.titleDrv = false;
        if (!(OYO.endless && OYO.endless.on) && RD.driver) { try { RD.setDriver(null); } catch (e) { /* ok */ } }       // Endless Run seats its own driver
      }
    }

    if (ridingNow) {
      updateRide(dt);
    } else if (h.tour) {
      S.tourS += 20 * dt;
      const a = royalAt(S.tourS), b = royalAt(S.tourS + 28);
      if (S.tourS > a.len - 30) S.tourS = 0;
      const sway = Math.sin(S.t * .35);
      P.x = a.x + (-a.tz) * sway * 3; P.z = a.z + a.tx * sway * 3;
      const ty = Math.atan2(b.x - a.x, b.z - a.z);
      P.yaw += angDiff(P.yaw, ty + sway * .25) * Math.min(1, dt * 1.8);
      P.pitch = lerp(P.pitch, .1, Math.min(1, dt * 1.5));
      const want = 4.5 + Math.sin(S.t * .5) * 1.2;
      P.eye = lerp(P.eye, want, Math.min(1, dt * 2));
      P.vx = P.vz = P.vy = 0;
      if (titleShow) {
        S.tourS -= 11 * dt;                                                   // slower than the fly-by: the horse trots at ~9 m/s
        const hs = S.tourS + 34, a2 = royalAt(hs), b2 = royalAt(hs + 8), hy = Math.atan2(b2.x - a2.x, b2.z - a2.z), st = RD.state;
        st.x = a2.x; st.z = a2.z; st.yaw = hy; st.y = W.height(a2.x, a2.z);
        RD.update(dt, { auto: true, fwd: true, back: false, brake: false, jump: false, steer: 0, analog: 0, boost: true, gal: false });
        st.x = a2.x; st.z = a2.z; st.yaw = hy; st.y = W.height(a2.x, a2.z); st.bump = 0;
        const fx = Math.sin(hy), fz = Math.cos(hy), tx = a2.x - fx * 3.3, tz = a2.z - fz * 3.3, ty = st.y + 1.5;      // look at the middle of horse + cart
        const off = hy + 1.15 + Math.sin(S.t * .3) * .35, cxp = tx + Math.sin(off) * 10.5, czp = tz + Math.cos(off) * 10.5, cyp = Math.max(st.y + 3.1, W.height(cxp, czp) + 1.6);
        const lx = tx - cxp, lz = tz - czp, hz = Math.hypot(lx, lz);
        P.x = cxp; P.z = czp; P.yaw = Math.atan2(lx, lz); P.pitch = Math.atan2(cyp - ty, hz); P.eye = cyp - W.height(cxp, czp);
      }
    } else {
      // keyboard look + move
      const ky = (k.ArrowRight ? 1 : 0) - (k.ArrowLeft ? 1 : 0);
      P.yaw += ky * 1.8 * dt;
      let mx = input.jx, my = input.jy;
      mx += (k.KeyD ? 1 : 0) - (k.KeyA ? 1 : 0);
      my += (k.KeyW || k.ArrowUp ? 1 : 0) - (k.KeyS || k.ArrowDown ? 1 : 0);
      const ml = Math.hypot(mx, my); if (ml > 1) { mx /= ml; my /= ml; }
      const sp = (k.ShiftLeft || k.ShiftRight ? mode.run : mode.speed) * (ml > 0 ? 1 : 0);
      const sy = Math.sin(P.yaw), cy = Math.cos(P.yaw);
      let tvx = (sy * my + cy * mx) * sp, tvz = (cy * my - sy * mx) * sp, tvy = 0;
      if (h.mode === 'fly') {
        const cp = Math.cos(P.pitch);
        tvx = (sy * cp * my + cy * mx) * sp; tvz = (cy * cp * my - sy * mx) * sp; tvy = -Math.sin(P.pitch) * my * sp;
        tvy += ((k.Space ? 1 : 0) - (k.KeyC ? 1 : 0)) * 20;
      }
      const f = Math.min(1, dt * mode.accel);
      P.vx = lerp(P.vx, tvx, f); P.vz = lerp(P.vz, tvz, f); P.vy = lerp(P.vy, tvy, f);
      P.x = clamp(P.x + P.vx * dt, -W.HALF + 6, W.HALF - 6);
      P.z = clamp(P.z + P.vz * dt, -W.HALF + 6, W.HALF - 6);

      const g = W.height(P.x, P.z);
      if (h.mode === 'fly') {
        P.eye = clamp(P.eye + P.vy * dt, 3, 220);
      } else {
        const spd = Math.hypot(P.vx, P.vz);
        P.bob += dt * (h.mode === 'ride' ? 7 : 8.5) * Math.min(1, spd / 6);
        const bob = Math.sin(P.bob) * (h.mode === 'ride' ? .07 : .05) * Math.min(1, spd / 6);
        P.eye = lerp(P.eye, mode.eye + bob, Math.min(1, dt * 8));
      }
    }

    const ground = W.height(P.x, P.z);
    const cam = S.cam;
    if (!ridingNow) {
      P.y = ground + P.eye;
      if (P.y < ground + 1.2) P.y = ground + 1.2;
      cam.position.set(P.x, P.y, P.z);
      cam.rotation.set(P.pitch, P.yaw, 0);
      if (cam.fov !== 1.0) cam.fov = 1.0;
      if (titleShow) { try { RD.mat.setVector3('camPos', cam.position); } catch (e) { /* ignore */ } }
    }

    if (W.updateSun) W.updateSun({ x: P.x, y: ground, z: P.z });
    if (W.sky) W.sky.setFloat('time', S.t);

    // HUD (throttled)
    if ((S.frame++ & 7) === 0) {
      h.heading = headingText(S.riding && S.riding.active ? S.riding.state.yaw : P.yaw); h.alt = Math.round(P.y);
      const q = W.queryRoad(P.x, P.z);
      let name = 'Open Savanna', cls = '';
      if (q && q.d <= q.hw * 1.25) { name = q.road.name; cls = q.road.cls; }
      if (name !== S.lastRoad) { S.lastRoad = name; h.roadName = name; h.roadClass = cls; }
    }
    if (MAP_ON.has(h.screen) && (S.frame & 1) === 0) drawMinimap();   // Stage 9: not drawn behind menus, half rate otherwise
  }
  const MAP_ON = new Set(['free', 'play', 'pause']);

  /* ---------- Stage 7: riding ---------- */
  function updateRide(dt) {
    const RD = S.riding, k = input.keys, h = OYO.hud, cam = S.cam;
    const steer = clamp(((k.KeyD || k.ArrowRight) ? 1 : 0) - ((k.KeyA || k.ArrowLeft) ? 1 : 0) + input.jx, -1, 1);
    // Stage 9: auto-gallop — the rider only steers, brakes (S / ↓ / stick down / BRAKE) and jumps (Space / W / ↑ / JUMP)
    const jump = input.jumpAt && performance.now() - input.jumpAt < 160; input.jumpAt = 0;
    const brake = !!(k.KeyS || k.ArrowDown || k.ShiftLeft || k.ShiftRight) || input.jy < -.4;
    const inp = { auto: true, fwd: true, back: false, brake, jump: !!jump, steer, analog: 0, boost: true, gal: !!(input.gal || k.Space || k.KeyW || k.ArrowUp) };
    const MS = OYO.mission; if (MS) MS.pre(dt, inp, RD.state);
    RD.update(dt, inp);
    if (MS) MS.post(dt, RD.state);
    const c = RD.camera(dt, cam);
    cam.position.set(c.x, c.y, c.z); cam.rotation.set(c.pitch, c.yaw, c.roll || 0); cam.fov = c.fov;
    P.x = RD.state.x; P.z = RD.state.z; P.y = c.y; P.yaw = c.yaw; P.pitch = c.pitch; P.eye = c.y - W0().height(P.x, P.z);
    RD.mat.setVector3('camPos', cam.position);
    if (h.gait !== RD.state.gaitLabel) h.gait = RD.state.gaitLabel;
    if (Math.abs(input.jy) > .15 || Math.abs(input.jx) > .15 || k.KeyW || k.KeyS || k.Space || k.ArrowUp || k.ArrowDown) h.hint = false;
  }
  const W0 = () => S.world;

  function drawMinimap() {
    const c = S.mapCtx, W = S.world; if (!c || !W.mapCanvas) return;
    const SZ = 264, k = SZ / W.WORLD;
    c.clearRect(0, 0, SZ, SZ);
    c.drawImage(W.mapCanvas, 0, 0, SZ, SZ);
    const px = (P.x + W.HALF) * k, py = (W.HALF - P.z) * k;
    c.save(); c.translate(px, py); c.rotate(S.riding && S.riding.active ? S.riding.state.yaw : P.yaw);
    c.fillStyle = '#fff3d0'; c.strokeStyle = '#2a170d'; c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(0, -11); c.lineTo(7, 8); c.lineTo(0, 4); c.lineTo(-7, 8); c.closePath(); c.fill(); c.stroke();
    c.restore();
  }

  /* ---------- boot ---------- */
  function fatal(msg) {
    console.error(msg);
    OYO.hud.fatal = String(msg && msg.message || msg);
    try { window.OYOBoot && OYOBoot.fail(String(msg && msg.message || msg)); } catch (e) { /* ignore */ }   // loading screen shows the problem + Try again
    OYO.hud.loading = false;
  }

  async function start() {
    if (S.booted) return; S.booted = true;
    const BOOT = window.OYOBoot || { world() {}, step() {}, yield: () => Promise.resolve(), begin() {}, ready() {} };
    BOOT.begin();
    try {
      if (typeof BABYLON === 'undefined') throw new Error('Babylon.js did not load. Check your internet connection and reload.');
      const B = BABYLON;
      const canvas = S.canvas = document.getElementById('renderCanvas');
      const engine = S.engine = new B.Engine(canvas, false, { antialias: false, stencil: false, powerPreference: 'high-performance' }, true);   // antialias off + capped resolution = much smoother on phones; the flat Yoruba colours stay crisp
      engine.setHardwareScalingLevel(1 / Math.min(window.devicePixelRatio || 1, 1.25));
      const scene = S.scene = new B.Scene(engine);
      scene.skipPointerMovePicking = true;

      const cam = S.cam = new B.FreeCamera('cam', new B.Vector3(0, 10, 0), scene);
      cam.inputs.clear(); cam.minZ = .3; cam.maxZ = 3500; cam.fov = 1.0; cam.rotationQuaternion = null;
      scene.activeCamera = cam;

      const hud = OYO.hud;
      const mc = document.getElementById('minimap'); if (mc) S.mapCtx = mc.getContext('2d');

      const World = S.world = window.OYOWorld;
      await World.build(scene, (f, t) => { hud.progress = f; hud.stage = t; BOOT.world(f, t); });

      // spawn on the Royal Road, facing along it
      const r = World.byId.royal, i0 = Math.min(r.n - 2, 20);
      P.x = r.x[i0]; P.z = r.z[i0]; P.yaw = Math.atan2(r.tx[i0], r.tz[i0]); P.eye = MODES.walk.eye;
      P.y = World.height(P.x, P.z) + P.eye;
      cam.position.set(P.x, P.y, P.z); cam.rotation.set(P.pitch, P.yaw, 0);

      // Stage 7: the transporter and his horse
      BOOT.step(.92, 'Saddling the horse…'); await BOOT.yield();
      try {
        if (window.OYORiding && window.OYOHorse && window.OYOMessenger) {
          S.riding = OYORiding.build(scene, World);
          const r2 = World.byId.royal, i1 = Math.min(r2.n - 2, 26);
          S.riding.place(r2.x[i1] + r2.nx[i1] * 1.6, r2.z[i1] + r2.nz[i1] * 1.6, Math.atan2(r2.tx[i1], r2.tz[i1]));
          hud.mode = 'ride'; hud.riderOn = true; P.yaw = S.riding.state.yaw; P.x = S.riding.state.x; P.z = S.riding.state.z;
        }
      } catch (e) { console.warn('Rider skipped:', e); S.riding = null; hud.mode = 'walk'; }

      // Stage 12b: the Oba's passenger cart, hitched behind the royal horse (moves with it; falls back to a parked cart if the rider failed to build; add ?cart=0 to hide it)
      try { if (window.OYOCart) { const rc = World.byId.royal; S.cart = (S.riding && S.riding.built) ? OYOCart.spawnHitched(scene, World, S.riding) : OYOCart.spawnParked(scene, World, rc, Math.min(rc.n - 2, 26)); } } catch (e) { console.warn('Cart skipped:', e); S.cart = null; }

      BOOT.step(.95, 'Preparing the roads…'); await BOOT.yield();
      bindControls();
      try { OYO.mission && OYO.mission.init(World, S.riding, scene, OYO.core); } catch (e) { console.warn('Missions failed to init', e); }
      window.addEventListener('resize', () => { engine.resize(); });
      window.addEventListener('orientationchange', () => { setTimeout(() => { try { engine.resize(); } catch (e) { /* ok */ } }, 250); });
      canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); try { OYO.hud.toast = 'Graphics paused by your phone. Please wait a moment…'; } catch (x) { /* ok */ } }, false);
      canvas.addEventListener('webglcontextrestored', () => { try { OYO.hud.toast = ''; engine.resize(); } catch (x) { /* ok */ } }, false);

      let last = performance.now(), idleF = 0, errRun = 0, errTotal = 0, errShown = false;
      /* Frame-rate governor: if frames run long, quietly lower the render resolution (never below 0.6x) until it is smooth again, and raise it back when there is headroom. */
      let gBase = engine.getHardwareScalingLevel(), gCur = gBase, gSlow = 0, gFast = 0, gEma = 16;
      engine.runRenderLoop(() => {
        const now = performance.now(), dt = Math.min(.05, (now - last) / 1000), raw = now - last; last = now;
        if (!(OYO.mission && OYO.mission.paused) && !document.hidden && raw < 500) {
          if (engine.getHardwareScalingLevel() !== gCur) { gBase = gCur = engine.getHardwareScalingLevel(); gSlow = gFast = 0; }   // quality changed in Settings
          gEma += (raw - gEma) * .1;
          if (gEma > 24) { gSlow++; gFast = 0; } else if (gEma < 15) { gFast++; gSlow = 0; } else { gSlow = gFast = 0; }
          if (gSlow > 40 && gCur < gBase / .6) { gCur = Math.min(gBase / .6, gCur * 1.12); engine.setHardwareScalingLevel(gCur); gSlow = 0; }
          else if (gFast > 240 && gCur > gBase) { gCur = Math.max(gBase, gCur / 1.08); engine.setHardwareScalingLevel(gCur); gFast = 0; }
        }
        try { update(dt); errRun = 0; } catch (e) {
          if (errTotal++ < 5) { try { console.error(e); } catch (x) { /* ok */ } }                  // report the first few only: logging every frame would itself make the game lag
          if (++errRun === 180 && !errShown) { errShown = true; try { OYO.hud.toast = 'Something went wrong. If the game feels stuck, reload the page.'; } catch (x) { /* ok */ } }   // ~3 s of failing frames in a row
        }
        // Stage 9: while paused / on a result screen nothing moves, so redraw at ~1/4 rate (saves battery; still repaints after a resize)
        const frozen = OYO.mission && OYO.mission.paused;
        if (!frozen || (++idleF & 3) === 0) scene.render();
      });
      // Stage 9: leaving the app / tab auto-pauses a ride and silences the audio; coming back resumes only what was running
      document.addEventListener('visibilitychange', () => {
        const MS = OYO.mission, A = window.OYOAudio;
        if (document.hidden) {
          try { if (MS && MS.playing && OYO.hud.screen === 'play') MS.togglePause(); } catch (e) { /* ignore */ }
          try { A && A.suspend && A.suspend(); } catch (e) { /* ignore */ }
          OYO.core.releaseInput();
        } else {
          try { if (A && A.resume && !(MS && MS.paused)) A.resume(); } catch (e) { /* ignore */ }
          last = performance.now(); engine.resize();
        }
      });

      // Real readiness: the loading screen leaves only once every material/shader is compiled and the scene can draw
      BOOT.step(.98, 'Preparing the savanna…');
      let shown = false;
      const showGame = () => { if (shown) return; shown = true; hud.loading = false; BOOT.ready(); setTimeout(() => { hud.hint = false; }, 9000); };
      scene.executeWhenReady(showGame);
      setTimeout(showGame, 20000);                    // safety net for devices where readiness is never reported
    } catch (e) {
      fatal(e);
    }
  }

  // (Alpine / Babylon load failures are now reported by boot.js on the loading screen.)
})();
