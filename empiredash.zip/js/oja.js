/* EMPIRE DASH — oja.js · Ọjà Ìlú (the town market)
   Full-screen shop for cart paints (skins), the cart's name board, horse regalia (3 earned with cowries: 3k / 5k / 8k, plus the paid royal set) and fittings. Pure cosmetics: "no gameplay advantage, just style".
   PAINTS + NAME BOARD: bought items are kept in localStorage ('jagun-oja-own'); the cart reads what is worn through window.OYOCartPaint() when it is built.
   PAYWALL SWITCHED OFF FOR NOW: the paid paints, royal regalia, Agogo bell and the Paystack hook are commented out (search "PAYWALL" to bring them back). Only the Name Board remains:
   free as a LAUNCH BONUS for LAUNCH_DAYS days from 22 Nov 2026, then ₦1,000 through the admin chat (see LAUNCH below), and a player who paid gets a signed link  siteurl/?cart=TOLU&k=… from the admin (see PAID LINK at the bottom).
   (old) PAYSTACK HOOK: set  OYO.market.paystack = function (item, cur) { ... }  (return a Promise; resolve true when paid) — a paid item is granted automatically.
   Prices live in ONE place (ITEMS below): ngn = naira (what Paystack charges), usd = display only. To test without paying, run  OYO.market.grant('ebony')  in the console. */
(function () {
  'use strict';
  const OYO = window.OYO = window.OYO || {}, U = window.OYOUI && window.OYOUI.state;
  if (!U) return;
  const ITEMS = [
    // PAYWALL (hidden for now): { id: 'adire',   sec: 'orig', kind: 'skin',  paint: 'indigo', name: 'Adire Indigo',   yo: 'Kẹ̀kẹ́ Àdìrẹ',  ngn: 4000, usd: 3,   look: 'indigo', note: 'Indigo-dyed cloth roof and cowrie trim' }
    // PAYWALL (hidden for now): { id: 'ebony',   sec: 'orig', kind: 'skin',  paint: 'ebony',  name: 'Ebony Night',    yo: 'Kẹ̀kẹ́ Òru',    ngn: 4000, usd: 3,   look: 'ebony',  note: 'Black camwood with brass studs' }
    // PAYWALL (hidden for now): { id: 'oba',     sec: 'orig', kind: 'skin',  paint: 'gold',   name: 'Oba’s Gold',     yo: 'Kẹ̀kẹ́ Wúrà',   ngn: 8000, usd: 6,   look: 'gold',   note: 'Gilded rails and a crimson canopy', limited: 'Limited · only 500 ever made' }
    { id: 'board',   sec: 'more', kind: 'board', name: 'Your Name Board', yo: 'Àmì Orúkọ',    ngn: 1000, usd: 0.8, launch: true, icon: 'bi-tag-fill',   note: 'Your name painted on both sides and the tail of your cart' },
    { id: 'cow3k',   sec: 'reg',  kind: 'gear',  reg: true, name: 'Cloth Trappings',  yo: 'Ẹ̀ṣọ́ Aláṣọ', cow: 3000, icon: 'bi-award',      note: 'Red and cream cloth over shoulder and hip, a fringe of tassels and a brass brow disc' },
    { id: 'cow5k',   sec: 'reg',  kind: 'gear',  reg: true, name: 'Brass Trappings',  yo: 'Ẹ̀ṣọ́ Idẹ',   cow: 5000, icon: 'bi-award',      note: 'Teal and gold cloth, bright breast bells and a brass brow plate' },
    { id: 'cow8k',   sec: 'reg',  kind: 'gear',  reg: true, name: 'Warrior Trappings', yo: 'Ẹ̀ṣọ́ Jagun', cow: 8000, icon: 'bi-award-fill', note: 'Quilted indigo caparison, gilded face plate and a tall red plume' },
    // PAYWALL (hidden for now): { id: 'regalia', sec: 'reg',  kind: 'gear',  reg: true, name: 'Royal Horse Regalia', yo: 'Ẹ̀ṣọ́ Ẹṣin Ọba', ngn: 5000, usd: 4, icon: 'bi-gem', note: 'Crimson and gold embroidered caparison, horned gilded frontlet, plume, cowrie collar and tail band' }
    // PAYWALL (hidden for now): { id: 'agogo',   sec: 'more', kind: 'gear',  name: 'Agogo Bell',      yo: 'Agogo Ẹṣin',   ngn: 1000, usd: 0.8, icon: 'bi-bell-fill',  note: 'A bright iron bell that rings as the horse gallops' }
  ];
  // PAYWALL (hidden for now): const BAG = [['Adire Indigo paint', 'orig'], ['Agogo Bell', 'more'], ['a pile of cowries', 'more'], ['Horse Regalia', 'more']];
  const BAG = [['a pile of cowries', 'more']];
  const NOW = () => { try { return window.OYOStore.now(); } catch (e) { return Date.now(); } };      // server time when available
  const OWN = 'jagun-oja-own', OSE_KEY = 'jagun-ose-preview', ST = window.OYOStore;
  const clean = s => String(s || '').replace(/[^\p{L}\p{M}\p{N} '’.\-]/gu, '').replace(/\s+/g, ' ').trim().slice(0, 14);
  let own = { owned: {}, paint: '', board: false, name: '', regalia: '' };
  /* What a player owns is stored SIGNED (secure-store.js): a hand-edited entry is thrown away. Only known item ids are ever accepted. */
  const KNOWN = ['board', 'cow3k', 'cow5k', 'cow8k', 'adire', 'ebony', 'oba', 'regalia', 'agogo'], PAINTS = ['', 'indigo', 'ebony', 'gold'];
  (function loadOwn() {
    let r; try { r = ST ? ST.read(OWN) : { obj: null, state: 'none' }; } catch (e) { r = { obj: null, state: 'none' }; }
    const o = r.state === 'ok' || (r.state === 'legacy' && (!ST || ST.legacyOk())) ? r.obj : null;
    if (!o) return;
    if (o.owned && typeof o.owned === 'object') KNOWN.forEach(id => { if (o.owned[id] === true) own.owned[id] = true; });
    if (typeof o.paint === 'string' && PAINTS.includes(o.paint)) own.paint = o.paint;
    own.board = !!o.board && !!own.owned.board; own.name = clean(o.name);
    if (typeof o.regalia === 'string') own.regalia = o.regalia;
  })();
  own.name = clean(own.name); if (own.regalia && !own.owned[own.regalia]) own.regalia = ''; if (own.board && !own.owned.board) own.board = false;
  const saveOwn = () => { if (ST) ST.write(OWN, own); else { try { localStorage.setItem(OWN, JSON.stringify(own)); } catch (e) { /* storage optional */ } } };
  window.OYOCartPaint = () => ({ paint: own.paint || '', name: own.board && own.name ? own.name : '' });    // cart.js asks what is worn
  window.OYOHorseRegalia = () => own.regalia || '';                                           // horse.js / riding.js ask which regalia is worn
  let opened = false, timer = 0, rideTimer = 0;   // separate timers: the item-sheet stage must never cancel the paint-preview start
  const M = OYO.market = { items: ITEMS };      // PAYWALL (hidden for now): paystack: null

  Object.assign(U, { ojaCur: 'ngn', ojaSel: null, ojaMsg: '', ojaBagTxt: '', ojaBagReady: false, ojaItems: ITEMS, ojaBusy: false, ojaLaunch: 'before', ojaLaunchTxt: '',
    ojaReg: own.regalia, ojaOwn: Object.assign({}, own.owned), ojaPaint: own.paint, ojaBoardOn: !!own.board, ojaName: own.name });
  const hud = () => OYO.hud || U;
  const sync = () => { const h = hud(); h.ojaOwn = Object.assign({}, own.owned); h.ojaReg = own.regalia; h.ojaPaint = own.paint; h.ojaBoardOn = !!own.board; };
  const refresh = () => { try { OYO.endless.carts.refresh(); } catch (e) { /* cart not built yet */ } };
  const toast = t => { const h = hud(); h.ojaMsg = t; setTimeout(() => { if (h.ojaMsg === t) h.ojaMsg = ''; }, 4200); };

  function tickBag() {
    let left = 0; try { left = OYO.endless.bagLeft(); } catch (e) { left = 0; }
    const h = hud();
    h.ojaBagReady = left <= 0;
    h.ojaBagTxt = left <= 0 ? 'Open today’s bag' : 'New bag in ' + Math.floor(left / 3600000) + 'h ' + String(Math.floor(left % 3600000 / 60000)).padStart(2, '0') + 'm';
  }
  M.openBag = function () {
    const E = OYO.endless; if (!E || !E.openBag) return;             // the cowrie purse is not ready: keep the bag closed instead of wasting it
    let amt = 0; try { amt = E.openBag(); } catch (e) { amt = 0; }
    if (!amt) { tickBag(); return; }                                 // still closed (6-hour timer lives in the signed save)
    toast('Your bag holds ' + amt.toLocaleString('en-US') + ' cowries! They are in your cowries balance now.'); tickBag();
  };

  /* ---------- LAUNCH BONUS: the Name Board is free for LAUNCH_DAYS days from 22 Nov 2026 (00:00 Nigerian time), then it costs ₦1,000 and is bought through the admin chat ----------
     Test any phase with  ?launch=live  /  ?launch=before  /  ?launch=ended  in the address. */
  const LAUNCH_START = Date.UTC(2026, 10, 21, 23, 0, 0), LAUNCH_DAYS = 5, LAUNCH_END = LAUNCH_START + LAUNCH_DAYS * 864e5, LAUNCH_LAST = '26 Nov';
  const ADMIN_DM = 'https://wa.me/2348087774012';      // ← PASTE the admin's WhatsApp number here (wa.me/<country code + number>, digits only). The name typed by the player is added to the message.
  const LOCAL = (() => { try { return /^(localhost|127\.0\.0\.1|\[::1\]|)$/.test(location.hostname); } catch (e) { return false; } })();      // the ?launch= test switch only works on your own computer, never on the live site
  const launchPhase = () => { if (LOCAL) { try { const m = /[?&]launch=(live|before|ended)/.exec(location.search); if (m) return m[1]; } catch (e) { /* no location */ } } const t = NOW(); return t < LAUNCH_START ? 'before' : t < LAUNCH_END ? 'live' : 'ended'; };
  function launchTick() {
    const h = hud(), ph = launchPhase(); h.ojaLaunch = ph;
    if (ph === 'live') { const left = Math.max(0, LAUNCH_END - NOW()), d = Math.floor(left / 864e5), hr = Math.floor(left % 864e5 / 36e5); h.ojaLaunchTxt = 'Free until ' + LAUNCH_LAST + ' · ' + (d ? d + 'd ' : '') + hr + 'h left'; }
    else if (ph === 'before') h.ojaLaunchTxt = 'Opens 22 Nov'; else h.ojaLaunchTxt = '';
  }
  M.claim = function () {                                           // Launch Bonus: the free name board
    const h = hud(); if (launchPhase() !== 'live') { launchTick(); return; }
    const n = clean(h.ojaName); if (!n) { toast('Type the name for your board first.'); return; }
    grant('board'); toast('🎁 Launch Bonus! “' + n + '” is painted on your cart.'); h.ojaSel = null;
  };
  M.chat = function () {                                            // after launch week: "Chat us" opens the admin DM with the payment message ready
    const h = hud(), n = clean(h.ojaName), msg = 'Hello! I want my name on my Empire Dash cart (₦1,000 name board). My name: ' + (n || '____') + '. Please send me the payment details.';
    if (/X{6,}/.test(ADMIN_DM)) { toast('The admin chat link is not set up yet.'); return; }
    try { window.open(ADMIN_DM + '?text=' + encodeURIComponent(msg), '_blank', 'noopener'); } catch (e) { location.href = ADMIN_DM + '?text=' + encodeURIComponent(msg); }
  };
  M.open = function () { const h = hud(); try { OYO.mission.modal('oja'); } catch (e) { h.modal = 'oja'; } h.ojaSel = null; h.ojaMsg = ''; h.ojaName = own.name; tickBag(); launchTick(); };
  M.pick = function (it) { const h = hud(); h.ojaSel = it; h.ojaMsg = ''; if (it.kind === 'board') h.ojaName = own.name; };
  const grant = function (id) {                                         // a paid (or test) purchase: the item is yours forever; skins are worn straight away
    const it = ITEMS.find(i => i.id === id); if (!it) return false;
    own.owned[id] = true;
    if (it.kind === 'skin') own.paint = it.paint;
    if (it.reg) own.regalia = id;
    if (it.kind === 'board') { own.board = true; const n = clean(hud().ojaName); if (n) own.name = n; }
    saveOwn(); sync(); refresh(); return true;
  };
  const byId = it => (it && typeof it.id === 'string') ? ITEMS.find(i => i.id === it.id) : null;      // never trust the object a caller passes in: price, paint and kind come from ITEMS
  M.wear = function (it) {                                          // owned skin: put on / take off
    it = byId(it); if (!it || it.kind !== 'skin' || !own.owned[it.id]) return; own.paint = own.paint === it.paint ? '' : it.paint; saveOwn(); sync(); refresh();
    toast(own.paint ? it.name + ' is on your cart.' : 'Back to the plain wood.'); hud().ojaSel = null;
  };
  M.wearReg = function (it) {                                       // owned regalia: put on / take off the horse
    it = byId(it); if (!it || !it.reg || !own.owned[it.id]) return; own.regalia = own.regalia === it.id ? '' : it.id; saveOwn(); sync(); refresh();
    toast(own.regalia ? it.name + ' is on your horse.' : 'Your horse is back in plain tack.'); hud().ojaSel = null;
  };
  M.buyCow = function (it) {                                        // regalia bought with cowries earned on the road
    const h = hud(); it = byId(it); if (!it || !it.cow || own.owned[it.id]) return;
    let ok = false; try { ok = OYO.endless.spendCowries(it.cow); } catch (e) { ok = false; }
    if (!ok) { toast('Not enough cowries yet — ' + it.name + ' costs ' + it.cow.toLocaleString('en-US') + ' 🐚.'); return; }
    grant(it.id); toast(it.name + ' is yours forever!'); h.ojaSel = null;
  };
  M.saveName = function () {                                        // owned name board: carve a new name (or switch it on/off)
    const h = hud(), n = clean(h.ojaName); if (!n) { toast('Type the name for your board first.'); return; }
    if (!own.owned.board) return;                                   // only a board you own (Launch Bonus or paid link) can be carved
    own.name = n; own.board = true; h.ojaName = n; saveOwn(); sync(); refresh(); toast('“' + n + '” is painted on your cart.'); h.ojaSel = null;
  };
  M.boardOff = function () { if (!own.owned.board) return; own.board = false; saveOwn(); sync(); refresh(); toast('Name board taken down.'); hud().ojaSel = null; };
  // PAYWALL (hidden for now): M.pay = function () {
  // PAYWALL (hidden for now): const h = hud(), it = h.ojaSel; if (!it || h.ojaBusy) return;
  // PAYWALL (hidden for now): if (it.cow) { M.buyCow(it); return; }
  // PAYWALL (hidden for now): if (it.kind === 'board' && !clean(h.ojaName)) { toast('Type the name for your board first.'); return; }
  // PAYWALL (hidden for now): if (typeof M.paystack !== 'function') { toast('Payments open soon — ' + it.name + ' will be waiting in the market.'); h.ojaSel = null; return; }
  // PAYWALL (hidden for now): h.ojaBusy = true;
  // PAYWALL (hidden for now): Promise.resolve(M.paystack(it, h.ojaCur)).then(ok => { h.ojaBusy = false; if (ok) { M.grant(it.id); toast(it.name + ' is yours forever!'); h.ojaSel = null; } }).catch(() => { h.ojaBusy = false; toast('Payment did not go through. Try again.'); });
  // PAYWALL (hidden for now): };
  M.pay = function () {                                             // no real-money payments in the game: cowrie items only; the name board is the Launch Bonus / admin chat
    const h = hud(), it = h.ojaSel; if (!it) return;
    if (it.cow) { M.buyCow(it); return; }
    if (it.kind === 'board') { if (launchPhase() === 'live') M.claim(); else if (launchPhase() === 'ended') M.chat(); }
  };
  M.stage = function (c, sel, name) {                               // live 3D look at the paint / name board inside the item sheet (debounced)
    clearTimeout(timer);
    if (!sel || !(sel.kind === 'board' || sel.reg) || !c) { if (opened && window.OYOCartView) { OYOCartView.close(); opened = false; } return; }
    timer = setTimeout(() => {
      if (!window.OYOCartView) return; opened = true;
      OYOCartView.open(c, 'royal', { paint: own.paint, name: sel.kind === 'board' ? (clean(name) || 'YOUR NAME') : (own.board ? own.name : ''), regalia: sel.reg ? sel.id : own.regalia });
    }, 220);
  };
  M.skins = () => ITEMS.filter(i => i.kind === 'skin');
  M.step = function (d) {                                           // preview screen: previous / next paint
    const h = hud(), L = M.skins(), i = L.findIndex(s => h.ojaSel && s.id === h.ojaSel.id); if (i < 0) return;
    h.ojaSel = L[(i + d + L.length) % L.length]; h.ojaMsg = '';
  };
  M.ride = function (c, sel) {                                      // preview screen: the paint on a cart that is rolling along the road
    clearTimeout(rideTimer);
    if (!sel || sel.kind !== 'skin' || !c) { if (window.OYOCartView && OYOCartView.stopRide) OYOCartView.stopRide(); return; }
    rideTimer = setTimeout(() => { if (window.OYOCartView && OYOCartView.ride) OYOCartView.ride(c, { paint: sel.paint, name: own.board ? own.name : '' }); }, 120);
  };
  setInterval(() => { const h = OYO.hud; if (h && h.modal === 'oja') { tickBag(); launchTick(); } }, 30000);
  launchTick();

  /* ---------- PAID LINK: siteurl/?cart=TOLU&k=<signature>  → the name board is switched on with that name and the game starts straight in the Endless Run ----------
     The signature is made by the admin with the PRIVATE key (admin-cart-link-generator.html, never uploaded to the site). The game only holds the PUBLIC key below,
     so nobody can invent a working link for a name: a link without a valid signature does nothing. (?cart=0 still hides the cart, as before.) */
  const LINK_KEY = {"kty":"EC","crv":"P-256","x":"_H2X0jNFio8GAdcxexVyLFtAWHQ2HS3OmvIOCWB5a6A","y":"2RatVkUymIxQp6BebXEUAxVPmV81YIb-cuZ2KWV5HpY"};
  const b64u = t => { t = t.replace(/-/g, '+').replace(/_/g, '/'); while (t.length % 4) t += '='; const bin = atob(t), a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return a; };
  const stripParams = names => {                                   // remove private parameters from the address bar once they are used, so a screenshot / share / copy of the address cannot leak them
    try { const u = new URL(location.href); let ch = false; names.forEach(n => { if (u.searchParams.has(n)) { u.searchParams.delete(n); ch = true; } }); if (ch && history.replaceState) history.replaceState(null, '', u.pathname + (u.search || '') + u.hash); } catch (e) { /* ok */ }
  };
  async function linkOk(name, sig) {
    try {
      const sub = window.crypto && window.crypto.subtle; if (!sub || !sig) return false;                         // no WebCrypto (not https) → fail closed
      const key = await sub.importKey('jwk', LINK_KEY, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
      return await sub.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, b64u(sig), new TextEncoder().encode('jagun-cart:' + name));
    } catch (e) { return false; }
  }
  (async function cartLink() {
    let nm = '', sig = ''; try { const q = location.search, m = /[?&]cart=([^&#]*)/.exec(q), k = /[?&]k=([^&#]*)/.exec(q); if (m) nm = clean(decodeURIComponent(m[1].replace(/\+/g, ' '))); if (k) sig = k[1]; } catch (e) { /* bad escape */ }
    if (!nm || nm === '0') return;
    let good = sig.length < 200 && await linkOk(nm, sig); stripParams(['cart', 'k']);
    let used = false;
    if (good) {                                                       // the server limits one paid link to 3 devices, so a forwarded link stops working; if the server cannot be reached the link is let through
      try { const r = await fetch('api/redeem', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: nm, sig, dev: ST ? ST.device() : '' }) }); if (r.status === 409 || r.status === 403) { good = false; used = r.status === 409; } } catch (e) { /* offline / no server: let it through */ }
    }
    if (!good) { const t = used ? 'This cart link is already in use on other devices. Chat us if it is yours.' : 'That cart link is not valid. Chat us to get your name on the cart.'; const h = hud(); h.toast = t; toast(t); setTimeout(() => { if (h.toast === t) h.toast = ''; }, 6000); return; }
    own.owned.board = true; own.board = true; own.name = nm; saveOwn(); sync(); U.ojaName = nm;
    let tries = 0; const iv = setInterval(() => {
      const B = window.OYOBoot, c = OYO.core && OYO.core.S;
      if ((!B || B.isReady) && c && c.riding && c.riding.built && c.cart && OYO.endless && OYO.endless.start) { clearInterval(iv); setTimeout(() => { refresh(); try { OYO.endless.start(); } catch (e) { console.warn('Cart link start', e); } }, 700); }
      else if (++tries > 480) clearInterval(iv);
    }, 250);
  })();

  /* ---------- ADMIN PREVIEW of Ose Ṣàngó + rude riders (hidden from players until 29 Nov 2026): siteurl/?ose=<signature> switches them on for THIS device; ?ose=off switches them off again.
     The signature is made with the admin's private key (admin-cart-link-generator.html), so players cannot unlock it early. */
  let oseOk = false;
  try { Object.defineProperty(window, 'OYOOseOk', { get: () => oseOk, configurable: false }); } catch (e) { /* ok */ }      // read-only: the console cannot just switch it on
  (async function osePreview() {
    let v = ''; try { const m = /[?&]ose=([^&#]*)/.exec(location.search); if (m) v = m[1]; } catch (e) { /* no location */ }
    try {
      if (v === 'off') localStorage.removeItem(OSE_KEY);
      else if (v && v.length < 200 && await linkOk('@admin-ose', v)) localStorage.setItem(OSE_KEY, v);        // the SIGNATURE is kept, not a bare "1"
      const kept = localStorage.getItem(OSE_KEY);
      if (kept) { if (kept.length < 200 && await linkOk('@admin-ose', kept)) oseOk = true; else localStorage.removeItem(OSE_KEY); }
    } catch (e) { /* storage optional */ }
    if (v) stripParams(['ose']);
  })();
})();
