/* EMPIRE DASH — oyo-royal.js  (Stage 14: royal landmarks of Old Oyo / Oyo-Ile, c. 1650)
   Adds to the Aláàfin's palace that palace.js already raises (walls, gatehouse, courtyards, throne pavilion, halls — all left as they are):
   • the ROYAL FOREWORKS in front of the great gate: a processional avenue of painted standards (pennant poles), a mariwo (palm-frond) ceremonial
     gateway at the mouth of the forecourt, state canopies flanking the gate, a drummers' shelter with hourglass talking drums, and a Ṣàngó shrine
   • ROYAL GUARDS and PALACE ATTENDANTS (existing villager archetypes: spear guards, courtiers, women attendants) at the gates, along the avenue,
     by the canopies, drum shelter and shrine — a few standing, a few on patrol — via the OYOPalaceCrew hook that villagers.js calls
   • (buildings.js, same stage) the ROYAL QUARTER: a ring of ordinary Yoruba compounds grown along the palace's approach road
   HISTORICAL NOTE: this is a historically INSPIRED, stylised impression, not a reconstruction. Old Oyo's palace is known to history mainly through
   later accounts and archaeology of the city walls; we do NOT claim exact layouts, dimensions or decoration. The Yoruba traditions used here
   (Ṣàngó as the royal-lineage deity, palm-frond mariwo marking sacred places, royal drumming, state canopies/standards, cloth and chalk) are
   general and well attested; their exact arrangement here is invented for play. Everything is flat-shaded vertex-coloured triangles merged into
   the oyo-world.js meshes (no extra draw calls, ~3k triangles), decoration only: no collision, no gameplay change.
   Self-contained. To remove: delete this file, its boot.js / sw.js entries, and the small hooks in oyo-world.js, villagers.js, buildings.js. */
(function () {
  'use strict';
  const TAU = Math.PI * 2, PI = Math.PI;
  const RED = [.72, .13, .1], INDIGO = [.14, .2, .5], OCHRE = [.85, .6, .16], CREAM = [.93, .9, .8], WOOD = [.36, .24, .13], THATCH = [.72, .56, .28], THATCHD = [.55, .42, .2], SKIN = [.88, .8, .62];

  function build(X) {
    const { World, bk, frame, tri, quad, jit, rr, rnd, sangoShrine, mariwoGate, H, stats } = X, PA = window.OYOPalace && OYOPalace.site;
    if (!PA || !PA.G || !PA.built) return;
    const fx = Math.sin(PA.yaw), fz = Math.cos(PA.yaw), gd = PA.road ? PA.road.d : 40, len = Math.max(16, Math.min(62, gd + 4)), reach = Math.max(10, Math.min(len, gd - 7));
    const at = (f, l) => [PA.G[0] + fx * f + Math.cos(PA.yaw) * l, PA.G[1] + fz * f - Math.sin(PA.yaw) * l];
    const offRoad = (p) => { const q = World.queryRoad(p[0], p[1]); return !q || q.d - q.hw > 2.5; };
    const G = (p) => bk(p[0], p[1]);
    let n0 = 0; const count = () => { n0++; };

    // standards: tall painted pennant poles (red / indigo / ochre / white) with a chalk-stone base
    function standard(p, yaw, c1, c2, dir) {
      const F = frame(p[0], p[1], yaw), y0 = H(p[0], p[1]), P = (lx, ly, lz) => { const q = F(lx, lz || 0); return [q[0], y0 + ly, q[1]]; }, g = G(p), h = 4.6;
      quad(g, P(-.06, h, 0), P(.06, h, 0), P(.08, 0, 0), P(-.08, 0, 0), WOOD); quad(g, P(0, h, -.06), P(0, h, .06), P(0, 0, .08), P(0, 0, -.08), WOOD);
      tri(g, P(-.1, h + .45, 0), P(.1, h + .45, 0), P(0, h + .85, 0), OCHRE, OCHRE, [1, .85, .4]);                       // finial
      const w = 1.5 * dir; tri(g, P(0, h, 0), P(w, h - .2, 0), P(0, h - .6, 0), c1, c1, c1); tri(g, P(0, h - .6, 0), P(w, h - .2, 0), P(w * .8, h - .78, 0), c2, c1, c2);    // two-band swallow-tail pennant
      tri(g, P(0, h - .6, 0), P(w * .8, h - .78, 0), P(0, h - 1.2, 0), c2, c2, c2); tri(g, P(0, h - 1.2, 0), P(w * .8, h - .78, 0), P(w * .45, h - 1.35, 0), c2, c2, c1);
      for (let a = 0; a < 4; a++) { const an = a * TAU / 4 + .4, r = .26, t = jit(CREAM, .06), b1 = P(Math.cos(an) * r, 0, Math.sin(an) * r), b2 = P(Math.cos(an + 1.5) * r, 0, Math.sin(an + 1.5) * r); tri(g, b1, b2, P(0, .3, 0), t); }
      count();
    }
    // state canopy (parasol of state): painted wedge canopy on a pole, with a gold fringe
    function canopy(p, yaw, col) {
      const F = frame(p[0], p[1], yaw), y0 = H(p[0], p[1]), P = (lx, ly, lz) => { const q = F(lx, lz); return [q[0], y0 + ly, q[1]]; }, g = G(p), R = 1.9, N = 8, top = P(0, 3.35, 0);
      quad(g, P(-.05, 2.9, 0), P(.05, 2.9, 0), P(.07, 0, 0), P(-.07, 0, 0), WOOD); quad(g, P(0, 2.9, -.05), P(0, 2.9, .05), P(0, 0, .07), P(0, 0, -.07), WOOD);
      for (let a = 0; a < N; a++) { const a0 = a * TAU / N, a1 = (a + 1) * TAU / N, c = a & 1 ? col : CREAM, p0 = P(Math.cos(a0) * R, 2.75, Math.sin(a0) * R), p1 = P(Math.cos(a1) * R, 2.75, Math.sin(a1) * R);
        tri(g, p0, p1, top, jit(c, .06), jit(c, .06), jit(c, .04));
        const m0 = P(Math.cos(a0) * R, 2.75, Math.sin(a0) * R), m1 = P(Math.cos(a1) * R, 2.75, Math.sin(a1) * R); tri(g, m0, m1, P(Math.cos((a0 + a1) / 2) * R * 1.02, 2.4, Math.sin((a0 + a1) / 2) * R * 1.02), OCHRE, OCHRE, [1, .8, .35]); }
      tri(g, P(-.14, 3.35, 0), P(.14, 3.35, 0), P(0, 3.75, 0), OCHRE, OCHRE, [1, .85, .4]); count();
    }
    // drummers' shelter: four posts, thatched cone, hourglass talking drums on a low platform
    function drumShelter(p, yaw) {
      const F = frame(p[0], p[1], yaw), y0 = H(p[0], p[1]), P = (lx, ly, lz) => { const q = F(lx, lz); return [q[0], y0 + ly, q[1]]; }, g = G(p), R = 2.5;
      quad(g, P(-1.9, .18, -1.9), P(1.9, .18, -1.9), P(1.9, .18, 1.9), P(-1.9, .18, 1.9), jit(WOOD, .1));
      for (const [a, b] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) { quad(g, P(a * 1.7 - .06, 2.1, b * 1.7), P(a * 1.7 + .06, 2.1, b * 1.7), P(a * 1.7 + .07, .18, b * 1.7), P(a * 1.7 - .07, .18, b * 1.7), WOOD); quad(g, P(a * 1.7, 2.1, b * 1.7 - .06), P(a * 1.7, 2.1, b * 1.7 + .06), P(a * 1.7, .18, b * 1.7 + .07), P(a * 1.7, .18, b * 1.7 - .07), WOOD); }
      const ring = []; for (let a = 0; a < 8; a++) ring.push(P(Math.cos(a * TAU / 8) * R, 2.05, Math.sin(a * TAU / 8) * R)); const apex = P(0, 3.35, 0);
      for (let a = 0; a < 8; a++) tri(g, ring[a], ring[(a + 1) % 8], apex, jit(THATCHD, .1), jit(THATCHD, .1), jit(THATCH, .08));
      [[-.7, -.2, .75], [.1, .5, .62], [.8, -.4, .7]].forEach(([x, z, h]) => {            // hourglass drums (two cones joined at the waist) with skin heads and a camwood band
        const rB = .3, rW = .1, y1 = .18, n = 6, top = [], mid = [], bot = [];
        for (let a = 0; a < n; a++) { const an = a * TAU / n; top.push(P(x + Math.cos(an) * rB, y1 + h, z + Math.sin(an) * rB)); mid.push(P(x + Math.cos(an) * rW, y1 + h / 2, z + Math.sin(an) * rW)); bot.push(P(x + Math.cos(an) * rB, y1, z + Math.sin(an) * rB)); }
        for (let a = 0; a < n; a++) { const b = (a + 1) % n; quad(g, top[a], top[b], mid[b], mid[a], jit(WOOD, .1), RED); quad(g, mid[a], mid[b], bot[b], bot[a], RED, jit(WOOD, .1)); tri(g, top[a], top[b], P(x, y1 + h + .03, z), SKIN); }
      }); count();
    }

    // ---- lay them out in the palace's own frame: +f = outward from the great gate toward the approach road, l = lateral
    const lat = 10.5;
    for (let f = 3, k = 0; f <= reach; f += 6.5, k++) for (const s of [-1, 1]) { const p = at(f, s * lat); if (!offRoad(p)) continue; const a = (k + (s > 0 ? 1 : 0)) % 3; standard(p, PA.yaw, [RED, INDIGO, OCHRE][a], [CREAM, CREAM, RED][a], -s); }
    const mouth = at(reach + 1.5, 0); if (offRoad(at(reach + 1.5, lat)) && offRoad(at(reach + 1.5, -lat))) { mariwoGate(bk(mouth[0], mouth[1]), mouth[0], mouth[1], Math.atan2(-fx, -fz), lat * 2); stats.royal = (stats.royal || 0) + 1; }
    for (const s of [-1, 1]) { const p = at(3.2, s * 8.6); if (offRoad(p)) canopy(p, PA.yaw, s < 0 ? RED : INDIGO); }
    const ds = at(7.5, -17.5); if (offRoad(ds)) drumShelter(ds, PA.yaw);
    const sh = at(7.5, 17.5); if (offRoad(sh)) { sangoShrine(G(sh), sh[0], sh[1], PA.yaw); n0++; }
    stats.royal = (stats.royal || 0) + n0;
  }

  /* palace guards & attendants — called by villagers.js popPalace() with its own helpers (Stage 15: royal dress archetypes) */
  function crew(A) {
    const P = A.P, { at, addP, walker, link, ok } = A, gd = P.road ? P.road.d : 40, len = Math.max(16, Math.min(62, gd + 4)), reach = Math.max(12, Math.min(len, gd - 7));
    const put = (id, f, l, yaw, st) => { const p = at(f, l); return ok(p) ? addP(id, p[0], p[1], yaw, st) : null; };
    const IN = P.yaw + PI;
    put('guard', -4.6, -4.4, P.yaw, 0); put('guard', -4.6, 4.4, P.yaw, 0);                    // inside the great gate
    put('guard', 2, -11.5, P.yaw, 0); put('guard', 2, 11.5, P.yaw, 0);                         // head of the avenue
    for (const s of [-1, 1]) { const a = at(5, s * 7), b = at(reach - 3, s * 7); if (ok(a) && ok(b)) { const p = addP('guard', a[0], a[1], P.yaw, 1); p.w = walker([a, b], .9, 1, 0, {}); } }   // two patrols
    put('attM', 1.8, -6.3, IN, 0); put('attM', 1.8, 6.3, IN, 0);                                 // attendants by the state canopies
    link(put('elder', 6.2, -15.2, P.yaw - 1.2, 2), put('chfB', 7.4, -14.7, P.yaw + 1.9, 0), 'chat');   // by the drummers' shelter
    link(put('wAtt', 6.0, 15.3, P.yaw + 1.3, 0), put('wAtt', 7.2, 15.8, P.yaw - 1.4, 2), 'chat');         // women attendants by the shrine
    const c0 = at(10, 2), c1 = at(reach - 4, -2); if (ok(c0) && ok(c1)) { const p = addP('elder', c0[0], c0[1], P.yaw, 1); p.w = walker([c0, c1], .8, 1, 2, {}); }   // a courtier walking the avenue
  }
  window.OYORoyal = { build }; window.OYOPalaceCrew = crew;
})();
