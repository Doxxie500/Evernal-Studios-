/* Test hosts (Spck preview, localhost, plain http, IP addresses): never run the service worker there. A worker left over from an earlier test can answer
   game-file requests with an error ("Could not load secure-store.js"). Remove any, then reload once. */
(function () {
  var h = location.hostname, dev = location.protocol !== 'https:' || /^(localhost|127\.|10\.|192\.168\.|\d+\.\d+\.\d+\.\d+$)|spck/i.test(h);
  window.OYODevHost = dev; if (!dev || !navigator.serviceWorker) return;
  var had = !!navigator.serviceWorker.controller;
  navigator.serviceWorker.getRegistrations().then(function (rs) {
    rs.forEach(function (r) { r.unregister(); });
    var jobs = window.caches && caches.keys ? caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return /^jagun-/.test(k); }).map(function (k) { return caches.delete(k); })); }) : Promise.resolve();
    jobs.then(function () { if ((had || rs.length) && !sessionStorage.getItem('jagun-dev-clean')) { sessionStorage.setItem('jagun-dev-clean', '1'); location.reload(); } });
  }).catch(function () {});
})();
/* EMPIRE DASH — pwa.js
   Service-worker registration and the "Install" button. The service worker (sw.js) only works on https:// (or http://localhost);
   everywhere else the game simply runs as a normal web page. */
(function () {
  'use strict';
  var P = window.OYOPWA = { deferred: null, registered: false };

  P.isStandalone = function () {
    try { return (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true; } catch (e) { return false; }
  };
  P.can = function () { return !!P.deferred && !P.isStandalone(); };
  P.sync = function () { try { if (window.OYO && OYO.hud) OYO.hud.pwaCan = P.can(); } catch (e) { /* ignore */ } };

  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); P.deferred = e; P.sync(); });   // keep the event: the Install button uses it
  window.addEventListener('appinstalled', function () { P.deferred = null; P.sync(); });

  P.install = function () {
    var d = P.deferred; if (!d) return;
    P.deferred = null; P.sync();
    try { d.prompt(); if (d.userChoice && d.userChoice.then) d.userChoice.then(function () { P.sync(); }); } catch (e) { /* ignore */ }
  };

  /* Troubleshooting without dev-tools (e.g. in Spck): open the game once with ?reset in the address to remove the service worker and
     its saved files; the page then reloads normally and re-installs everything fresh. */
  P.reset = function () {
    var unreg = Promise.resolve();
    try { if (navigator.serviceWorker) unreg = navigator.serviceWorker.getRegistrations().then(function (rs) { return Promise.all(rs.map(function (r) { return r.unregister(); })); }); } catch (e) { /* ignore */ }
    return unreg.then(function () {                                  // caches last, so a still-running worker cannot re-create them
      if (!window.caches) return;
      return caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return (k.indexOf('jagun-royal-messenger') === 0 || k.indexOf('jagun-transporter') === 0); }).map(function (k) { return caches.delete(k); })); });
    });
  };

  var resetting = /[?&]reset(=|&|$)/.test(location.search);
  if (resetting) {
    P.reset().then(function () { location.replace(location.pathname + location.search.replace(/([?&])reset(=[^&]*)?(&|$)/, '$1').replace(/[?&]$/, '') + location.hash); });
  }

  P.register = function () {
    if (resetting || window.OYODevHost || P.registered || !('serviceWorker' in navigator) || !window.isSecureContext) return;
    P.registered = true;
    try {
      navigator.serviceWorker.register('sw.js').then(function (reg) {
        try { reg.update(); } catch (e) { /* ignore */ }                    // look for a newer service worker on every launch
      }, function (err) { console.warn('Offline mode unavailable:', err && err.message || err); });
    } catch (e) { /* ignore */ }
  };
})();

/* Fonts that never go missing: once online, force every face the UI uses to download (so the service worker saves it), and ask the worker to re-save the font set. */
(function () {
  function warm() {
    try {
      if (document.fonts && document.fonts.load) ['600 1em "Baloo 2"', '700 1em "Baloo 2"', '800 1em "Baloo 2"', '700 1em Nunito', '800 1em Nunito', '700 1em Fraunces', '900 1em Fraunces'].forEach(function (f) { document.fonts.load(f, 'Jagun Ọ̀yọ́ ẹ ṣ').catch(function () {}); });
      if (navigator.serviceWorker && navigator.serviceWorker.controller) navigator.serviceWorker.controller.postMessage('save-fonts');
    } catch (e) { /* optional */ }
  }
  window.addEventListener('load', function () { setTimeout(warm, 1500); });
  window.addEventListener('online', warm);
})();
