/* EMPIRE DASH — Stage 7 · rideanim.js
   Animation brain for horse + rider (pure JS, unit-testable).
   - Gait engine: idle / walk / trot / gallop, cross-faded by speed, foot-path driven with analytic limb IK (feet stay planted)
   - Body motion (heave, pitch, roll, spine flex, neck, head, ears, tail), turning lean
   - Rider: seated, absorbs motion, hands IK-attached to the reins; secondary motion for mane / tail / cloth is applied per vertex */
(function (root) {
  'use strict';
  const R = root.OYORig || require('./rig.js'), H = root.OYOHorse || require('./horse.js'), M = root.OYOMessenger || require('./messenger.js');
  const { mMul, mApply, mApplyDir, mInvRigid, boneM, pitchAt, frameM, circ, mIdent, clamp, lerp, smooth, sub, add, mul, norm, cross, dot, len, PI, TAU } = R;
  const HB = H.B, RB = M.B, NBH = H.NB, NBR = M.NB, NB = NBH + NBR;
  const sin = Math.sin, cos = Math.cos;

  /* ---------------- gait tables ---------------- */
  const GAITS = {
    walk:   { beta: .62, off: [.25, .75, 0, .5], lift: [.09, .09], cap: .8, f: v => .9 + .12 * clamp(v, .35, 3.4), vmin: .35, vmax: 3.4 },
    trot:   { beta: .44, off: [0, .5, .5, 0], lift: [.15, .13], cap: .85, f: v => 1.9 + .1 * (clamp(v, 2.5, 8) - 3), vmin: 2.5, vmax: 8 },
    gallop: { beta: .28, off: [.5, .36, .13, 0], lift: [.21, .17], cap: 1.05, f: v => 2.0 + .06 * (clamp(v, 6, 13) - 7), vmin: 6, vmax: 13 }
  };                                   // leg order: FL, FR, HL, HR
  const LEGS = [['FL', 'front', -1], ['FR', 'front', 1], ['HL', 'hind', -1], ['HR', 'hind', 1]];

  function footPath(u, g, travel, lift, front) {      // → [dz, lift, hoofAngle]
    u -= Math.floor(u); const b = g.beta;
    if (u < b) {
      const s = u / b, toe = s > .82 ? Math.pow((s - .82) / .18, 2) : 0;
      return [lerp(travel / 2, -travel / 2, s), toe * .035, -toe * (front ? .25 : -.15)];
    }
    const s = (u - b) / (1 - b), e = s - sin(TAU * s) / TAU, arc = sin(PI * Math.pow(s, .8));
    return [lerp(-travel / 2, travel / 2, e), lift * arc, (front ? -.85 : .55) * Math.pow(sin(PI * s), 1.2) * (1 - smooth(.8, 1, s))];
  }

  function ang(a, b) { return Math.atan2(b[1] - a[1], b[0] - a[0]); }   // vectors given as [y,z] -> atan2(z - ..) done manually below
  const th = (a, b) => Math.atan2(b[1] - a[1], b[0] - a[0]);          // angle of segment a→b with x := y, y := z

  /* solve one limb in the body-bone frame.  Gl = desired hoof sole [y,z] ; returns joint positions + bone transforms */
  function solveLimb(front, x, Gl, hoofAng) {
    const L = front ? H.LIMB.front : H.LIMB.hind, S = L.S;
    // hoof direction (F→G) rotated by hoofAng
    const c = cos(hoofAng), s = sin(hoofAng), p = [L.p[0] * c + L.p[1] * s, -L.p[0] * s + L.p[1] * c];
    const F0 = [Gl[0] - p[0], Gl[1] - p[1]];
    const dSF = Math.hypot(F0[0] - S[0], F0[1] - S[1]);
    const D = clamp(dSF - .85 * L.l3, Math.abs(L.l1 - L.l2) + .02, L.l1 + L.l2 - .005);
    const K = circ(S, D, F0, L.l3, front ? 1 : -1);
    const dk = Math.hypot(F0[0] - K[0], F0[1] - K[1]) || 1, F = [K[0] + (F0[0] - K[0]) / dk * L.l3, K[1] + (F0[1] - K[1]) / dk * L.l3];
    const E = circ(S, L.l1, K, L.l2, front ? -1 : 1);
    const G = [F[0] + p[0], F[1] + p[1]];
    return { S, E, K, F, G, L };
  }
  const limbM = (x, rest, cur) => {       // 3-D pitch about X from rest joints to current ones: returns bone matrices (4 bones)
    const a = [[rest.S, rest.E], [rest.E, rest.K], [rest.K, rest.F], [rest.F, rest.G]], c = [[cur.S, cur.E], [cur.E, cur.K], [cur.K, cur.F], [cur.F, cur.G]], out = [];
    for (let i = 0; i < 4; i++) {
      const d = th(a[i][0], a[i][1]) - th(c[i][0], c[i][1]);
      out.push(pitchAt([x, a[i][0][0], a[i][0][1]], [x, c[i][0][0], c[i][0][1]], -d * -1));
    }
    return out;
  };

  function Animator() {
    const A = this;
    A.bones = new Float32Array(NB * 12);
    A.clock = { walk: 0, trot: 0, gallop: 0 };
    A.t = 0; A.v = 0; A.turn = 0; A.idleT = Math.random() * 10; A.seatLag = 0; A.prevH = 0; A.vy = 0; A.wind = [0, 0, 0];
    A.w = { idle: 1, walk: 0, trot: 0, gallop: 0 };
    A.info = { gait: 'idle', phase: 0 };
    A.reinPts = [[], []];
    A.flexK = [0, .022, .034, .008, .017, .028];   // per-kind wind gain (m per m/s)
  }


  /* Endless Run: the messenger sits upright on the cart's driver bench (rest pose, no horse bob), left hand on the reins, right hand whipping
     continuously. Everything is in rider model space; riding.js moves it onto the cart. A.whipPts = [grip end, tip, 7 lash points]. */
  function driverRider(A, Mb, dt, v, turnK) {
    const T = A.t, sp = Math.min(1, Math.abs(v) / 11), Ms = R.mIdent(), road = .006 * Math.sin(T * 19) * sp + .004 * Math.sin(T * 7.3), lean = -(.04 + .06 * sp);
    const Mc = mMul(Ms, boneM([0, 1.66, -.07], lean + road * 3, -turnK * .04, -turnK * .05, 0, road, 0));
    const Mhd = mMul(Mc, boneM([0, 2.12, -.06], -lean * .6, turnK * .1 + .03 * sin(T * .9), 0));
    const Mr = new Array(NBR); Mr[RB.HIPS] = Ms; Mr[RB.CHEST] = Mc; Mr[RB.HEAD] = Mhd;
    for (const k of ['L', 'R']) { Mr[RB['THIGH_' + k]] = Ms.slice(); Mr[RB['SHIN_' + k]] = Ms.slice(); Mr[RB['FOOT_' + k]] = Ms.slice(); }
    // whip cycle: 0 = lash forward/down (end of the stroke), 1 = arm raised back
    const rate = 1 / (.58 - .16 * sp), ph = (T * rate) % 1, WU = .6; let s;
    if (ph < WU) { const q = ph / WU; s = q * q * (3 - 2 * q); } else { s = 1 - Math.pow((ph - WU) / (1 - WU), 1.6); }
    const hn = [], T3s = {};
    for (const sg of [-1, 1]) {
      const k = sg < 0 ? 'L' : 'R', sh = M.rest['sh' + k], hr = M.rest['hand' + k]; let T3;
      if (k === 'L') T3 = add(hr, [0, -.03 + .012 * sin(T * 2.1) + road, -.02]);
      else { const sx = Math.sign(sh[0]) || 1, fr = add(sh, [sx * .09, -.20, .50]), bk = add(sh, [sx * .06, .30, -.16]); T3 = [lerp(fr[0], bk[0], s), lerp(fr[1], bk[1], s) + road, lerp(fr[2], bk[2], s)]; }
      const shC = mApply(Mc, sh), poleRest = M.rest['polA' + k], poleC = mApplyDir(Mc, poleRest), Eel = M.ik3(shC, T3, M.LU, M.LF, poleC), el = M.rest['elb' + k];
      const dirU = sub(el, sh), dirF = sub(hr, el);
      Mr[RB['UARM_' + k]] = frameM(sh, shC, dirU, poleRest, sub(Eel, shC), poleC);
      Mr[RB['FARM_' + k]] = frameM(el, Eel, dirF, poleRest, sub(T3, Eel), poleC);
      T3s[k] = T3;
    }
    for (const sg of [-1, 1]) {      // both reins run to the left hand; the right hand holds the whip
      const k = sg < 0 ? 'L' : 'R', bR = A.bitRest[k] || [0, 0, 0], bC = mApply(Mb[HB.HEAD], bR);
      hn.push({ hand: k === 'L' ? T3s.L : add(T3s.L, [.045, 0, 0]), bitC: bC });
    }
    A.hands = hn;
    for (let i = 0; i < NBR; i++) for (let k = 0; k < 12; k++) A.bones[(NBH + i) * 12 + k] = Mr[i][k];
    // whip: stiff handle + verlet lash that trails and cracks forward on the stroke
    const dsp = R.norm([-.1 * (T3s.R[0] < 0 ? -1 : 1) * 0, lerp(.30, .95, s), lerp(.95, -.30, s)]), hand = T3s.R, tip = add(hand, mul(dsp, .8)), base = sub(hand, mul(dsp, .14));
    const W = A.whip || (A.whip = { p: [], q: [] }), NL = 8, seg = .19, h2 = Math.min(dt, .033);
    if (!W.p.length) for (let i = 0; i < NL; i++) { W.p.push([tip[0], tip[1] - i * seg, tip[2]]); W.q.push([tip[0], tip[1] - i * seg, tip[2]]); }
    W.p[0] = tip; W.q[0] = tip;
    const acc = [0, -9, -(2 + .5 * Math.abs(v))];
    for (let i = 1; i < NL; i++) { const p = W.p[i], q = W.q[i]; W.q[i] = p; W.p[i] = [p[0] + (p[0] - q[0]) * .9 + acc[0] * h2 * h2, p[1] + (p[1] - q[1]) * .9 + acc[1] * h2 * h2, p[2] + (p[2] - q[2]) * .9 + acc[2] * h2 * h2]; }
    for (let it = 0; it < 2; it++) for (let i = 1; i < NL; i++) { const d = sub(W.p[i], W.p[i - 1]), l = Math.hypot(d[0], d[1], d[2]) || 1e-4; W.p[i] = add(W.p[i - 1], mul(d, seg / l)); }
    A.whipPts = [base].concat(W.p);
  }

  Animator.prototype.update = function (dt, v, turn, lookX) {
    const A = this; dt = Math.min(dt, .05); A.t += dt;
    const sp = Math.abs(v), stepV = Math.max(sp, Math.min(1.5, Math.abs(turn) * .9)), fwd = v >= 0 ? 1 : -1;
    A.v = lerp(A.v, v, 1 - Math.exp(-dt * 12)); A.turn = lerp(A.turn, turn, 1 - Math.exp(-dt * 6));
    /* ---- gait weights ---- */
    const mv = smooth(.12, .7, stepV), a = smooth(2.7, 3.7, stepV), b = smooth(7.0, 8.6, stepV);
    const wt = { idle: 1 - mv, walk: mv * (1 - a), trot: mv * a * (1 - b), gallop: mv * b };
    const sm = 1 - Math.exp(-dt * 9);
    for (const k in wt) A.w[k] = lerp(A.w[k], wt[k], sm);
    const ws = A.w.idle + A.w.walk + A.w.trot + A.w.gallop; for (const k in A.w) A.w[k] /= ws;
    const fr = {}; for (const k of ['walk', 'trot', 'gallop']) { const g = GAITS[k]; fr[k] = g.f(stepV); A.clock[k] = (A.clock[k] + fr[k] * dt * fwd) % 1; if (A.clock[k] < 0) A.clock[k] += 1; }
    const dom = A.w.gallop > .5 ? 'gallop' : A.w.trot > .45 ? 'trot' : A.w.walk > .3 ? 'walk' : 'idle'; A.info.gait = dom;
    const gW = A.w.gallop, tW = A.w.trot, wW = A.w.walk, iW = A.w.idle, mvF = 1 - iW;
    const T = A.t, ci = A.idleT + T;

    /* ---- body motion ---- */
    const pw = A.clock.walk * TAU, pt = A.clock.trot * TAU, pg = A.clock.gallop * TAU;
    const turnK = clamp(A.turn, -2, 2), lean = clamp(-turnK * (sp + 1.5) * .018, -.16, .16);
    let heave = 0, rootPitch = 0, pelP = 0, chP = 0, pelYaw = 0, chYaw = 0, n1p = 0, n2p = 0, hP = 0, tailP = 0, roll = lean;
    // idle
    heave += iW * (.004 * sin(TAU * .24 * ci));
    n1p += iW * (.02 * sin(TAU * .11 * ci)); hP += iW * (.04 * sin(TAU * .17 * ci + 1));
    // walk
    heave += wW * (.012 * sin(2 * pw + .6)); rootPitch += wW * .012 * sin(2 * pw); roll += wW * .018 * sin(pw);
    pelYaw += wW * .035 * sin(pw); chYaw -= wW * .035 * sin(pw); n1p += wW * (.05 * sin(pw + .5)); n2p += wW * .05 * sin(pw + .9); hP += wW * .03 * sin(pw + 1.3);
    // trot
    heave += tW * (.035 * cos(2 * pt)); rootPitch += tW * .014 * sin(2 * pt); pelYaw += tW * .02 * sin(pt); chYaw -= tW * .02 * sin(pt); n1p += tW * (-.03 + .02 * sin(2 * pt + 1)); hP += tW * (.03 * sin(2 * pt + 2));
    // gallop (rotary): rhythm cycle = phase of the 4-beat; bounds spine flex and neck pumping
    heave += gW * (.085 * cos(pg - .9) + .03 * cos(2 * pg));
    rootPitch += gW * (.10 * sin(pg + .2)); pelP += gW * (-.12 * sin(pg - .6)); chP += gW * (.10 * sin(pg - .6));
    n1p += gW * (-.16 + .12 * sin(pg + 1.2)); n2p += gW * (-.1 + .1 * sin(pg + 1.6)); hP += gW * (.1 * sin(pg + 2.1));
    tailP += gW * (-.5) + tW * (-.25) + wW * (-.08) + iW * 0;
    heave -= (.04 * wW + .05 * tW + .075 * gW);          // legs flex slightly while moving
    roll += gW * .02 * sin(pg);
    // neck/head into turns, spine curves, tail counter-swings
    const n2y = clamp(turnK * .22, -.35, .35), hY = n2y * .7;
    const tailY = clamp(-turnK * .2, -.4, .4) + .12 * sin(ci * .9) * (iW + wW * .5) + .1 * sin(T * 9 + 1) * gW;
    pelYaw += clamp(-turnK * .05, -.08, .08); chYaw += clamp(turnK * .07, -.1, .1);
    const ear = .22 * sin(ci * 1.9) * Math.max(0, sin(ci * .23)) * iW;
    const earBack = gW * .5 + tW * .15;

    /* ---- horse bone matrices ---- */
    const Mb = new Array(NBH);
    const P = H.PIV;
    Mb[HB.ROOT] = boneM(P.ROOT, rootPitch, 0, roll, 0, heave, 0);
    Mb[HB.PELVIS] = mMul(Mb[HB.ROOT], boneM(P.PELVIS, pelP, pelYaw, 0));
    Mb[HB.CHEST] = mMul(Mb[HB.ROOT], boneM(P.CHEST, chP, chYaw, 0));
    Mb[HB.NECK1] = mMul(Mb[HB.CHEST], boneM(P.NECK1, n1p, n2y * .4, 0));
    Mb[HB.NECK2] = mMul(Mb[HB.NECK1], boneM(P.NECK2, n2p, n2y * .6, 0));
    Mb[HB.HEAD] = mMul(Mb[HB.NECK2], boneM(P.HEAD, hP, hY + (lookX || 0) * .0, -turnK * .05));
    Mb[HB.EAR_L] = mMul(Mb[HB.HEAD], boneM(P.EAR_L, earBack + ear, 0, -ear * .6 - (1 - iW) * .0));
    Mb[HB.EAR_R] = mMul(Mb[HB.HEAD], boneM(P.EAR_R, earBack + ear * .5, 0, ear * .3));
    Mb[HB.TAIL1] = mMul(Mb[HB.PELVIS], boneM(P.TAIL1, tailP + .06 * sin(T * 1.7) * iW, tailY, 0));
    Mb[HB.TAIL2] = mMul(Mb[HB.TAIL1], boneM(P.TAIL2, tailP * .5 + .1 * sin(T * 2.3 + 1) * (iW + wW), tailY * .6, 0));
    Mb[HB.TAIL3] = mMul(Mb[HB.TAIL2], boneM(P.TAIL3, tailP * .4, tailY * .5, 0));

    /* ---- legs ---- */
    const gl = { walk: GAITS.walk, trot: GAITS.trot, gallop: GAITS.gallop };
    const travelOf = (g, v) => Math.min(Math.max(v, g.vmin) * g.beta / g.f(v), g.cap);
    A.feet = [];
    LEGS.forEach(([n, kind, side], li) => {
      const front = kind === 'front', L = H.LIMB[kind], x = side * L.x, body = front ? Mb[HB.CHEST] : Mb[HB.PELVIS];
      let dz = 0, lift = 0, ha = 0, wsum = iW;
      for (const k of ['walk', 'trot', 'gallop']) {
        const w = A.w[k]; if (w < .002) continue;
        const g = gl[k], vv = k === 'walk' ? clamp(stepV, g.vmin, g.vmax) : stepV, tr = travelOf(g, vv) * (sp < .3 ? Math.max(.35, Math.min(1, stepV / 1.2)) : 1);
        const f = footPath(A.clock[k] + g.off[li], g, tr, g.lift[front ? 0 : 1] * (k === 'walk' ? 1 : 1), front);
        dz += w * f[0]; lift += w * f[1]; ha += w * f[2];
      }
      const Gw = [lift, L.G[1] + dz], Gm = mApply(mInvRigid(body), [x, Gw[0], Gw[1]]);
      const cur = solveLimb(front, x, [Gm[1], Gm[2]], ha);
      const rst = { S: L.S, E: L.E, K: L.K, F: L.F, G: [L.F[0] + L.p[0], L.F[1] + L.p[1]] };
      const ms = limbM(x, rst, cur), ids = [HB[n + (front ? '_U' : '_T')], HB[n + (front ? '_F' : '_G')], HB[n + '_C'], HB[n + '_P']];
      for (let i = 0; i < 4; i++) Mb[ids[i]] = mMul(body, ms[i]);
      const ach = mApply(body, [x, cur.G[0], cur.G[1]]);
      A.feet[li] = { world: [x, lift, L.G[1] + dz], achY: ach[1], err: ach[1] - lift, achZ: ach[2], stance: (A.clock[dom === 'idle' ? 'walk' : dom] + (dom === 'idle' ? 0 : gl[dom].off[li])) % 1 < (dom === 'idle' ? 1 : gl[dom].beta) };
    });

    /* ---- write horse bones ---- */
    for (let i = 0; i < NBH; i++) for (let k = 0; k < 12; k++) A.bones[i * 12 + k] = Mb[i][k];

    /* ---- rider ---- */
    if (A.driver) { driverRider(A, Mb, dt, v, turnK); } else {
    const wS = R.smooth(-.30, .30, -.06), Ms = Mb[HB.PELVIS].map((v, i) => lerp(v, Mb[HB.CHEST][i], wS));
    const seatY = mApply(Ms, [0, 1.55, -.07])[1] - 1.55;
    A.seatLag = lerp(A.seatLag, seatY, 1 - Math.exp(-dt / .075));
    const dy = clamp((A.seatLag - seatY) * .7, -.05, .05);
    const gf = gW + tW * .25 + wW * .05, leanF = -(.02 * wW + .07 * tW + .30 * gW) + .015 * sin(ci * .3) * iW;
    const Mrh = Ms;
    const Mc = mMul(Ms, boneM([0, 1.66, -.07], leanF + .02 * dy * 8, -turnK * .03, -roll * .35 + .01 * sin(T * .7) * iW, 0, dy, 0));
    const lookSwing = .03 * sin(ci * .31) * iW;
    const Mhd = mMul(Mc, boneM([0, 2.12, -.06], -leanF * .6 + .02 * sin(T * 1.3) * iW, turnK * .12 + lookSwing, 0));
    const Mr = new Array(NBR);
    Mr[RB.HIPS] = Mrh; Mr[RB.CHEST] = Mc; Mr[RB.HEAD] = Mhd;
    // legs: rigid to saddle with a little swing
    const swing = .05 * (gW + tW * .6 + wW * .3) * sin(A.clock.gallop * TAU * gW + A.clock.trot * TAU * tW + A.clock.walk * TAU * wW * 2 + 1.0);
    for (const s of [-1, 1]) {
      const k = s < 0 ? 'L' : 'R', hip = M.rest['hip' + k], kn = M.rest['knee' + k], an = M.rest['ank' + k];
      const Mt = mMul(Ms, boneM(hip, swing * s * .5, 0, 0)), Msh = mMul(Mt, boneM(kn, -swing * 1.6, 0, 0)), Mf = mMul(Msh, boneM(an, swing * .8, 0, 0));
      Mr[RB['THIGH_' + k]] = Mt; Mr[RB['SHIN_' + k]] = Msh; Mr[RB['FOOT_' + k]] = Mf;
    }
    // arms: IK to rein grips. grips follow the bit a little (rein tension), lean forward at speed
    A.bitRest = A.bitRest || { L: null, R: null };
    const hn = [];
    for (const s of [-1, 1]) {
      const k = s < 0 ? 'L' : 'R', bR = A.bitRest[k] || [0, 0, 0], bC = mApply(Mb[HB.HEAD], bR), disp = sub(bC, bR);
      const hr = M.rest['hand' + k], tgt0 = add(hr, [0, -.055 * gf, .06 * gf]);
      const T3 = add(mApply(Ms, tgt0), add(mul(disp, .3), [0, .015 * sin(T * 2.1 + s) * iW, 0]));
      const sh = M.rest['sh' + k], shC = mApply(Mc, sh), poleRest = M.rest['polA' + k], poleC = mApplyDir(Mc, poleRest);
      const Eel = M.ik3(shC, T3, M.LU, M.LF, poleC), el = M.rest['elb' + k];
      const dirU = sub(el, sh), dirF = sub(hr, el);
      Mr[RB['UARM_' + k]] = frameM(sh, shC, dirU, poleRest, sub(Eel, shC), poleC);
      Mr[RB['FARM_' + k]] = frameM(el, Eel, dirF, poleRest, sub(T3, Eel), poleC);
      // fist grip point (rest hand + palm centre) after FARM transform = T3
      hn.push({ hand: T3, bitC: bC });
    }
    A.hands = hn;
    for (let i = 0; i < NBR; i++) for (let k = 0; k < 12; k++) A.bones[(NBH + i) * 12 + k] = Mr[i][k];
    }

    /* ---- wind for secondary motion (model-space lag) ---- */
    A.vy = (heave - A.prevH) / Math.max(dt, 1e-3); A.prevH = heave;
    const wz = -A.v * 1, wy = -A.vy * .6;
    A.wind[0] = lerp(A.wind[0], -turnK * (sp + 1) * .1, 1 - Math.exp(-dt * 4)); A.wind[1] = lerp(A.wind[1], wy, 1 - Math.exp(-dt * 10)); A.wind[2] = lerp(A.wind[2], wz, 1 - Math.exp(-dt * 5));
    A.hipSpeed = sp; A.heave = heave; A.roll = roll; A.mvF = mvF; A.Mhead = Mb[HB.HEAD];
    return A;
  };

  /* apply per-vertex secondary motion (mane, tail, cloth, tassels) to skinned positions (model space) */
  Animator.prototype.applyFlex = function (mesh, P, v0, v1, ex, ey, ez) {
    ex = ex || [1, 0, 0]; ey = ey || [0, 1, 0]; ez = ez || [0, 0, 1];
    const A = this, T = A.t, sp = Math.min(14, Math.abs(A.v)), w = A.wind, fk = mesh.fk, fa = mesh.fa, fp = mesh.fp, K = A.flexK;
    for (let k = v0; k < v1; k++) {
      const kind = fk[k]; if (!kind) continue;
      const amp = fa[k], g = K[kind], ph = fp[k];
      const sway = sin(T * (3.1 + kind * .4) + ph * 2.7) * amp * (.012 + .0035 * sp) + sin(T * 1.3 + ph) * amp * .008;
      const dx = w[0] * g * 8 * amp + sway, dz = w[2] * g * amp;
      const dy = w[1] * g * 3 * amp + (kind === 1 || kind === 2 ? sp * g * .25 * amp * amp : 0);
      P[k * 3] += ex[0] * dx + ey[0] * dy + ez[0] * dz; P[k * 3 + 1] += ex[1] * dx + ey[1] * dy + ez[1] * dz; P[k * 3 + 2] += ex[2] * dx + ey[2] * dy + ez[2] * dz;
    }
  };

  const api = { Animator, GAITS, NB, NBH, NBR, footPath, solveLimb };
  root.OYORideAnim = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
