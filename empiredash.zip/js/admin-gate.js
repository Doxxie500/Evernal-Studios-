/* Admin test mode: siteurl/?admin=<signature> (made in the admin page) unlocks Free Roam, Live and Race buttons on THIS device; ?admin=off removes it.
   The signature is checked with the PUBLIC key, so players cannot unlock these by typing something into storage (a fake value is removed and the page reloads). */
(function () {
  'use strict';
  var KEY = 'jagun-admin', PUB = { kty: 'EC', crv: 'P-256', x: '_H2X0jNFio8GAdcxexVyLFtAWHQ2HS3OmvIOCWB5a6A', y: '2RatVkUymIxQp6BebXEUAxVPmV81YIb-cuZ2KWV5HpY' };
  var v = '', kept = ''; try { var m = /[?&]admin=([^&#]*)/.exec(location.search); if (m) v = m[1]; if (v === 'off') localStorage.removeItem(KEY); kept = v && v !== 'off' ? v : localStorage.getItem(KEY) || ''; } catch (e) { /* none */ }
  if (kept && kept.length < 200) { window.JAGUN_FREE_ROAM = true; window.OYOAdminMode = true; }      // provisional (UI only) until the signature is checked below
  function b64u(t) { t = t.replace(/-/g, '+').replace(/_/g, '/'); while (t.length % 4) t += '='; var s = atob(t), a = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a; }
  function strip() { try { var u = new URL(location.href); u.searchParams.delete('admin'); history.replaceState(null, '', u.pathname + (u.search || '') + u.hash); } catch (e) { /* ok */ } }
  if (!kept) { if (v) strip(); return; }
  (async function () {
    var ok = false;
    try { var k = await crypto.subtle.importKey('jwk', PUB, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']); ok = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, k, b64u(kept), new TextEncoder().encode('jagun-cart:@admin-all')); } catch (e) { ok = false; }
    if (ok) { try { localStorage.setItem(KEY, kept); } catch (e) { /* ok */ } strip(); }
    else { window.JAGUN_FREE_ROAM = false; window.OYOAdminMode = false; try { localStorage.removeItem(KEY); } catch (e) { /* ok */ } strip(); location.reload(); }
  })();
})();
