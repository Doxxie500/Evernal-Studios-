/* EMPIRE DASH — missions.js (shared game controller)
   Resolves the world's stops, builds the trail obstacles, owns the title / Free Roam screen flow, pause state, settings and the save.
   Story missions have been removed: the game now has two modes — Free Roam and Endless Run (endless.js).
   Hooks into game.js through OYO.mission.pre / post and OYO.core. */
(function () {
  'use strict';
  const B = BABYLON, OYO = window.OYO, A = window.OYOAudio || {};
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v)), PI = Math.PI;
  const KEY = 'jagun_transporter_v1', OLD_KEYS = ['jagun_royal_messenger_v1', 'oyo_royal_messenger_v1'];   // renamed game; older saves are migrated on first load
  const H = () => OYO.hud;
  const snd = (f, ...a) => { try { A[f] && A[f](...a); } catch (e) { /* audio is optional */ } };

  /* ---------- UI state (merged into the Alpine component by game.js) ---------- */
  window.OYOUI = {
    state: {
      screen: 'title', modal: '', vol: 70, sound: true, mvol: 50, music: true, amb: true, avol: 70, quality: 'bal', lefty: false,
      cartPrev: '', stam: 100, exh: false, rough: false, score: 0, toast: '', cow: 0, cowPop: false
    }
  };

  const M = OYO.mission = { paused: true, playing: false, dest: null };   // `playing` stays false (Endless Run manages its own state); `paused` freezes the simulation
  let W = null, RD = null, scene = null, core = null, DEST = {}, SPAWN = null;

  const DEF_SAVE = () => ({ score: 0, vol: 70, sound: true, mvol: 50, music: true, quality: 'bal', lefty: false });
  function load() {
    const d = DEF_SAVE();
    try {
      let raw = localStorage.getItem(KEY);
      if (!raw) { for (const k of OLD_KEYS) { raw = localStorage.getItem(k); if (raw) break; } }   // migrate pre-rename progress (settings + cowries)
      const p = JSON.parse(raw || '{}');
      if (p && typeof p === 'object') Object.keys(d).forEach(k => { if (k in p) d[k] = p[k]; });
    } catch (e) { /* corrupt or unavailable storage → fresh save */ }
    const num = (v, lo, hi, def) => (typeof v === 'number' && isFinite(v)) ? Math.min(hi, Math.max(lo, v)) : def;
    d.score = Math.round(num(d.score, 0, 1e9, 0)); d.vol = num(d.vol, 0, 100, 70); d.mvol = num(d.mvol, 0, 100, 50);
    d.sound = d.sound !== false; d.music = d.music !== false; d.lefty = d.lefty === true;
    if (!['perf', 'bal', 'high'].includes(d.quality)) d.quality = 'bal';
    return d;
  }
  function store() { try { localStorage.setItem(KEY, JSON.stringify(save)); } catch (e) { /* private mode */ } }
  let save = load();

  const VIL = { p1: 'Farmers’ Village', p2: 'Potters’ Village', p3: 'Weavers’ Village', p4: 'Well Village', p5: 'Hunters’ Camp', p6: 'Herders’ Settlement', p7: 'Shrine Village', p8: 'Dyers’ Village', p9: 'Northern Hamlet' };
  const TOWN = { s1: 'Northern Caravan Town', s2: 'Southern Salt Town', s3: 'Kola Road Town', s4: 'Cattle Road Town' };
  /* ---------- destinations (all on roads, so they are always reachable) ---------- */
  function roadAtS(id, s) { const r = W.byId[id]; if (!r) return null; let i = 0; while (i < r.n - 2 && r.s[i] < s) i++; return { x: r.x[i], z: r.z[i] }; }
  function roadEnd(id, back) { const r = W.byId[id]; if (!r) return null; let i = r.n - 1; while (i > 0 && r.len - r.s[i] < back) i--; return { x: r.x[i], z: r.z[i] }; }
  function resolve() {
    DEST = {};
    const PA = window.OYOPalace && OYOPalace.site;
    if (PA && PA.G) {
      const dx = Math.sin(PA.yaw), dz = Math.cos(PA.yaw);
      DEST.palace = { name: 'The Aláàfin’s Palace', x: PA.G[0] + dx * 14, z: PA.G[1] + dz * 14, r: 13 };
      // Stage 9b: start inside the palace compound — outer courtyard, 14 m in from the great gate, facing out through it
      const lz = (PA.b || 36) - 14;
      SPAWN = { x: PA.x + dx * lz, z: PA.z + dz * lz, yaw: PA.yaw };
    } else {
      const r = W.byId.royal, i = Math.min(r.n - 2, 26);
      DEST.palace = { name: 'The Aláàfin’s Palace', x: r.x[i], z: r.z[i], r: 14 };
      SPAWN = { x: r.x[i] + r.nx[i] * 1.6, z: r.z[i] + r.nz[i] * 1.6, yaw: Math.atan2(r.tx[i], r.tz[i]) };
    }
    Object.keys(VIL).forEach(id => { const p = roadEnd(id, 10); if (p) DEST[id] = { name: VIL[id], x: p.x, z: p.z, r: 13 }; });
    Object.keys(TOWN).forEach(id => { const p = roadAtS(id, 36); if (p) DEST[id] = { name: TOWN[id], x: p.x, z: p.z, r: 16 }; });
    const mk = (window.OYOVillagers && OYOVillagers.markets || []).slice().sort((a, b) => b.R - a.R)[0];
    if (mk) DEST.market = { name: 'Ọjà Ọba · Grand Market', x: mk.x, z: mk.z, r: mk.R + 4 };
    else { const p = roadAtS('royal', W.byId.royal.len * .5); DEST.market = { name: 'Ọjà Ọba · Grand Market', x: p.x, z: p.z, r: 14 }; }
  }


  /* ---------- obstacles: rocks, termite mounds, fallen branches, narrow passes ---------- */
  function buildObstacles() {
    let sd = 8801; const rnd = () => { sd = (sd * 16807) % 2147483647; return (sd - 1) / 2147483646; };
    const rocks = [], logs = [], mounds = [], o = RD.obs;
    const PA = RD.palace, sEdge = W.siteEdge ? (x, z) => W.siteEdge(x, z) : () => 99;
    const free = (x, z, r) => {
      if (Math.abs(x) > W.HALF - 20 || Math.abs(z) > W.HALF - 20) return false;
      for (let k = 0; k < o.x.length; k++) if (Math.hypot(x - o.x[k], z - o.z[k]) < o.r[k] + r + 5) return false;
      if (PA && Math.hypot(x - PA.x, z - PA.z) < Math.hypot(PA.a, PA.b) + 55) return false;
      if (Math.hypot(x - SPAWN.x, z - SPAWN.z) < 40) return false;
      for (const k in DEST) if (Math.hypot(x - DEST[k].x, z - DEST[k].z) < DEST[k].r + 10) return false;
      return sEdge(x, z) > 8;
    };
    const rock = (x, z, r) => { rocks.push({ x, z, r, yaw: rnd() * 6.28, sy: .55 + rnd() * .3 }); RD.addObstacle(x, z, r * .88, 1.6, 1); };
    const mound = (x, z, r) => { mounds.push({ x, z, r }); RD.addObstacle(x, z, r * .9, 2, 1); };
    const log = (x, z, yaw, len, th) => {
      logs.push({ x, z, yaw, len, th });
      const sx = Math.sin(yaw), cz = Math.cos(yaw), n = Math.max(2, Math.round(len / 1.3));
      for (let k = 0; k < n; k++) { const t = (k / (n - 1) - .5) * len * .8; RD.addObstacle(x + sx * t, z + cz * t, .7, 1, 2); }
    };
    const onRoad = (r, x, z, hw) => { const q = W.queryRoad(x, z); return q && q.road === r && q.d < hw * 1.6; };
    // lateral centre for an obstacle of half-extent `ext`: it may only intrude a little into the road edge, always leaving a wide clear lane
    const edgeL = (hw, ext) => hw - clamp(Math.min(2 * ext, .6 * hw, 2 * hw - 4.2), 0, 9) + ext;
    W.roads.forEach(r => {
      const cls = r.cls, step = cls === 'royal' ? 120 : cls === 'secondary' ? 90 : 70;
      let s = 95 + rnd() * 20, i = 0;
      while (s < r.len - 95) {
        while (i < r.n - 2 && r.s[i] < s) i++;
        const hw = W.widthAt(r, i) * .5, px = r.x[i], pz = r.z[i], nx = r.nx[i], nz = r.nz[i], tx = r.tx[i], tz = r.tz[i], roll = rnd();
        const lat = (l, a, b) => [a + nx * l, b + nz * l];
        if (cls === 'path' && roll < .14) {                            // pass: two boulders flanking the path, ~3.7 m rideable gap
          const L = 2.85, rr = .95, a = lat(L, px, pz), b = lat(-L, px, pz);
          if (free(a[0], a[1], rr) && free(b[0], b[1], rr) && onRoad(r, px, pz, hw)) { rock(a[0], a[1], rr); rock(b[0], b[1], rr); }
        } else if (cls === 'secondary' && roll < .10) {
          const L = 3.9, rr = 1.0, a = lat(L, px, pz), b = lat(-L, px, pz);
          if (free(a[0], a[1], rr) && free(b[0], b[1], rr) && onRoad(r, px, pz, hw)) { rock(a[0], a[1], rr); rock(b[0], b[1], rr); }
        } else if (roll < .55) {                                       // single rock, partly in the road
          const rr = .7 + rnd() * .55, l = (rnd() < .5 ? -1 : 1) * edgeL(hw, rr), p = lat(l, px, pz);
          if (free(p[0], p[1], rr) && onRoad(r, p[0], p[1], hw)) rock(p[0], p[1], rr);
        } else if (roll < .72) {                                       // termite mound beside the track
          const l = (rnd() < .5 ? -1 : 1) * (hw + 1.5 + rnd() * 2), p = lat(l, px, pz), rr = 1 + rnd() * .5;
          if (free(p[0], p[1], rr)) mound(p[0], p[1], rr);
        } else {                                                       // fallen branch lying across the road
          const len = (cls === 'royal' ? 3.6 : 3.0) + rnd(), l = (rnd() < .5 ? -1 : 1) * edgeL(hw, len * .4 + .5), p = lat(l, px, pz);
          if (free(p[0], p[1], 1.6)) log(p[0], p[1], Math.atan2(tx, tz) + PI / 2 + (rnd() - .5) * .7, len, .3 + rnd() * .12);
        }
        s += step * (.7 + rnd() * .7);
      }
    });
    // ---- meshes (thin instances: 3 draw calls total) ----
    const q = new B.Quaternion(), sc = new B.Vector3(), tr = new B.Vector3(), mtx = new B.Matrix();
    const mat = (name, em) => { const m = new B.StandardMaterial(name, scene); m.specularColor = B.Color3.Black(); m.emissiveColor = em; return m; };
    const finish = (mesh, mArr, cArr, material) => {
      if (!mArr.length) { mesh.dispose(); return; }
      mesh.material = material; mesh.thinInstanceSetBuffer('matrix', new Float32Array(mArr), 16, true); mesh.thinInstanceSetBuffer('color', new Float32Array(cArr), 4, true);
      mesh.thinInstanceRefreshBoundingInfo(true); mesh.isPickable = false; mesh.alwaysSelectAsActiveMesh = true;
    };
    const pal = [[.78, .6, .44], [.66, .42, .32], [.86, .74, .58], [.55, .38, .3]];
    { const m = [], c = [];
      rocks.forEach(k => {
        B.Quaternion.RotationYawPitchRollToRef(k.yaw, (rnd() - .5) * .3, (rnd() - .5) * .3, q);
        sc.set(k.r * 1.05, k.r * k.sy * 1.4, k.r * 1.05); tr.set(k.x, W.height(k.x, k.z) + k.r * .2, k.z);
        B.Matrix.ComposeToRef(sc, q, tr, mtx); m.push(...mtx.m); const p = pal[Math.floor(rnd() * 4)], l = .85 + rnd() * .25; c.push(p[0] * l, p[1] * l, p[2] * l, 1);
      });
      const mesh = B.MeshBuilder.CreatePolyhedron('obsRocks', { type: 2, size: 1 }, scene); mesh.convertToFlatShadedMesh();
      finish(mesh, m, c, mat('obsRockMat', new B.Color3(.1, .065, .05))); }
    { const m = [], c = [];
      mounds.forEach(k => {
        B.Quaternion.RotationYawPitchRollToRef(rnd() * 6.28, 0, 0, q);
        sc.set(k.r, k.r * 1.5, k.r); tr.set(k.x, W.height(k.x, k.z) + k.r * .7, k.z);
        B.Matrix.ComposeToRef(sc, q, tr, mtx); m.push(...mtx.m); const l = .85 + rnd() * .2; c.push(.80 * l, .52 * l, .36 * l, 1);
      });
      const mesh = B.MeshBuilder.CreateCylinder('obsMounds', { diameterTop: .45, diameterBottom: 1.9, height: 1.8, tessellation: 9 }, scene); mesh.convertToFlatShadedMesh();
      finish(mesh, m, c, mat('obsMoundMat', new B.Color3(.12, .07, .05))); }
    { const m = [], c = [];
      logs.forEach(k => {
        const put = (yaw, len, th, ox, oz, dy) => {
          B.Quaternion.RotationYawPitchRollToRef(yaw, 0, PI / 2, q); sc.set(th, len, th);
          const x = k.x + ox, z = k.z + oz; tr.set(x, W.height(x, z) + th * .55 + dy, z);
          B.Matrix.ComposeToRef(sc, q, tr, mtx); m.push(...mtx.m); const l = .8 + rnd() * .25; c.push(.46 * l, .31 * l, .2 * l, 1);
        };
        // cylinder lies along local Y → after roll π/2 it points along +X rotated by yaw ... compensate so it matches the collision line (sin yaw, cos yaw)
        const yaw = k.yaw - PI / 2;
        put(yaw, k.len, k.th, 0, 0, 0);
        const sx = Math.sin(k.yaw), cz = Math.cos(k.yaw);
        put(yaw + .7, k.len * .45, k.th * .5, sx * k.len * .12 + cz * .3, cz * k.len * .12 - sx * .3, k.th * .5);
        put(yaw - .8, k.len * .4, k.th * .45, -sx * k.len * .2 - cz * .25, -cz * k.len * .2 + sx * .25, k.th * .4);
      });
      const mesh = B.MeshBuilder.CreateCylinder('obsLogs', { diameter: 1, height: 1, tessellation: 7 }, scene); mesh.convertToFlatShadedMesh();
      finish(mesh, m, c, mat('obsLogMat', new B.Color3(.1, .06, .04))); }
    M.obstacleCount = { rocks: rocks.length, mounds: mounds.length, logs: logs.length };
  }

  /* ---------- init ---------- */
  M.init = function (world, riding, scn, coreRef) {
    W = world; RD = riding; scene = scn; core = coreRef;
    resolve();
    try { buildObstacles(); } catch (e) { console.warn('Obstacles skipped:', e); }
    try { window.OYOVillagers && OYOVillagers.setObstacles && OYOVillagers.setObstacles(RD.obs); } catch (e) { console.warn('NPC detours skipped:', e); }
    const h = H(); h.vol = save.vol; h.sound = save.sound; h.mvol = save.mvol; h.music = save.music; h.quality = save.quality; h.lefty = save.lefty; h.score = save.score; applyHand();
    snd('setVolume', save.vol / 100); snd('setOn', save.sound); snd('setMusicVolume', save.mvol / 100); snd('setMusicOn', save.music); applyQuality();
    M.toTitle();
  };

  /* ---------- screens ---------- */
  function setPaused(p) { M.paused = p; if (p) snd('suspend'); else snd('resume'); }
  function persistScore() { const h = H(); if (h && typeof h.score === 'number' && h.score !== save.score) { save.score = h.score; store(); } }
  M.toTitle = function () {
    const h = H(); M.playing = false; h.screen = 'title'; h.modal = ''; h.mode = 'ride'; setPaused(false); core.tourOn(true); persistScore();
  };
  M.modal = function (n) { snd('init'); snd('click'); const h = H(); if (n === 'carts') h.cartPrev = ''; h.modal = n; };
  M.free = function () {
    snd('init'); snd('click'); const h = H(); M.playing = false; h.screen = 'free'; h.modal = ''; setPaused(false);
    core.tourOn(false); OYO.setMode('ride'); RD.place(SPAWN.x, SPAWN.z, SPAWN.yaw); h.hint = true; setTimeout(() => { h.hint = false; }, 8000);
  };
  M.togglePause = function () { /* Endless Run has its own pause (endless.js); Free Roam has none */ };
  window.addEventListener('pagehide', persistScore);

  /* ---------- settings ---------- */
  function applyQuality() {
    const lv = { perf: 1.0, bal: 1.25, high: 1.5 }[H().quality] || 1.5, S = core.S;
    if (S.engine) { S.engine.setHardwareScalingLevel(1 / Math.min(window.devicePixelRatio || 1, lv)); S.engine.resize(); }
  }
  M.setVol = function (v) { const h = H(); h.vol = +v; save.vol = +v; snd('setVolume', v / 100); store(); };
  M.setMusicVol = function (v) { const h = H(); h.mvol = +v; save.mvol = +v; snd('setMusicVolume', v / 100); store(); };
  M.toggleMusic = function () { const h = H(); h.music = !h.music; save.music = h.music; snd('setMusicOn', h.music); store(); snd('click'); };
  M.toggleSound = function () { const h = H(); h.sound = !h.sound; save.sound = h.sound; snd('setOn', h.sound); store(); snd('click'); };
  function applyHand() { try { document.documentElement.classList.toggle('lefty', !!save.lefty); } catch (e) { /* ok */ } }   // left-handed layout: the touch buttons swap to the left side of the screen
  applyHand();
  M.toggleLefty = function () { const h = H(); h.lefty = !h.lefty; save.lefty = h.lefty; applyHand(); store(); snd('click'); };
  M.setQuality = function (q) { const h = H(); h.quality = q; save.quality = q; applyQuality(); store(); snd('click'); };
  M.resetProgress = function () { save = Object.assign(DEF_SAVE(), { vol: H().vol, sound: H().sound, mvol: H().mvol, music: H().music, quality: H().quality, lefty: H().lefty }); H().score = 0; store(); snd('click'); };

  /* ---------- gameplay hooks (stamina.js wraps pre for Free Roam; Endless Run wraps both) ---------- */
  M.pre = function () {};
  M.post = function () {};

  /* test / debug access */
  M._t = { DEST: () => DEST, SPAWN: () => SPAWN };
})();
