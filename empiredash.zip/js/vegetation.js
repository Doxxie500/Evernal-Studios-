/* EMPIRE DASH — Stage 3 · vegetation.js
   Placement of trees, palms, baobabs, shrubs, grass, flowers, fallen branches, dry leaves,
   canopy shadows and distant woodland. Everything is thin-instanced per 300 m chunk. */
(function () {
  'use strict';
  const HALF = 450, CH = 300;
  let sd = 31337; const rnd = () => { sd = (sd * 16807) % 2147483647; return (sd - 1) / 2147483646; };
  const rr = (a, b) => a + (b - a) * rnd(), pick = a => a[(rnd() * a.length) | 0];
  const sm = (a, b, x) => { x = Math.min(1, Math.max(0, (x - a) / (b - a))); return x * x * (3 - 2 * x); };

  // Row-major (Babylon) instance matrix: scale * Ry(yaw) * Rx(tx) * Rz(tz), translated.
  function compose(out, x, y, z, sx, sy, sz, yaw, tx, tz) {
    const cy = Math.cos(yaw), sy_ = Math.sin(yaw), cx = Math.cos(tx), sxn = Math.sin(tx), cz = Math.cos(tz), szn = Math.sin(tz);
    const rot = (vx, vy, vz) => { let a = vx * cz - vy * szn, b = vx * szn + vy * cz, c = vz; const b2 = b * cx - c * sxn, c2 = b * sxn + c * cx; return [a * cy + c2 * sy_, b2, -a * sy_ + c2 * cy]; };
    const ex = rot(1, 0, 0), ey = rot(0, 1, 0), ez = rot(0, 0, 1);
    out.push(ex[0] * sx, ex[1] * sx, ex[2] * sx, 0, ey[0] * sy, ey[1] * sy, ey[2] * sy, 0, ez[0] * sz, ez[1] * sz, ez[2] * sz, 0, x, y, z, 1);
  }

  const SPEC = {
    baobab: { models: ['baobab'], clear: 17, slope: .14, sc: [.9, 1.25], tints: [[1, 1, .92], [1.08, 1.04, .82]] },
    acacia: { models: ['acacia1', 'acacia2'], clear: 9, slope: .3, sc: [.85, 1.3], tints: [[1, 1, .95], [1.1, 1.05, .8], [.9, 1, .85]] },
    tropical: { models: ['tropical1', 'tropical2'], clear: 8.5, slope: .3, sc: [.85, 1.25], tints: [[1, 1, 1], [1.1, 1.08, .8], [.85, 1, .9], [1.12, .95, .75]] },
    palm: { models: ['palm1', 'palm2'], clear: 6.5, slope: .3, sc: [.85, 1.25], tints: [[1, 1, .95], [1.05, 1.05, .8]] }
  };

  /* Pure planning step: decides every instance. `dims` = {model:{r,h}}. */
  function plan(World, dims) {
    const T = OYOTerrain, tp = T._t, meshH = World.height, inst = {}, nv = { x: 0, y: 1, z: 0 }, stats = { trees: {}, small: {} };
    const key = (name, x, z) => name.startsWith('far') ? (x < 0 ? 0 : 1) * 10 + (z < 0 ? 0 : 1) : Math.min(2, Math.max(0, Math.floor((x + HALF) / CH))) * 10 + Math.min(2, Math.max(0, Math.floor((z + HALF) / CH)));
    function add(name, x, y, z, sx, sy, sz, yaw, tx, tz, cl, cw) {
      const t = inst[name] || (inst[name] = new Map()), k = key(name, x, z); let c = t.get(k); if (!c) t.set(k, c = { m: [], cl: [], cw: [] });
      compose(c.m, x, y, z, sx, sy, sz, yaw, tx || 0, tz || 0); c.cl.push(cl[0], cl[1], cl[2], 1); const w = cw || cl; c.cw.push(w[0], w[1], w[2], 1);
      stats.small[name] = (stats.small[name] || 0) + 1;
    }
    const edgeOf = (x, z) => { const q = World.queryRoad(x, z); let e = q ? q.d - q.hw : 1e9; if (World.siteEdge) { const s = World.siteEdge(x, z); if (s < e) e = s; } return e; };
    const slopeAt = (x, z) => 1 - T.normalAt(x, z, nv).y;
    const sun = World.sunDir, shx = -sun.x / sun.y, shz = -sun.z / sun.y;

    /* ----- ground-cover helpers ----- */
    const gcol = () => { const t = rnd(); return [.82 + t * .3, .8 + t * .22, .7 + t * .12]; };
    function ground(name, x, z, lift, s, minEdge, col) {
      if ((name === 'bush' && rnd() < .4) || (name === 'grass' && rnd() < .25) || (name === 'plant' && rnd() < .35)) return false;   // keep triangle budget in check
      if (Math.abs(x) > HALF - 6 || Math.abs(z) > HALF - 6 || edgeOf(x, z) < minEdge) return false;
      const y = meshH(x, z) + lift, sc = s * (.8 + rnd() * .5); add(name, x, y, z, sc * (.9 + rnd() * .25), sc, sc * (.9 + rnd() * .25), rnd() * 6.283, 0, 0, col || gcol()); return true;
    }
    function leafDrift(x, z, n, r, minEdge) {
      const pal = [[.78, .42, .2], [.7, .5, .22], [.55, .34, .18], [.85, .66, .3], [.6, .55, .22], [.45, .3, .16]];
      for (let i = 0; i < n; i++) {
        const a = rnd() * 6.283, d = Math.sqrt(rnd()) * r, px = x + Math.cos(a) * d, pz = z + Math.sin(a) * d; if (Math.abs(px) > HALF - 6 || Math.abs(pz) > HALF - 6 || edgeOf(px, pz) < minEdge) continue;
        const s = rr(.1, .2), p = pick(pal), l = .85 + rnd() * .3; add('leafDecal', px, meshH(px, pz) + .04, pz, s, 1, s * 1.2, rnd() * 6.283, (rnd() - .5) * .4, (rnd() - .5) * .4, [p[0] * l, p[1] * l, p[2] * l]);
      }
    }
    function around(x, z, r0, r1, n, fn) { for (let i = 0; i < n; i++) { const a = rnd() * 6.283, d = r0 + (r1 - r0) * Math.sqrt(rnd()); fn(x + Math.cos(a) * d, z + Math.sin(a) * d); } }
    const bushTint = () => pick([[.9, 1, .85], [1, 1, .9], [1.1, 1.08, .8], [.8, .95, .8]]);
    const branchAt = (x, z, big) => { if (edgeOf(x, z) < 2.5) return; const s = big ? rr(1.6, 2.3) : rr(.7, 1.3), y = meshH(x, z) + .05 * s; add('branch', x, y, z, s, s, s, rnd() * 6.283, (rnd() - .5) * .25, (rnd() - .5) * .25, [.9 + rnd() * .2, .9 + rnd() * .2, .9 + rnd() * .2]); };

    /* ----- trees ----- */
    const placed = [], occ = new Map(), ok = k => stats.trees[k] = (stats.trees[k] || 0) + 1;
    const hk = (x, z) => Math.floor(x / 10) * 1000 + Math.floor(z / 10);
    function placeTree(kind, x, z, understory) {
      const spec = SPEC[kind]; if (Math.abs(x) > HALF - 14 || Math.abs(z) > HALF - 14) return false;
      if (edgeOf(x, z) < spec.clear) return false;
      const mname = pick(spec.models), d = dims[mname], s = rr(spec.sc[0], spec.sc[1]), crown = d.r * s;
      if (slopeAt(x, z) > spec.slope) return false;
      const h = meshH(x, z); tp.paintAt(x, z, h, 1, 30); if (tp.P[2] > .5) return false;
      for (let ix = -3; ix <= 3; ix++) for (let iz = -3; iz <= 3; iz++) { const a = occ.get(hk(x + ix * 10, z + iz * 10)); if (a) for (const e of a) { const need = kind === 'baobab' || e.kind === 'baobab' ? (crown + e.crown) * .75 : (crown + e.crown) * .55; if (Math.hypot(e.x - x, e.z - z) < need) return false; } }
      const e = { x, z, crown, kind }; placed.push(e); const kk = hk(x, z); (occ.get(kk) || occ.set(kk, []).get(kk)).push(e); ok(kind);
      const tint = pick(spec.tints), wl = .88 + rnd() * .2, yaw = rnd() * 6.283, sxz = s * rr(.92, 1.1);
      add(mname, x, h - .3 * s, z, sxz, s, sxz, yaw, 0, 0, [tint[0] * (.95 + rnd() * .1), tint[1] * (.95 + rnd() * .1), tint[2]], [wl, wl, wl]);
      // painted canopy shadow, thrown away from the sun
      const hs = d.h * s * .55, bx = x + shx * hs, bz = z + shz * hs, w = crown * 2.1, ln = w * 1.35, dx = bx - x, dz = bz - z;
      add('blob', bx, meshH(bx, bz) + .22, bz, kind === 'palm' ? w * 1.2 : w, 1, ln, Math.atan2(dx, dz), 0, 0, [1, 1, 1]);
      if (understory !== false) {
        const cr = Math.max(2.4, crown * .9);
        if (kind === 'baobab') { around(x, z, 4.5, 9, 6, (px, pz) => ground('bush', px, pz, -.05, rr(.8, 1.3), 3.2, bushTint())); around(x, z, 4, 8, 2, (px, pz) => branchAt(px, pz, true)); around(x, z, 1, 8, 6, (px, pz) => ground('grass', px, pz, -.02, rr(.9, 1.5), 1.8)); leafDrift(x, z, 22, 8, 1.5); }
        else if (kind === 'palm') { around(x, z, 1.6, 4.5, 2, (px, pz) => ground('grass', px, pz, -.02, rr(.9, 1.5), 1.8)); around(x, z, 1.5, 4, 1, (px, pz) => ground('plant', px, pz, -.03, rr(.9, 1.4), 2.2, bushTint())); leafDrift(x, z, 5, 4, 1.5); if (rnd() < .5) around(x, z, 2, 5, 1, (px, pz) => branchAt(px, pz, false)); }
        else if (kind === 'acacia') { around(x, z, 2, cr + 1, 4, (px, pz) => ground('grass', px, pz, -.02, rr(1, 1.6), 1.8)); if (rnd() < .5) around(x, z, 3, cr, 1, (px, pz) => ground('dryBush', px, pz, -.05, rr(.8, 1.2), 3, [1.05, 1, .85])); leafDrift(x, z, 8, cr, 1.5); if (rnd() < .35) around(x, z, 2, cr, 1, (px, pz) => branchAt(px, pz, false)); }
        else { around(x, z, 1.8, cr, 4, (px, pz) => ground('bush', px, pz, -.05, rr(.8, 1.4), 3.2, bushTint())); around(x, z, 1.5, cr, 3, (px, pz) => ground('grass', px, pz, -.02, rr(.9, 1.5), 1.8)); around(x, z, 2, cr, 2, (px, pz) => ground('plant', px, pz, -.03, rr(.9, 1.4), 2.2, bushTint())); leafDrift(x, z, 16, cr, 1.5); if (rnd() < .5) around(x, z, 2, cr, 1, (px, pz) => branchAt(px, pz, false)); }
      }
      return true;
    }

    // 1. ancient baobabs — isolated, on open, gentle ground
    for (let t = 0, n = 0; t < 900 && n < 12; t++) { const x = rr(-400, 400), z = rr(-400, 400); if (placed.some(p => p.kind === 'baobab' && Math.hypot(p.x - x, p.z - z) < 110)) continue; if (placeTree('baobab', x, z)) n++; }
    // 2. woodland groves (tropical trees with palms and a few acacia), thicker in low, moist land
    for (let t = 0, g = 0; t < 600 && g < 15; t++) {
      const cx = rr(-370, 370), cz = rr(-370, 370), R = rr(20, 36); if (edgeOf(cx, cz) < 12 || rnd() > .35 + .65 * sm(4, -8, meshH(cx, cz))) continue; g++;
      const tries = Math.ceil(R * R * 3.14 / 170 * 1.7);
      for (let i = 0; i < tries; i++) { const a = rnd() * 6.283, d = R * Math.sqrt(rnd()); if (rnd() > Math.pow(1 - d / R, .4)) continue; const r = rnd(); placeTree(r < .72 ? 'tropical' : r < .9 ? 'palm' : 'acacia', cx + Math.cos(a) * d, cz + Math.sin(a) * d); }
    }
    // 3. palm oases in low ground
    for (let t = 0, g = 0; t < 700 && g < 9; t++) {
      const cx = rr(-380, 380), cz = rr(-380, 380); if (edgeOf(cx, cz) < 16 || meshH(cx, cz) > -1 + rnd() * 4) continue; g++;
      for (let i = 0, n = 4 + (rnd() * 5 | 0); i < n; i++) { const a = rnd() * 6.283, d = rr(1, 10); placeTree('palm', cx + Math.cos(a) * d, cz + Math.sin(a) * d); }
      around(cx, cz, 2, 11, 7, (px, pz) => ground('bush', px, pz, -.05, rr(.8, 1.3), 3.2, bushTint())); around(cx, cz, 1, 11, 6, (px, pz) => ground('flower', px, pz, -.02, rr(1, 1.5), 2.2, [1, 1, 1]));
    }
    // 4. flat-topped savanna acacias scattered over the grasslands
    for (let t = 0, n = 0; t < 6000 && n < 85; t++) {
      const x = rr(-415, 415), z = rr(-415, 415); if (rnd() > .2 + .8 * sm(.5, .7, World.fbm(x / 140 + 7, z / 140 + 3, 2))) continue; if (placeTree('acacia', x, z)) n++;
    }

    /* ----- roadside plants (never on the road, never blocking it) ----- */
    World.roads.forEach(r => {
      for (let i = 2; i < r.n - 2; i += 2) {
        for (const side of [-1, 1]) {
          if (rnd() > .55) continue; const hw = World.widthAt(r, i) * .5, off = side * (hw + 1.5 + rnd() * 4.5), x = r.x[i] + r.nx[i] * off + (rnd() - .5), z = r.z[i] + r.nz[i] * off + (rnd() - .5), t = rnd();
          if (t < .5) ground('plant', x, z, -.03, rr(.8, 1.4), 1.3, bushTint()); else if (t < .72) ground('flower', x, z, -.02, rr(1, 1.5), 1.3, [1, 1, 1]); else if (t < .94) ground('grass', x, z, -.02, rr(.9, 1.5), 1.3); else ground('dryBush', x, z, -.05, rr(.8, 1.3), 3, [1, .98, .85]);
        }
      }
    });
    // roadside litter: fallen branches and drifts of dry leaves along the verge
    for (let k = 0; k < 40; k++) { const r = pick(World.roads), i = 3 + (rnd() * (r.n - 6) | 0), off = (rnd() < .5 ? -1 : 1) * (World.widthAt(r, i) * .5 + rr(2.5, 7)); branchAt(r.x[i] + r.nx[i] * off, r.z[i] + r.nz[i] * off, false); }
    for (let k = 0; k < 24; k++) { const r = pick(World.roads), i = 3 + (rnd() * (r.n - 6) | 0), off = (rnd() < .5 ? -1 : 1) * (World.widthAt(r, i) * .5 + rr(1.4, 4)); leafDrift(r.x[i] + r.nx[i] * off, r.z[i] + r.nz[i] * off, 12, 2.5, 1.3); }

    /* ----- wild vegetation patches ----- */
    for (let t = 0, g = 0; t < 500 && g < 26; t++) {
      const cx = rr(-400, 400), cz = rr(-400, 400), R = rr(5, 13); if (edgeOf(cx, cz) < R + 6) continue; g++;
      around(cx, cz, 0, R, 6 + (R | 0), (x, z) => ground('bush', x, z, -.05, rr(.8, 1.5), 3, bushTint()));
      around(cx, cz, 0, R, 14 + (R | 0), (x, z) => ground('flower', x, z, -.02, rr(1, 1.6), 2, [1, 1, 1]));
      around(cx, cz, 0, R * 1.1, 28, (x, z) => ground('grass', x, z, -.02, rr(1, 1.7), 1.8));
      around(cx, cz, 0, R, 8, (x, z) => ground('plant', x, z, -.03, rr(.9, 1.5), 2, bushTint()));
    }
    for (let k = 0; k < 10; k++) { const x = rr(-400, 400), z = rr(-400, 400); if (edgeOf(x, z) > 8 && slopeAt(x, z) < .25 && Math.abs(x) < HALF - 10) { if (edgeOf(x, z) < 9) continue; const y = meshH(x, z), s = rr(2, 2.6); add('branch', x, y + .15 * s, z, s, s, s, rnd() * 6.283, 0, (rnd() - .5) * .15, [.85, .82, .8]); } }

    /* ----- dry savanna grass over the open land ----- */
    for (let x = -HALF + 6; x < HALF - 6; x += 10) for (let z = -HALF + 6; z < HALF - 6; z += 10) {
      const px = x + rr(-4, 4), pz = z + rr(-4, 4), e = edgeOf(px, pz); if (e < 1.6) continue;
      const h = meshH(px, pz); tp.paintAt(px, pz, h, 1 - slopeAt(px, pz), e); const dens = tp.P[1] * .95 + tp.P[0] * .1; if (rnd() > dens) continue;
      for (let k = 0, n = 1 + (rnd() < .5 ? 1 : 0); k < n; k++) ground('grass', px + rr(-2, 2), pz + rr(-2, 2), -.02, rr(.9, 1.8), 1.6, [.85 + rnd() * .3, .82 + rnd() * .22, .62 + rnd() * .2]);
      if (rnd() < .06) ground('dryBush', px, pz, -.05, rr(.8, 1.2), 3, [1.05, 1, .85]);
    }

    /* ----- distant woodland beyond the play area (4-triangle trees) ----- */
    let far = 0;
    for (let t = 0; t < 12000 && far < 650; t++) {
      const x = rr(-1100, 1100), z = rr(-1100, 1100); if (Math.max(Math.abs(x), Math.abs(z)) < 458) continue;
      const h = T.baseHeight(x, z); if (h > 75 || rnd() > .15 + .85 * sm(.45, .62, World.fbm(x / 160 + 5, z / 160 + 9, 2))) continue;
      const sl = Math.hypot(T.baseHeight(x + 8, z) - T.baseHeight(x - 8, z), T.baseHeight(x, z + 8) - T.baseHeight(x, z - 8)) / 16; if (sl > .4) continue;
      const s = rr(11, 22), c = .88 + rnd() * .2; add(rnd() < .55 ? 'far2' : 'far1', x, h - .3, z, s, s * rr(.9, 1.15), s, rnd() * 6.283, 0, 0, [c * .86, c * .9, c * .95]); far++;
    }
    try { World.treePts = placed.map(e => [e.x, e.z]); } catch (e) { /* optional: used only by ambient.js */ }
    return { inst, stats };
  }

  /* Create the Babylon meshes (one clone per model part per chunk, thin-instanced). */
  function build(scene, World) {
    const VM = OYOVegModels.create(scene), dims = {}; for (const k in VM.models) dims[k] = { r: VM.models[k].r, h: VM.models[k].h };
    const out = plan(World, dims); let draw = 0, total = 0;
    for (const name in out.inst) {
      const model = VM.models[name];
      out.inst[name].forEach(c => {
        const mbuf = new Float32Array(c.m), n = c.m.length / 16; total += n * model.tris;
        model.parts.forEach(part => {
          const m = part.clone(name + '_c'); m.setEnabled(true); m.thinInstanceSetBuffer('matrix', mbuf, 16, true);
          m.thinInstanceSetBuffer('color', new Float32Array(part.name.endsWith('_wood') ? c.cw : c.cl), 4, true); m.thinInstanceRefreshBoundingInfo(true); m.isPickable = false; m.alwaysSelectAsActiveMesh = false; draw++;
        });
      });
      model.parts.forEach(p => p.dispose());
    }
    return { stats: out.stats, meshes: draw, triangles: total };
  }

  window.OYOVegetation = { build, plan, SPEC };
})();
