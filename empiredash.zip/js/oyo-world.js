/* EMPIRE DASH — oyo-world.js  (Stage 13: the Oyo Kingdom world pack, c. 1650)
   The game launches with ONE world: the Oyo Kingdom (Ọ̀yọ́, seat of the Aláàfin). This file
   (1) defines a tiny world registry — OYOWorlds — so Ife, Ijebu, Benin, Egba… can later be added as separate worlds
       without touching the engine: a future kingdom is just another OYOWorlds.register({ id, name, era, identity, build(scene, World) }) call
       and a different OYOWorlds.current. (Only Oyo exists now — no other kingdom is built.)
   (2) adds the Oyo layer that the existing terrain / compounds / markets / palace / vegetation did not yet have, on top of them:
       • cultivated fields round every farmstead, village and town: yam mounds with vine stakes, maize, guinea-corn (sorghum), cassava, with farm shelters
       • Ṣàngó shrines (patron deity of Oyo): white efun-chalk stones, a red-and-white double-axe oṣé staff, ribbons
       • mariwo (palm-frond fringe) gateways across the village footpaths — the Yoruba mark of a sacred or protected place
       • aso-oke / adire cloth lines in indigo, white, red and ochre; calabash poles
       • village oil palms (ọ̀pẹ) and leafy plants beside compounds — re-using the game's existing palm / plant models (no new textures)
   Everything is hand-built from flat-shaded triangles, baked into ~8 merged meshes (vertex colours, no textures) → a handful of draw calls, ~30k
   triangles, built once at load. Existing gameplay, horse, cart, controls and roads are untouched (all of this is decoration; no collision).
   Self-contained. To remove: delete this file, its boot.js / sw.js entries and the OYOWorlds line in world.js. */
(function () {
  'use strict';
  const B = window.BABYLON; if (!B) return;
  const TAU = Math.PI * 2, clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  /* ---------- world registry (future kingdoms plug in here) ---------- */
  const OYOWorlds = window.OYOWorlds = {
    current: 'oyo', worlds: {},
    register(def) { this.worlds[def.id] = def; return def; },
    info() { return this.worlds[this.current] || null; },
    buildCurrent(scene, World) { const w = this.info(); return w && w.build ? w.build(scene, World) : null; }
  };

  let sd = 1650; const rnd = () => { sd = (sd * 16807) % 2147483647; return (sd - 1) / 2147483646; }, rr = (a, b) => a + (b - a) * rnd(), pick = a => a[(rnd() * a.length) | 0];
  const jit = (c, k) => { const f = 1 + (rnd() - .5) * k; return [clamp(c[0] * f, 0, 1), clamp(c[1] * f, 0, 1), clamp(c[2] * f, 0, 1)]; };

  /* ---------- palette: natural earth, thatch and cloth colours ---------- */
  const COL = {
    soil: [.42, .27, .15], soilD: [.34, .21, .12], mound: [.47, .3, .17], stake: [.38, .27, .15], vine: [.3, .52, .2], vineD: [.22, .42, .16],
    maizeB: [.36, .5, .2], maizeT: [.74, .72, .3], sorgB: [.4, .5, .2], sorgT: [.78, .66, .3], head: [.58, .2, .11], cassS: [.45, .33, .2], cassL: [.26, .5, .2],
    wood: [.36, .24, .13], thatch: [.72, .56, .28], thatchD: [.55, .42, .2], efun: [.95, .93, .86], red: [.72, .13, .1], gourd: [.78, .55, .2], gourdD: [.6, .4, .14],
    mariwo: [.84, .82, .46], mariwoD: [.66, .7, .32], rope: [.5, .38, .22],
    cloth: [[.12, .19, .44], [.08, .12, .3], [.93, .91, .85], [.8, .55, .15], [.7, .18, .12], [.2, .46, .3], [.25, .3, .55]]
  };

  /* ---------- tiny triangle-soup kit ---------- */
  const buf = () => ({ p: [], n: [], c: [], i: [] });
  function tri(G, A, Bp, C, c1, c2, c3) {
    const ux = Bp[0] - A[0], uy = Bp[1] - A[1], uz = Bp[2] - A[2], vx = C[0] - A[0], vy = C[1] - A[1], vz = C[2] - A[2];
    let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx; const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
    if (ny < 0) { nx = -nx; ny = -ny; nz = -nz; }
    const k = G.p.length / 3; c2 = c2 || c1; c3 = c3 || c1;
    G.p.push(A[0], A[1], A[2], Bp[0], Bp[1], Bp[2], C[0], C[1], C[2]); G.n.push(nx, ny, nz, nx, ny, nz, nx, ny, nz);
    G.c.push(c1[0], c1[1], c1[2], 1, c2[0], c2[1], c2[2], 1, c3[0], c3[1], c3[2], 1); G.i.push(k, k + 1, k + 2);
  }
  function quad(G, A, Bp, C, D, c1, c2) { tri(G, A, Bp, C, c1, c1, c2 || c1); tri(G, A, C, D, c1, c2 || c1, c2 || c1); }   // A,B = top edge (c1), C,D = bottom edge (c2)

  function build(scene, World) {
    const H = World.height, S = World.settlements || { sites: [], compounds: [] }, sites = S.sites || [], comps = S.compounds || [];
    const PA = window.OYOPalace && OYOPalace.site;
    const buckets = {}, bk = (x, z) => { const k = (x > 0 ? 1 : 0) + (z > 0 ? 2 : 0); return buckets[k] || (buckets[k] = buf()); };
    const frame = (ox, oz, yaw) => { const c = Math.cos(yaw), s = Math.sin(yaw); return (lx, lz) => [ox + lx * c + lz * s, oz - lx * s + lz * c]; };
    const stats = { fields: 0, shrines: 0, gates: 0, cloth: 0, poles: 0, palms: 0, plants: 0 };

    const clear = (x, z, roadM, compM, extra) => {
      const q = World.queryRoad(x, z); if (q && q.d - q.hw < roadM) return false;
      for (const c of comps) if (Math.hypot(c.x - x, c.z - z) < (c.rc || 8) + compM) return false;
      if (PA && PA.a && Math.hypot(x - PA.x, z - PA.z) < Math.max(PA.a, PA.b) + 22) return false;
      if (extra) for (const e of extra) if (Math.hypot(e.x - x, e.z - z) < e.r) return false;
      return true;
    };

    /* ---------- cultivated fields ---------- */
    const fields = [];
    function plantField(G, ox, oz, yaw, w, d, type) {
      const F = frame(ox, oz, yaw), g = (lx, lz) => { const p = F(lx, lz); return [p[0], H(p[0], p[1]), p[1]]; };
      const nx = Math.ceil(w / 3.5), nz = Math.ceil(d / 3.5);
      for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) {                      // tilled soil, follows the terrain
        const x0 = -w / 2 + i * w / nx, x1 = x0 + w / nx, z0 = -d / 2 + j * d / nz, z1 = z0 + d / nz, up = (a, b) => { const p = g(a, b); p[1] += .06; return p; }, cs = (i + j) & 1 ? COL.soil : COL.soilD;
        quad(G, up(x0, z0), up(x1, z0), up(x1, z1), up(x0, z1), jit(cs, .12));
      }
      const sx = type === 'yam' ? 1.7 : type === 'cassava' ? 1.5 : 1.15, sz = type === 'yam' ? 1.7 : type === 'cassava' ? 1.5 : .9;
      for (let u = -w / 2 + 1; u < w / 2 - .5; u += sx) for (let v = -d / 2 + 1; v < d / 2 - .5; v += sz) {
        if (rnd() < .05) continue; const p = g(u + (rnd() - .5) * .2, v + (rnd() - .5) * .2), x = p[0], y = p[1], z = p[2], k = rr(.85, 1.15);
        if (type === 'yam') {                                                              // raised earth mound + a vine climbing its stake
          const r = .44 * k, hh = .4 * k, top = [x, y + hh, z], ring = []; for (let a = 0; a < 6; a++) ring.push([x + Math.cos(a * TAU / 6) * r, y + .03, z + Math.sin(a * TAU / 6) * r]);
          for (let a = 0; a < 6; a++) tri(G, ring[a], ring[(a + 1) % 6], top, jit(COL.soilD, .1), jit(COL.soilD, .1), jit(COL.mound, .1));
          const sh = 1.5 * k; tri(G, [x - .05, y + hh, z], [x + .05, y + hh, z], [x, y + hh + sh, z], COL.stake, COL.stake, jit(COL.vine, .25)); tri(G, [x, y + hh, z - .05], [x, y + hh, z + .05], [x, y + hh + sh, z], COL.stake, COL.stake, jit(COL.vine, .25));
          tri(G, [x - .32, y + hh + sh * .55, z], [x + .32, y + hh + sh * .6, z], [x, y + hh + sh * .85, z + .05], jit(COL.vineD, .2), jit(COL.vine, .2), jit(COL.vine, .2));   // leaf spread
        } else if (type === 'cassava') {
          const sh = 1.1 * k; tri(G, [x - .04, y, z], [x + .04, y, z], [x + .05, y + sh, z], COL.cassS); const ry = y + sh, R = .55 * k, ring = []; for (let a = 0; a < 6; a++) ring.push([x + Math.cos(a * TAU / 6) * R, ry - .12, z + Math.sin(a * TAU / 6) * R]);
          for (let a = 0; a < 6; a++) tri(G, ring[a], ring[(a + 1) % 6], [x, ry + .1, z], jit(COL.cassL, .25), jit(COL.cassL, .25), jit(COL.vine, .2));
        } else {                                                                           // maize or guinea-corn: crossed blades, grain heads
          const sor = type === 'sorghum', hgt = (sor ? 1.9 : 1.7) * k, bt = sor ? COL.sorgB : COL.maizeB, tp = jit(sor ? COL.sorgT : COL.maizeT, .2), wv = .13;
          tri(G, [x - wv, y, z], [x + wv, y, z], [x + (rnd() - .5) * .25, y + hgt, z], bt, bt, tp); tri(G, [x, y, z - wv], [x, y, z + wv], [x, y + hgt, z + (rnd() - .5) * .25], bt, bt, tp);
          if (sor) { const hy = y + hgt; tri(G, [x - .1, hy - .18, z], [x + .1, hy - .18, z], [x, hy + .12, z], jit(COL.head, .2)); tri(G, [x, hy - .18, z - .1], [x, hy - .18, z + .1], [x, hy + .12, z], jit(COL.head, .2)); }
          else tri(G, [x - .07, y + hgt * .55, z], [x + .07, y + hgt * .55, z], [x + .02, y + hgt * .75, z + .08], [.85, .75, .35]);   // cob
        }
      }
      if (rnd() < .6) {                                                                     // farm shelter (ahéré): four posts, thatched cone, on the field's edge
        const sp = g(w / 2 + 1.8, rr(-d / 3, d / 3)), x = sp[0], y = sp[1], z = sp[2], R = 1.5;
        for (const [a, b] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) quad(G, [x + a * 1.0 - .05, y + 1.3, z + b * 1.0], [x + a * 1.0 + .05, y + 1.3, z + b * 1.0], [x + a * 1.0 + .05, y, z + b * 1.0], [x + a * 1.0 - .05, y, z + b * 1.0], COL.wood);
        const ring = []; for (let a = 0; a < 8; a++) ring.push([x + Math.cos(a * TAU / 8) * R, y + 1.25, z + Math.sin(a * TAU / 8) * R]);
        for (let a = 0; a < 8; a++) tri(G, ring[a], ring[(a + 1) % 8], [x, y + 2.3, z], jit(COL.thatchD, .12), jit(COL.thatchD, .12), jit(COL.thatch, .1));
      }
    }
    function planFields() {
      const placed = [], types = ['yam', 'yam', 'yam', 'maize', 'maize', 'maize', 'sorghum', 'sorghum', 'cassava', 'cassava'];
      sites.forEach(site => {
        const farm = site.type === 'farm', R = site.R || 30, n = farm ? 2 : site.type === 'town' ? (rnd() < .7 ? 2 : 1) : 2;
        let got = 0;
        for (let t = 0; t < 60 && got < n; t++) {
          const a = rnd() * TAU, d = farm ? rr(20, 42) : R * rr(.85, 1.25), x = site.x + Math.sin(a) * d, z = site.z + Math.cos(a) * d, w = rr(15, 21), dd = rr(10, 14), yaw = rnd() * TAU;
          const F = frame(x, z, yaw), pts = [[0, 0], [-w / 2, -dd / 2], [w / 2, -dd / 2], [w / 2, dd / 2], [-w / 2, dd / 2], [0, -dd / 2], [0, dd / 2], [-w / 2, 0], [w / 2, 0]].map(q => F(q[0], q[1]));
          if (Math.abs(x) > 400 || Math.abs(z) > 400) continue;
          if (placed.some(f => Math.hypot(f.x - x, f.z - z) < 26)) continue;
          if (!pts.every(p => clear(p[0], p[1], 7, 6))) continue;
          let lo = 1e9, hi = -1e9; pts.forEach(p => { const h = H(p[0], p[1]); lo = Math.min(lo, h); hi = Math.max(hi, h); }); if (hi - lo > 1.3) continue;
          plantField(bk(x, z), x, z, yaw, w, dd, pick(types)); placed.push({ x, z, r: 14 }); got++; stats.fields++;
        }
      });
      return placed;
    }

    /* ---------- Oyo decorations ---------- */
    function sangoShrine(G, ox, oz, yaw) {                                                  // white efun stones ring + double-axe oṣé staff, red & white ribbons
      const F = frame(ox, oz, yaw), y0 = H(ox, oz), P = (lx, ly, lz) => { const p = F(lx, lz); return [p[0], y0 + ly, p[1]]; };
      for (let a = 0; a < 7; a++) { const ang = a * TAU / 7, x = Math.cos(ang) * 1.35, z = Math.sin(ang) * 1.35, r = rr(.22, .34), h = rr(.28, .45), c = jit(COL.efun, .06); const p = [P(x - r, 0, z), P(x + r, 0, z - r * .3), P(x, 0, z + r), P(x - r * .2, h, z)]; tri(G, p[0], p[1], p[3], c); tri(G, p[1], p[2], p[3], c); tri(G, p[2], p[0], p[3], c); }
      quad(G, P(-.05, 2.7, 0), P(.05, 2.7, 0), P(.07, 0, 0), P(-.07, 0, 0), COL.wood); quad(G, P(0, 2.7, -.05), P(0, 2.7, .05), P(0, 0, .07), P(0, 0, -.07), COL.wood);
      tri(G, P(0, 2.35, 0), P(-.62, 2.75, 0), P(-.62, 1.95, 0), COL.red, COL.red, [.5, .08, .06]); tri(G, P(0, 2.35, 0), P(.62, 2.75, 0), P(.62, 1.95, 0), COL.red, COL.red, [.5, .08, .06]);   // the two axe blades
      tri(G, P(0, 2.35, 0), P(-.3, 2.5, 0), P(-.3, 2.2, 0), COL.efun); tri(G, P(0, 2.35, 0), P(.3, 2.5, 0), P(.3, 2.2, 0), COL.efun);
      tri(G, P(-.12, 2.9, 0), P(.12, 2.9, 0), P(0, 3.15, 0), COL.red);
      for (let k = 0; k < 4; k++) { const lz = (k - 1.5) * .12, c = k & 1 ? COL.red : COL.efun; quad(G, P(-.04, 1.9, lz), P(.04, 1.9, lz), P(.05, 1.1 - k * .08, lz), P(-.05, 1.1 - k * .08, lz), c, jit(c, .1)); }
    }
    function mariwoGate(G, ox, oz, yaw, span) {                                              // palm-frond fringe hung across a footpath
      const F = frame(ox, oz, yaw), y0 = H(ox, oz), P = (lx, ly) => { const p = F(lx, 0); return [p[0], y0 + ly, p[1]]; }, hh = 2.8, hw = span / 2;
      for (const s of [-1, 1]) { const x = s * hw; quad(G, P(x - .06, hh + .15), P(x + .06, hh + .15), P(x + .08, 0), P(x - .08, 0), COL.wood);
        for (let k = 0; k < 5; k++) { const ang = (k - 2) * .3, len = rr(1, 1.4), top = P(x, hh - .1); tri(G, top, P(x + Math.sin(ang) * .35 + .06, hh - .1 - len), P(x + Math.sin(ang) * .35 - .06, hh - .1 - len), COL.mariwo, COL.mariwoD, COL.mariwoD); } }
      quad(G, P(-hw, hh + .04), P(hw, hh + .04), P(hw, hh - .04), P(-hw, hh - .04), COL.rope);
      const n = Math.round(span * 4.2);
      for (let k = 0; k <= n; k++) { const x = -hw + .15 + (span - .3) * k / n, len = rr(.85, 1.3), w = .13; tri(G, P(x - w, hh), P(x + w, hh), P(x + (rnd() - .5) * .1, hh - len), COL.mariwo, COL.mariwo, jit(COL.mariwoD, .2)); }
    }
    function clothLine(G, ox, oz, yaw) {                                                    // aso-oke / adire cloths drying between two poles
      const F = frame(ox, oz, yaw), y0 = H(ox, oz), P = (lx, ly) => { const p = F(lx, 0); return [p[0], y0 + ly, p[1]]; }, hw = 2.7, hh = 2.1;
      for (const s of [-1, 1]) quad(G, P(s * hw - .05, hh + .1), P(s * hw + .05, hh + .1), P(s * hw + .06, 0), P(s * hw - .06, 0), COL.wood);
      quad(G, P(-hw, hh), P(hw, hh), P(hw, hh - .04), P(-hw, hh - .04), COL.rope);
      let x = -hw + .2; while (x < hw - .8) {
        const wd = rr(.7, .95), ln = rr(1.1, 1.7), strips = 3, sw = wd / strips, base = pick(COL.cloth), acc = pick(COL.cloth);
        for (let s = 0; s < strips; s++) { const c = s === 1 ? acc : base, xa = x + s * sw, sag = rr(-.06, .06); quad(G, P(xa, hh - .03), P(xa + sw, hh - .03), P(xa + sw, hh - ln + sag), P(xa, hh - ln - sag), jit(c, .1), jit(c, .2)); }
        x += wd + .12;
      }
    }
    function calabashPole(G, ox, oz, yaw) {                                                 // gourds hung on a forked pole
      const F = frame(ox, oz, yaw), y0 = H(ox, oz), P = (lx, ly) => { const p = F(lx, 0); return [p[0], y0 + ly, p[1]]; };
      quad(G, P(-.05, 2.3), P(.05, 2.3), P(.07, 0), P(-.07, 0), COL.wood); quad(G, P(-.7, 2.2), P(.7, 2.2), P(.7, 2.14), P(-.7, 2.14), COL.rope);
      for (const gx of [-.55, 0, .55]) { const cx = gx, top = P(cx, 1.95), bot = P(cx, 1.3), l = P(cx - .2, 1.55), r = P(cx + .2, 1.55), f = F(cx, .2), fr = [f[0], y0 + 1.55, f[1]], bk2 = F(cx, -.2), bkp = [bk2[0], y0 + 1.55, bk2[1]], c = jit(COL.gourd, .15), cd = COL.gourdD;
        tri(G, top, l, fr, c, cd, c); tri(G, top, fr, r, c, c, cd); tri(G, bot, fr, l, cd, c, cd); tri(G, bot, r, fr, cd, cd, c); tri(G, top, bkp, l, c, cd, cd); tri(G, top, r, bkp, c, cd, cd); tri(G, bot, l, bkp, cd, cd, cd); tri(G, bot, bkp, r, cd, cd, cd); }
    }
    function ringSpot(site, rmin, rmax, extra) {
      for (let t = 0; t < 50; t++) { const a = rnd() * TAU, d = (site.R || 30) * rr(rmin, rmax), x = site.x + Math.sin(a) * d, z = site.z + Math.cos(a) * d; if (Math.abs(x) < 400 && Math.abs(z) < 400 && clear(x, z, 6, 7, extra)) return { x, z }; }
      return null;
    }
    function decorate(avoid) {
      sites.forEach(site => {
        if (site.type === 'farm') return;
        const town = site.type === 'town', R = site.R || 40;
        const shrine = ringSpot(site, .5, .9, avoid); if (shrine && (town || rnd() < .6)) { sangoShrine(bk(shrine.x, shrine.z), shrine.x, shrine.z, rnd() * TAU); avoid.push({ x: shrine.x, z: shrine.z, r: 8 }); stats.shrines++; }
        for (let k = 0, n = town ? 3 : 2; k < n; k++) { const s = ringSpot(site, .45, .95, avoid); if (!s) continue; clothLine(bk(s.x, s.z), s.x, s.z, rnd() * TAU); avoid.push({ x: s.x, z: s.z, r: 7 }); stats.cloth++; }
        for (let k = 0, n = town ? 2 : 1; k < n; k++) { const s = ringSpot(site, .4, .95, avoid); if (!s) continue; calabashPole(bk(s.x, s.z), s.x, s.z, rnd() * TAU); avoid.push({ x: s.x, z: s.z, r: 4 }); stats.poles++; }
      });
      // Ṣàngó shrines beside the Royal Road, and a mariwo gateway across every village footpath
      const royal = World.byId.royal;
      if (royal) [.2, .52, .83].forEach(t => { const i = Math.floor(t * (royal.n - 1)), side = t > .5 ? 1 : -1, off = World.widthAt(royal, i) * .5 + 7, x = royal.x[i] + royal.nx[i] * off * side, z = royal.z[i] + royal.nz[i] * off * side; if (clear(x, z, 5, 8, avoid)) { sangoShrine(bk(x, z), x, z, Math.atan2(royal.tx[i], royal.tz[i])); avoid.push({ x, z, r: 8 }); stats.shrines++; } });
      World.roads.forEach(r => { if (r.cls !== 'path') return; const i = Math.min(r.n - 3, 18); mariwoGate(bk(r.x[i], r.z[i]), r.x[i], r.z[i], Math.atan2(-r.tx[i], -r.tz[i]), World.widthAt(r, i) + 1.7); stats.gates++; });
    }

    /* ---------- village palms & leafy plants: clones of the game's own vegetation meshes (same materials / geometry) ---------- */
    function villagePlants() {
      const find = (name) => { const out = {}; scene.meshes.forEach(m => { if (m.name === name + '_c' && m.material && !out[m.material.name]) out[m.material.name] = m; }); return Object.values(out); };
      const q = new B.Quaternion(), sc = new B.Vector3(), tr = new B.Vector3(), mx = new B.Matrix(), items = { palm2: [], palm1: [], plant: [] };
      comps.forEach(c => {
        if (c.site && c.site.type === 'farm' ? rnd() < .3 : rnd() < .25) return;
        const np = 1 + (rnd() * 2 | 0);
        for (let k = 0; k < np; k++) { const a = rnd() * TAU, d = (c.rc || 8) + rr(4, 9), x = c.x + Math.sin(a) * d, z = c.z + Math.cos(a) * d; if (Math.abs(x) > 410 || Math.abs(z) > 410 || !clear(x, z, 4, 3)) continue; items[rnd() < .6 ? 'palm2' : 'palm1'].push([x, H(x, z), z, rr(.7, .98)]); stats.palms++; }
        for (let k = 0; k < 2; k++) { const a = rnd() * TAU, d = (c.rc || 8) + rr(2.5, 6), x = c.x + Math.sin(a) * d, z = c.z + Math.cos(a) * d; if (Math.abs(x) > 410 || Math.abs(z) > 410 || !clear(x, z, 3.5, 2)) continue; items.plant.push([x, H(x, z) - .05, z, rr(.9, 1.5)]); stats.plants++; }
      });
      for (const name in items) {
        const list = items[name]; if (!list.length) continue; const parts = find(name); if (!parts.length) continue;
        const mb = new Float32Array(list.length * 16), cb = new Float32Array(list.length * 4);
        list.forEach((p, k) => { B.Quaternion.RotationYawPitchRollToRef(rnd() * TAU, 0, 0, q); sc.set(p[3], p[3] * rr(.95, 1.1), p[3]); tr.set(p[0], p[1], p[2]); B.Matrix.ComposeToRef(sc, q, tr, mx); mb.set(mx.m, k * 16); const t = rr(.92, 1.06); cb.set([t, t, t * .97, 1], k * 4); });
        parts.forEach(src => { const m = src.clone(name + '_oyo'); m.setEnabled(true); m.isPickable = false; m.thinInstanceSetBuffer('matrix', mb, 16, true); m.thinInstanceSetBuffer('color', cb, 4, true); m.thinInstanceRefreshBoundingInfo(true); });
      }
    }

    /* ---------- run ---------- */
    const avoid = planFields();
    decorate(avoid);
    try { villagePlants(); } catch (e) { console.warn('Village palms skipped:', e); }
    try { window.OYORoyal && OYORoyal.build({ World, scene, bk, frame, tri, quad, jit, rr, rnd, sangoShrine, mariwoGate, H, stats }); } catch (e) { console.warn('Royal landmarks skipped:', e); }   // Stage 14 (oyo-royal.js)
    const mat = new B.StandardMaterial('oyoPackMat', scene); mat.diffuseColor = new B.Color3(1, 1, 1); mat.specularColor = B.Color3.Black(); mat.emissiveColor = new B.Color3(.14, .1, .07); mat.backFaceCulling = false; mat.zOffset = -2;
    let tris = 0, meshes = 0;
    for (const k in buckets) {
      const G = buckets[k]; if (!G.i.length) continue;
      const m = new B.Mesh('oyoPack' + k, scene), vd = new B.VertexData(); vd.positions = G.p; vd.normals = G.n; vd.colors = G.c; vd.indices = G.i; vd.applyToMesh(m);
      m.material = mat; m.isPickable = false; m.freezeWorldMatrix(); m.refreshBoundingInfo(); tris += G.i.length / 3; meshes++;
    }
    try { const k = document.querySelector('.hud-title .kicker'); const w = OYOWorlds.info(); if (k && w) k.textContent = 'FREE ROAM · ' + w.name.toUpperCase() + ' · ' + w.era; } catch (e) { /* HUD optional */ }
    stats.triangles = tris; stats.meshes = meshes;
    return stats;
  }

  OYOWorlds.register({
    id: 'oyo', name: 'The Yoruba Kingdom', era: 'c. 1650', title: 'Ọ̀yọ́ — seat of the Aláàfin',
    identity: {   // data for the art direction of this world; later kingdoms register their own
      patron: 'Ṣàngó (red & white, double-axe oṣé)', palette: 'savanna ochre, red laterite, thatch gold, indigo & white aso-oke',
      crops: ['yam', 'maize', 'guinea-corn', 'cassava'], motifs: ['mariwo palm-frond gateways', 'efun chalk shrines', 'adire / aso-oke cloth lines', 'calabash poles'],
      landscape: 'open guinea savanna with granite kopjes, baobabs, oil palms and gallery forest'
    },
    build
  });
})();
