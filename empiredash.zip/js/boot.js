/* EMPIRE DASH — boot.js
   Loads everything in the right order and drives the loading screen from REAL progress:
     1. Bootstrap CSS, Babylon.js, every game script and Alpine.js are requested together (scripts still run in order);
        the bar moves each time one of them has genuinely finished loading.
     2. game.js then reports the world-building stages (OYOBoot.world / OYOBoot.step) and calls OYOBoot.ready() only when the
        3D scene has compiled its shaders and can draw a frame. Only then does the loading screen fade away.
   If anything fails to load, the screen says so and offers "Try again" (the old behaviour was a blank page). */
(function () {
  'use strict';

  /* CDN libraries (same versions as before). To run fully offline from your own files, put a copy in the project and change the URL. */
  var CDN = {                                                  // each library lists its main source first, then backup sources that are tried automatically
    bootstrap: ['https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css'],
    babylon: ['https://cdn.babylonjs.com/babylon.js', 'https://cdn.jsdelivr.net/npm/babylonjs/babylon.js', 'https://unpkg.com/babylonjs/babylon.js'],
    alpine: ['https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js', 'https://unpkg.com/alpinejs@3.14.1/dist/cdn.min.js']
  };
  /* Game files, in dependency order (unchanged from the original index.html). */
  var GAME = ['secure-store.js', 'terrain.js', 'veg-models.js', 'vegetation.js', 'buildings.js', 'palace.js', 'villagers.js', 'oyo-world.js', 'oyo-royal.js', 'world.js', 'rig.js', 'horse.js',
    'messenger.js', 'rideanim.js', 'dust.js', 'riding.js', 'cart.js', 'audio.js', 'game.js', 'missions.js', 'roam-fare.js', 'dropoff.js', 'cowrie-road.js', 'obstacles.js', 'stamina.js', 'ambient.js', 'yoruba-music.js', 'endless.js', 'oja.js', 'cart-view.js', 'cart-guard.js'].map(function (f) { return 'js/' + f; });   // all game scripts live in /js

  /* work units: how much each file counts towards the "files" part of the bar (Babylon is by far the largest download) */
  var LIB_SHARE = 0.25;                       // 0 → 25 %: downloading files;  25 → 90 %: building the world;  90 → 100 %: final set-up
  var WORLD_SHARE = 0.65;

  var $ = function (id) { return document.getElementById(id); };
  var boot = $('boot'), fill = $('bootFill'), pct = $('bootPct'), stage = $('bootStage'), bar = boot && boot.querySelector('.boot-bar');
  var B = window.OYOBoot = { p: 0, isReady: false, failed: false, started: false };

  /* ---------------- safety net: one stray error must never snowball. Errors are counted, only the first few are logged. ---------------- */
  var errN = 0, lastNote = 0, noted = 0;
  /* Subtle message: a small pill at the top of the screen that fades by itself. Never blocks play, never asks anything. */
  var noteEl = null, noteT = 0;
  B.note = function (msg, ms) {
    try {
      if (!msg || !document.body) return;
      if (!noteEl) {
        noteEl = document.createElement('div'); noteEl.setAttribute('role', 'status'); noteEl.setAttribute('aria-live', 'polite');
        noteEl.style.cssText = 'position:fixed;left:50%;top:calc(env(safe-area-inset-top,0px) + 8px);transform:translate(-50%,-6px);max-width:86vw;z-index:2147483000;pointer-events:none;' +
          'padding:6px 13px;border-radius:999px;background:rgba(18,12,6,.74);border:1px solid rgba(218,170,73,.38);color:#f6e7c1;font:600 12px/1.35 Nunito,system-ui,sans-serif;' +
          'text-align:center;opacity:0;transition:opacity .35s ease,transform .35s ease;box-shadow:0 2px 10px rgba(0,0,0,.35)';
        document.body.appendChild(noteEl);
      }
      noteEl.textContent = msg; noteEl.style.opacity = '1'; noteEl.style.transform = 'translate(-50%,0)';
      clearTimeout(noteT); noteT = setTimeout(function () { noteEl.style.opacity = '0'; noteEl.style.transform = 'translate(-50%,-6px)'; }, ms || 4800);
    } catch (e) { /* a message must never cause a problem */ }
  };
  function onErr(ev) {
    errN++; if (errN === 6) { try { console.warn('[EMPIRE DASH] further errors are not logged'); } catch (e) { /* ignore */ } }
    var m = String((ev && (ev.message || (ev.reason && ev.reason.message))) || '');
    if (/ResizeObserver|Script error\.?$/i.test(m) || !B.isReady || noted >= 2 || Date.now() - lastNote < 30000) return;   // quiet while loading (the loading screen has its own messages); at most 2 notes, 30 s apart
    noted++; lastNote = Date.now(); B.note('Something small went wrong, but the game is still running.');
  }
  window.addEventListener('error', onErr);
  window.addEventListener('unhandledrejection', function (ev) { onErr(ev); try { ev.preventDefault(); } catch (e) { /* ignore */ } });
  window.addEventListener('offline', function () { B.note('You are offline. The saved copy of the game keeps working.'); });
  try { if (navigator.serviceWorker) navigator.serviceWorker.addEventListener('message', function (ev) { if (ev && ev.data === 'oyo-update') B.note('A new version is ready. It starts next time you open the game.', 6500); }); } catch (e) { /* optional */ }

  /* ---------------- UI ---------------- */
  function set(p, text) {
    if (!boot || B.isReady || B.failed) return;
    p = Math.max(B.p, Math.min(1, p)); B.p = p;
    var n = Math.round(p * 100);
    fill.style.width = n + '%'; pct.textContent = n + '%'; if (bar) bar.setAttribute('aria-valuenow', String(n));
    if (text) stage.textContent = text;
  }
  /* Self-repair: a stale service-worker / cache copy can make a game file fail to load. Once per session: drop the old workers + caches and reload fresh. */
  function heal() {
    try {
      if (sessionStorage.getItem('jagun-healed')) return false; sessionStorage.setItem('jagun-healed', '1');
      var jobs = [];
      if (navigator.serviceWorker && navigator.serviceWorker.getRegistrations) jobs.push(navigator.serviceWorker.getRegistrations().then(function (rs) { return Promise.all(rs.map(function (r) { return r.unregister(); })); }));
      if (window.caches && caches.keys) jobs.push(caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return k.indexOf('jagun-transporter-') === 0 || k.indexOf('jagun-royal-messenger-') === 0; }).map(function (k) { return caches.delete(k); })); }));
      var go = function () { location.replace(location.pathname + '?fresh=' + Date.now()); };
      Promise.all(jobs).then(go, go); setTimeout(go, 2500); return true;
    } catch (e) { return false; }
  }
  function fail(msg) {
    if (B.failed || B.isReady || !boot) return;
    if (/the game file/.test(msg || '') && !window.OYODevHost && navigator.serviceWorker && navigator.serviceWorker.controller && heal()) return;
    B.failed = true;
    boot.classList.add('boot-failed');
    var off = typeof navigator.onLine === 'boolean' && !navigator.onLine;
    $('bootErrorMsg').textContent = (msg || 'Something went wrong while loading the game.') +
      (off ? ' You appear to be offline. Connect to the internet once so the game can save itself for offline play, then try again.' : ' Please check your connection and tap Try again. Your progress is safe.');
    $('bootError').hidden = false; stage.textContent = 'Loading stopped';
    try { console.error('[EMPIRE DASH boot]', msg); } catch (e) { /* ignore */ }
  }
  var retry = $('bootRetry'); if (retry) retry.addEventListener('click', function () { location.reload(); });

  /* The artwork follows the real shape of the screen (also after Settings → Landscape mode turns the page). */
  var art = $('bootArt'), ro;
  function pickArt() {
    var port = boot.clientHeight > boot.clientWidth, want = port ? 'assets/art/scene-port.jpg' : 'assets/art/scene-land.jpg';
    boot.setAttribute('data-orient', port ? 'port' : 'land');
    if (art.getAttribute('src') !== want) art.setAttribute('src', want);
  }
  if (boot && art) { pickArt(); if (window.ResizeObserver) { ro = new ResizeObserver(pickArt); ro.observe(boot); } else window.addEventListener('resize', pickArt); }

  /* ---------------- API used by game.js ---------------- */
  B.set = set;
  B.world = function (f, text) { set(LIB_SHARE + WORLD_SHARE * f, f >= 1 ? 'Finishing the world…' : text); };            // f = 0..1 from World.build
  B.step = function (p, text) { set(p, text); };
  B.yield = function () {                                                                                                  // one repaint between heavy steps (no fixed waiting)
    return new Promise(function (r) {
      var done = false, go = function () { if (!done) { done = true; r(); } };
      try { requestAnimationFrame(function () { setTimeout(go, 0); }); } catch (e) { /* ignore */ }
      setTimeout(go, 60);                                                                                                // rAF does not run in a hidden tab
    });
  };                                   // lets the browser repaint between heavy steps
  B.fail = fail;
  B.begin = function () { B.started = true; };                                                                            // game.js start() has been entered
  B.ready = function () {
    if (!boot || B.isReady || B.failed) return;
    set(1, 'Ready'); B.isReady = true;
    setTimeout(function () {
      boot.classList.add('boot-done');
      setTimeout(function () { if (ro) ro.disconnect(); if (boot.parentNode) boot.parentNode.removeChild(boot); }, 900);
    }, 250);
    try { window.OYOPWA && OYOPWA.register(); } catch (e) { /* optional */ }                                              // service worker after the game is up, so it never competes with loading
    if (badFiles.length) setTimeout(function () { B.note('Some extras could not start. If anything looks wrong, reload the game.', 6000); }, 1200);
  };

  /* ---------------- audio: browsers only allow sound after a tap, so the first tap anywhere unlocks it ---------------- */
  var unlock = ['pointerup', 'touchend', 'keydown', 'click'];
  function unlockAudio() {
    var A = window.OYOAudio;
    if (!A || !A.init) return;
    try { A.init(); } catch (e) { /* audio is optional */ }
    if (A.ctx) unlock.forEach(function (t) { document.removeEventListener(t, unlockAudio, true); });
  }
  unlock.forEach(function (t) { document.addEventListener(t, unlockAudio, true); });

  /* ---------------- loading the files ---------------- */
  var total = 0, doneW = 0, left = 0, badFiles = [];
  function unit(w, label) {
    total += w;
    return function () { doneW += w; set(LIB_SHARE * (doneW / total), label); };
  }
  function css(urls, w, label) {                                                       // tries each source in turn; if none works the game still starts (plainer look) and says so quietly
    var tick = unit(w, label), i = 0, l, to;
    function next() {
      clearTimeout(to);
      if (l && l.parentNode) l.parentNode.removeChild(l);
      if (i >= urls.length) { tick(); try { console.warn('[EMPIRE DASH] interface styles unavailable'); } catch (e) { /* ignore */ } setTimeout(function () { B.note('Some styling could not load, so parts of the menus may look plain.', 6000); }, 4000); return; }
      l = document.createElement('link'); l.rel = 'stylesheet'; l.href = urls[i++];
      l.onload = function () { clearTimeout(to); tick(); }; l.onerror = next;
      to = setTimeout(next, 20000);                                                    // a stuck source: move on to the backup
      document.head.appendChild(l);
    }
    next();
  }
  function js(urls, w, label, what) {                                                  // CDN libraries: tries the main source, then the backups (each a normal script tag, resolves when it has run)
    var tick = unit(w, label);
    return new Promise(function (resolve) {
      var i = 0, s, to, settled = false;
      function attempt() {
        clearTimeout(to);
        if (s && s.parentNode) s.parentNode.removeChild(s);
        if (i >= urls.length) {
          var m = 'Could not load ' + (what || 'a game library') + '.'; settled = true;
          try { fetch(urls[0], { cache: 'no-store', mode: 'no-cors' }).then(function () { fail(m + ' (the download was interrupted)'); }, function () { fail(m + ' (the file could not be fetched)'); }); } catch (e) { fail(m); }
          resolve(false); return;
        }
        var url = urls[i++], last = i >= urls.length;
        if (i > 1) { stage.textContent = 'Trying another download source…'; B.note('First download source was slow. Trying a backup…', 3500); }
        s = document.createElement('script'); s.src = url; s.async = false;
        s.onload = function () { if (settled) return; settled = true; clearTimeout(to); tick(); resolve(true); };
        s.onerror = function () { if (!settled) attempt(); };
        if (!last) to = setTimeout(function () { if (!settled) attempt(); }, 75000);     // a connection that has stalled completely: move on to the next source
        document.head.appendChild(s);
      }
      attempt();
    });
  }
  /* Game files are downloaded as text (in parallel, with retries) and then run in order as inline scripts. This is immune to wrong MIME types,
     "nosniff", a stale service worker answering oddly, and one-off network hiccups, which made a plain <script src> report "could not load". */
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function getText(url, tries) {
    var n = 0;
    function attempt() {
      var u = n === 0 ? url : url + (url.indexOf('?') < 0 ? '?' : '&') + 'r=' + Date.now() + n;
      return fetch(u, { cache: n === 0 ? (navigator.serviceWorker && navigator.serviceWorker.controller ? 'default' : 'no-cache') : 'reload', credentials: 'same-origin' }).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.text();
      }).then(function (t) {
        if (!t || /^\s*</.test(t)) throw new Error('not a script');                 // an HTML error page instead of the file
        return t;
      }).catch(function (e) {
        n++; if (n >= tries) throw e;
        return wait(400 * n).then(attempt);
      });
    }
    return attempt();
  }
  function fetchGame(url) {
    var tick = unit(1, 'Loading game code…');
    return getText(url, 4).then(function (t) { tick(); return t; }, function (e) {
      fail('Could not load the game file ' + url + '. (' + (e && e.message || 'network error') + ')'); throw e;
    });
  }
  function runText(url, text) {
    var s = document.createElement('script');
    s.text = text + '\n//# sourceURL=' + url;
    document.head.appendChild(s); document.head.removeChild(s);
  }

  function load() {
    if (!boot) return;
    set(0, 'Downloading the game…');
    css(CDN.bootstrap, 2, 'Downloading the game…');
    var babylonP = js(CDN.babylon, 14, 'Downloading the 3D engine…', 'the 3D engine (Babylon.js)');
    var files = GAME.map(fetchGame);
    var alpineTick = unit(2, 'Starting the interface…');
    try { var pl = document.createElement('link'); pl.rel = 'preload'; pl.as = 'script'; pl.href = CDN.alpine[0]; document.head.appendChild(pl); } catch (e) { /* optional */ }
    Promise.all([babylonP, Promise.all(files)]).then(function (r) {
      if (B.failed || !r[0]) return;
      var texts = r[1];
      for (var i = 0; i < GAME.length; i++) {
        try { runText(GAME[i], texts[i]); } catch (e) { badFiles.push(GAME[i]); try { console.error('[EMPIRE DASH] error in ' + GAME[i], e); } catch (x) { /* ignore */ } }
      }
      return js(CDN.alpine, 0, 'Starting the interface…', 'the interface library (Alpine.js)').then(function (ok) { if (ok) alpineTick(); });
    }).catch(function () { /* fail() has already shown the message */ });
    // Safety net: if everything downloaded but the game never started (for example Alpine could not run), say so instead of hanging.
    setTimeout(function wait2() {
      if (B.started || B.failed || B.isReady) return;
      if (doneW >= total && total > 0) { fail('The game did not start' + (badFiles.length ? ' (a part of it, ' + badFiles[0] + ', could not run)' : '') + '.'); return; }
      if (!document.hidden && Date.now() - t0 > 90000) { fail('Loading is taking too long.'); return; }
      setTimeout(wait2, 2000);
    }, 12000);
  }
  var t0 = Date.now();
  setTimeout(function () { if (!B.isReady && !B.failed) B.note('Slow connection. Still loading, please keep this screen open.', 5500); }, 25000);
  load();
})();
