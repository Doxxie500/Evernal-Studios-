/* EMPIRE DASH — endless.js  (Stage 18: Endless Run)
   A second, fully separate game mode next to Free Roam.
   - ENDLESS RUN: a procedurally streamed Royal Road that never ends. The road is a pure function of distance (x = roadX(z)), cut into 60 m
     chunks. A fixed pool of chunks is RECYCLED: when the cart moves on, the chunk furthest behind is regenerated in front (the same meshes,
     vertex buffers and instance buffers are rewritten in place, so nothing new is created or leaked while you ride).
     Each chunk carries its own trees, Yoruba compounds, villagers, hedges, obstacles and cowries, seeded per run so every run differs.
     Difficulty rises with distance (denser, nastier obstacle patterns, a slightly faster horse). The run ends when all 3 lives are lost.
   - FREE ROAM is not touched: it keeps its 900 m world, its boundaries (riding.js / game.js clamp to the map) and its own systems.
   Separation: the corridor lives at x ≈ 6000 (far outside the Free Roam map). On start the height function, road query, obstacle list and fog are
   swapped for the endless ones; on quit/menu everything is restored exactly. Only screens 'endless' / 'epause' / 'eover' use this file, and its
   MS.pre/MS.post wrappers stay out of the way (and out of the Free Roam wrappers' way) unless a run is active.
   Reused: horse/cart/riding.js, stamina rules + HUD bar, cowrie look + sound, OYOVegModels trees, OYOBuildings house prototypes + materials,
   the terrain shader (landMat), the royal road texture (roadMat_royal), the sky/sun/fog.
   Stage 40 (Oyo regions c. 1650): seven areas (outskirts, market, royal, farming, forest, village, trade route) are dressed onto the same chunks: see ZN / dressZone.
   To remove: delete this file, its line in boot.js + sw.js, the endless blocks in index.html + style.css, and the `W.endless` line in riding.js. */
(function () {
  'use strict';
  const OYO = window.OYO, MS = OYO && OYO.mission, B = window.BABYLON;
  if (!OYO || !MS || !B || !OYO.core) return;

  /* ---------- HUD state (merged into the Alpine component) ---------- */
  Object.assign(window.OYOUI.state, { pMiss: [], crashFx: false, ePax: '0/4', eDist: '0 m', eLvl: 1, eStage: 'Beginner', eStageN: 1, eHearts: 'Hits 0/3', eHits: 0, eWarn: '', eCart: '', oseOn: false, eOse: 0, oseHot: false, thunder: 0, cState: 'ok', cPctB: 0, cPctW: 0, cBal: 0, repStage: 'ask', repMsg: '', eMag: 0, eBoost: 0, eDbl: 0, ePhase: 0, ePMag: 0, ePBoost: 0, ePDbl: 0, ePPhase: 0, eBest: '0 m', eRes: null, hmTab: 'run', hmSoon: '', eShare: '', eShareImg: '', hmLoc: 0, hmLocs: ['Ogbomọ̀ṣọ́', 'Igbeti', 'Ìgbóho', 'Ṣaki', 'Ìṣẹ́yìn', 'Àgó-Ọ̀jà', 'Kíṣí', 'Òyó-Ilé'], cartSel: 'starter', cartRoyal: false, cartDeliv: 0, cartGoal: 300, cartPct: 0, cartLeft: 300, zoneOn: false, zoneT: '', zoneS: '', zoneN: 0, eTgt: '—', eTgtCap: 'pick-up', locName: 'Oyo Town Outskirts' });
  Object.assign(window.OYOUI.state, { festOn: false, festT: '', festS: '', festE: '', festB: 0 });
  Object.assign(window.OYOUI.state, { homeAsk: false });   // pause menu: "Go back home?" confirmation

  /* ---------- constants ---------- */
  const OX = 6000;                       // corridor centre x — far outside the Free Roam map
  const CL = 60, AHEAD = 9, BEHIND = 2, NCH = AHEAD + BEHIND + 1;
  const OFF = 12.5, SO = sd => sd < 0 ? OFF : 0;               // oncoming carriageway sits OFF m to the player's left (NPC traffic coming towards the player); SO = left-side shift for scenery
  const HW = 5.5, WALL = 12.2, HEDGE = 14;          // road half width (11 m, like the Royal Road), invisible wall, visible hedge
  const FOG = .0022, FOG_FREE = .0011;
  const MAG_T = 15, MAG_R = 26, BOOST_T = 7, BOOST_MUL = 1.9, DBL_T = 22, PHASE_T = 12, PK_SHOW = 170, PK_HIT = 2.4;     // power-up durations (s), magnet reach (m), boost speed multiplier
  const LIVES = 3, NPC_LIVES = 3, INVUL = 1.3, COW_PICK = 2.7, COW_STEP = 2.4, COW_SHOW = 150, COW_PER_LIFE = 40;
  const DRAIN = 1.5, TROT = 10, WALK = 20, REVIVE = 20, TIRING = 22, LOW = 35, EXH_CAP = .6;      // same stamina numbers as missions / Free Roam
  const NOW = () => { try { return window.OYOStore.now(); } catch (e) { return Date.now(); } };      // server time when available
  const KEY = 'jagun_endless_v1';
  const LW = 3.2, SWIPE = 34;                       // lane spacing (3 lanes: -1, 0, +1) and swipe distance in px
  let lane = 0, latV = 0, ghost = 0, prevSteer = 0, galNow = false;
  const GAL = 1.28, GAL_DRAIN = 2.4;                 // GALLOP (hold): horse top speed x1.28, stamina drains 2.4x faster
  const PI = Math.PI;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const sm = (a, b, x) => { x = clamp((x - a) / (b - a), 0, 1); return x * x * (3 - 2 * x); };
  const WARNED = {}, wOnce = (k, e) => { if (WARNED[k] = (WARNED[k] | 0) + 1, WARNED[k] <= 3) { try { console.warn('Endless: ' + k, e); } catch (x) { /* ok */ } } };      // a per-frame problem is reported 3 times, never 60 times a second
  const snd = (f, a, b) => { try { window.OYOAudio && OYOAudio[f] && OYOAudio[f](a, b); } catch (e) { /* audio optional */ } };
  const angDiff = (a, b) => { let d = (b - a) % (PI * 2); if (d > PI) d -= PI * 2; if (d < -PI) d += PI * 2; return d; };

  const E = OYO.endless = { on: false, over: false, paused: false };
  let S = null, W = null, RD = null, scene = null, core = null;
  let built = false, SEED = 1, frame = 0;

  /* ---------- the road: a pure function of z, so every chunk joins the next exactly ---------- */
  const amp = z => .45 + .55 * clamp(z / 6000, 0, 1);                       // gentle at first, more winding further on
  const cx = z => OX + amp(z) * (24 * Math.sin(z / 110) + 10 * Math.sin(z / 47 + 1.3) + 34 * Math.sin(z / 300 + .6));
  const slope = z => (cx(z + .5) - cx(z - .5));
  const yawAt = z => Math.atan2(slope(z), 1);
  const roadY = z => 1.6 * Math.sin(z / 85) + .9 * Math.sin(z / 31 + 2);
  const latOf = (x, z) => (x - cx(z)) / Math.sqrt(1 + slope(z) * slope(z));
  function pt(zc, lat) { const s = slope(zc), l = Math.sqrt(1 + s * s); return [cx(zc) + lat / l, zc - lat * s / l]; }   // point at lateral offset `lat` (normal to the road) from centre row zc
  function hgt(x, z) {
    const a = Math.abs(x - cx(z)), by = roadY(z);
    if (a < 7.5) return by;
    const w = sm(7.5, 34, a); let h = (W.fbm(x / 70, z / 70, 2) - .5) * 12 * w;
    const w2 = sm(55, 130, a); if (w2 > 0) h += w2 * (8 + 34 * W.fbm(x / 180 + 3, z / 180 + 7, 2));
    return by + h;
  }
  const FAKE_ROAD = { id: 'endless', cls: 'royal', w: 11, name: 'The Royal Road · Ọ̀nà Ọba' };
  const fakeQuery = (x, z) => ({ road: FAKE_ROAD, i: 0, d: Math.abs(latOf(x, z)), hw: HW, s: z });

  /* ---------- tiny seeded rng ---------- */
  function rngOf(k) { let a = ((k * 73856093) ^ SEED ^ 0x9e3779b9) >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  /* ---------- persistence ---------- */
  let save = { best: 0, runs: 0, cow: 0, deliv: 0, royal: false, cart: 'starter', bestScore: 0, missions: [], top: [], streak: 0, lastDay: '' };
  /* Saves are signed (secure-store.js). A hand-edited / damaged save is refused and this save starts fresh; only known keys are ever copied in. */
  const ST = window.OYOStore;
  let saveNotice = '';
  (function loadSave() {
    const SAVE_KEYS = ['best', 'runs', 'cow', 'deliv', 'royal', 'cart', 'bestScore', 'missions', 'top', 'streak', 'lastDay', 'dmgB', 'dmgW', 'cartState', 'ose', 'bagAt'];
    let r; try { r = ST ? ST.read(KEY) : { obj: null, state: 'none' }; } catch (e) { r = { obj: null, state: 'none' }; }
    let src = null;
    if (r.state === 'ok') src = r.obj;
    else if (r.state === 'legacy') { if (!ST || ST.legacyOk()) src = r.obj; else saveNotice = 'Your saved progress could not be verified, so it was reset.'; }
    else if (r.state === 'bad') saveNotice = 'Your saved progress was damaged or changed outside the game, so it was reset.';
    if (src) SAVE_KEYS.forEach(k => { if (Object.prototype.hasOwnProperty.call(src, k)) save[k] = src[k]; });
    if (src && r.state === 'legacy') {                                  // an unsigned (pre-launch) save is accepted once, but only up to believable early-game numbers
      save.cow = clamp(+save.cow || 0, 0, 60000); save.deliv = clamp(+save.deliv || 0, 0, 1500); save.best = clamp(+save.best || 0, 0, 20000); save.bestScore = clamp(+save.bestScore || 0, 0, 500000); save.runs = clamp(+save.runs || 0, 0, 5000); save.streak = clamp(+save.streak || 0, 0, 120); save.ose = 0;
      if (+save.deliv < 30) save.royal = false;
    }
  })();
  const SAVE_MAX = { cow: 9999999, deliv: 100000, best: 500000, bestScore: 99999999, runs: 1000000, streak: 3650 };     // sanity ceilings: nobody legitimately reaches these
  save.cow = Math.floor(clamp(+save.cow || 0, 0, SAVE_MAX.cow)); save.runs = Math.floor(clamp(+save.runs || 0, 0, SAVE_MAX.runs));
  save.deliv = Math.floor(clamp(+save.deliv || 0, 0, SAVE_MAX.deliv)); save.royal = !!save.royal || save.deliv >= 30;      // the unlock is permanent once earned
  save.best = Math.round(clamp(+save.best || 0, 0, SAVE_MAX.best)); save.bestScore = Math.round(clamp(+save.bestScore || 0, 0, SAVE_MAX.bestScore)); save.streak = Math.floor(clamp(+save.streak || 0, 0, SAVE_MAX.streak));
  save.lastDay = typeof save.lastDay === 'string' ? save.lastDay.slice(0, 12) : '';
  if (!Array.isArray(save.missions)) save.missions = []; if (!Array.isArray(save.top)) save.top = [];
  save.missions = save.missions.slice(0, 3).filter(m => m && typeof m === 'object').map(m => ({ id: String(m.id), goal: clamp(+m.goal || 0, 0, 1e6), reward: clamp(Math.floor(+m.reward || 0), 0, 500), prog: clamp(+m.prog || 0, 0, 1e6), done: !!m.done, fresh: false }));
  save.top = save.top.slice(0, 5).filter(q => q && typeof q === 'object' && isFinite(+q.s)).map(q => ({ s: Math.round(clamp(+q.s, 0, SAVE_MAX.bestScore)), km: (clamp(+q.km || 0, 0, 5000)).toFixed(2), t: Math.floor(+q.t || 0) }));
  if (save.cart === 'emerald') save.cart = save.royal ? 'royal' : 'starter';          // the Emerald Cart no longer exists: anyone who had it selected moves to the Royal Cart (or the Wooden one)
  delete save.emerald;
  if ((save.cart === 'royal' && !save.royal) || !['starter', 'royal'].includes(save.cart)) save.cart = 'starter';
  const store = () => { try { save.cow = Math.floor(clamp(+save.cow || 0, 0, SAVE_MAX.cow)); } catch (e) { /* ok */ } if (ST) ST.write(KEY, save); else { try { localStorage.setItem(KEY, JSON.stringify(save)); } catch (e) { /* private mode */ } } };
  /* ---------- cart condition: potholes no longer cost a life; they wear the cart. 4+ potholes in one run = the cart is damaged (body / wheels) and must be repaired ---------- */
  const CART_HITS = 4, DMG_STEP = 25, DMG_MAX = 8, REP = { body: 1000, wheel: 750, full: 2500 }, COLLAPSE_SECS = 12;
  save.dmgB = clamp(Math.floor(+save.dmgB || 0), 0, DMG_MAX); save.dmgW = clamp(Math.floor(+save.dmgW || 0), 0, DMG_MAX);
  if (!['ok', 'worn', 'broken'].includes(save.cartState)) save.cartState = 'ok';
  if (!save.dmgB && !save.dmgW) save.cartState = 'ok'; else if (save.cartState === 'ok') save.cartState = 'worn';
  /* ---------- Ose Ṣàngó + rude riders: HIDDEN from players until one week after launch (29 Nov 2026, 00:00 Nigerian time); the admin sees them now through the signed preview link (oja.js) ---------- */
  const OSE_FROM = Date.UTC(2026, 10, 28, 23, 0, 0), OSE_MAX = 9;
  const oseVisible = () => { try { if (window.OYOOseOk === true) return true; } catch (e) { /* storage optional */ } return NOW() >= OSE_FROM; };
  save.ose = clamp(Math.floor(+save.ose || 0), 0, OSE_MAX);                          // Ose Ṣàngó strikes kept for the player until used
  const fmtD = d => d >= 1000 ? (d / 1000).toFixed(2) + ' km' : Math.round(d) + ' m';
  window.OYOUI.state.eBest = fmtD(save.best);

  /* ---------- carts: plain wooden STARTER cart for everyone; the decorated ROYAL cart unlocks at 30 delivered passengers (Endless Run, summed over all runs) ---------- */
  const CART_GOAL = 30;
  let previewCart = null;                                            // a cart only being LOOKED at in the start-menu clip (e.g. the locked Royal cart)
  const cartOwned = id => id === 'starter' || (id === 'royal' && !!save.royal);
  const ownedCart = () => cartOwned(save.cart) ? save.cart : 'starter';                  // the cart the player really owns and selected: never a locked one
  let previewT = 0;                                                  // a locked cart is only shown for a moment, then the tab goes back to the starter cart on its own
  function endPreview() { clearTimeout(previewT); previewT = 0; if (previewCart) { previewCart = null; cartUi(); swapCartModel(); } }
  window.OYOCartSel = () => (previewCart && !E.on) ? previewCart : ownedCart();      // cart.js asks which model to build
  function cartVals() {
    const d = Math.min(save.deliv, CART_GOAL);
    return { cowTotal: save.cow | 0, cartSel: save.cart, cartShow: previewCart || save.cart, cartRoyal: save.royal, cartDeliv: d, cartGoal: CART_GOAL, cartPct: Math.round(d / CART_GOAL * 100), cartLeft: Math.max(0, CART_GOAL - save.deliv) };
  }
  /* Daily bag (Ọjà Ìlú): the 6-hour timer and the random pile both live HERE, in the signed save. There is no public "add cowries" function any more,
     so the console cannot simply hand itself a pile of cowries. */
  const BAG_GAP = 6 * 3600 * 1000, BAG_MIN = 1000, BAG_MAX = 2500;
  save.bagAt = Math.floor(clamp(+save.bagAt || 0, 0, 4e12));                // plain number check only (the phone clock is not trusted at load time)
  if (saveNotice) setTimeout(() => { try { toast(saveNotice); } catch (e) { /* hud not ready */ } }, 6000);
  E.bagLeft = () => Math.max(0, (+save.bagAt || 0) - NOW());
  E.openBag = function () {
    if (E.bagLeft() > 0) return 0;
    const amt = BAG_MIN + Math.floor(Math.random() * (BAG_MAX - BAG_MIN + 1));
    save.bagAt = NOW() + BAG_GAP; save.cow = (save.cow | 0) + amt; store(); cartUi(); return amt;
  };
  E.spendCowries = function (n) { n = Math.floor(+n) || 0; if (n <= 0 || (save.cow | 0) < n) return false; save.cow -= n; store(); cartUi(); return true; };   // Ọjà Ìlú: pay earned cowries
  function cartUi() { const h = OYO.hud; if (h) Object.assign(h, cartVals()); }
  Object.assign(window.OYOUI.state, cartVals());
  E.carts = {
    state: () => ({ selected: save.cart, royalUnlocked: save.royal, delivered: save.deliv, goal: CART_GOAL }),
    select(id) {                                                       // from the start menu (title screen only): swap the hitched cart model
      if (E.on || !['starter', 'royal'].includes(id) || (id === 'royal' && !save.royal)) return false;
      if (id === save.cart) { if (!previewCart) return false; clearTimeout(previewT); previewT = 0; previewCart = null; cartUi(); swapCartModel(); snd('click'); return true; }
      clearTimeout(previewT); previewT = 0; previewCart = null; save.cart = id; store(); cartUi(); swapCartModel();
      snd('click'); return true;
    },
    refresh() { try { const c = OYO.core && OYO.core.S; if (c && c.riding && c.riding.refit) c.riding.refit(); } catch (err) { console.warn('Regalia refit failed', err); } swapCartModel(); },                                    // Ọjà Ìlú equipped a new paint / name board: rebuild the hitched cart
    preview(id) {                                                      // show a cart (even a locked one) with the horse on the road in the start-menu clip; never selects it
      if (E.on || !['starter', 'royal'].includes(id)) return false;
      const want = id === save.cart ? null : id; if (previewCart === want) return false;
      previewCart = want; cartUi(); swapCartModel(); snd('click');
      clearTimeout(previewT); if (want && !cartOwned(want)) previewT = setTimeout(endPreview, 2500);      // not eligible: the tab switches back to the starter cart by itself, long before Ride is pressed
      return true;
    }
  };
  /* a swapped cart must take over the rider's driver seat, or he stays bolted to the disposed one */
  function swapCartModel() {
    try {
      const c = OYO.core && OYO.core.S; if (!(c && c.cart && c.riding && c.riding.built && window.OYOCart)) return;
      const drv = c.riding.driver; c.cart.dispose(); c.cart = null;                  // never leave a disposed cart behind: if the new one fails, the cart guard builds it again
      c.cart = OYOCart.spawnHitched(c.scene, c.world, c.riding);
      if (drv && c.cart) c.riding.setDriver(c.cart); else if (drv) c.riding.setDriver(null);
    } catch (err) { console.warn('Cart swap failed', err); try { const c = OYO.core.S; if (c.riding && c.riding.driver && (!c.cart || !c.cart.hitched)) c.riding.setDriver(null); } catch (e2) { /* ok */ } }
  }


  /* ============================== ASSETS (built once, reused by every run) ============================== */
  const LAT = [-110, -70, -45, -30, -20, -14, -10, -7.5, -5.5, -2.8, 0, 2.8, 5.5, 7.5, 10, 14, 20, 30, 45, 70, 110];
  const GC = LAT.length, GR = 13, RR = 21;                     // ground columns / rows, road rows
  const VSPEC = [['acacia1', 10], ['acacia2', 10], ['palm1', 7], ['palm2', 7], ['baobab', 3], ['tropical1', 8], ['tropical2', 8], ['bush', 56], ['grass', 100], ['flower', 14]];     // Stage 40: roomier caps so the Forest Pathway can grow dense
  const VI = {}; VSPEC.forEach((v, i) => { VI[v[0]] = i; });
  const OSPEC = [['rock', 14], ['mound', 8], ['log', 14], ['gate', 4], ['palace', 1], ['shrine', 3], ['market', 2], ['staff', 3], ['buka', 2], ['bukaP', 2], ['mark', 2], ['pothole', 6], ['granary', 4], ['well', 4]];     // obstacle visual instances per chunk
  const CIRC = 70, CMAX = 16, VMAX = 16;
  const TINTS = { tree: [[1, 1, .95], [1.1, 1.05, .8], [.9, 1, .85]], palm: [[1, 1, .95], [1.05, 1.05, .8]], bush: [[.9, .95, .7], [1, .95, .8], [.8, .9, .6]], grass: [[.9, .85, .62], [1, .92, .7], [.8, .78, .56]] };
  const ROBES = [[1, 1, 1], [.2, .27, .55], [.85, .62, .22], [.7, .22, .18], [.95, .9, .78], [.25, .5, .45]];
  const SKINS = [[.42, .26, .18], [.34, .2, .14], [.5, .32, .22], [.28, .17, .12]];
  const HOUSE_SRC = [['main', 0], ['rect', 0], ['round', 0], ['oval', 0], ['main', 1], ['round', 1]];

  const A = { chunks: [], vm: [], om: [], houseVar: [], houseFree: [], cow: null, cowBuf: null, cowFx: [], vil: null, groundMat: null, roadMat: null, vergeMat: null, idxG: null, idxR: null };
  let curK = -999, startZ = 0, villagerT = 0;

  function stdMat(name, em) { const m = new B.StandardMaterial(name, scene); m.specularColor = B.Color3.Black(); m.emissiveColor = em; return m; }

  function buildVegetation() {
    if (!window.OYOVegModels) return;
    const before = new Set(scene.materials);
    const VM = OYOVegModels.create(scene), keep = new Set(VSPEC.map(v => v[0]));
    const fresh = scene.materials.filter(m => !before.has(m)), swap = new Map();                   // reuse the Free Roam materials/textures instead of keeping a second copy
    fresh.forEach(m => { const old = scene.materials.find(o => before.has(o) && o.name === m.name); if (old) swap.set(m, old); });
    VSPEC.forEach(([name, max]) => {
      const mdl = VM.models[name]; if (!mdl) { A.vm.push(null); return; }
      const parts = mdl.parts.map(p => { const m = p.clone(name + '_endless'); m.material = swap.get(p.material) || p.material; m.setEnabled(false); m.isPickable = false; m.alwaysSelectAsActiveMesh = true; return m; });
      const mat = new Float32Array(NCH * max * 16), col = new Float32Array(NCH * max * 4);
      parts.forEach(m => { m.thinInstanceSetBuffer('matrix', mat, 16, false); m.thinInstanceSetBuffer('color', col, 4, false); m.thinInstanceCount = 0; });
      A.vm.push({ name, max, parts, mat, col, n: 0 });
    });
    for (const k in VM.models) VM.models[k].parts.forEach(p => { try { p.dispose(); } catch (e) { /* ok */ } });
    swap.forEach((old, m) => { try { if (m.diffuseTexture) m.diffuseTexture.dispose(); m.dispose(); } catch (e) { /* ok */ } });
    VM.models = null;
  }

  function buildHouses() {
    const T = window.OYOBuildings && OYOBuildings._t; if (!T || !T.protos || !T.stamp || !T.newSet) return;
    const P = T.protos(), mats = { mud: scene.getMaterialByName('bMud'), thatch: scene.getMaterialByName('bThatch'), wood: scene.getMaterialByName('bWood') };
    if (!mats.mud) return;
    HOUSE_SRC.forEach(([kind, n]) => {
      const pro = P[kind] && P[kind][n]; if (!pro) return;
      [1, -1].forEach(side => {                                                  // door faces the road: right-hand houses face -x, left-hand houses face +x
        const set = T.newSet(); T.stamp(set, pro, 0, 0, 0, -side * PI / 2, 1, [1, 1, 1], [1, 1, 1]);
        const parts = {};
        ['mud', 'thatch', 'wood'].forEach(k => {
          const s = set[k]; if (!s || !s.i.length || !mats[k]) return;
          const m = new B.Mesh('endHouse_' + kind + n + '_' + k, scene), vd = new B.VertexData();
          vd.positions = s.p; vd.normals = s.n; vd.colors = s.c; vd.uvs = s.u; vd.indices = s.i; vd.applyToMesh(m);
          m.material = mats[k]; m.isPickable = false; m.alwaysSelectAsActiveMesh = true; m.setEnabled(false); parts[k] = m;
        });
        A.houseVar.push({ side, parts }); A.houseFree.push([]);
      });
    });
  }
  function houseAcquire(side, rnd) {
    const cands = []; A.houseVar.forEach((v, i) => { if (v.side === side) cands.push(i); }); if (!cands.length) return null;
    const vi = cands[Math.floor(rnd() * cands.length)], free = A.houseFree[vi], v = A.houseVar[vi];
    let set = free.pop();
    if (!set) { set = {}; for (const k in v.parts) set[k] = v.parts[k].clone(v.parts[k].name + '_i'); }
    return { vi, set };
  }
  function houseRelease(h) { for (const k in h.set) h.set[k].setEnabled(false); A.houseFree[h.vi].push(h.set); }

  function buildObstacleMeshes() {
    const mk = (mesh, name, em, max) => {
      const mat = new Float32Array(NCH * max * 16), col = new Float32Array(NCH * max * 4);
      mesh.convertToFlatShadedMesh(); mesh.material = stdMat(name, em); mesh.isPickable = false; mesh.alwaysSelectAsActiveMesh = true;
      mesh.thinInstanceSetBuffer('matrix', mat, 16, false); mesh.thinInstanceSetBuffer('color', col, 4, false); mesh.thinInstanceCount = 0; mesh.setEnabled(false);
      A.om.push({ mesh, max, mat, col, n: 0 });
    };
    mk(B.MeshBuilder.CreatePolyhedron('endRocks', { type: 2, size: 1 }, scene), 'endRockMat', new B.Color3(.24, .2, .17), OSPEC[0][1]);
    mk(B.MeshBuilder.CreateCylinder('endMounds', { diameterTop: .45, diameterBottom: 1.9, height: 1.8, tessellation: 9 }, scene), 'endMoundMat', new B.Color3(.26, .15, .1), OSPEC[1][1]);
    mk(B.MeshBuilder.CreateCylinder('endLogs', { diameter: 1, height: 1, tessellation: 7 }, scene), 'endLogMat', new B.Color3(.24, .15, .1), OSPEC[2][1]);
  }


  /* ---------- Stage 19: landmarks + mariwo gateways (static vertex-coloured meshes, instanced through the same per-chunk buffers as the obstacles) ---------- */
  const DI = { gate: 3, palace: 4, shrine: 5, market: 6, staff: 7, buka: 8, bukaP: 9, mark: 10, pothole: 11, granary: 12, well: 13 };
  let PAXMAX = 4; const FARE = 8;
  const STOP_P = 14, STOP_GAP = 10;                              // stop cycle: 14 chunks (840 m); a pick-up and the nearest drop-off are STOP_GAP chunks = 600 m apart
  /* Destinations for a boarding group: every passenger gets a DIFFERENT drop-off stop (and so a different area). Stops already claimed by someone aboard are skipped, and a
     passenger whose stop was missed still counts as getting off at the very next stop. Candidates are the next drop-off stops in order, so rides stay as short as possible. */
  function planDests(sp, n) {
    const used = {}; (R_.pl || []).forEach(q => { used[q.k > sp.k ? q.k : sp.k + STOP_GAP] = 1; });
    const free = []; for (let i = 0; free.length < n + 2 && i < 12; i++) { const kd = sp.k + STOP_GAP + i * STOP_P; if (!used[kd]) free.push(kd); }
    const out = [];
    for (let i = 0; i < n; i++) { const w = Math.min(free.length, 3), j = Math.floor(Math.random() * w); out.push(free.splice(j, 1)[0]); }     // random among the nearest few, never twice the same
    return out;
  }
  let startTown = 0;                                              // index into AREAS: the town chosen on the start menu (0 = Ogbomọ̀ṣọ́ by default)
  const areaFor = kd => AREAS[(Math.floor(kd / STOP_P) * 3 + startTown) % AREAS.length];     // drop-off chunk -> area
  const AREAS = [['Ogbomọ̀ṣọ́', 6], ['Igbeti', 9], ['Ìgbóho', 12], ['Ṣaki', 15], ['Ìṣẹ́yìn', 18], ['Àgó-Ọ̀jà', 22], ['Kíṣí', 26], ['Òyó-Ilé', 32]];   // drop-off areas and the fare each pays (cowries)
                                   // cart seats / cowries paid per boarded passenger      // indices into A.om (the three obstacle meshes come first)
  const DSPEC = [['gate', 4], ['palace', 1], ['shrine', 3], ['market', 2], ['staff', 3], ['buka', 2], ['bukaP', 2], ['mark', 2], ['pothole', 6], ['granary', 4], ['well', 4]];
  /* realistic pothole mesh (unit size): irregular broken outline, heaved crumbling lip, sheared wall, dark compacted floor; vertex colours carry the dirt, the light does the rest */
  function potholeData() {
    let sd = 9137; const rn = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
    const N = 44, TAU = Math.PI * 2, R0 = .76;
    const edge = a => 1 + .17 * Math.sin(a * 2 + 1.3) + .12 * Math.sin(a * 3 + .4) + .07 * Math.sin(a * 5 + 2.1) + .05 * Math.sin(a * 9 + .7);
    const RG = [[1.42, -.012, [.46, .34, .24], .05], [1.30, .012, [.5, .37, .26], .12], [1.13, .04, [.57, .43, .3], .1], [1.0, .095, [.66, .51, .36], .07], [.9, .06, [.38, .28, .19], .06], [.76, .02, [.2, .14, .1], .06], [.6, .004, [.11, .08, .06], .05], [.3, 0, [.075, .055, .04], .04]];
    const pos = [], col = [], idx = [];
    RG.forEach(([f, y, c, j]) => { for (let i = 0; i < N; i++) { const a = i / N * TAU, r = R0 * f * edge(a) * (1 + (rn() - .5) * 2 * j), s = .86 + rn() * .26, yy = y + (f > .8 && f < 1.2 ? (rn() - .3) * .035 : 0); pos.push(Math.cos(a) * r, yy, Math.sin(a) * r); col.push(Math.min(1, c[0] * s), Math.min(1, c[1] * s), Math.min(1, c[2] * s), 1); } });
    pos.push(.06, -.004, -.04); col.push(.06, .045, .033, 1);
    const L = RG.length, C = L * N;
    for (let r = 0; r < L - 1; r++) for (let i = 0; i < N; i++) { const a = r * N + i, b = r * N + (i + 1) % N, c = (r + 1) * N + i, d = (r + 1) * N + (i + 1) % N; idx.push(a, c, b, b, c, d); }
    for (let i = 0; i < N; i++) idx.push((L - 1) * N + i, C, (L - 1) * N + (i + 1) % N);
    return { pos, idx, col };
  }
  function buildDeco() {
    const C = { mud: [.8, .56, .38], chalk: [.93, .9, .8], thatch: [.58, .45, .22], thatchD: [.45, .34, .17], wood: [.4, .27, .16], earth: [.52, .32, .2], dark: [.1, .06, .04], gold: [.9, .7, .2], red: [.75, .18, .14], blue: [.15, .25, .6], mar: [.84, .82, .46], marD: [.66, .7, .32], stone: [.55, .52, .5] };
    const paint = (m, c) => { const n = m.getTotalVertices(), a = new Float32Array(n * 4); for (let i = 0; i < n; i++) { a[i * 4] = c[0]; a[i * 4 + 1] = c[1]; a[i * 4 + 2] = c[2]; a[i * 4 + 3] = 1; } m.setVerticesData(B.VertexBuffer.ColorKind, a); };
    A.decoMat = new B.StandardMaterial('endDecoMat', scene); A.decoMat.specularColor = B.Color3.Black(); A.decoMat.emissiveColor = new B.Color3(.2, .17, .12);
    A.markMat = new B.StandardMaterial('endMarkMat', scene); A.markMat.specularColor = B.Color3.Black(); A.markMat.emissiveColor = new B.Color3(.05, .13, .36); A.markMat.alpha = .2; A.markMat.zOffset = -4;
    A.potMat = new B.StandardMaterial('endPotMat', scene); A.potMat.specularColor = B.Color3.Black(); A.potMat.emissiveColor = new B.Color3(.07, .058, .045); A.potMat.zOffset = -4;
    DSPEC.forEach(([name, max]) => {
      const L = [], add = (m, x, y, z, ry, rz, c) => { m.rotation.y = ry || 0; m.rotation.z = rz || 0; m.position.set(x, y, z); m.bakeCurrentTransformIntoVertices(); paint(m, c); L.push(m); };
      const box = (x, y, z, w, h, d, c, ry, rz) => add(B.MeshBuilder.CreateBox('d', { width: w, height: h, depth: d }, scene), x, y + h / 2, z, ry, rz, c);
      const cyl = (x, y, z, dt, db, h, t, c) => add(B.MeshBuilder.CreateCylinder('d', { diameterTop: dt, diameterBottom: db, height: h, tessellation: t }, scene), x, y + h / 2, z, 0, 0, c);
      const roof = (x, y, z, w, h, c) => add(B.MeshBuilder.CreateCylinder('d', { diameterTop: 0, diameterBottom: w * 1.4142, height: h, tessellation: 4 }, scene), x, y + h / 2, z, Math.PI / 4, 0, c);
      const fringe = (x0, x1, y, z, n, Lo, Lr) => { for (let i = 0; i <= n; i++) { const l = Lo + Math.random() * Lr; box(x0 + (x1 - x0) * i / n, y - l, z, .2, l, .03, i % 2 ? C.mar : C.marD, 0, (Math.random() - .5) * .22); } };
      if (name === 'gate') {                                              // mariwo (palm-frond) gateway across the road: posts, rope beam, hanging fringe
        cyl(-6.2, -.6, 0, .34, .4, 5.6, 7, C.wood); cyl(6.2, -.6, 0, .34, .4, 5.6, 7, C.wood);
        box(0, 4.45, 0, 12.8, .2, .2, C.wood); box(-6.2, 5, 0, .8, .3, .8, C.gold); box(6.2, 5, 0, .8, .3, .8, C.gold);
        fringe(-6, 6, 4.45, 0, 38, 1.1, .45);
        for (const sx of [-1, 1]) for (let q = 0; q < 5; q++) box(sx * (6.2 + (q - 2) * .22), 4.3 - q * .05, .25, .16, 1.3, .03, q % 2 ? C.mar : C.marD, 0, sx * (q - 2) * .16);
      } else if (name === 'palace') {                                     // Afin (palace): walled compound, gate, tiered throne hall, flanking halls, pennants. +z = front (faces the road)
        box(0, -8, -13, 40, 8.2, 28, C.earth);                                                                  // plinth hides the slope
        box(-11.5, .2, 0, 13, 3.4, 1, C.mud); box(11.5, .2, 0, 13, 3.4, 1, C.mud); box(-18, .2, -13, 1, 3.4, 26, C.mud); box(18, .2, -13, 1, 3.4, 26, C.mud); box(0, .2, -26, 36, 3.4, 1, C.mud);
        box(-4.2, .2, 0, 1.2, 4.6, 1.3, C.chalk); box(4.2, .2, 0, 1.2, 4.6, 1.3, C.chalk); box(0, 3.6, 0, 9, .9, 1.3, C.chalk); roof(0, 4.5, 0, 2.6, 1.6, C.thatch);
        for (const sx of [-18, 18]) { cyl(sx, .2, 0, 2.4, 2.6, 6.4, 8, C.chalk); add(B.MeshBuilder.CreateCylinder('d', { diameterTop: 0, diameterBottom: 3.8, height: 2.8, tessellation: 8 }, scene), sx, 6.6 + 1.4, 0, 0, 0, C.thatch); }
        box(0, .2, -15, 16, 5.2, 10, C.mud); roof(0, 5.4, -15, 11.5, 2.8, C.thatch); box(0, 5.4, -15, 6.5, 3.4, 6.5, C.chalk); roof(0, 8.8, -15, 5.2, 3.2, C.thatchD); cyl(0, 12, -15, .18, .3, 2.6, 6, C.gold);
        for (let i = 0; i < 6; i++) box(-9 + i * 3.6, .2, -9.6, .7, 5.2, .7, C.chalk);
        for (const sx of [-10.5, 10.5]) { box(sx, .2, -8, 5, 3.2, 12, C.mud); roof(sx, 3.4, -8, 7.4, 2.2, C.thatch); }
        for (const sx of [-6.5, 6.5]) { cyl(sx, 0, 4.5, .16, .2, 9.4, 6, C.wood); box(sx + 1, 7.7, 4.5, 1.8, 1.1, .06, sx < 0 ? C.red : C.blue); }
      } else if (name === 'shrine') {                                     // Ṣàngó shrine: chalk-white round house, thatch, mariwo skirt, oṣé double-axe staff
        cyl(0, 0, 0, 3.8, 4, 2.6, 10, C.chalk); add(B.MeshBuilder.CreateCylinder('d', { diameterTop: 0, diameterBottom: 5.6, height: 2.8, tessellation: 10 }, scene), 0, 2.6 + 1.4, 0, 0, 0, C.thatch);
        box(0, 0, 1.95, 1, 1.8, .2, C.dark); fringe(-2.7, 2.7, 2.7, 2.7, 20, .9, .35);
        cyl(3.4, 0, 3.2, .12, .16, 4.2, 6, C.wood); box(3.4, 3.7, 3.2, .08, .7, 1, C.red, 0, .35); box(3.4, 3.7, 3.2, .08, .7, 1, C.red, 0, -.35);
        for (let i = 0; i < 8; i++) { const a = i / 8 * 6.283; box(Math.sin(a) * 4.4, 0, 1 + Math.cos(a) * 4.4, .6, .35, .6, C.stone, a); }
      } else if (name === 'market') {                                     // Ọjà market: rows of cloth-canopied stalls
        const CL_ = [C.red, C.blue, C.gold, [.2, .5, .4], [.7, .35, .6]];
        [[-7, 0], [-2.3, 0], [2.4, 0], [7.1, 0], [-4.6, -5.5], [0, -5.5], [4.6, -5.5]].forEach(([x, z], i) => {
          for (const dx of [-1.5, 1.5]) for (const dz of [-1.1, 1.1]) box(x + dx, 0, z + dz, .14, 2.3, .14, C.wood);
          box(x, 2.3, z, 3.4, .12, 2.8, CL_[i % 5], 0, (i % 2 ? .06 : -.06)); box(x, 0, z, 2.6, .85, 1.1, C.wood);
          cyl(x - .6, .85, z, .5, .9, .6, 7, [.72, .38, .2]); cyl(x + .7, .85, z, .1, 1, .55, 7, [.8, .62, .2]);
        });
      } else if (name === 'buka' || name === 'bukaP') {                   // buka: 4 standing logs + gable roof of dried palm fronds. +z = front (faces the road)
        for (const sx of [-1, 1]) for (const sz of [-1, 1]) cyl(sx * 1.55, -.4, sz * 1.25, .17, .22, 3.0, 6, C.wood);
        box(0, 2.5, 1.25, 3.5, .12, .14, C.wood); box(0, 2.5, -1.25, 3.5, .12, .14, C.wood); box(-1.55, 2.5, 0, .14, .12, 2.6, C.wood); box(1.55, 2.5, 0, .14, .12, 2.6, C.wood);
        box(-1.05, 3.0, 0, 2.3, .2, 3.7, C.thatch, 0, .36); box(1.05, 3.0, 0, 2.3, .2, 3.7, C.thatchD, 0, -.36); box(0, 3.5, 0, .35, .22, 3.8, C.thatchD);
        for (const sx of [-1, 1]) for (let i = 0; i < 15; i++) { const l = .45 + Math.random() * .4; box(sx * 2.13, 2.5 - l * .1 + .1, -1.75 + 3.5 * i / 14, .04, l, .2, i % 2 ? C.thatch : C.mar, 0, sx * (.45 + Math.random() * .15)); }   // dried fronds drooping over the eaves
        if (name === 'buka') {                                            // trader's buka: counter, goods, sacks, cloth sign
          box(0, 0, .95, 2.9, .9, .6, C.wood); box(0, .9, .95, 3.1, .06, .75, [.5, .34, .18]);
          const G = [[.8, .22, .15], [.9, .8, .55], [.95, .55, .15], [.35, .55, .2], [.75, .3, .2], [.9, .8, .55]];
          for (let i = 0; i < 6; i++) cyl(-1.15 + i * .46, .96, .95, 0, .4, .3, 7, G[i]);
          cyl(-1.2, 0, -.8, .45, .55, .55, 7, [.72, .6, .38]); cyl(-.5, 0, -.9, .45, .55, .5, 7, [.66, .52, .32]); cyl(1.1, 0, -.7, .5, .6, .5, 7, [.72, .38, .2]);
          box(0, 2.0, 1.28, 1.7, .5, .04, [.7, .35, .6]);
        } else {                                                          // passenger buka: bench + blue stop sign
          box(0, 0, -.95, 2.6, .45, .5, C.wood); box(0, .45, -1.15, 2.6, .5, .08, C.wood);
          cyl(2.2, 0, 1.7, .1, .12, 2.5, 6, C.wood); box(2.2, 1.9, 1.7, 1.0, .6, .06, [.12, .38, .95]); box(2.2, 2.05, 1.74, .7, .1, .02, C.chalk);
        }
      } else if (name === 'mark') {                                       // blue stopping rectangle painted on the road (2.8 m x 6.4 m)
        box(0, 0, 0, 2.8, .04, 6.4, [.1, .36, .95]);
        box(-1.4, 0, 0, .14, .06, 6.4, [.85, .92, 1]); box(1.4, 0, 0, .14, .06, 6.4, [.85, .92, 1]); box(0, 0, -3.2, 2.94, .06, .14, [.85, .92, 1]); box(0, 0, 3.2, 2.94, .06, .14, [.85, .92, 1]);
        for (const z of [-1.4, 0, 1.4]) { box(-.38, 0, z, .12, .065, .8, [.85, .92, 1], .6); box(.38, 0, z, .12, .065, .8, [.85, .92, 1], -.6); }
      } else if (name === 'pothole') {                                    // pothole: worn rim, black hollow, a patch of deeper shadow
        { const pd = potholeData(), pm = new B.Mesh('d', scene), vd = new B.VertexData(); vd.positions = pd.pos; vd.indices = pd.idx; const nr = []; B.VertexData.ComputeNormals(pd.pos, pd.idx, nr);
          if (nr[1] < 0) { for (let q = 0; q < pd.idx.length; q += 3) { const t = pd.idx[q + 1]; pd.idx[q + 1] = pd.idx[q + 2]; pd.idx[q + 2] = t; } B.VertexData.ComputeNormals(pd.pos, pd.idx, nr); }      // make sure the surface faces up
          vd.normals = nr; vd.colors = pd.col; vd.uvs = new Array(pd.pos.length / 3 * 2).fill(0); vd.applyToMesh(pm); L.push(pm); }
        { let sd = 4417; const sc = (v, f) => v.map(q => Math.min(1, q * f)); const rn = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
          for (let q = 0; q < 8; q++) { const a = rn() * 6.283, d = .1 + rn() * .42, w = .08 + rn() * .13; box(Math.cos(a) * d, .004, Math.sin(a) * d, w, .05 + rn() * .05, w * (.7 + rn() * .6), sc([.5, .45, .38], .7 + rn() * .5), rn() * 3); }   // loose stones and gravel in the hollow
          for (let q = 0; q < 11; q++) { const a = q / 11 * 6.283 + rn() * .4, d = .78 + rn() * .2, w = .13 + rn() * .2; box(Math.cos(a) * d, .055, Math.sin(a) * d, w, .045 + rn() * .04, w * (.6 + rn() * .6), sc([.9, .84, .68], .9 + rn() * .2), rn() * 3); }      // pale broken lumps of crust along the rim: the hole is outlined, so it reads from far away
          for (let q = 0; q < 7; q++) { const a = q / 7 * 6.283 + rn() * .7, d0 = .98 + rn() * .12, ln = .45 + rn() * .5; box(Math.cos(a) * (d0 + ln / 2), .02, Math.sin(a) * (d0 + ln / 2), .028 + rn() * .02, .012, ln, [.1, .07, .05], 1.571 - a); }                        // hairline cracks running out of the rim
          cyl(.1, .004, -.06, .74, .74, .012, 14, [.18, .13, .09]); cyl(.2, .014, -.1, .3, .3, .008, 10, [.36, .33, .32]); }                                                                                               // muddy rain water in the bottom, with a pale sheen
      } else if (name === 'staff') {                                      // Ọ̀pá Ọ̀rànmíyàn: tall tapering stone staff on a stepped base
        box(0, 0, 0, 4.2, .5, 4.2, C.stone); box(0, .5, 0, 2.8, .5, 2.8, C.stone); cyl(0, 1, 0, .45, 1.5, 9.5, 8, [.6, .56, .52]);
      } else if (name === 'granary') {                                    // Yoruba grain store: three round mud bins on stone feet, conical thatch, stake fence. +z = front
        [[-2.4, 0, 1.0], [0, -.7, 1.15], [2.4, .1, .95]].forEach(([x, z, r]) => {
          for (let q = 0; q < 4; q++) { const a = q / 4 * 6.283 + .4; cyl(x + Math.sin(a) * r * .6, 0, z + Math.cos(a) * r * .6, .3, .36, .5, 6, C.stone); }
          cyl(x, .5, z, r * 1.7, r * 1.95, 1.9, 9, C.mud); cyl(x, 1.6, z + r * .95, .5, .5, .05, 6, C.dark);
          add(B.MeshBuilder.CreateCylinder('d', { diameterTop: 0, diameterBottom: r * 2.9, height: 1.4, tessellation: 9 }, scene), x, 2.4 + .7, z, 0, 0, C.thatch);
        });
        for (let i = 0; i < 11; i++) cyl(-4.5 + i * .9, 0, 2.6, .09, .12, 1.1, 5, C.wood);
        box(0, .75, 2.6, 9.4, .07, .07, C.wood);
      } else if (name === 'well') {                                       // village well: stone ring, post-and-beam with a small thatch hood, bucket, trough, water pots
        cyl(0, 0, 0, 2.2, 2.45, .95, 10, C.stone); cyl(0, .9, 0, 1.45, 1.45, .05, 10, C.dark);
        for (const sx of [-1, 1]) cyl(sx * 1.15, 0, 0, .15, .19, 2.7, 6, C.wood);
        box(0, 2.55, 0, 2.7, .15, .15, C.wood); roof(0, 2.65, 0, 2.2, .8, C.thatch); box(0, 1.5, 0, .04, 1.05, .04, C.wood); cyl(0, 1.0, 0, .34, .42, .4, 7, [.5, .34, .18]);
        box(2.4, 0, .9, 1.7, .5, .6, C.wood); box(2.4, .45, .9, 1.5, .05, .42, [.25, .4, .5]);
        cyl(-2.1, 0, .9, .4, .7, .75, 8, [.72, .38, .2]); cyl(-2.9, 0, .5, .35, .62, .65, 8, [.72, .38, .2]);
      }
      const m = B.Mesh.MergeMeshes(L, true, true); m.name = 'endDeco_' + name; m.convertToFlatShadedMesh();
      const buf = new Float32Array(NCH * max * 16), col = new Float32Array(NCH * max * 4);
      m.material = name === 'mark' ? A.markMat : name === 'pothole' ? A.potMat : A.decoMat; m.isPickable = false; m.alwaysSelectAsActiveMesh = true;
      m.thinInstanceSetBuffer('matrix', buf, 16, false); m.thinInstanceSetBuffer('color', col, 4, false); m.thinInstanceCount = 0; m.setEnabled(false);
      A.om.push({ mesh: m, max, mat: buf, col, n: 0 });
    });
  }

  /* ============================== STAGE 40 · OYO REGIONS (c. 1650) ==============================
     Seven areas of the Oyo kingdom, woven into the SAME endless corridor (no extra maps): the run is cut into region segments of 6-9 chunks (360-540 m),
     chosen from the run seed. A region only changes how a chunk is DRESSED: ground colour, tree / house / landmark density, roadside props, people and fog.
     Near a boundary every parameter eases over ~90 m and props pick the old or the new region by chance, so one area melts into the next.
     Props are static vertex-coloured meshes drawn as thin instances through the same per-chunk buffers as the landmarks (no new draw paths, no per-frame work).
     Placement rule: every prop sits >= 7 m from the centre of a carriageway (the cart only ever uses +-3.2 m), except the town gates, whose posts stand at +-6.3 m
     and whose lintel is 4.6 m up. Nothing new has a collision circle, so nothing can ever block a lane. */
  const ZN = [
    { id: 'outskirts', yo: 'Ìgbèríko Òyó', en: 'Oyo Town Outskirts', tint: [1, 1, 1], gr: 1, so: 1, tr: 1, hs: 1, lm: 1, fog: 1, vz: 1.9, mu: 'village' },
    { id: 'market', yo: 'Ọjà Ìlú', en: 'Traditional Marketplace', tint: [1.06, .98, .88], gr: .7, so: 1.15, tr: .7, hs: .8, lm: 1.5, fog: 1, vz: 1.9, mu: 'market' },
    { id: 'royal', yo: 'Ìlú Ọba', en: 'Royal Settlement', tint: [1.04, 1.02, .95], gr: .9, so: 1, tr: .9, hs: .45, lm: 1.15, fog: .95, vz: 2, mu: 'royal' },
    { id: 'farm', yo: 'Ìletò Oko', en: 'Farming Settlement', tint: [.95, 1.07, .82], gr: 1.25, so: 1.1, tr: .6, hs: .7, lm: .6, fog: 1, vz: 1.9, mu: 'village' },
    { id: 'forest', yo: 'Ọ̀nà Igbó', en: 'Forest Pathway', tint: [.72, .95, .66], gr: 1.7, so: .7, tr: 2.6, hs: .04, lm: .12, fog: 1.45, vz: 1.75, mu: 'forest' },
    { id: 'village', yo: 'Abúlé', en: 'Rural Village', tint: [1, .99, .9], gr: 1, so: 1.05, tr: .9, hs: 1.7, lm: 1.1, fog: 1, vz: 1.9, mu: 'village' },
    { id: 'trade', yo: 'Ọ̀nà Òwò', en: 'Ancient Trade Route', tint: [1.13, 1, .8], gr: .45, so: 1.3, tr: .55, hs: .3, lm: .5, fog: .85, vz: 2.35, mu: 'market' }
  ];
  const ZNAMES = AREAS.map(a => a[0]);                                             // carved on the signposts: only places of the Oyo kingdom (the same names the drop-off stops use)
  const ZMSG = ['Ọjà ọ̀la', 'Àpéjọ ìlú', 'Ẹ káàbọ̀', 'Ọba ń bọ̀', 'Ọ̀nà ọba'];          // painted on mud walls: market tomorrow · town meeting · welcome · the king is coming · the king's road
  const ZSPEC = [['zpost', 2]].concat(ZNAMES.map((n, i) => ['zplank' + i, 2]), [['zwall', 2]], ZMSG.map((n, i) => ['zpaint' + i, 2]), ZN.map((n, i) => ['zrplank' + i, 2]), ZN.map((n, i) => ['zrpaint' + i, 2]),
    [['ztgate', 2], ['zbanner', 5], ['zstall', 6], ['zpots', 5], ['zhut', 4], ['zfarm', 4], ['zrest', 1], ['zmark', 2], ['zcomp', 2], ['zpalwall', 3]]);
  const ZI = {}; ZSPEC.forEach((z, i) => { ZI[z[0]] = OSPEC.length + i; });
  ZSPEC.forEach(z => OSPEC.push(z));

  /* region sequence: segments {k0, k1, id} extended lazily from the run seed; the first region of every run is the Oyo Town Outskirts */
  let ZS = [], ZW = { a: 0, b: 0, t: 0, tw: 1 };
  const TW = 45;                                                                   // half-width (m) of the blend around a boundary
  /* the opening region follows the chosen town (AREAS order: Ogbomọ̀ṣọ́ market · Igbeti trade-route hills · Ìgbóho farmland · Ṣaki village · Ìṣẹ́yìn trade route · Àgó-Ọ̀jà town outskirts · Kíṣí forest pathway · Òyó-Ilé royal settlement) */
  const TOWN_ZONE = [1, 6, 3, 5, 4, 0, 4, 2];
  /* every town has its own look for the opening ~500 m, easing back to the normal regions over the next ~700 m: ground colour, fog, vegetation / house / landmark density and which roadside props are favoured (multipliers on the region values) */
  const TN = [
    { tint: [1.06, .97, .86], gr: .8, so: 1.1, tr: .7, hs: 1.3, lm: 1.3, fog: 1, pw: { stall: 1.5, pots: 1.4, banner: 2.5, wall: 1.3 } },            // Ogbomọ̀ṣọ́: busy trading city, bunting everywhere
    { tint: [1.1, 1.08, 1.12], gr: .55, so: 1.35, tr: .5, hs: .5, lm: .55, fog: 1.12, pw: { mark: 1.8, rest: 2.5, sign: 1.4 } },                 // Igbeti: pale marble hills, hazy
    { tint: [.86, 1.14, .76], gr: 1.45, so: .9, tr: .9, hs: .8, lm: .8, fog: 1, pw: { farm: 1.8, hut: 1.5, pots: .6 } },                         // Ìgbóho: lush farmland
    { tint: [1.16, .88, .74], gr: .9, so: 1.2, tr: .7, hs: 1.55, lm: 1.1, fog: .95, pw: { comp: 1.7, wall: 2, pots: 1.6 } },                     // Ṣaki: red-clay compounds
    { tint: [1.18, 1.05, .72], gr: .5, so: 1.3, tr: .5, hs: 1, lm: .9, fog: .82, pw: { banner: 2.4, stall: 1.4, sign: 1.4, mark: 1.3 } },        // Ìṣẹ́yìn: golden dry savanna, weavers' banners
    { tint: [.9, 1, 1.12], gr: 1.1, so: 1, tr: 1.25, hs: 1.1, lm: 1, fog: 1.18, pw: { sign: 1.6, wall: 1.4, comp: 1.2 } },                       // Àgó-Ọ̀jà: cool blue-green outskirts
    { tint: [.64, .9, .6], gr: 1.7, so: .7, tr: 1.9, hs: .15, lm: .25, fog: 1.55, pw: { mark: 2.2, rest: 1.6 } },                                // Kíṣí: deep misty park forest
    { tint: [1.1, .94, 1.08], gr: .85, so: 1, tr: .8, hs: .55, lm: 1.5, fog: .9, pw: { banner: 3, palwall: 1.6 } }                               // Òyó-Ilé: royal purple and gold
  ];
  function zoneReset() { const id = TOWN_ZONE[startTown] != null ? TOWN_ZONE[startTown] : 0; ZS = [{ k0: -999, k1: 8, id }]; ZW = { a: id, b: id, t: 0, tw: 1 }; }
  function zoneEnsure(k) {
    while (ZS[ZS.length - 1].k1 <= k + 4) {
      const last = ZS[ZS.length - 1], rz = rngOf(8800 + ZS.length * 31), len = 6 + Math.floor(rz() * 4);
      let id, n = 0; do { id = Math.floor(rz() * ZN.length); n++; } while ((id === last.id || (ZS.length > 1 && id === ZS[ZS.length - 2].id)) && n < 40);
      ZS.push({ k0: last.k1, k1: last.k1 + len, id });
    }
  }
  function zoneSeg(k) { zoneEnsure(k); for (let i = ZS.length - 1; i >= 0; i--) if (k >= ZS[i].k0) return ZS[i]; return ZS[0]; }
  const zoneIdAt = z => zoneSeg(Math.floor(z / CL)).id;
  function zoneW(z) {                                                              // fills ZW = { a: region before, b: region after, t: 0..1 } for height z
    const k = Math.floor(z / CL), seg = zoneSeg(k), i = ZS.indexOf(seg);
    ZW.a = ZW.b = seg.id; ZW.t = 0;
    const d0 = z - seg.k0 * CL, d1 = z - seg.k1 * CL;
    if (i > 0 && d0 < TW) { ZW.a = ZS[i - 1].id; ZW.t = sm(-TW, TW, d0); }
    else if (d1 > -TW) { zoneEnsure(seg.k1 + 1); ZW.b = ZS[i + 1].id; ZW.t = sm(-TW, TW, d1); }
    ZW.tw = 1 - sm(8 * CL, 30 * CL, z);                                              // how strongly the start town's look still applies here
    return ZW;
  }
  const zp = key => { const a = ZN[ZW.a][key], b = ZN[ZW.b][key], m = TN[startTown][key]; return (a + (b - a) * ZW.t) * (m == null ? 1 : 1 + (m - 1) * ZW.tw); };
  const zt = c => { const a = ZN[ZW.a].tint[c], b = ZN[ZW.b].tint[c]; return (a + (b - a) * ZW.t) * (1 + (TN[startTown].tint[c] - 1) * ZW.tw); };
  const zPick = (z, r) => { zoneW(z); return r < ZW.t ? ZW.b : ZW.a; };           // which region an object at height z belongs to (chosen by chance inside a blend)

  /* hand-made textures: carved settlement names on weathered planks, painted mud-wall announcements (canvas, drawn once, reused by every run) */
  function zoneTex(name, w, h, draw) {
    const t = new B.DynamicTexture(name, { width: w, height: h }, scene, true), c = t.getContext(); draw(c, w, h); t.update(); return t;
  }
  function fitText(c, txt, maxW, size, face) { do { c.font = 'bold ' + size + 'px ' + face; size -= 3; } while (c.measureText(txt).width > maxW && size > 18); }
  const SERIF = '"Fraunces", "Fraunces Local", Georgia, "Times New Roman", serif';
  function drawSign(c, w, h, txt) {
    const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#7a5230'); g.addColorStop(.5, '#6a4527'); g.addColorStop(1, '#583820'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    let s = 7; const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
    for (let i = 0; i < 46; i++) { c.strokeStyle = 'rgba(' + (rnd() < .5 ? '40,24,12' : '150,108,66') + ',' + (.12 + rnd() * .2) + ')'; c.lineWidth = 1 + rnd() * 2; const y = rnd() * h; c.beginPath(); c.moveTo(0, y); c.bezierCurveTo(w * .3, y + (rnd() - .5) * 8, w * .7, y + (rnd() - .5) * 8, w, y + (rnd() - .5) * 6); c.stroke(); }
    c.strokeStyle = '#2d1b0e'; c.lineWidth = 10; c.strokeRect(5, 5, w - 10, h - 10); c.strokeStyle = '#d6a64a'; c.lineWidth = 3; c.strokeRect(17, 17, w - 34, h - 34);
    for (let i = 0; i < 9; i++) { const x = 40 + i * (w - 80) / 8; c.fillStyle = '#d6a64a'; c.beginPath(); c.moveTo(x - 7, 9); c.lineTo(x + 7, 9); c.lineTo(x, 18); c.fill(); c.beginPath(); c.moveTo(x - 7, h - 9); c.lineTo(x + 7, h - 9); c.lineTo(x, h - 18); c.fill(); }   // carved zig-zag border
    c.textAlign = 'center'; c.textBaseline = 'middle'; fitText(c, txt, w - 190, 78, SERIF);
    c.fillStyle = 'rgba(236,200,140,.65)'; c.fillText(txt, w / 2 - 22 + 2.5, h / 2 + 3.5); c.fillStyle = '#1f1208'; c.fillText(txt, w / 2 - 22, h / 2 + 1);        // carved groove: light lower lip, dark cut
    c.fillStyle = '#1f1208'; for (let i = 0; i < 3; i++) { const x = w - 96 + i * 22; c.beginPath(); c.moveTo(x, h / 2 - 22); c.lineTo(x + 18, h / 2); c.lineTo(x, h / 2 + 22); c.lineTo(x + 7, h / 2); c.fill(); }   // » : onward
  }
  function drawPaint(c, w, h, txt, ink, k) {
    c.fillStyle = '#e9dfc6'; c.fillRect(0, 0, w, h);
    let s = 11 + k * 7; const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
    for (let i = 0; i < 160; i++) { c.fillStyle = 'rgba(150,112,72,' + (.04 + rnd() * .08) + ')'; c.fillRect(rnd() * w, rnd() * h, 6 + rnd() * 40, 2 + rnd() * 8); }   // lime-wash streaks of the mud beneath
    c.strokeStyle = '#b9772a'; c.lineWidth = 9; c.strokeRect(10, 10, w - 20, h - 20); c.strokeStyle = ink; c.lineWidth = 4; c.strokeRect(26, 26, w - 52, h - 52);
    for (let i = 0; i < 14; i++) { const x = 40 + i * (w - 80) / 13, up = i % 2; c.fillStyle = up ? ink : '#b9772a'; c.beginPath(); c.moveTo(x - 9, h - 32); c.lineTo(x + 9, h - 32); c.lineTo(x, h - 52 - (up ? 6 : 0)); c.fill(); }   // painted zig-zag (adire-style)
    c.textAlign = 'center'; c.textBaseline = 'middle'; c.save(); c.translate(w / 2, h / 2 - 8); c.rotate((rnd() - .5) * .05); fitText(c, txt, w - 130, 84, SERIF);
    c.fillStyle = 'rgba(60,30,10,.25)'; c.fillText(txt, 3, 4); c.fillStyle = ink; c.fillText(txt, 0, 0); c.restore();
  }

  /* region-entry inscriptions: "Ẹ ń wọ̀" (you are entering) + the region's Yoruba name, with a small English line. Carved into weathered plank / painted in ink on lime-washed mud. */
  function entryLines(c, w, h, yo, en, ink, carved) {
    c.textAlign = 'center'; c.textBaseline = 'middle';
    const y1 = h * .27, y2 = h * .53, y3 = h * .8, cx = carved ? w / 2 - 14 : w / 2;
    c.font = 'bold ' + Math.round(h * .17) + 'px ' + SERIF; c.fillStyle = carved ? 'rgba(236,200,140,.6)' : 'rgba(60,30,10,.25)'; c.fillText('Ẹ ń wọ̀', cx + 2, y1 + 2); c.fillStyle = ink; c.fillText('Ẹ ń wọ̀', cx, y1);
    fitText(c, yo, w - (carved ? 190 : 130), Math.round(h * .38), SERIF); c.fillStyle = carved ? 'rgba(236,200,140,.65)' : 'rgba(60,30,10,.25)'; c.fillText(yo, cx + 2.5, y2 + 3); c.fillStyle = ink; c.fillText(yo, cx, y2);
    c.font = 'italic 600 ' + Math.round(h * .15) + 'px ' + SERIF; c.fillStyle = carved ? 'rgba(236,200,140,.8)' : 'rgba(80,45,20,.8)'; c.fillText('Entering · ' + en, cx, y3);
  }
  function drawEntrySign(c, w, h, yo, en) {
    drawSign(c, w, h, '');                                                           // same carved plank, border and » marks as the place-name boards, then re-cut the wording over the blank groove
    entryLines(c, w, h, yo, en, '#1f1208', true);
  }
  function drawEntryPaint(c, w, h, yo, en, ink, k) {
    drawPaint(c, w, h, '', ink, k); entryLines(c, w, h - 56, yo, en, ink, false);
  }

  function buildZoneDeco() {
    const C = { mud: [.8, .56, .38], mudD: [.66, .45, .3], chalk: [.93, .9, .8], thatch: [.58, .45, .22], thatchD: [.45, .34, .17], wood: [.4, .27, .16], woodL: [.55, .38, .22], earth: [.5, .31, .19], dark: [.1, .06, .04], gold: [.9, .7, .2], red: [.75, .18, .14], blue: [.15, .25, .6], stone: [.55, .52, .5], leaf: [.3, .5, .2], leaf2: [.42, .55, .22], clay: [.72, .38, .2], clayD: [.5, .27, .16] };
    const paint = (m, c) => { const n = m.getTotalVertices(), a = new Float32Array(n * 4); for (let i = 0; i < n; i++) { a[i * 4] = c[0]; a[i * 4 + 1] = c[1]; a[i * 4 + 2] = c[2]; a[i * 4 + 3] = 1; } m.setVerticesData(B.VertexBuffer.ColorKind, a); };
    A.zMat = new B.StandardMaterial('endZoneMat', scene); A.zMat.specularColor = B.Color3.Black(); A.zMat.emissiveColor = new B.Color3(.2, .17, .12);
    const signTx = ZNAMES.map((n, i) => zoneTex('endSignTx' + i, 512, 160, (c, w, h) => drawSign(c, w, h, n)));
    const INK = ['rgb(26,41,107)', 'rgb(140,31,26)', 'rgb(31,92,61)', 'rgb(128,31,26)', 'rgb(26,41,107)'];
    const paintTx = ZMSG.map((n, i) => zoneTex('endPaintTx' + i, 512, 192, (c, w, h) => drawPaint(c, w, h, n, INK[i], i)));
    const entrySignTx = ZN.map((z, i) => zoneTex('endEntrySignTx' + i, 512, 160, (c, w, h) => drawEntrySign(c, w, h, z.yo, z.en)));
    const entryPaintTx = ZN.map((z, i) => zoneTex('endEntryPaintTx' + i, 512, 192, (c, w, h) => drawEntryPaint(c, w, h, z.yo, z.en, INK[i % INK.length], i + 3)));
    const texMat = (name, tx) => { const m = new B.StandardMaterial(name, scene); m.diffuseTexture = tx; m.specularColor = B.Color3.Black(); m.emissiveColor = new B.Color3(.34, .3, .26); m.backFaceCulling = true; return m; };
    const plane = (w, h, y, z) => { const m = B.MeshBuilder.CreatePlane('zpl', { width: w, height: h, sideOrientation: B.Mesh.FRONTSIDE }, scene); m.rotation.y = PI; m.position.set(0, y, z); m.bakeCurrentTransformIntoVertices(); return m; };   // faces +z (the road side)
    ZSPEC.forEach(([name, max]) => {
      let m = null;
      try {
        const L = [], add = (mm, x, y, z, ry, rz, c) => { mm.rotation.y = ry || 0; mm.rotation.z = rz || 0; mm.position.set(x, y, z); mm.bakeCurrentTransformIntoVertices(); paint(mm, c); L.push(mm); };
        const box = (x, y, z, w, h, d, c, ry, rz) => add(B.MeshBuilder.CreateBox('d', { width: w, height: h, depth: d }, scene), x, y + h / 2, z, ry, rz, c);
        const cyl = (x, y, z, dt, db, h, t, c) => add(B.MeshBuilder.CreateCylinder('d', { diameterTop: dt, diameterBottom: db, height: h, tessellation: t }, scene), x, y + h / 2, z, 0, 0, c);
        const cone = (x, y, z, w, h, t, c) => add(B.MeshBuilder.CreateCylinder('d', { diameterTop: 0, diameterBottom: w, height: h, tessellation: t }, scene), x, y + h / 2, z, 0, 0, c);
        const pot = (x, y, z, s, c) => { cyl(x, y, z, s * .55, s * .95, s * .85, 8, c); cyl(x, y + s * .85, z, s * .5, s * .55, s * .18, 8, c); };
        const sc = (v, f) => v.map(q => Math.min(1, q * f));
        if (name === 'zpost') {                                                       // signpost: two carved posts, board, little thatch cap (the name plank is a separate textured mesh)
          for (const sx of [-1, 1]) { cyl(sx * 1.2, -.6, 0, .2, .27, 3.7, 6, C.wood); box(sx * 1.2, -.05, 0, .62, .3, .62, C.stone); for (let q = 0; q < 4; q++) box(sx * 1.2, 1.0 + q * .36, .11, .2, .09, .04, C.gold); }
          box(0, 1.93, -.03, 2.9, 1.04, .12, C.dark); box(0, 3.05, 0, 3.3, .14, .8, C.thatch); box(0, 3.19, 0, 3.0, .1, .5, C.thatchD);
        } else if (name.indexOf('zplank') === 0) { m = plane(2.62, .82, 2.45, .07); m.material = texMat('endSignMat' + name, signTx[+name.slice(6)]); }
        else if (name.indexOf('zrplank') === 0) { m = plane(2.62, .82, 2.45, .07); m.material = texMat('endEntrySignMat' + name, entrySignTx[+name.slice(7)]); }
        else if (name.indexOf('zrpaint') === 0) { m = plane(3.4, 1.27, 1.05, .27); m.material = texMat('endEntryPaintMat' + name, entryPaintTx[+name.slice(7)]); }
        else if (name === 'zwall') {                                                  // mud wall for painted notices: buttresses, lime-washed top band, thatch coping
          box(0, -.4, 0, 4.8, 2.45, .5, C.mud); box(-2.5, -.4, 0, .55, 2.7, .75, C.mudD); box(2.5, -.4, 0, .55, 2.7, .75, C.mudD); box(0, -.4, .02, 5.0, .5, .56, C.earth);
          box(0, 2.0, 0, 5.2, .16, .8, C.thatch); box(0, 2.14, 0, 4.9, .1, .52, C.thatchD);
        } else if (name.indexOf('zpaint') === 0) { m = plane(3.4, 1.27, 1.05, .27); m.material = texMat('endPaintMat' + name, paintTx[+name.slice(6)]); }
        else if (name === 'ztgate') {                                                 // town entrance gate: two thatched mud pylons, carved lintel with inlay and cowrie strings (overhead clearance 3.8 m)
          for (const sx of [-1, 1]) {
            box(sx * 6.3, -.9, 0, 1.55, 5.8, 1.55, C.mud); box(sx * 6.3, 4.1, 0, 1.75, .32, 1.75, C.chalk); box(sx * 6.3, .2, 0, 1.8, .3, 1.8, C.stone);
            add(B.MeshBuilder.CreateCylinder('d', { diameterTop: 0, diameterBottom: 3.0, height: 1.5, tessellation: 4 }, scene), sx * 6.3, 4.9 + .75, 0, PI / 4, 0, C.thatch);
            box(sx * 6.3, 1.2, .8, .95, 1.9, .06, C.dark); for (let q = 0; q < 4; q++) box(sx * 6.3, 1.45 + q * .42, .85, .6, .1, .04, q % 2 ? C.gold : C.red);
          }
          box(0, 4.35, 0, 13.4, .42, .6, C.wood); for (let i = 0; i < 12; i++) box(-5.8 + i * 1.05, 4.42, .32, .55, .26, .05, i % 2 ? C.gold : C.red);
          for (let i = 0; i <= 30; i++) { const l = .45 + (i % 3) * .14, x = -6 + 12 * i / 30; box(x, 4.35 - l, .08, .14, l, .05, i % 2 ? C.chalk : C.gold); }
        } else if (name === 'zbanner') {                                              // pole with a crossbar and two strip-woven (aṣọ òkè) banners
          cyl(0, -.5, 0, .13, .2, 6.5, 6, C.wood); box(0, 5.55, 0, 2.5, .11, .11, C.wood); cone(0, 6.0, 0, .3, .55, 6, C.gold);
          const SET = [[C.red, C.chalk, C.blue, C.gold], [C.blue, C.gold, C.chalk, C.red]];
          [-.62, .62].forEach((x, bi) => { for (let r = 0; r < 11; r++) { const c = SET[bi][r % 4]; box(x, 5.5 - (r + 1) * .24, .02, .9, .24, .05, r % 5 === 4 ? C.dark : c); } for (let f = 0; f < 6; f++) box(x - .35 + f * .14, 2.75, .02, .07, .3, .04, C.gold); });
        } else if (name === 'zstall') {                                               // market stall: posts, counter, thatch canopy with a cloth valance, pots and baskets of produce
          for (const dx of [-1.55, 1.55]) for (const dz of [-1.1, 1.3]) cyl(dx, -.4, dz, .14, .17, 2.9, 6, C.wood);
          box(0, -.2, .75, 3.1, 1.0, .85, C.wood); box(0, .8, .75, 3.35, .07, 1.05, C.woodL);
          box(0, 2.5, .1, 3.9, .15, 3.1, C.thatch, 0, .07); box(0, 2.62, .1, 3.7, .08, 2.7, C.thatchD, 0, .07); box(0, 2.1, 1.62, 3.7, .5, .05, C.red); for (let i = 0; i < 9; i++) box(-1.6 + i * .4, 2.12, 1.66, .2, .22, .03, i % 2 ? C.gold : C.blue);
          pot(-1.0, .87, .75, .6, C.clay); pot(-.35, .87, .75, .5, C.clayD); cyl(.45, .87, .75, .8, .6, .3, 8, [.76, .62, .36]); cyl(.45, 1.16, .75, 0, .6, .2, 8, [.8, .2, .14]); cyl(1.1, .87, .75, .8, .6, .3, 8, [.76, .62, .36]); cyl(1.1, 1.16, .75, 0, .6, .22, 8, [.9, .7, .2]);
          box(0, -.4, -.5, 2.6, .05, 1.8, [.78, .68, .46]);
        } else if (name === 'zpots') {                                                // stacked pottery: terracotta and dark-fired water pots
          [[-.62, 0], [.62, 0], [0, .1]].forEach(([x, z], i) => pot(x, -.05, z, 1.0, i % 2 ? C.clayD : C.clay)); [[-.3, .05], [.3, .08]].forEach(([x, z], i) => pot(x, .8, z, .85, i ? C.clay : C.clayD)); pot(0, 1.55, .06, .7, C.clay);
          pot(1.9, -.05, .5, .8, C.clayD); pot(-1.9, -.05, .4, .9, C.clay); pot(2.5, -.05, -.4, .55, C.clay);
        } else if (name === 'zhut') {                                                 // farm hut: round mud wall, dark doorway, conical thatch with a binding ring
          cyl(0, -.7, 0, 3.2, 3.55, 3.1, 10, C.mud); box(0, -.05, 1.68, .95, 1.8, .12, C.dark); cyl(0, -.7, 0, 3.25, 3.6, .55, 10, C.earth);
          cone(0, 2.4, 0, 5.1, 2.3, 10, C.thatch); cyl(0, 3.4, 0, 2.0, 2.35, .16, 10, C.thatchD); cyl(0, 4.7, 0, .14, .3, .45, 6, C.wood);
        } else if (name === 'zfarm') {                                                // farm plot: raised earth bed, rows of ridges, yam stakes with vines, young crops
          box(0, -.7, 0, 12, .72, 9, C.earth);
          for (let r = 0; r < 6; r++) { const x = -4.5 + r * 1.8; box(x, .02, 0, .95, .38, 8, [.46, .3, .18]); for (let q = 0; q < 4; q++) { const z = -3.2 + q * 2.1 + (r % 2) * .5; if (r % 2) { cyl(x, .35, z, .05, .08, 1.5, 5, C.wood); box(x, 1.5, z, .62, .5, .62, C.leaf); } else { box(x, .38, z, .6, .36, .6, C.leaf2); box(x + .1, .66, z + .2, .34, .2, .34, C.leaf); } } }
        } else if (name === 'zrest') {                                                // resting point on the trade route: thatch shelter on posts, benches, water pot on a stand
          for (const dx of [-2.1, 2.1]) for (const dz of [-1.5, 1.5]) cyl(dx, -.5, dz, .17, .22, 3.2, 6, C.wood);
          box(-1.1, 2.55, 0, 2.9, .14, 4.0, C.thatch, 0, .32); box(1.1, 2.55, 0, 2.9, .14, 4.0, C.thatchD, 0, -.32); box(0, 3.0, 0, .35, .22, 4.1, C.thatchD);
          box(0, -.2, -1.1, 3.6, .22, .6, C.woodL); for (const dx of [-1.5, 1.5]) box(dx, -.5, -1.1, .22, .5, .5, C.wood); box(0, -.2, 1.1, 3.6, .22, .6, C.woodL); for (const dx of [-1.5, 1.5]) box(dx, -.5, 1.1, .22, .5, .5, C.wood);
          for (const dx of [-.5, .5]) cyl(dx, -.5, 0, .1, .16, 1.0, 5, C.wood); box(0, .45, 0, 1.3, .1, .2, C.wood); pot(0, .55, 0, .8, C.clayD); cyl(1.7, 1.9, 1.5, .1, .5, .55, 6, [.74, .6, .3]);
        } else if (name === 'zmark') {                                                // wooden direction marker: post with two carved arrow boards pointing along the route
          cyl(0, -.5, 0, .2, .28, 4.2, 6, C.wood); box(0, -.05, 0, .72, .3, .72, C.stone);
          box(.62, 2.9, .0, 1.5, .42, .09, C.woodL, 0, .03); box(1.38, 2.9, .0, .4, .4, .09, C.woodL, PI / 4 * 0, PI / 4); box(-.62, 2.2, .0, 1.5, .42, .09, C.woodL, 0, -.03); box(-1.38, 2.2, .0, .4, .4, .09, C.woodL, 0, PI / 4);
          for (let q = 0; q < 3; q++) { box(.25 + q * .42, 2.9, .06, .18, .3, .04, C.dark); box(-.25 - q * .42, 2.2, .06, .18, .3, .04, C.dark); }
          cone(0, 3.45, 0, .46, .5, 6, C.gold);
        } else if (name === 'zcomp') {                                                // settlement entrance: mud portal with a thatched hood, flanking walls
          for (const sx of [-1, 1]) { box(sx * 2.0, -.45, 0, 1.2, 3.4, 1.2, C.mud); box(sx * 2.0, 2.4, 0, 1.4, .22, 1.4, C.chalk); add(B.MeshBuilder.CreateCylinder('d', { diameterTop: 0, diameterBottom: 2.4, height: 1.1, tessellation: 4 }, scene), sx * 2.0, 2.65 + .55, 0, PI / 4, 0, C.thatch);
            box(sx * 4.4, -.45, 0, 3.7, 2.2, .55, C.mud); box(sx * 4.4, 1.7, 0, 3.9, .14, .8, C.thatch); }
          box(0, 2.15, 0, 4.4, .4, .75, C.wood); for (let i = 0; i < 5; i++) box(-1.6 + i * .8, 2.22, .4, .45, .25, .04, i % 2 ? C.gold : C.red);
        } else if (name === 'zpalwall') {                                             // royal compound wall: whitened mud, ochre plinth, pillars with thatched finials, painted diamond frieze, pennants
          box(0, -.4, 0, 8.2, 3.1, .6, C.chalk); box(0, -.4, .03, 8.3, .95, .66, C.earth);
          for (let i = 0; i < 5; i++) { box(-4 + i * 2, -.4, 0, .75, 3.9, .85, C.chalk); cone(-4 + i * 2, 3.5, 0, 1.15, .75, 6, C.thatch); }
          for (let i = 0; i < 10; i++) box(-3.6 + i * .8, 1.75, .33, .36, .36, .05, i % 2 ? C.red : C.blue, 0, PI / 4);
          for (const sx of [-4.1, 4.1]) { cyl(sx, -.4, .5, .1, .14, 5.8, 6, C.wood); box(sx + .55, 4.9, .5, 1.0, .65, .04, sx < 0 ? C.red : C.blue); }
        }
        if (!m) { m = B.Mesh.MergeMeshes(L, true, true); m.name = 'endZ_' + name; m.convertToFlatShadedMesh(); m.material = A.zMat; }
      } catch (err) { console.warn('Endless: region prop ' + name + ' skipped', err); m = null; }
      if (!m) { A.om.push({ mesh: new B.Mesh('endZstub_' + name, scene), max: 0, mat: new Float32Array(16), col: new Float32Array(4), n: 0 }); A.om[A.om.length - 1].mesh.setEnabled(false); return; }
      const buf = new Float32Array(NCH * max * 16), col = new Float32Array(NCH * max * 4);
      m.isPickable = false; m.alwaysSelectAsActiveMesh = true; m.thinInstanceSetBuffer('matrix', buf, 16, false); m.thinInstanceSetBuffer('color', col, 4, false); m.thinInstanceCount = 0; m.setEnabled(false);
      A.om.push({ mesh: m, max, mat: buf, col, n: 0 });
    });
  }

  function buildCowries() {
    const paint = (m, c) => { const n = m.getTotalVertices(), a = new Float32Array(n * 4); for (let i = 0; i < n; i++) { a[i * 4] = c[0]; a[i * 4 + 1] = c[1]; a[i * 4 + 2] = c[2]; a[i * 4 + 3] = 1; } m.setVerticesData(B.VertexBuffer.ColorKind, a); };
    const body = B.MeshBuilder.CreateSphere('endCowBody', { diameter: 1, segments: 10 }, scene); body.scaling.set(.62, .4, .92); body.bakeCurrentTransformIntoVertices();
    const slit = B.MeshBuilder.CreateBox('endCowSlit', { width: .08, height: .06, depth: .66 }, scene); slit.position.y = .19; slit.bakeCurrentTransformIntoVertices();
    paint(body, [1, .93, .78]); paint(slit, [.32, .18, .1]);
    const m = A.cow = B.Mesh.MergeMeshes([body, slit], true, true); m.name = 'endCowries';
    const mat = new B.StandardMaterial('endCowMat', scene); mat.diffuseColor = new B.Color3(1, 1, 1); mat.emissiveColor = new B.Color3(.36, .3, .2); mat.specularColor = new B.Color3(.55, .5, .38); mat.specularPower = 24;
    m.material = mat; m.isPickable = false; m.alwaysSelectAsActiveMesh = true;
    A.cowBuf = new Float32Array(NCH * CMAX * 16); m.thinInstanceSetBuffer('matrix', A.cowBuf, 16, false); m.thinInstanceCount = 0; m.setEnabled(false);
    for (let i = 0; i < 6; i++) {
      const r = B.MeshBuilder.CreateTorus('endCowFx' + i, { diameter: 1, thickness: .06, tessellation: 28 }, scene), mt = new B.StandardMaterial('endCowFxMat' + i, scene);
      mt.disableLighting = true; mt.emissiveColor = new B.Color3(1, .82, .38); mt.diffuseColor = B.Color3.Black(); mt.specularColor = B.Color3.Black(); mt.alpha = 0; mt.fogEnabled = false;
      r.material = mt; r.isPickable = false; r.alphaIndex = 42; r.setEnabled(false); A.cowFx.push({ m: r, t: 9, x: 0, y: 0, z: 0 });
    }
  }

  /* livestock: one merged goat-shaped mesh drawn as thin instances (goats at scale 1, cattle scaled up) - a handful of instances, one draw call */
  function buildLivestock() {
    const part = (w, h, d, x, y, z, rx) => { const b = B.MeshBuilder.CreateBox('endLivP', { width: w, height: h, depth: d }, scene); b.position.set(x, y, z); if (rx) b.rotation.x = rx; b.bakeCurrentTransformIntoVertices(); return b; };
    const parts = [part(.4, .44, .95, 0, .72, 0), part(.17, .34, .17, 0, .9, .45, -.5), part(.2, .24, .32, 0, 1.05, .62), part(.05, .05, .22, 0, .86, -.52, .5), part(.04, .22, .04, -.07, 1.24, .54), part(.04, .22, .04, .07, 1.24, .54)];
    for (const sx of [-.14, .14]) for (const sz of [-.32, .32]) parts.push(part(.09, .5, .09, sx, .25, sz));
    const m = B.Mesh.MergeMeshes(parts, true, true); m.name = 'endLivestock'; m.convertToFlatShadedMesh();
    const mat = new Float32Array(LIV_MAX * 16), col = new Float32Array(LIV_MAX * 4);
    m.material = stdMat('endLivMat', new B.Color3(.12, .08, .06)); m.isPickable = false; m.alwaysSelectAsActiveMesh = true;
    m.thinInstanceSetBuffer('matrix', mat, 16, false); m.thinInstanceSetBuffer('color', col, 4, false); m.thinInstanceCount = 0; m.setEnabled(false);
    A.liv = { mesh: m, mat, col };
  }

  function buildVillagers() {
    const robe = B.MeshBuilder.CreateCylinder('endRobe', { diameterTop: .38, diameterBottom: .72, height: 1.25, tessellation: 8 }, scene); robe.position.y = .63; robe.bakeCurrentTransformIntoVertices();
    const head = B.MeshBuilder.CreateSphere('endHead', { diameter: .32, segments: 6 }, scene); head.position.y = 1.42; head.bakeCurrentTransformIntoVertices();
    const max = NCH * VMAX, mat = new Float32Array(max * 16), rc = new Float32Array(max * 4), hc = new Float32Array(max * 4);
    [[robe, rc, 'endRobeMat'], [head, hc, 'endHeadMat']].forEach(([m, c, nm]) => {
      m.material = stdMat(nm, new B.Color3(.12, .08, .06)); m.isPickable = false; m.alwaysSelectAsActiveMesh = true;
      m.thinInstanceSetBuffer('matrix', mat, 16, false); m.thinInstanceSetBuffer('color', c, 4, false); m.thinInstanceCount = 0; m.setEnabled(false);
    });
    A.vil = { robe, head, mat, rc, hc, n: 0 };
  }

  /* ---------- chunk pool: fixed meshes + fixed typed arrays, rewritten in place ---------- */
  function buildChunkPool() {
    A.groundMat = scene.getMaterialByName('landMat') || stdMat('endGroundMat', new B.Color3(.3, .24, .12));
    A.roadMat = scene.getMaterialByName('roadMat_royal') || stdMat('endRoadMat', new B.Color3(.45, .26, .16));
    A.vergeMat = scene.getMaterialByName('vergeMat') || stdMat('endVergeMat', new B.Color3(.4, .28, .18));
    const gi = [], ri = [], vi = [];
    for (let j = 0; j < GR - 1; j++) for (let i = 0; i < GC - 1; i++) { const a = j * GC + i, b = a + 1, c = a + GC, d = c + 1; gi.push(a, c, b, b, c, d); }
    for (let j = 0; j < RR - 1; j++) for (let i = 0; i < 6; i++) { const a = j * 7 + i, b = a + 1, c = a + 7, d = c + 1; ri.push(a, c, b, b, c, d); }
    for (let j = 0; j < RR - 1; j++) for (let i = 0; i < 4; i++) { const a = j * 5 + i, b = a + 1, c = a + 5, d = c + 1; vi.push(a, c, b, b, c, d); }
    const mkMesh = (name, nv, idx, nc, extra) => {
      const m = new B.Mesh(name, scene), vd = new B.VertexData(), pos = new Float32Array(nv * 3), nor = new Float32Array(nv * 3), col = new Float32Array(nv * 4);
      vd.positions = pos; vd.normals = nor; vd.colors = col; vd.indices = idx; if (extra.uv) vd.uvs = extra.uvArr = new Float32Array(nv * 2);
      vd.applyToMesh(m, true);
      const o = { m, pos, nor, col, uv: extra.uvArr || null, tint: null };
      if (extra.tint) { o.tint = new Float32Array(nv * 3); m.setVerticesData('tint', o.tint, true, 3); }
      m.isPickable = false; m.setEnabled(false); return o;
    };
    for (let c = 0; c < NCH; c++) {
      const ch = { idx: -999, ground: mkMesh('endGround' + c, GC * GR, gi, 4, { tint: true }), road: mkMesh('endRoad' + c, 7 * RR, ri, 4, { uv: true }), verge: mkMesh('endVerge' + c, 5 * RR, vi, 4, { uv: false }), road2: mkMesh('endRoadB' + c, 7 * RR, ri, 4, { uv: true }), verge2: mkMesh('endVergeB' + c, 5 * RR, vi, 4, { uv: false }),
        vm: VSPEC.map(([, max]) => ({ a: new Float32Array(max * 16), c: new Float32Array(max * 4), n: 0 })), om: OSPEC.map(([, max]) => ({ a: new Float32Array(max * 16), c: new Float32Array(max * 4), n: 0 })),
        circ: new Float32Array(CIRC * 5), nc: 0, cows: new Float32Array(CMAX * 5), ncw: 0, vil: new Float32Array(VMAX * 8), nv: 0, houses: [], stops: [], pp: [] };
      ch.ground.m.material = A.groundMat; ch.ground.m.freezeWorldMatrix();
      ch.road.m.material = A.roadMat; ch.road.m.hasVertexAlpha = true; ch.road.m.alphaIndex = 2; ch.road.m.freezeWorldMatrix();
      ch.verge.m.material = A.vergeMat; ch.verge.m.hasVertexAlpha = true; ch.verge.m.alphaIndex = 1; ch.verge.m.freezeWorldMatrix();
      ch.road2.m.material = A.roadMat; ch.road2.m.hasVertexAlpha = true; ch.road2.m.alphaIndex = 2; ch.road2.m.freezeWorldMatrix();
      ch.verge2.m.material = A.vergeMat; ch.verge2.m.hasVertexAlpha = true; ch.verge2.m.alphaIndex = 1; ch.verge2.m.freezeWorldMatrix();
      const spi = []; for (let j = 0; j < SN - 1; j++) for (let i = 0; i < 6; i++) { const a = j * 7 + i, b = a + 1, c2 = a + 7, d = c2 + 1; spi.push(a, c2, b, b, c2, d); }
      ch.spurs = []; ch.sp = [0, 1].map(q => { const o = mkMesh('endSpur' + q + '_' + c, 7 * SN, spi, 4, { uv: true }); o.m.material = A.roadMat; o.m.hasVertexAlpha = true; o.m.alphaIndex = 2; return o; });
      A.chunks.push(ch);
    }
  }

  function ensureBuilt() {
    if (built) return;
    const step = (fn, label) => { try { fn(); } catch (e) { console.warn('Endless: ' + label + ' skipped', e); } };
    buildChunkPool();                                   // essential: if this throws, start() reports it
    step(buildVegetation, 'trees'); step(buildHouses, 'houses'); step(buildObstacleMeshes, 'obstacles'); step(buildDeco, 'landmarks'); step(buildZoneDeco, 'regions'); step(buildCowries, 'cowries'); step(buildPickups, 'pickups'); step(buildVillagers, 'villagers'); step(buildLivestock, 'livestock');
    built = true;
  }

  /* ============================== CHUNK GENERATION ============================== */
  const lvlOf = d => Math.min(12, 1 + Math.floor(Math.max(0, d) / 500));

  /* ---------- PROGRESSIVE DIFFICULTY (Endless Run only: Free Roam and the missions never read any of this) ----------
     Five stages by distance. Inside a stage obstacle spacing and horse speed still ease up continuously, so there are no sudden jumps.
     FAIRNESS: every chunk's obstacle layout is checked by laneFeasible() before it is built. The check assumes the horse is at its TOP gallop speed
     for that distance and that one lane change needs LANE_T seconds; a layout that can't be ridden through from EVERY starting lane is dropped. */
  const STAGES = [['Beginner', 0], ['Experienced', 700], ['Skilled', 1800], ['Expert', 3500], ['Master Messenger', 6000]];
  const stageOf = d => { let s = 1; for (let i = 1; i < STAGES.length; i++) if (d >= STAGES[i][1]) s = i + 1; return s; };
  const speedMul = d => { d = Math.max(0, d); return 1.12 * (1 + .3 * Math.min(1, d / 4500) + .15 * clamp((d - 4500) / 4500, 0, 1)); };      // x1.12 at the start (12% quicker than before so the player can catch the royal-cart rider), x1.46 at 4.5 km, x1.62 from 9 km
  const TOP = 15, LANE_T = .4;                                      // TOP = riding.js top speed (m/s); LANE_T = seconds budgeted per lane change
  const vGal = d => TOP * speedMul(d) * GAL;                          // fastest the cart goes without a speed boost
  const HERD_LAT = 7, LIV_MAX = 8, LIV_TINT = [[[.95, .92, .85], [.55, .38, .26], [.22, .18, .15]], [[.62, .42, .28], [.9, .86, .78], [.32, .25, .2]]];   // verge distance animals wait at; goat / cow coat colours
  const HERD_GAP = 30;                                                // metres between crossing animals (room for two lane changes at top speed)
  const DIFF = [
    { types: ['rock', 'rock', 'mound', 'log', 'rock', 'mound'], slack: 7, herd: 0, cw: { g: 2.6, n: [3, 3], step: 1, weave: .4, zig: 0, margin: 1.7 } },
    { types: ['rock', 'mound', 'log', 'rock2', 'log2', 'pothole', 'rock', 'log'], slack: 5, herd: .10, cw: { g: 2.3, n: [3, 3], step: 1.1, weave: .5, zig: 0, margin: 1.7 } },
    { types: ['rock', 'log', 'rock2', 'log2', 'pothole', 'chicane', 'pass', 'mixed', 'chicane'], slack: 4, herd: .16, cw: { g: 1.9, n: [3, 2], step: 1.25, weave: .6, zig: 0, margin: 1.55 } },
    { types: ['rock2', 'log2', 'pothole', 'chicane', 'pass', 'mixed', 'gauntlet', 'chicane', 'gauntlet', 'log'], slack: 2.5, herd: .2, cw: { g: 1.6, n: [3, 2], step: 1.4, weave: .7, zig: .4, margin: 1.4 } },
    { types: ['pothole', 'chicane', 'pass', 'mixed', 'gauntlet', 'gauntlet', 'chicane', 'mixed', 'rock2', 'log2'], slack: 1.5, herd: .26, cw: { g: 1.3, n: [3, 2], step: 1.55, weave: .8, zig: .6, margin: 1.25 } }
  ];
  /* Can the cart get through this chunk's obstacles? plan = [{z, lane, zr}] (lane -1..1, zr = half-length of the blocked stretch in metres).
     Dynamic programme over 1 m steps: stay in a lane while it is free, or change to the next lane over n steps with BOTH lanes free the whole time.
     Must succeed from each of the 3 possible starting lanes, finishing the chunk in a settled lane, so consecutive chunks always chain. */
  function laneFeasible(plan, z0, L, TL) {
    const n = Math.max(1, Math.ceil(TL)), blk = [new Uint8Array(L), new Uint8Array(L), new Uint8Array(L)], pre = [new Int16Array(L + 1), new Int16Array(L + 1), new Int16Array(L + 1)];
    for (const o of plan) { const a = Math.max(0, Math.floor(o.z - o.zr - z0)), b = Math.min(L - 1, Math.floor(o.z + o.zr - z0)); for (let i = a; i <= b; i++) blk[o.lane + 1][i] = 1; }
    for (let l = 0; l < 3; l++) for (let i = 0; i < L; i++) pre[l][i + 1] = pre[l][i] + blk[l][i];
    const free = (l, i, m) => pre[l][i + m] - pre[l][i] === 0;
    for (let s0 = 0; s0 < 3; s0++) {
      const reach = []; for (let i = 0; i <= L; i++) reach.push([0, 0, 0]); reach[0][s0] = 1;
      for (let i = 0; i < L; i++) for (let l = 0; l < 3; l++) {
        if (!reach[i][l]) continue;
        if (!blk[l][i]) reach[i + 1][l] = 1;
        if (i + n <= L) for (const b of [l - 1, l + 1]) if (b >= 0 && b < 3 && free(l, i, n) && free(b, i, n)) reach[i + n][b] = 1;
      }
      if (!(reach[L][0] || reach[L][1] || reach[L][2])) return false;
    }
    return true;
  }

  function put(arr, i, x, y, z, sx, sy, sz, yaw) {
    const o = i * 16, c = Math.cos(yaw), s = Math.sin(yaw);
    arr[o] = c * sx; arr[o + 1] = 0; arr[o + 2] = -s * sx; arr[o + 3] = 0; arr[o + 4] = 0; arr[o + 5] = sy; arr[o + 6] = 0; arr[o + 7] = 0;
    arr[o + 8] = s * sz; arr[o + 9] = 0; arr[o + 10] = c * sz; arr[o + 11] = 0; arr[o + 12] = x; arr[o + 13] = y; arr[o + 14] = z; arr[o + 15] = 1;
  }
  const vq = new B.Quaternion(), vs = new B.Vector3(), vt = new B.Vector3(), vmx = new B.Matrix();
  function putQ(arr, i, x, y, z, sx, sy, sz, yaw, pitch, roll) {
    B.Quaternion.RotationYawPitchRollToRef(yaw, pitch, roll, vq); vs.set(sx, sy, sz); vt.set(x, y, z); B.Matrix.ComposeToRef(vs, vq, vt, vmx);
    for (let k = 0; k < 16; k++) arr[i * 16 + k] = vmx.m[k];
  }

  /* ---------- Stage 37: side roads that join the main road (scenery only: the cart glides in its 3 lanes, so it can never turn into them) ---------- */
  const SN = 15, SPW = 3.3;                                    // rows along a side road, half width (m)
  const smS = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  function groundY(ch, x, z) {                                 // height of the ground mesh itself (bilinear on its grid) so the side road never sinks into it
    const s = slope(z), l = Math.sqrt(1 + s * s), lat = latOf(x, z), zc = z + lat * s / l, jf = (zc - ch.z0) / (CL / (GR - 1));
    if (jf < 0 || jf > GR - 1 || lat < LAT[0] || lat > LAT[GC - 1]) return hgt(x, z);
    let i = 0; while (i < GC - 2 && LAT[i + 1] < lat) i++;
    const ti = (lat - LAT[i]) / (LAT[i + 1] - LAT[i]), j = Math.min(GR - 2, Math.floor(jf)), tj = jf - j, P = ch.ground.pos, y = (jj, ii) => P[(jj * GC + ii) * 3 + 1];
    const a = y(j, i) + (y(j, i + 1) - y(j, i)) * ti, b = y(j + 1, i) + (y(j + 1, i + 1) - y(j + 1, i)) * ti;
    return a + (b - a) * tj;
  }
  function genSpurs(ch, k, z0, dist) {
    ch.spurs.length = 0;
    const RS = rngOf(k + 7777), stopC = k % STOP_P === 2 || k % STOP_P === STOP_P - 2, bigC = k % 12 === 5;
    for (let si = 0; si < 2; si++) {
      const side = si === 0 ? 1 : -1, o = ch.sp[si];
      const roll = RS(), zs = z0 + 20 + RS() * 20, ang = (RS() - .5) * .44, curv = (RS() - .5) * .005, len = 72 + RS() * 28;
      if (dist < 40 || bigC || (side > 0 && stopC) || k % 2 !== si || roll > (side > 0 ? .3 : .26)) {   // rare: at most one side road per chunk, roughly one every ~7 chunks
         o.m.setEnabled(false); continue; }
      const lat0 = side > 0 ? HW - 1.2 : -(OFF + HW) + 1.2;       // starts a little inside the road edge so there is no gap
      const p0 = pt(zs, lat0), s0 = slope(zs), l0 = Math.sqrt(1 + s0 * s0);
      const nx = side / l0, nz = -side * s0 / l0, tx = s0 / l0, tz = 1 / l0, step = len / (SN - 1);
      let x = p0[0], z = p0[1], th = ang; const pts = [];
      for (let j = 0; j < SN; j++) { const dx = nx * Math.cos(th) + tx * Math.sin(th), dz = nz * Math.cos(th) + tz * Math.sin(th); pts.push([x, z, dx, dz]); x += dx * step; z += dz * step; th += curv * step; }
      const r = o;
      for (let j = 0; j < SN; j++) {
        const t = j / (SN - 1), [cxp, czp, dx, dz] = pts[j], px = -dz, pz = dx, hw = SPW * (1 + .75 * (1 - smS(0, .22, t))) * (1 + (W.vnoise(czp / 6 + 5, k) - .5) * .12);
        for (let c = 0; c < 7; c++) {
          const vv = -1 + 2 * c / 6, av = Math.abs(vv), wx = cxp + px * vv * hw, wz = czp + pz * vv * hw, oo = j * 7 + c;
          const y = Math.max(hgt(wx, wz), groundY(ch, wx, wz)) + .14 + .05 * (1 - vv * vv) - .04 * Math.exp(-Math.pow((av - .45) / .13, 2)), sh = (.92 + .14 * W.vnoise(czp / 9 + 2, 4.4)) * (1 - .22 * av * av);
          r.pos[oo * 3] = wx; r.pos[oo * 3 + 1] = y; r.pos[oo * 3 + 2] = wz; r.nor[oo * 3] = 0; r.nor[oo * 3 + 1] = 1; r.nor[oo * 3 + 2] = 0;
          r.col[oo * 4] = sh; r.col[oo * 4 + 1] = sh * .97; r.col[oo * 4 + 2] = sh * .93; r.col[oo * 4 + 3] = (1 - smS(.8, 1, av)) * smS(0, .08, t) * (1 - smS(.8, 1, t));
          r.uv[oo * 2] = (vv + 1) / 2; r.uv[oo * 2 + 1] = j * step / 10.45;
        }
      }
      const m = r.m;
      m.updateVerticesData(B.VertexBuffer.PositionKind, r.pos); m.updateVerticesData(B.VertexBuffer.NormalKind, r.nor); m.updateVerticesData(B.VertexBuffer.ColorKind, r.col); m.updateVerticesData(B.VertexBuffer.UVKind, r.uv);
      m.refreshBoundingInfo(); m.setEnabled(true);
      ch.spurs.push({ side, pts, hw: SPW });
    }
  }
  const nearSpur = (ch, x, z, pad) => { for (const sp of ch.spurs) { const rr = sp.hw * 1.5 + pad; for (let q = 0; q < sp.pts.length; q++) { const dx = x - sp.pts[q][0], dz = z - sp.pts[q][1]; if (dx * dx + dz * dz < rr * rr) return true; } } return false; };
  function clearSpurs(ch) {                                    // trees, bushes, hedge, landmarks and their collision circles never grow on a side road (the main road and its lanes are left alone)
    if (!ch.spurs.length) return;
    const offRoad = (x, z) => { const l = latOf(x, z); return l > HW + 1.7 || l < -(OFF + HW + 1.7); };
    const pack = (a, n, w, keepAll) => { let m = 0; for (let q = 0; q < n; q++) { const x = a[q * w + (w === 16 ? 12 : 0)], z = a[q * w + (w === 16 ? 14 : 1)]; if (nearSpur(ch, x, z, 1.8) && (keepAll || offRoad(x, z))) continue; if (m !== q) for (let u = 0; u < w; u++) a[m * w + u] = a[q * w + u]; m++; } return m; };
    ch.vm.forEach(o => { const w4 = o.c; let m = 0; for (let q = 0; q < o.n; q++) { if (nearSpur(ch, o.a[q * 16 + 12], o.a[q * 16 + 14], 1.8)) continue; if (m !== q) { for (let u = 0; u < 16; u++) o.a[m * 16 + u] = o.a[q * 16 + u]; for (let u = 0; u < 4; u++) w4[m * 4 + u] = w4[q * 4 + u]; } m++; } o.n = m; });
    ch.om.forEach(o => { const w4 = o.c; let m = 0; for (let q = 0; q < o.n; q++) { const x = o.a[q * 16 + 12], z = o.a[q * 16 + 14]; if (nearSpur(ch, x, z, 1.8) && offRoad(x, z)) continue; if (m !== q) { for (let u = 0; u < 16; u++) o.a[m * 16 + u] = o.a[q * 16 + u]; for (let u = 0; u < 4; u++) w4[m * 4 + u] = w4[q * 4 + u]; } m++; } o.n = m; });
    { let m = 0; for (let q = 0; q < ch.nc; q++) { const x = ch.circ[q * 5], z = ch.circ[q * 5 + 1]; if (nearSpur(ch, x, z, 1.8) && offRoad(x, z)) continue; if (m !== q) for (let u = 0; u < 5; u++) ch.circ[m * 5 + u] = ch.circ[q * 5 + u]; m++; } ch.nc = m; }
  }

  function fillTerrain(ch, z0) {
    const g = ch.ground, e = 1.5;
    for (let j = 0; j < GR; j++) {
      const zc = z0 + j * (CL / (GR - 1)); zoneW(zc);
      const zT0 = zt(0), zT1 = zt(1), zT2 = zt(2), zGr = zp('gr'), zSo = zp('so');                 // Stage 40: the region tints the ground; it eases over ~90 m at a boundary
      for (let i = 0; i < GC; i++) {
        const lat = LAT[i], p = pt(zc, lat), x = p[0], z = p[1], y = hgt(x, z), o = j * GC + i;
        const hx = (hgt(x + e, z) - hgt(x - e, z)) / (2 * e), hz = (hgt(x, z + e) - hgt(x, z - e)) / (2 * e), l = Math.hypot(hx, 1, hz);
        g.pos[o * 3] = x; g.pos[o * 3 + 1] = y; g.pos[o * 3 + 2] = z; g.nor[o * 3] = -hx / l; g.nor[o * 3 + 1] = 1 / l; g.nor[o * 3 + 2] = -hz / l;
        const a = lat > 0 ? lat : Math.max(0, -lat - OFF), near = 1 - sm(6, 24, a), n1 = W.vnoise(x / 38, z / 38), n2 = W.vnoise(x / 15 + 9, z / 15 + 4), steep = sm(.16, .4, 1 - 1 / l);
        const soil = .12 + .8 * near * (.7 + .3 * n2), grass = (1 - near) * (n1 > .45 ? .85 : .55) + .05, rock = steep * .9 + (n2 > .8 ? .15 : 0), clay = near * .15 * n1 + (n1 < .3 ? .2 * (1 - near) : 0);
        g.col[o * 4] = Math.min(1, soil * zSo); g.col[o * 4 + 1] = Math.min(1, grass * zGr); g.col[o * 4 + 2] = rock; g.col[o * 4 + 3] = clay;
        const t = .9 + .2 * n2; g.tint[o * 3] = t * zT0; g.tint[o * 3 + 1] = t * zT1; g.tint[o * 3 + 2] = t * zT2;
      }
    }
    const m = g.m;
    m.updateVerticesData(B.VertexBuffer.PositionKind, g.pos); m.updateVerticesData(B.VertexBuffer.NormalKind, g.nor); m.updateVerticesData(B.VertexBuffer.ColorKind, g.col); m.updateVerticesData('tint', g.tint);
    m.refreshBoundingInfo(); m.setEnabled(true);

    // road bed + verge ribbons (same look as the Royal Road: wheel ruts, soft jittered edges, painted royal texture)
    const dz = CL / (RR - 1);
    for (const [r, v, ofs] of [[ch.road, ch.verge, 0], [ch.road2, ch.verge2, -OFF]]) {   // carriageway 1 = player's (towards the destination); carriageway 2 = oncoming NPC traffic
    for (let j = 0; j < RR; j++) {
      const zc = z0 + j * dz, vzw = (zoneW(zc), zp('vz')), jl = 1 + (W.vnoise(zc / 5 + 3 - ofs * 7, 1.7) - .5) * .16, jr = 1 + (W.vnoise(zc / 5 + 43 - ofs * 7, 8.1) - .5) * .16, tint = .92 + .14 * W.vnoise(zc / 9 + 2, 4.4);
      for (let c = 0; c < 7; c++) {
        const vv = -1 + 2 * c / 6, av = Math.abs(vv), lat = ofs + vv * HW * (1 + ((vv < 0 ? jl : jr) - 1) * av * av), p = pt(zc, lat), x = p[0], z = p[1], o = j * 7 + c;
        const y = hgt(x, z) + .1 + .06 * (1 - vv * vv) + (W.vnoise(x * .8, z * .8) - .5) * .08 - .05 * Math.exp(-Math.pow((av - .45) / .13, 2)), sh = tint * (1 - .22 * av * av);
        r.pos[o * 3] = x; r.pos[o * 3 + 1] = y; r.pos[o * 3 + 2] = z; r.nor[o * 3] = 0; r.nor[o * 3 + 1] = 1; r.nor[o * 3 + 2] = 0;
        r.col[o * 4] = sh; r.col[o * 4 + 1] = sh * .97; r.col[o * 4 + 2] = sh * .93; r.col[o * 4 + 3] = 1 - sm(.8, 1, av);
        r.uv[o * 2] = (vv + 1) / 2; r.uv[o * 2 + 1] = zc / 10.45;
      }
      for (let c = 0; c < 5; c++) {
        const vv = -1 + 2 * c / 4, av = Math.abs(vv), lat = ofs + vv * HW * vzw * .98, p = pt(zc, lat), x = p[0], z = p[1], o = j * 5 + c;
        v.pos[o * 3] = x; v.pos[o * 3 + 1] = hgt(x, z) + .07; v.pos[o * 3 + 2] = z; v.nor[o * 3] = 0; v.nor[o * 3 + 1] = 1; v.nor[o * 3 + 2] = 0;
        v.col[o * 4] = .80 * tint; v.col[o * 4 + 1] = .60 * tint; v.col[o * 4 + 2] = .34 * tint; v.col[o * 4 + 3] = .8 * (1 - sm(.2, 1, av));
      }
    }
    r.m.updateVerticesData(B.VertexBuffer.PositionKind, r.pos); r.m.updateVerticesData(B.VertexBuffer.NormalKind, r.nor); r.m.updateVerticesData(B.VertexBuffer.ColorKind, r.col); r.m.updateVerticesData(B.VertexBuffer.UVKind, r.uv);
    v.m.updateVerticesData(B.VertexBuffer.PositionKind, v.pos); v.m.updateVerticesData(B.VertexBuffer.NormalKind, v.nor); v.m.updateVerticesData(B.VertexBuffer.ColorKind, v.col);
    r.m.refreshBoundingInfo(); v.m.refreshBoundingInfo(); r.m.setEnabled(true); v.m.setEnabled(true);
    }
  }

  /* ---------- Stage 40: dress one chunk for its region (own seeded rng, so the obstacle layout and fairness proof are untouched) ---------- */
  const ZROLE = { 3: ['guard'], 4: ['farmA', 'farmB', 'farmB'], 5: ['vndM', 'wVnd', 'trdM', 'trdW'] };     // flag -> villager archetypes (spawnPP)
  function dressZone(ch, k, z0, dist, X) {
    const RZ = rngOf(k + 31337), rz = (a, b) => a + (b - a) * RZ(), zid = zoneSeg(k).id, nm = ZN[zid].id;
    const pickN = a => a[Math.floor(RZ() * a.length)], vilZ = (side, L, z, flag, rng) => {            // people: robe / skin slots choose the archetype in spawnPP
      if (ch.nv >= VMAX) return; const o = ch.nv++ * 8; ch.vil[o] = side; ch.vil[o + 1] = L; ch.vil[o + 2] = z; ch.vil[o + 3] = rng || 0; ch.vil[o + 4] = RZ() * 6.28; ch.vil[o + 5] = Math.floor(RZ() * 12); ch.vil[o + 6] = Math.floor(RZ() * 4); ch.vil[o + 7] = flag;
    };
    const put = (names, zc, L, side, mode, r) => {
      const p = pt(zc, side * L - SO(side)); if (!X.clear(p[0], p[1], r)) return null;
      for (const n of names) if (ZI[n] == null || !A.om[ZI[n]] || ch.om[ZI[n]].n >= A.om[ZI[n]].max) return null;
      const ya = yawAt(zc), yaw = mode === 'face' ? ya - side * PI / 2 : mode === 'fwd' ? ya + PI + side * .45 : mode === 'row' ? ya : RZ() * 6.28, rr_ = r * .7;
      let y0 = 1e9; for (const [dx, dz] of [[0, 0], [rr_, 0], [-rr_, 0], [0, rr_], [0, -rr_]]) y0 = Math.min(y0, hgt(p[0] + dx, p[1] + dz));
      for (const n of names) X.putD(ZI[n], p[0], y0 - .05, p[1], yaw + (mode === 'face' ? (RZ() - .5) * .12 : 0));
      X.taken.push([p[0], p[1], r]); return p;
    };
    const sideR = () => RZ() < .62 ? 1 : -1, zcR = () => z0 + rz(8, CL - 8);
    // weights per region for each kind of prop, in ZN order: outskirts, market, royal, farm, forest, village, trade
    const WT = { stall: [0, 1, 0, 0, 0, 0, .05], pots: [.4, .8, .1, .1, 0, .5, .3], banner: [.12, .3, 1, 0, 0, .1, .05], palwall: [0, 0, .85, 0, 0, 0, 0], hut: [.4, 0, 0, .9, 0, .25, 0],
      farm: [.5, 0, 0, 1, 0, .25, 0], rest: [0, 0, 0, 0, .12, 0, .5], mark: [.05, 0, 0, 0, .3, .05, .9], comp: [0, 0, 0, 0, 0, .8, 0], wall: [.45, .35, .12, .2, 0, .5, .1], sign: [.55, .55, .5, .5, .55, .6, .9] };
    const w = (kind, zc) => { zoneW(zc); const t = WT[kind], pm = TN[startTown].pw[kind]; return (t[ZW.a] + (t[ZW.b] - t[ZW.a]) * ZW.t) * (pm ? 1 + (pm - 1) * ZW.tw : 1); };
    const roll = (kind, zc) => RZ() < w(kind, zc);
    // --- signposts with carved settlement names; wooden direction markers on the trade route / forest ---
    { const zc = zcR(), side = sideR(); const nearStart = dist > 25 && dist < 220; if ((nearStart && RZ() < .85) || (roll('sign', zc) && dist > 25)) { const ni = nearStart ? startTown : Math.floor(RZ() * ZNAMES.length); put(['zpost', 'zplank' + ni], zc, 7.7, side, 'fwd', 2.7); } }
    if (dist > 25) { const zc = zcR(), side = sideR(); if (roll('mark', zc)) put(['zmark'], zc, 7.5, side, 'fwd', 1.6); }
    // --- region entry: at the start of every new region a carved signpost (right) and an inscribed mud wall (left) name the region you are entering ---
    if (dist > 25 && k === zoneSeg(k).k0) {
      for (const zc of [z0 + 9, z0 + 12, z0 + 6, z0 + 16]) if (put(['zpost', 'zrplank' + zid], zc, 7.7, 1, 'fwd', 2.7)) break;
      for (const zc of [z0 + 13, z0 + 18, z0 + 9, z0 + 22]) if (put(['zwall', 'zrpaint' + zid], zc, 9.2, -1, 'face', 3.1)) break;
    }
    // --- painted mud-wall community announcements ---
    { const zc = zcR(), side = sideR(); if (roll('wall', zc) && dist > 25) put(['zwall', 'zpaint' + Math.floor(RZ() * ZMSG.length)], zc, 9.2, side, 'face', 3.1); }
    // --- market: stalls (with traders), pottery ---
    for (let q = 0; q < 6; q++) {
      const zc = z0 + 6 + q * 9 + rz(-2, 2), side = q % 2 ? 1 : -1; if (!roll('stall', zc)) continue;
      const L = rz(8.8, 10.4), p = put(['zstall'], zc, L, side, 'face', 3.1);
      if (p) { vilZ(side, L + 1.3, zc + rz(-.6, .6), 5, 0); if (RZ() < .6) vilZ(side, L - 2.2, zc + rz(-1.4, 1.4), 2, 0); }
    }
    for (let q = 0; q < 4; q++) { const zc = zcR(), side = sideR(); if (roll('pots', zc)) put(['zpots'], zc, rz(8, 11.5), side, 'face', 2.2); }
    // --- royal: woven banners, palace walls, guards ---
    for (let q = 0; q < 5; q++) { const zc = z0 + 6 + q * 11 + rz(-2, 2), side = q % 2 ? 1 : -1; if (roll('banner', zc)) put(['zbanner'], zc, 7.6, side, 'fwd', 1.4); }
    for (let q = 0; q < 3; q++) {
      const zc = z0 + 8 + q * 18 + rz(-2, 2), side = q % 2 ? 1 : -1; if (!roll('palwall', zc)) continue;
      const p = put(['zpalwall'], zc, 10.2, side, 'face', 4.2); if (p && RZ() < .75) vilZ(side, 8.4, zc + rz(-2, 2), 3, 0);
    }
    // --- farms: plots (the hedge in front is cleared), huts, farmers ---
    for (let q = 0; q < 4; q++) {
      const zc = z0 + 8 + q * 14 + rz(-3, 3), side = q % 2 ? 1 : -1;
      if (roll('farm', zc)) { const L = rz(15, 19); if (put(['zfarm'], zc, L, side, 'face', 7)) { if (RZ() < .8) vilZ(side, L, zc + rz(-3, 3), 4, RZ() < .5 ? rz(3, 6) : 0); } }
      else if (roll('hut', zc)) { const L = rz(11, 21); if (put(['zhut'], zc, L, side, 'face', 2.7) && RZ() < .5) vilZ(side, L - 3, zc + rz(-1, 1), 4, 0); }
    }
    // --- village: settlement entrances ---
    for (let q = 0; q < 2; q++) { const zc = z0 + 14 + q * 30 + rz(-5, 5), side = q % 2 ? 1 : -1; if (roll('comp', zc)) { const p = put(['zcomp'], zc, 9.3, side, 'face', 4.6); if (p && RZ() < .6) vilZ(side, 8, zc + rz(-3, 3), 2, 0); } }
    // --- trade route: resting points, travelling traders with loads ---
    { const zc = z0 + rz(12, 48), side = sideR(); if (roll('rest', zc)) { const L = 9; if (put(['zrest'], zc, L, side, 'face', 3.6)) { vilZ(side, L - 1.6, zc + rz(-1, 1), 5, 0); if (RZ() < .6) vilZ(side, L + .2, zc + rz(-1.5, 1.5), 2, 0); } } }
    if (nm === 'trade' || (nm === 'forest' && RZ() < .3)) for (let q = 0, n = nm === 'trade' ? 1 + (RZ() < .5 ? 1 : 0) : 1; q < n; q++) vilZ(sideR(), rz(7.4, 8.6), z0 + rz(10, 50), 5, rz(8, 16));
    if (nm === 'outskirts' && RZ() < .35) vilZ(sideR(), rz(15, 22), zcR(), 4, rz(3, 6));
  }

  function genChunk(ch, k) {
    const z0 = k * CL, R = rngOf(k), dist = z0 - startZ;
    ch.idx = k; ch.z0 = z0; releasePP(ch);
    fillTerrain(ch, z0); genSpurs(ch, k, z0, dist);
    ch.vm.forEach(o => { o.n = 0; }); ch.om.forEach(o => { o.n = 0; }); ch.nc = 0; ch.ncw = 0; ch.nv = 0;
    ch.houses.forEach(houseRelease); ch.houses.length = 0;
    const rr = (a, b) => a + (b - a) * R(), pick = a => a[Math.floor(R() * a.length)];
    const addV = (name, x, y, z, s, sy, yaw, tint) => {
      const mi = VI[name], d = A.vm[mi], c = ch.vm[mi]; if (!d || c.n >= d.max) return false;
      put(c.a, c.n, x, y, z, s, s * sy, s, yaw); c.c[c.n * 4] = tint[0]; c.c[c.n * 4 + 1] = tint[1]; c.c[c.n * 4 + 2] = tint[2]; c.c[c.n * 4 + 3] = 1; c.n++; return true;
    };
    const taken = [];                                            // houses (x, z, radius): trees keep clear of them
    ch.spurs.forEach(sp => sp.pts.forEach(q => taken.push([q[0], q[1], sp.hw + 5.5])));   // houses, bukas and landmarks keep clear of side roads
    const clear = (x, z, r) => { for (let q = 0; q < taken.length; q++) if (Math.hypot(x - taken[q][0], z - taken[q][1]) < taken[q][2] + r) return false; return true; };

    /* --- Stage 19: landmarks, mariwo gateways and denser compounds (own rng, so the obstacle layout is unchanged) --- */
    const RL = rngOf(k + 5003), rl = (a, b) => a + (b - a) * RL();
    const putD = (di, x, y, z, yaw) => { const d = A.om[di], c = ch.om[di]; if (!d || !c || c.n >= d.max) return false; put(c.a, c.n, x, y, z, 1, 1, 1, yaw); const o = c.n * 4; c.c[o] = c.c[o + 1] = c.c[o + 2] = c.c[o + 3] = 1; c.n++; return true; };
    const gZ = [];
    /* Stage 28: landmark rows on BOTH sides of the road. Two slots per side per chunk, closer to the road (hedge is at 14 m), getting denser with distance;
       the single Afin (palace) of the run stands once, ~900 m in (the run starts well BEFORE the palace front), on one side. Kinds: shrine, granary, well, Opa Oranmiyan staff, Oja market. */
    const lmBig = dist >= 20 && k === Math.max(3, Math.round(900 / CL)), lmBigSide = RL() < .5 ? -1 : 1, lmDens = Math.min(.97, .88 + Math.max(0, dist) / 6000) * (zoneW(z0 + CL / 2), Math.min(1.2, zp('lm')));     // Stage 40: the region sets how many landmarks line the road
    const LMK = [DI.shrine, DI.granary, DI.well, DI.staff, DI.market, DI.granary, DI.well, DI.shrine, DI.staff];
    if (dist >= 20) for (const lmSide of [-1, 1]) {
      const big = lmBig && lmSide === lmBigSide;
      (big ? [rl(24, 36)] : [rl(6, 20), rl(34, 54)]).forEach(lmZ => {
        const lmKind = big ? DI.palace : LMK[Math.floor(RL() * LMK.length)], roll = RL();
        if (!big && roll > lmDens) return;
        const lmLat = big ? rl(24, 26) : (lmKind === DI.market ? rl(14, 16) : rl(11.5, 14));      // in front of the hedge line so they are seen from the road
        const o = pt(lmZ, lmSide * lmLat - SO(lmSide)), yaw = yawAt(lmZ) - lmSide * PI / 2, cs = Math.cos(yaw), sn = Math.sin(yaw);
        if (!big && !clear(o[0], o[1], 6)) return;
        const loc = (lx, lz) => [o[0] + lx * cs + lz * sn, o[1] - lx * sn + lz * cs];
        const fp = big ? [[-18, 0], [0, 0], [18, 0], [-18, -26], [18, -26], [0, -26]] : lmKind === DI.market ? [[-8, 0], [8, 0], [0, -6]] : [[-5, 0], [5, 0], [0, -5]];
        let y0 = 1e9; for (const [lx, lz] of fp) { const q = loc(lx, lz); y0 = Math.min(y0, hgt(q[0], q[1])); }
        if (putD(lmKind, o[0], y0 - .05, o[1], yaw)) {
          const mid = loc(0, big ? -13 : -2); taken.push([mid[0], mid[1], big ? 24 : lmKind === DI.market ? 9 : 5]);
          if (lmKind === DI.market) for (let q = 0; q < 3 && ch.nv < VMAX; q++) { const o2 = ch.nv++ * 8; ch.vil[o2] = lmSide; ch.vil[o2 + 1] = lmLat - rr(2.5, 5); ch.vil[o2 + 2] = lmZ + rr(-8, 8); ch.vil[o2 + 3] = 0; ch.vil[o2 + 4] = R() * 6.28; ch.vil[o2 + 5] = Math.floor(R() * ROBES.length); ch.vil[o2 + 6] = Math.floor(R() * SKINS.length); ch.vil[o2 + 7] = 0; }
        }
      });
    }
    /* Stage 40: town entrance gate on the first chunk of a market / royal / farming / village region (posts at +-6.3 m, lintel 4.6 m up: ridden under, never in the way) */
    const seg40 = zoneSeg(k); let tGate = false;
    if (dist >= 30 && (k === seg40.k0 || k === 1) && A.om[ZI.ztgate]) {            // a gate at the start of the run and at every region change
      const zc = z0 + 14, p = pt(zc, 0), p2 = pt(zc, -OFF); gZ.push(zc); tGate = true;
      putD(ZI.ztgate, p[0], hgt(p[0], p[1]), p[1], yawAt(zc)); putD(ZI.ztgate, p2[0], hgt(p2[0], p2[1]), p2[1], yawAt(zc));
      if (seg40.id === 2) for (const sg of [-1, 1]) { const o2 = ch.nv < VMAX - 1 ? ch.nv++ * 8 : -1; if (o2 >= 0) { ch.vil[o2] = sg; ch.vil[o2 + 1] = 7.6; ch.vil[o2 + 2] = zc + 2.2; ch.vil[o2 + 3] = 0; ch.vil[o2 + 4] = 0; ch.vil[o2 + 5] = 0; ch.vil[o2 + 6] = 0; ch.vil[o2 + 7] = 3; } }   // royal settlement: guards flank the gate
      else for (const sg of [-1, 1]) for (let q = 0; q < 2; q++) { if (ch.nv >= VMAX - 1) break; const o2 = ch.nv++ * 8; ch.vil[o2] = sg; ch.vil[o2 + 1] = 7.8 + q * 1.3; ch.vil[o2 + 2] = zc + (q ? 3.2 : -2.4); ch.vil[o2 + 3] = 0; ch.vil[o2 + 4] = R() * 6.28; ch.vil[o2 + 5] = Math.floor(R() * 12); ch.vil[o2 + 6] = Math.floor(R() * 4); ch.vil[o2 + 7] = 0; }     // a welcoming crowd at every other gate
    }
    for (let g = 0, ng = !tGate && dist >= 60 && k % 4 === 1 ? 1 : 0; g < ng; g++) {          // mariwo gateways: at most one every 4 chunks (~240 m)          // mariwo gateways straddling the road
      const zc = z0 + 8 + rl(0, 40), p = pt(zc, 0), p2 = pt(zc, -OFF); gZ.push(zc); putD(DI.gate, p[0], hgt(p[0], p[1]), p[1], yawAt(zc)); putD(DI.gate, p2[0], hgt(p2[0], p2[1]), p2[1], yawAt(zc));
    }

    /* --- bukas on both sides of the road: trader bukas (goods + trader) and passenger bukas (waiting villagers + blue stopping mark) --- */
    ch.stops.length = 0; const noObs = [];
    if (dist > 80) for (const side of [-1, 1]) {
      const isPick = k % STOP_P === 2, isDrop = k % STOP_P === STOP_P - 2, stopChunk = isPick || isDrop, kindP = side > 0 && stopChunk;       // pick-up / drop-off stops: right-hand side only, alternating every 3 chunks (~180 m apart, a pick-up only every ~360 m)
      if (!kindP && (RL() > .4 || (side > 0 && stopChunk))) continue;
      const zc = z0 + rl(15, 45), p = pt(zc, side * 9.4 - SO(side)), yaw = yawAt(zc) - side * PI / 2, cs = Math.cos(yaw), sn = Math.sin(yaw);
      if (!clear(p[0], p[1], 5) || noObs.some(q => Math.abs(q - zc) < 18) || gZ.some(q => Math.abs(q - zc) < 16)) continue;
      let y0 = 1e9; for (const [lx, lz] of [[-1.6, -1.3], [1.6, -1.3], [-1.6, 1.3], [1.6, 1.3]]) y0 = Math.min(y0, hgt(p[0] + lx * cs + lz * sn, p[1] - lx * sn + lz * cs));
      if (!putD(kindP ? DI.bukaP : DI.buka, p[0], y0 - .05, p[1], yaw)) continue;
      taken.push([p[0], p[1], 5]); noObs.push(zc);
      const addVil = (lat, z, flag) => { if (ch.nv >= VMAX) return -1; const q = ch.nv++, o = q * 8; ch.vil[o] = side; ch.vil[o + 1] = lat; ch.vil[o + 2] = z; ch.vil[o + 3] = 0; ch.vil[o + 4] = R() * 6.28; ch.vil[o + 5] = Math.floor(R() * ROBES.length); ch.vil[o + 6] = Math.floor(R() * SKINS.length); ch.vil[o + 7] = flag; return q; };
      if (!kindP) { for (let q = 0, n = 1 + (RL() < .4 ? 1 : 0); q < n; q++) addVil(9.55, zc + (q ? .9 : -.5), 0); }
      else {
        const m = pt(zc, side * LW), my = hgt(m[0], m[1]) + .07, pitch = -Math.atan2(roadY(zc + 3) - roadY(zc - 3), 6), d = A.om[DI.mark], c = ch.om[DI.mark];
        if (d && c && c.n < d.max) { putQ(c.a, c.n, m[0], my, m[1], 1, 1, 1, yawAt(zc), pitch, 0); const o = c.n * 4; c.c[o] = c.c[o + 1] = c.c[o + 2] = c.c[o + 3] = 1; c.n++; }
        const stop = { z: zc, side, kind: isDrop ? 'drop' : 'pick', k, area: areaFor(k), state: 0, dwell: 0, t: 0, vo: [], ann: false };
        if (isPick) for (let q = 0, n = 2; q < n; q++) { const vq = addVil(5.0, zc + (q - (n - 1) / 2) * 1.1, 2); if (vq >= 0) stop.vo.push(vq); }
        if (isDrop || stop.vo.length) ch.stops.push(stop);
      }
    }
    const inStop = zc => noObs.some(q => Math.abs(q - zc) < 14);

    /* --- Yoruba compounds beside the road (door faces the road): one to two houses a side, clustered --- */
    if (A.houseVar.length) for (const side of [-1, 1]) {
      const hsz = (zoneW(z0 + CL / 2), zp('hs')), nh = R() < Math.min(.97, .22 + Math.max(0, 1 - hsz) * .8) ? 0 : (R() < Math.min(.9, .5 * hsz) ? 2 : 1); let zPrev = z0 + 8 + R() * 28;
      for (let q = 0; q < nh; q++) {
        const zc = clamp(q === 0 ? zPrev : (zPrev + 17 < z0 + CL - 5 ? zPrev + 17 : zPrev - 17) + rr(-2, 2), z0 + 4, z0 + CL - 4), lat = side * rr(29, 46), p = pt(zc, lat - SO(side));
        zPrev = zc; if (!clear(p[0], p[1], 8)) continue;
        const h = houseAcquire(side, R); if (!h) continue;
        const x = p[0], z = p[1], y = Math.min(hgt(x, z), hgt(x + 3, z), hgt(x - 3, z), hgt(x, z + 3), hgt(x, z - 3)) - .12;
        for (const kx in h.set) { const m = h.set[kx]; m.position.set(x, y, z); m.setEnabled(true); }
        ch.houses.push(h); taken.push([x, z, 8]);
        for (let v = 0, n = 1 + (R() < .5 ? 1 : 0); v < n && ch.nv < VMAX; v++) { const o = ch.nv++ * 8; ch.vil[o] = side; ch.vil[o + 1] = Math.abs(lat) - rr(4.5, 7); ch.vil[o + 2] = zc + rr(-3, 3); ch.vil[o + 3] = 0; ch.vil[o + 4] = R() * 6.28; ch.vil[o + 5] = Math.floor(R() * ROBES.length); ch.vil[o + 6] = Math.floor(R() * SKINS.length); ch.vil[o + 7] = 0; }
      }
    }
    /* --- villagers on the verge (some pace to and fro along the road) --- */
    for (let q = 0, n = Math.floor(R() * 2.4); q < n && ch.nv < VMAX; q++) {
      const side = R() < .5 ? -1 : 1, o = ch.nv++ * 8; ch.vil[o] = side; ch.vil[o + 1] = rr(8, 11.2); ch.vil[o + 2] = z0 + rr(14, 46); ch.vil[o + 3] = R() < .55 ? rr(5, 10) : 0; ch.vil[o + 4] = R() * 6.28; ch.vil[o + 5] = Math.floor(R() * ROBES.length); ch.vil[o + 6] = Math.floor(R() * SKINS.length); ch.vil[o + 7] = 1;
    }
    dressZone(ch, k, z0, dist, { clear, taken, putD });                    // Stage 40: region props + people (before hedge and trees, which keep clear of them)
    /* --- hedge along both sides (the visible edge of the route) --- */
    for (const side of [-1, 1]) for (let q = 0; q < 13; q++) {
      const zc = z0 + (q + R()) * (CL / 13), p = pt(zc, side * (HEDGE + rr(-.6, .9)) - SO(side));
      if (!clear(p[0], p[1], 1)) continue;                                 // no hedge in front of a landmark
      addV('bush', p[0], hgt(p[0], p[1]) - .05, p[1], rr(1.0, 1.7), rr(.9, 1.3), R() * 6.28, pick(TINTS.bush));
    }
    /* --- trees --- */
    const trN = (zoneW(z0 + CL / 2), zp('tr'));
    for (const side of [-1, 1]) for (let q = 0, n = Math.round((1 + Math.floor(R() * 3.4)) * trN); q < n; q++) {
      const zc = z0 + R() * CL, lat = side * rr(trN > 1.5 ? 15 : 18, 64), p = pt(zc, lat - SO(side)), x = p[0], z = p[1]; if (!clear(x, z, 5)) continue;
      const roll = R(), y = hgt(x, z) - .05, yaw = R() * 6.28;
      if (roll < .46) addV(R() < .5 ? 'acacia1' : 'acacia2', x, y, z, rr(.85, 1.3), 1, yaw, pick(TINTS.tree));
      else if (roll < .7) addV(R() < .5 ? 'palm1' : 'palm2', x, y, z, rr(.85, 1.25), 1, yaw, pick(TINTS.palm));
      else if (roll < .9) addV(R() < .5 ? 'tropical1' : 'tropical2', x, y, z, rr(.85, 1.25), 1, yaw, pick(TINTS.tree));
      else if (Math.abs(lat) > 32) addV('baobab', x, y, z, rr(.9, 1.25), 1, yaw, pick(TINTS.tree));
    }
    if (trN > 1.5) for (let q = 0, n = Math.round(16 * (trN - 1)); q < n; q++) {          // Stage 40 · Forest Pathway: thick undergrowth right up to the verge
      const side = R() < .5 ? -1 : 1, p = pt(z0 + R() * CL, side * rr(8, 30) - SO(side)); if (!clear(p[0], p[1], 2)) continue;
      addV(R() < .75 ? 'bush' : (R() < .5 ? 'tropical1' : 'tropical2'), p[0], hgt(p[0], p[1]) - .05, p[1], rr(1, 1.9), rr(.9, 1.4), R() * 6.28, pick(TINTS.bush));
    }
    /* --- grass tufts along the median between the two carriageways --- */
    for (let zc = z0 + 1 + R() * 1.5; zc < z0 + CL; zc += 2 + R() * 1.4) { const p = pt(zc, -(HW + .35 + R() * .75)); addV('grass', p[0], hgt(p[0], p[1]) - .02, p[1], rr(.55, 1.0), 1, R() * 6.28, [.78 + R() * .12, 1, .55 + R() * .1]); }
    /* --- dry grass + flowers --- */
    for (let q = 0; q < 28; q++) { const side = R() < .5 ? -1 : 1, p = pt(z0 + R() * CL, side * rr(7.2, 60) - SO(side)); if (!clear(p[0], p[1], 2)) continue; addV('grass', p[0], hgt(p[0], p[1]) - .02, p[1], rr(.9, 1.8), 1, R() * 6.28, pick(TINTS.grass)); }
    for (let q = 0; q < 8; q++) { const side = R() < .5 ? -1 : 1, p = pt(z0 + R() * CL, side * rr(7, 30) - SO(side)); addV('flower', p[0], hgt(p[0], p[1]) - .02, p[1], rr(1, 1.5), 1, R() * 6.28, [1, 1, 1]); }

    /* --- obstacles: denser and nastier with distance; every non-jump pattern keeps a rideable lane of >= 3.4 m --- */
    const circ = (x, z, r, h, kind) => { if (ch.nc < CIRC) { const o = ch.nc++ * 5; ch.circ[o] = x; ch.circ[o + 1] = z; ch.circ[o + 2] = r; ch.circ[o + 3] = h; ch.circ[o + 4] = kind; } };
    const rock = (zc, lat, r) => {
      if (inStop(zc)) return; const p = pt(zc, lat), c = ch.om[0], d = A.om[0]; if (!d || c.n >= d.max) return;
      putQ(c.a, c.n, p[0], hgt(p[0], p[1]) + r * .2, p[1], r * 1.05, r * (.55 + R() * .3) * 1.4, r * 1.05, R() * 6.28, (R() - .5) * .3, (R() - .5) * .3);
      const l = .85 + R() * .25, pc = pick([[.86, .84, .8], [.74, .72, .7], [.94, .9, .82], [.68, .66, .66]]);          // pale stone: stands out against the tan road c.c[c.n * 4] = pc[0] * l; c.c[c.n * 4 + 1] = pc[1] * l; c.c[c.n * 4 + 2] = pc[2] * l; c.c[c.n * 4 + 3] = 1; c.n++;
      circ(p[0], p[1], r * .88, 1.6, 1);
    };
    const mound = (zc, lat, r) => {
      if (inStop(zc)) return; const p = pt(zc, lat), c = ch.om[1], d = A.om[1]; if (!d || c.n >= d.max) return;
      putQ(c.a, c.n, p[0], hgt(p[0], p[1]) + r * .7, p[1], r, r * 1.5, r, R() * 6.28, 0, 0);
      const l = .85 + R() * .2; c.c[c.n * 4] = .8 * l; c.c[c.n * 4 + 1] = .52 * l; c.c[c.n * 4 + 2] = .36 * l; c.c[c.n * 4 + 3] = 1; c.n++;
      circ(p[0], p[1], r * .9, 2, 1);
    };
    const pothole = (zc, lat, r) => {
      if (inStop(zc)) return; const p = pt(zc, lat), c = ch.om[DI.pothole], d = A.om[DI.pothole]; if (!d || c.n >= d.max) return;
      putQ(c.a, c.n, p[0], hgt(p[0], p[1]) + .185, p[1], r, 1, r, R() * 6.28, 0, 0); const o = c.n * 4; c.c[o] = c.c[o + 1] = c.c[o + 2] = c.c[o + 3] = 1; c.n++;
      circ(p[0], p[1], r * .78, .4, 3);
    };
    const logPiece = (x, z, yaw, len, th, dy) => {                // yaw = direction the log lies along (sin, cos)
      const c = ch.om[2], d = A.om[2]; if (!d || c.n >= d.max) return;
      putQ(c.a, c.n, x, hgt(x, z) + th * .55 + dy, z, th, len, th, yaw - PI / 2, 0, PI / 2);
      const l = .8 + R() * .25; c.c[c.n * 4] = .6 * l; c.c[c.n * 4 + 1] = .4 * l; c.c[c.n * 4 + 2] = .26 * l; c.c[c.n * 4 + 3] = 1; c.n++;
    };
    const log = (zc, lat, len, across) => {
      if (inStop(zc)) return;
      const p = pt(zc, lat), ry = yawAt(zc), yaw = ry + (across ? PI / 2 : (R() - .5) * 1.2 + PI / 2), th = .3 + R() * .12, sx = Math.sin(yaw), cz = Math.cos(yaw);
      logPiece(p[0], p[1], yaw, len, th, 0);
      if (!across) { logPiece(p[0] + sx * len * .12 + cz * .3, p[1] + cz * len * .12 - sx * .3, yaw + .7, len * .45, th * .5, th * .5); }
      const n = 4;
      for (let q = 0; q < n; q++) { const t = (q / (n - 1) - .5) * len * .8; circ(p[0] + sx * t, p[1] + cz * t, .7, 1, 2); }
    };
    const ln = () => Math.floor(R() * 3) - 1, ln2 = a => { let b = ln(); if (b === a) b = a === 1 ? -1 : a + 1; return b; };
    const dd = dist + CL / 2, stg = stageOf(dd), DP = DIFF[stg - 1];

    /* --- livestock crossing (rare, from Stage 2). Decided first: a herd chunk gets no static obstacles, and never sits on or beside a bus stop ---
       one animal per HERD_GAP metres, so at any instant only one animal can be in the cart's way and there is always a free lane to take */
    ch.herd = null;
    if (A.liv && DP.herd && dist > 110 && k % 3 === 1 && [1, 2, 3, 11, 12, 13].indexOf(k % STOP_P) < 0) {
      const RH = rngOf(k + 7717);
      if (RH() < DP.herd) {
        const side = RH() < .5 ? -1 : 1, an = [], cnt = stg >= 4 ? 2 : 1, zh = z0 + 14 + RH() * 3;
        for (let q = 0; q < cnt; q++) an.push({ z: zh + q * HERD_GAP, kind: RH() < .6 ? 0 : 1, tint: Math.floor(RH() * 3), side, s: 0, t: 0, lat: side * HERD_LAT, hit: false });
        ch.herd = { an, warned: false };
      }
    }

    /* --- static obstacles: planned first, proven rideable, only then built --- */
    const plan = [], zlo = z0 + 10, zhi = z0 + CL - 10, TL = vGal(dd) * 1.04 * LANE_T, SL = DP.slack;
    const zrOf = (t, r) => (t === 'log' ? .7 : t === 'rock' ? r * .88 : t === 'mound' ? r * .9 : r * .78) + .85 + .4;     // blocked half-length = obstacle radius + horse radius + margin
    const sp = (t, z, lane, r) => ({ t, z, lane, r, zr: zrOf(t, r) });
    const gap = (p1, p2, l1, l2) => p1.zr + p2.zr + Math.max(1, Math.abs(l1 - l2)) * TL + 1 + rr(0, SL);                   // smallest centre distance that leaves time to change lane in between
    const kindR = t => t === 'log' ? rr(2.6, 3.1) : t === 'pothole' ? rr(.95, 1.2) : t === 'mound' ? rr(1, 1.5) : rr(.8, 1.3);
    const build = (t, s0) => {
      const o = [];
      if (t === 'rock' || t === 'mound' || t === 'log' || t === 'pothole') o.push(sp(t, s0, ln(), kindR(t)));
      else if (t === 'rock2' || t === 'log2') { const k1 = t === 'rock2' ? 'rock' : 'log', l1 = ln(), l2 = ln2(l1), p1 = sp(k1, s0, l1, kindR(k1)), p2 = sp(k1, 0, l2, kindR(k1)); p2.z = s0 + gap(p1, p2, l1, l2); o.push(p1, p2); }
      else if (t === 'chicane') { const pr = [[-1, 0], [0, 1], [-1, 0], [0, 1], [-1, 1]][Math.floor(R() * 5)]; let z = s0; for (let q = 0; q < 3; q++) { const p1 = sp('rock', z, pr[q % 2], rr(.9, 1.15)); o.push(p1); z += gap(p1, p1, pr[0], pr[1]); } }
      else if (t === 'pass') { const f = ln(); for (let l = -1; l <= 1; l++) if (l !== f) o.push(sp('rock', s0, l, rr(.9, 1.2))); }
      else if (t === 'gauntlet') { const f1 = ln(), f2 = ln(), z2 = s0 + 2 * zrOf('rock', 1.2) + Math.max(1, Math.abs(f1 - f2)) * TL + 1 + rr(0, SL); [[s0, f1], [z2, f2]].forEach(([z, f]) => { for (let l = -1; l <= 1; l++) if (l !== f) o.push(sp('rock', z, l, rr(.9, 1.2))); }); }
      else if (t === 'mixed') { const ks = ['rock', 'log', 'pothole', 'mound']; let z = s0, l1 = ln(); for (let q = 0; q < 3; q++) { const kk = pick(ks), p1 = sp(kk, z, l1, kindR(kk)), l2 = ln2(l1); o.push(p1); z += p1.zr + 2.3 + Math.abs(l2 - l1) * TL + 1 + rr(0, SL); l1 = l2; } }
      return o;
    };
    const S0 = 95 - 59 * clamp(dd / 7000, 0, 1);                                                  // obstacle spacing eases from 95 m (easy start) down to 36 m by 7 km
    if (dist > 110 && !ch.herd) {
      let s0 = z0 + 12 + R() * S0 * .5;
      while (s0 < zhi) {
        let o = build(pick(DP.types), s0);
        const fits = q => q.length && !q.some(p => p.z < zlo || p.z > zhi) && laneFeasible(plan.concat(q), z0, CL, TL);
        if (!fits(o)) o = build(pick(['rock', 'log', 'mound']), s0);                     // layout wasn't provably fair: fall back to one simple obstacle so the road doesn't thin out
        if (fits(o)) for (const p of o) plan.push(p); else o = [];                         // unfair layouts are simply not built
        s0 += S0 * (.75 + R() * .5) + Math.max(0, o.reduce((m, p) => Math.max(m, p.z), s0) - s0);
      }
    }
    plan.forEach(p => { const lat = p.lane * LW; if (p.t === 'rock') rock(p.z, lat, p.r); else if (p.t === 'mound') mound(p.z, lat, p.r); else if (p.t === 'log') log(p.z, lat, p.r, true); else pothole(p.z, lat, p.r); });
    ch.plan = plan;

    /* --- cowries: strings weaving across the road. Higher stages: fewer strings, wider spacing, more weaving and cowries tucked closer to obstacles (never inside one) --- */
    const CW = DP.cw, CSTEP = COW_STEP * CW.step;
    const blocked = (x, z) => { for (let q = 0; q < ch.nc; q++) { const o = q * 5, r = ch.circ[o + 2] + CW.margin; if ((x - ch.circ[o]) ** 2 + (z - ch.circ[o + 1]) ** 2 < r * r) return true; } return false; };
    for (let g = 0, ng = 1 + Math.floor(R() * CW.g); g < ng; g++) {
      const n = CW.n[0] + Math.floor(R() * CW.n[1]), zs = z0 + 6 + R() * (CL - 12 - n * CSTEP), L0 = ln(), L1 = clamp(L0 + (R() < CW.weave ? (R() < .5 ? -1 : 1) : 0), -1, 1), L2 = R() < CW.zig ? L0 : L1;
      for (let q = 0; q < n && ch.ncw < CMAX; q++) {
        const zc = zs + q * CSTEP, lat = (L2 !== L1 || L1 !== L0 ? [L0, L1, L2][Math.min(2, Math.floor(q * 3 / n))] : L0) * LW, p = pt(zc, lat); if (blocked(p[0], p[1])) continue;
        const o = ch.ncw++ * 5; ch.cows[o] = p[0]; ch.cows[o + 1] = hgt(p[0], p[1]); ch.cows[o + 2] = p[1]; ch.cows[o + 3] = 0; ch.cows[o + 4] = R() * 6.28;
      }
    }
    /* --- power-ups: only every third chunk (offset by the run seed) and anywhere inside its middle 40 m, so any two are >= 140 m apart; kept clear of obstacles, cowries and bus stops --- */
    ch.pk = [];
    if (dist > 90 && ((k + SEED) % 3) === 0) {
      const RP = rngOf(k + 9001), r = RP(), kind = R_.oseOn ? (r < .2 ? 'mag' : r < .4 ? 'boost' : r < .52 ? 'ose' : r < .76 ? 'dbl' : 'crate') : (r < .24 ? 'mag' : r < .5 ? 'boost' : r < .74 ? 'dbl' : 'crate');
      for (let tr = 0; tr < 10; tr++) {
        const zc = z0 + 10 + RP() * (CL - 20), p = pt(zc, (Math.floor(RP() * 3) - 1) * LW);
        if (blocked(p[0], p[1])) continue;
        let ok = !ch.stops.some(sp => Math.abs(sp.z - zc) < 16);
        for (let q = 0; ok && q < ch.ncw; q++) { const o = q * 5; if ((p[0] - ch.cows[o]) ** 2 + (p[1] - ch.cows[o + 2]) ** 2 < 16) ok = false; }
        if (ok) { ch.pk.push({ x: p[0], y: hgt(p[0], p[1]), z: p[1], kind, taken: 0, ph: RP() * 6.28 }); break; }
      }
    }
    clearSpurs(ch);
    spawnPP(ch);
  }

  /* ---------- gather every active chunk into the shared instance buffers; refresh the obstacle list ---------- */
  function gather() {
    A.vm.forEach((d, mi) => {
      if (!d) return; let n = 0;
      A.chunks.forEach(ch => { if (ch.idx === -999) return; const c = ch.vm[mi]; if (!c.n) return; d.mat.set(c.a.subarray(0, c.n * 16), n * 16); d.col.set(c.c.subarray(0, c.n * 4), n * 4); n += c.n; });
      d.n = n; d.parts.forEach(m => { m.thinInstanceCount = n; m.thinInstanceBufferUpdated('matrix'); m.thinInstanceBufferUpdated('color'); m.setEnabled(n > 0); });
    });
    A.om.forEach((d, mi) => {
      let n = 0;
      A.chunks.forEach(ch => { if (ch.idx === -999) return; const c = ch.om[mi]; if (!c.n) return; d.mat.set(c.a.subarray(0, c.n * 16), n * 16); d.col.set(c.c.subarray(0, c.n * 4), n * 4); n += c.n; });
      d.n = n; d.mesh.thinInstanceCount = n; d.mesh.thinInstanceBufferUpdated('matrix'); d.mesh.thinInstanceBufferUpdated('color'); d.mesh.setEnabled(n > 0);
    });
    const o = RD.obs; o.x.length = o.z.length = o.r.length = o.h.length = o.k.length = 0;       // riding.js collides against this list: only the live chunks' obstacles are in it
    A.chunks.forEach(ch => { if (ch.idx === -999) return; for (let q = 0; q < ch.nc; q++) { const b = q * 5; RD.addObstacle(ch.circ[b], ch.circ[b + 1], ch.circ[b + 2], ch.circ[b + 3], ch.circ[b + 4]); } });
    try { window.OYOVillagers && OYOVillagers.setObstacles(RD.obs); } catch (e) { /* ok */ }
  }

  /* ---------- streaming: new road in front, old road behind goes back to the pool ---------- */
  function stream(z, all) {
    const kp = Math.floor(z / CL); curK = kp;
    let did = 0;
    for (let k = kp - BEHIND; k <= kp + AHEAD; k++) {
      if (A.chunks.some(c => c.idx === k)) continue;
      let pool = null, far = -1;
      A.chunks.forEach(c => { const d = c.idx === -999 ? 1e9 : (c.idx < kp - BEHIND || c.idx > kp + AHEAD) ? Math.abs(c.idx - kp) : -1; if (d > far) { far = d; pool = c; } });
      if (!pool || far < 0) break;
      genChunk(pool, k); did++;
      if (!all) break;                                           // one chunk per frame while riding (smooth), all of them on start
    }
    if (did) gather();
    return did;
  }
  function releaseAll() {
    clearPeople();
    A.chunks.forEach(ch => { ch.idx = -999; ch.ground.m.setEnabled(false); ch.road.m.setEnabled(false); ch.verge.m.setEnabled(false); ch.road2.m.setEnabled(false); ch.verge2.m.setEnabled(false); ch.sp.forEach(s => s.m.setEnabled(false)); ch.spurs.length = 0; ch.houses.forEach(houseRelease); ch.houses.length = 0; ch.nc = ch.ncw = ch.nv = 0; ch.stops.length = 0; ch.vm.forEach(o => { o.n = 0; }); ch.om.forEach(o => { o.n = 0; }); });
    A.vm.forEach(d => { if (d) d.parts.forEach(m => { m.thinInstanceCount = 0; m.setEnabled(false); }); });
    A.om.forEach(d => { d.mesh.thinInstanceCount = 0; d.mesh.setEnabled(false); });
    if (A.cow) { A.cow.thinInstanceCount = 0; A.cow.setEnabled(false); }
    A.cowFx.forEach(f => { f.t = 9; f.m.setEnabled(false); });
    hidePk();
    if (A.liv) { A.liv.mesh.thinInstanceCount = 0; A.liv.mesh.setEnabled(false); }
    A.chunks.forEach(ch => { ch.herd = null; ch.plan = null; });
    if (A.vil) { A.vil.n = 0; A.vil.robe.thinInstanceCount = 0; A.vil.head.thinInstanceCount = 0; A.vil.robe.setEnabled(false); A.vil.head.setEnabled(false); }
  }

  /* ============================== RUN STATE ============================== */
  const R_ = { pot: 0, pB: 0, pW: 0, potCd: 0, startWorn: false, warnAt: 1e9, cWarned: false, collT: 0, cJ: 0, cSec: -1, mag: 0, boost: 0, dbl: 0, phase: 0, deliv: 0, warnT: 0, unlockedNow: false, dist: 0, lvl: 1, stage: 1, lives: LIVES, cow: 0, stam: 100, exh: false, tired: false, invul: 0, toastT: 0, t: 0, streak: 0, lastCow: -9, mended: 0, last: {} };
  const saved = { obs: null, fog: FOG_FREE, query: null };
  /* ============================== TIME OF DAY ==============================
     One full day lasts TOD.cyc seconds of riding: sunrise, morning, midday, afternoon, golden dusk, twilight, moonlit night, then dawn again. Each town starts at its own hour.
     Sky, sun, lights, fog and the lighting colours of every shader material follow the palette (each material keeps its own baseline and is only scaled), and everything snaps back to normal daylight when the run ends. */
  const K_ = (u, zen, mid, hor, fog, sunMul, skyMul, hazeMul, hemiI, sunI, hemiD, hemiG, sunD, elev, disc, glow, cloud, star) => ({ u, zen, mid, hor, fog, sunMul, skyMul, hazeMul, hemiI, sunI, hemiD, hemiG, sunD, elev, disc, glow, cloud, star });
  const TOD_K = [
    K_(0, [.20, .24, .50], [.55, .50, .72], [1, .62, .38], [.98, .66, .46], [1.15, .80, .55], [.95, .85, .95], [1.05, .78, .60], .64, .95, [1, .82, .72], [.50, .38, .40], [1, .68, .42], .14, [1, .85, .60], [1, .60, .35], [1, .82, .70], 0),
    K_(.10, [.13, .25, .56], [.34, .52, .84], [.98, .82, .60], [.96, .82, .62], [1.05, .95, .80], [1, 1, 1], [1, .95, .85], .74, 1.08, [1, .94, .82], [.55, .44, .42], [1, .86, .62], .36, [1, .93, .72], [1, .76, .42], [1, .94, .84], 0),
    K_(.30, [.10, .20, .47], [.28, .45, .78], [.95, .86, .66], [.95, .86, .66], [1, 1, 1], [1, 1, 1], [1, 1, 1], .78, 1.15, [1, .96, .86], [.56, .44, .42], [1, .90, .68], .55, [1, .95, .76], [1, .80, .46], [.99, .96, .86], 0),
    K_(.55, [.10, .20, .47], [.30, .45, .76], [.97, .83, .60], [.96, .83, .60], [1.05, .95, .78], [1, .98, .95], [1, .95, .85], .76, 1.12, [1, .95, .84], [.56, .44, .42], [1, .86, .60], .42, [1, .92, .70], [1, .76, .42], [1, .92, .80], 0),
    K_(.70, [.16, .17, .42], [.55, .38, .56], [1, .55, .26], [.98, .60, .34], [1.20, .76, .42], [1, .80, .80], [1.10, .74, .48], .56, .92, [.98, .74, .66], [.46, .32, .34], [1, .58, .30], .13, [1, .78, .50], [1, .50, .25], [1, .70, .55], 0),
    K_(.82, [.07, .08, .26], [.20, .20, .42], [.62, .36, .42], [.44, .32, .40], [.60, .46, .60], [.60, .60, .85], [.62, .52, .68], .46, .55, [.70, .66, .90], [.28, .26, .36], [.70, .55, .80], .08, [.95, .90, .90], [.80, .50, .50], [.55, .45, .60], .35),
    K_(.92, [.02, .03, .11], [.06, .09, .22], [.12, .15, .28], [.11, .14, .26], [.44, .52, .80], [.62, .70, .96], [.52, .60, .82], .48, .62, [.55, .62, .95], [.20, .22, .34], [.50, .60, 1], .50, [.90, .93, 1], [.40, .50, .90], [.22, .26, .38], 1)
  ];
  TOD_K.push(Object.assign({}, TOD_K[0], { u: 1 }));
  const TOWN_TOD = [.10, 0, .30, .52, .68, .20, .02, .62];                           // start hour of each town (AREAS order): morning, sunrise, midday, afternoon, golden dusk, bright morning, misty dawn, late-afternoon gold
  const TOD = { on: false, t: 0, u0: .3, cyc: 420, c: new WeakMap() };
  const todMix = (a, b, t) => Array.isArray(a) ? a.map((v, i) => v + (b[i] - v) * t) : a + (b - a) * t;
  function todSample(u) {
    u = ((u % 1) + 1) % 1; let i = 0; while (i < TOD_K.length - 2 && u >= TOD_K[i + 1].u) i++;
    const a = TOD_K[i], b = TOD_K[i + 1]; let t = (u - a.u) / (b.u - a.u); t = t * t * (3 - 2 * t); const P = {};
    for (const key in a) if (key !== 'u') P[key] = todMix(a[key], b[key], t);
    return P;
  }
  function todApply(P) {
    const sc = scene; if (!sc || !sc.fogColor) return;
    const hemi = sc.getLightByName('hemi'), sun = sc.getLightByName('sun'), sky = sc.getMaterialByName('sky'), sd = S && S.world && S.world.sunDir;
    sc.clearColor.copyFromFloats(P.hor[0], P.hor[1], P.hor[2], 1); sc.fogColor.copyFromFloats(P.fog[0], P.fog[1], P.fog[2]);
    if (sd) sd.copyFromFloats(.55, P.elev, -.5).normalize();
    if (sun) { sun.diffuse.copyFromFloats(P.sunD[0], P.sunD[1], P.sunD[2]); sun.intensity = P.sunI; if (sd) sun.direction.copyFromFloats(-sd.x, -sd.y, -sd.z); try { sun.forceProjectionMatrixCompute(); } catch (e) { /* ok */ } }
    if (hemi) { hemi.diffuse.copyFromFloats(P.hemiD[0], P.hemiD[1], P.hemiD[2]); hemi.groundColor.copyFromFloats(P.hemiG[0], P.hemiG[1], P.hemiG[2]); hemi.intensity = P.hemiI; }
    if (sky) {
      const sv = (n, a) => { let v = TOD.c.get(sky); if (!v) { v = {}; TOD.c.set(sky, v); } if (!v[n]) { v[n] = new B.Vector3(); sky.setVector3(n, v[n]); } v[n].copyFromFloats(a[0], a[1], a[2]); };
      sv('skyZen', P.zen); sv('skyMid', P.mid); sv('skyHor', P.hor); sv('sunGlow', P.glow); sv('sunDisc', P.disc); sv('cloudCol', P.cloud); sky.setFloat('starAmt', P.star);
    }
    const mats = sc.materials;
    for (let i = 0; i < mats.length; i++) {
      const m = mats[i]; if (!m || m === sky || !m._vectors3 || !m.setVector3) continue;
      let c = TOD.c.get(m);
      if (!c) {
        const v = m._vectors3; if (!v.sunCol && !v.fogCol) { TOD.c.set(m, { skip: true }); continue; }
        c = { b: {}, cur: {} };
        ['sunCol', 'skyCol', 'hazeCol'].forEach(n => { if (v[n]) { c.b[n] = [v[n].x, v[n].y, v[n].z]; c.cur[n] = new B.Vector3(v[n].x, v[n].y, v[n].z); m.setVector3(n, c.cur[n]); } });
        if (v.fogCol) { c.fog = new B.Vector3(v.fogCol.x, v.fogCol.y, v.fogCol.z); m.setVector3('fogCol', c.fog); }
        TOD.c.set(m, c);
      }
      if (c.skip) continue;
      if (c.cur.sunCol) c.cur.sunCol.copyFromFloats(c.b.sunCol[0] * P.sunMul[0], c.b.sunCol[1] * P.sunMul[1], c.b.sunCol[2] * P.sunMul[2]);
      if (c.cur.skyCol) c.cur.skyCol.copyFromFloats(c.b.skyCol[0] * P.skyMul[0], c.b.skyCol[1] * P.skyMul[1], c.b.skyCol[2] * P.skyMul[2]);
      if (c.cur.hazeCol) c.cur.hazeCol.copyFromFloats(c.b.hazeCol[0] * P.hazeMul[0], c.b.hazeCol[1] * P.hazeMul[1], c.b.hazeCol[2] * P.hazeMul[2]);
      if (c.fog) c.fog.copyFromFloats(P.fog[0], P.fog[1], P.fog[2]);
    }
  }
  function todStart() { TOD.on = true; TOD.t = 0; TOD.u0 = TOWN_TOD[startTown] != null ? TOWN_TOD[startTown] : .3; try { todApply(todSample(TOD.u0)); } catch (e) { console.warn('Time of day', e); TOD.on = false; } }
  function todStop() { if (!TOD.on) return; TOD.on = false; try { todApply(todSample(.3)); } catch (e) { /* ok */ } }
  const fogMats = () => ['landMat', 'bMud', 'bThatch', 'bWood', 'bDecal'].map(n => scene.getMaterialByName(n)).filter(Boolean);
  function setFog(d) { scene.fogDensity = d; fogMats().forEach(m => { try { m.setFloat('fogD', d); } catch (e) { /* not a shader material */ } }); }
  const hitsOf = n => LIVES - Math.max(0, n), hearts = n => 'Hits ' + hitsOf(n) + '/' + LIVES;     // collision counter: 0/3 → 3/3 (the third ends the run)
  function toast(t) { const h = OYO.hud; h.toast = t; R_.toastT = 3; }

  function begin() {
    const h = OYO.hud; S = core.S; W = S.world; RD = S.riding; scene = S.scene;
    { const n = AREAS.length, i = parseInt(h.hmLoc, 10); startTown = (isFinite(i) && i >= 0 && i < n) ? i : 0; }      // run starts in the town picked on the start menu; no pick = the default town (first in the list)
    clearTimeout(previewT); previewT = 0; previewCart = null;                 // a run always uses the cart you really own/selected: never a locked one being looked at
    if (!cartOwned(save.cart)) { save.cart = 'starter'; store(); }
    cartUi();
    const wantCart = ownedCart();
    for (let k = 0; k < 2 && !(S.cart && S.cart.variant === wantCart); k++) swapCartModel();       // the hitched cart must be exactly the owned model (rebuilt if it is not)
    SEED = (Math.random() * 1e9) | 0; frame = 0; startZ = 0; villagerT = 0; if (S.cart) S.cart.rigid = true;     // rigid cart: it slides with the horse instead of swinging on lane changes
    ensureBuilt();
    try { const ns = (S.cart && S.cart.anchors && S.cart.anchors.seats.length) || 0; PAXMAX = wantCart === 'starter' ? Math.min(4, ns || 4) : (ns || 6); } catch (e) { PAXMAX = wantCart === 'starter' ? 4 : 6; }      // starter cart: ALWAYS 4 passenger seats, royal cart: 6
    // --- swap the world over to the endless corridor (restored in cleanup) ---
    const o = RD.obs; saved.obs = { x: o.x.slice(), z: o.z.slice(), r: o.r.slice(), h: o.h.slice(), k: o.k.slice() };
    saved.fog = scene.fogDensity || FOG_FREE; saved.query = W.queryRoad;
    W.setHeightFn(hgt); W.queryRoad = fakeQuery; W.endless = true;
    setFog(FOG); todStart();
    E.on = true; E.over = false; E.paused = false; E.crash = null; try { if (S.cart) S.cart.crashK = 0; OYO.hud.crashFx = false; } catch (err) { /* ok */ }
    try { if (RD.shadow) RD.shadow.setEnabled(false); } catch (err) { /* ok */ }      // no ground shadow under the player's horse + cart
    lane = 0; latV = 0; ghost = 0; prevSteer = 0; bindSwipe();
    Object.assign(R_, { mag: 0, boost: 0, dbl: 0, phase: 0, deliv: 0, warnT: 0, unlockedNow: false, pax: 0, pl: [], dist: 0, lvl: 1, stage: 1, lives: LIVES, npcN: 0, npcFatal: 0, cow: 0, stam: 100, exh: false, tired: false, invul: 1.5, toastT: 0, t: 0, streak: 0, lastCow: -9, mended: 0, pups: 0, fare: 0, oseOn: oseVisible(), rudeT: 40, rudeN: 0, thT: 0, pot: 0, pB: 0, pW: 0, potCd: 0, cWarned: false, collT: 0, cJ: 0, cSec: -1, startWorn: save.cartState !== 'ok', warnAt: Math.max(1200, 3600 - (save.dmgB + save.dmgW) * 350) });
    zoneReset(); R_.zone = -1; R_.zoneT = 0; R_.zoneArmed = 1.2; R_.fogNow = 0; stream(startZ, true); initPeopleRoad();
    core.tourOn(false); OYO.setMode('ride');
    try { if (S.cart && S.cart.seatPassengers) S.cart.seatPassengers(0); } catch (err) { /* ok */ }     // empty cart: passengers join at the bukas
    try { if (S.cart && !S.cart.hitched && RD.built) S.cart.hitch(RD); } catch (err) { console.warn('Re-hitch skipped', err); }       // horse and cart always start coupled
    try { if (S.cart && S.cart.hitched) RD.setDriver(S.cart); } catch (err) { console.warn('Driver seat skipped', err); }   // the messenger drives from the cart's front bench
    const z = 6, p = pt(z, 0), yaw = yawAt(z); RD.place(p[0], p[1], yaw); core.P.x = p[0]; core.P.z = p[1]; core.P.yaw = yaw; RD.state.bump = 0;
    try { RD.setActive(true); if (S.cart && S.cart.snapToHorse) S.cart.snapToHorse(); RD.cam.snap = true; } catch (err) { console.warn('Cart snap skipped', err); }       // cart + rider are on the horse from the very first frame (no lag, no pop-in)
    startZ = z; curK = Math.floor(z / CL);
    h.festOn = false; R_.festT = 0; h.screen = 'endless'; h.modal = ''; h.oseOn = R_.oseOn; h.eOse = save.ose; h.oseHot = false; h.thunder = 0; h.cow = 0; h.stam = 100; h.exh = false; h.rough = false; h.toast = ''; h.hint = false; h.ePax = '0/' + PAXMAX; h.eDist = '0 m'; h.eLvl = 1; h.eStage = STAGES[0][0]; h.eStageN = 1; h.eHearts = hearts(LIVES); h.eHits = 0; h.eWarn = ''; h.eCart = ''; h.eMag = h.eBoost = h.eDbl = h.ePhase = h.ePMag = h.ePBoost = h.ePDbl = h.ePPhase = 0; fxK = 0; h.eBest = fmtD(save.best); h.eRes = null; h.zoneOn = false; h.locName = AREAS[startTown][0]; h.eTgt = '—'; h.eTgtCap = 'pick-up'; cartUi();
    MS.playing = false; MS.paused = false; core.releaseInput();
    snd('init'); snd('start'); toast('Swipe to change lane · hold GALLOP · brake in a blue box to pick up passengers, then drop them at the next stop!');
  }

  function cleanup() {
    if (!E.on) return;
    try { todStop(); } catch (e) { /* ok */ }
    E.on = false; E.over = false; E.paused = false; E.crash = null; try { OYO.hud.crashFx = false; } catch (err) { /* ok */ } try { if (S.cart) { S.cart.rigid = false; S.cart.jolt = 0; S.cart.crashK = 0; } } catch (err) { /* ok */ }
    try { RD.setDriver(null); } catch (err) { /* ok */ }
    try { if (RD.shadow && RD.mesh && RD.mesh.isEnabled(false)) RD.shadow.setEnabled(true); } catch (err) { /* ok */ }
    try { if (S.cart && S.cart.seatPassengers) S.cart.seatPassengers(); } catch (err) { /* ok */ }         // restore the default Free Roam passengers              // the messenger goes back to the saddle for Free Roam
    try { releaseAll(); } catch (e) { console.warn('Endless cleanup', e); }
    try {
      if (window.OYOTerrain) W.setHeightFn(OYOTerrain.meshH);
      if (saved.query) W.queryRoad = saved.query; W.endless = false; setFog(saved.fog || FOG_FREE);
      const o = RD.obs, s = saved.obs; if (s) { o.x.length = o.z.length = o.r.length = o.h.length = o.k.length = 0; for (let i = 0; i < s.x.length; i++) { o.x.push(s.x[i]); o.z.push(s.z[i]); o.r.push(s.r[i]); o.h.push(s.h[i]); o.k.push(s.k[i]); } saved.obs = null; }
      try { window.OYOVillagers && OYOVillagers.setObstacles(RD.obs); } catch (e) { /* ok */ }
    } catch (e) { console.warn('Endless restore', e); }
    const h = OYO.hud; h.toast = ''; h.eWarn = ''; h.eCart = ''; h.eMag = h.eBoost = h.eDbl = h.ePhase = h.ePMag = h.ePBoost = h.ePDbl = h.ePPhase = 0; hidePk(); h.rough = false; h.eRes = null; h.zoneOn = false; MS.paused = false;
  }

  /* ============================== PER-FRAME HOOKS ============================== */
  function pre(dt, inp, st) {
    if (E.crash) { inp.gal = false; inp.steer = 0; inp.jump = false; inp.cap = 0; inp.spd = 0; prevSteer = 0; const o = RD.obs; o.x.length = o.z.length = o.r.length = o.h.length = o.k.length = 0; return; }      // crash sequence playing: no steering, no braking, nothing to hit
    let cap = 1;                                                            // no horse stamina any more: the horse never tires
    const off = Math.abs(latOf(st.x, st.z)) > HW * 1.25; if (off) cap = Math.min(cap, .72);
    if (R_.boost > 0) cap = 1;                                              // speed booster: the horse is never held back
    galNow = !!inp.gal; inp.jump = false;                                   // no jumping in Endless Run: the JUMP button is GALLOP
    inp.cap = cap; inp.spd = speedMul(R_.dist) * (R_.boost > 0 ? BOOST_MUL : galNow ? GAL : 1); OYO.hud.rough = off;
    // --- lane switching: A/D, ←/→ (and any steer input) become one-shot lane changes; the horse never steers freely ---
    const sv = inp.steer; if (sv > .55 && prevSteer <= .55) E.shift(1); else if (sv < -.55 && prevSteer >= -.55) E.shift(-1); prevSteer = sv; inp.steer = 0;
    try { npcLaneGuard(st); npcBrake(dt, st); } catch (e) { wOnce('npcsolid', e); }      // road riders are solid: no lane change into one, no riding through the back of one
    { // glide to the chosen lane BEFORE the horse and cart are posed this frame, so both always move together (danfo-run style straight slide)
      const ry = yawAt(st.z), lat = latOf(st.x, st.z), sl = slope(st.z), lq = Math.sqrt(1 + sl * sl), dl = (lane * LW - lat) * (1 - Math.exp(-dt * 11));
      st.x += dl / lq; st.z -= dl * sl / lq;
      latV += (dl / Math.max(dt, .001) - latV) * .35;
      st.yaw += angDiff(st.yaw, ry) * (1 - Math.exp(-dt * 14)); st.turn = 0;
    }
    // --- after a crash the horse rides through for a moment (no grinding against the rock) ---
    if (R_.phase > 0) ghost = Math.max(ghost, .8);                          // crate gift: ride straight through every obstacle (the list stays empty while it lasts + a short grace)
    if (ghost > 0) { ghost -= dt; const o = RD.obs; o.x.length = o.z.length = o.r.length = o.h.length = o.k.length = 0; if (ghost <= 0) gather(); }
  }

  const cq = new B.Quaternion(), csc = new B.Vector3(), ctr = new B.Vector3(), cmx = new B.Matrix();
  function updateCows(dt, st) {
    const cart = S.cart && S.cart.state && S.cart.state.hitched ? S.cart.state : null, buf = A.cowBuf; let n = 0;
    R_.t += dt;
    A.chunks.forEach(ch => {
      if (ch.idx === -999) return;
      for (let q = 0; q < ch.ncw; q++) {
        const o = q * 5; if (ch.cows[o + 3]) continue;
        let x = ch.cows[o], z = ch.cows[o + 2];
        if (R_.mag > 0) { const mx = st.x - x, mz = st.z - z, m2 = mx * mx + mz * mz; if (m2 < MAG_R * MAG_R && m2 > .04) { const f = 1 - Math.exp(-dt * 7); x += mx * f; z += mz * f; ch.cows[o] = x; ch.cows[o + 2] = z; ch.cows[o + 1] += (st.y + .5 - ch.cows[o + 1]) * f; } }       // magnet: cowries fly to the cart
        let dx = x - st.x, dz = z - st.z, d2 = dx * dx + dz * dz, hit = d2 < COW_PICK * COW_PICK;
        if (!hit && cart) { dx = x - cart.x; dz = z - cart.z; hit = dx * dx + dz * dz < COW_PICK * COW_PICK; }
        if (hit) { collect(ch, q); continue; }
        if (d2 > COW_SHOW * COW_SHOW) continue;
        B.Quaternion.RotationYawPitchRollToRef(R_.t * 2.2 + ch.cows[o + 4], .45, 0, cq); csc.set(1.25, 1.25, 1.25);
        ctr.set(x, ch.cows[o + 1] + .95 + Math.sin(R_.t * 2.6 + ch.cows[o + 4]) * .05, z);
        B.Matrix.ComposeToRef(csc, cq, ctr, cmx); buf.set(cmx.m, n * 16); n++;
      }
    });
    if (A.cow) { A.cow.thinInstanceCount = n; A.cow.setEnabled(n > 0); if (n) A.cow.thinInstanceBufferUpdated('matrix'); }
    A.cowFx.forEach(f => {
      if (f.t >= .5) return; f.t += dt; if (f.t >= .5) { f.m.setEnabled(false); return; }
      const k = f.t / .5; f.m.position.set(f.x, f.y + k * .7, f.z); f.m.scaling.set(.4 + k * 1.6, .4 + k * 1.6, .4 + k * 1.6); f.m.material.alpha = .75 * (1 - k);
    });
  }
  /* livestock crossings: animals wait on the verge, start walking across when the cart is ~4 s away, and are ordinary one-hit collisions (like a rock).
     Only one animal is ever in the cart's way at a time (HERD_GAP apart); they stand still instead of walking into a halted cart. */
  function updateLivestock(dt, st) {
    const L = A.liv; if (!L) return; let n = 0; const sp = Math.abs(st.speed), h = OYO.hud;
    A.chunks.forEach(ch => {
      const hd = ch.idx === -999 ? null : ch.herd; if (!hd) return;
      for (const a of hd.an) {
        const dz = a.z - st.z; if (dz < -30 || dz > COW_SHOW + 60) continue;
        if (a.s === 0 && dz < Math.min(130, Math.max(55, sp * 4.2))) a.s = 1;
        const rA = a.kind ? .8 : .55;
        if (a.s === 1) {
          if (!(dz > -3 && dz < 14 && sp < 2.5)) a.t += dt;
          a.lat = a.side * HERD_LAT - a.side * (a.kind ? 1.5 : 2.1) * a.t;
          if (a.lat * a.side <= -HERD_LAT) { a.lat = -a.side * HERD_LAT; a.s = 2; }
        }
        const p = pt(a.z, a.lat);
        if (!a.hit && sp > 2 && ghost <= 0 && R_.phase <= 0) { const dx = p[0] - st.x, dy = p[1] - st.z; if (dx * dx + dy * dy < (rA + .85) * (rA + .85)) { a.hit = true; st.speed *= .5; st.bump = 1; R_.animalHit = true; } }
        if (n >= LIV_MAX) continue;
        const walk = a.s === 1 ? R_.t * 8 + a.z : 0, yaw = yawAt(a.z) - a.side * PI / 2, sc = a.kind ? 1.55 : 1, c = LIV_TINT[a.kind][a.tint];
        B.Quaternion.RotationYawPitchRollToRef(yaw, 0, Math.sin(walk) * .05, cq); csc.set(sc, sc, sc);
        ctr.set(p[0], hgt(p[0], p[1]) + Math.abs(Math.sin(walk)) * .04, p[1]); B.Matrix.ComposeToRef(csc, cq, ctr, cmx);
        L.mat.set(cmx.m, n * 16); L.col[n * 4] = c[0]; L.col[n * 4 + 1] = c[1]; L.col[n * 4 + 2] = c[2]; L.col[n * 4 + 3] = 1; n++;
      }
    });
    L.mesh.thinInstanceCount = n; L.mesh.setEnabled(n > 0); if (n) { L.mesh.thinInstanceBufferUpdated('matrix'); L.mesh.thinInstanceBufferUpdated('color'); }
  }
  function collect(ch, q) {
    const o = q * 5, h = OYO.hud; ch.cows[o + 3] = 1; R_.cow += R_.dbl > 0 ? 2 : 1; h.cow = R_.cow; h.cowPop = true; setTimeout(() => { h.cowPop = false; }, 170);
    R_.streak = (R_.t - R_.lastCow < 1.3) ? Math.min(R_.streak + 1, 6) : 0; R_.lastCow = R_.t; snd('cowrie', R_.streak);
    const f = A.cowFx.find(z => z.t >= .5); if (f) { f.t = 0; f.x = ch.cows[o]; f.y = ch.cows[o + 1] + .6; f.z = ch.cows[o + 2]; f.m.setEnabled(true); }
  }


  /* ============================== POWER-UPS: magnet · speed booster · mystery crate ============================== */
  const DURS = { mag: MAG_T, boost: BOOST_T, dbl: DBL_T, phase: PHASE_T }, NST = 28, stk = [];
  let fxK = 0;
  const POOL = { mag: [], boost: [], dbl: [], crate: [], ose: [] };
  function buildPickups() {
    const V3 = (x, y, z) => new B.Vector3(x, y, z);
    const mk = (n, d, e) => { const m = new B.StandardMaterial(n, scene); m.diffuseColor = new B.Color3(d[0], d[1], d[2]); m.emissiveColor = new B.Color3(e[0], e[1], e[2]); m.specularColor = new B.Color3(.3, .3, .3); return m; };
    const M = { red: mk('pkRed', [.85, .1, .1], [.5, .05, .05]), steel: mk('pkSteel', [.85, .87, .9], [.35, .35, .38]), cyan: mk('pkCyan', [.2, .85, 1], [.1, .55, .75]), gold: mk('pkGold', [1, .78, .2], [.6, .43, .08]), wood: mk('pkWood', [.5, .3, .14], [.24, .13, .06]),
      camwood: mk('pkCam', [.68, .16, .08], [.4, .07, .04]), indigo: mk('pkIndigo', [.1, .16, .5], [.05, .08, .3]), cowrie: mk('pkCowrie', [.97, .94, .84], [.55, .52, .44]), gourd: mk('pkGourd', [.8, .46, .12], [.4, .2, .05]),
      gourdD: mk('pkGourdD', [.45, .24, .08], [.2, .1, .03]), burlap: mk('pkBurlap', [.74, .56, .33], [.42, .3, .15]), rope: mk('pkRope', [.45, .3, .16], [.22, .14, .07]), foam: mk('pkFoam', [1, 1, .96], [.7, .7, .66]), sRed: mk('pkSRed', [.92, .1, .08], [.6, .05, .04]), sWhite: mk('pkSWhite', [.97, .97, .97], [.6, .6, .62]), bolt: mk('pkBolt', [.9, .85, 1], [.8, .7, 1]) };
    const glow = (n, c) => { const m = new B.StandardMaterial(n, scene); m.disableLighting = true; m.diffuseColor = B.Color3.Black(); m.specularColor = B.Color3.Black(); m.emissiveColor = new B.Color3(c[0], c[1], c[2]); m.alpha = .55; return m; };
    const RING = { mag: glow('pkRingM', [1, .25, .2]), boost: glow('pkRingB', [1, .68, .2]), crate: glow('pkRingC', [1, .8, .25]), ose: glow('pkRingO', [.7, .55, 1]), dbl: glow('pkRingD', [1, .8, .25]) };
    const put = (m, par, mat, x, y, z) => { m.material = mat; m.parent = par; m.position.set(x || 0, y || 0, z || 0); m.isPickable = false; return m; };
    const unlit = (n, tex) => { const m = new B.StandardMaterial(n, scene); m.diffuseTexture = tex; m.diffuseColor = new B.Color3(1, 1, 1); m.emissiveColor = new B.Color3(1, 1, 1); m.specularColor = B.Color3.Black(); m.disableLighting = true; m.backFaceCulling = false; return m; };
    // the sack is CLOTHED in the sponsor's logo: one printed-cloth texture wraps the whole body (logo on the front and the back, woven-cloth grain, gold stitching)
    const fabric = (n, tex) => { const m = new B.StandardMaterial(n, scene); m.diffuseTexture = tex; m.diffuseColor = new B.Color3(.8, .8, .8); m.emissiveTexture = tex; m.emissiveColor = new B.Color3(.5, .5, .5); m.specularColor = new B.Color3(.08, .08, .08); m.backFaceCulling = false; return m; };
    const weave = (g, W, H, a) => { g.lineWidth = 1; g.strokeStyle = 'rgba(120,92,52,' + a + ')'; for (let x = 0; x < W; x += 5) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, H); g.stroke(); } for (let y = 0; y < H; y += 5) { g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); } };
    const stitch = (g, W, y) => { g.save(); g.setLineDash([14, 10]); g.lineWidth = 4; g.strokeStyle = '#c9962b'; g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); g.restore(); };
    const CLOTH = '#fcf8f4';
    const sackTex = new B.DynamicTexture('pkSackFabric', { width: 1024, height: 512 }, scene, true), sg = sackTex.getContext();
    sg.fillStyle = CLOTH; sg.fillRect(0, 0, 1024, 512); weave(sg, 1024, 512, .07); stitch(sg, 1024, 30); stitch(sg, 1024, 482); sackTex.update();
    const neckTex = new B.DynamicTexture('pkSackNeck', { width: 128, height: 128 }, scene, true), ng = neckTex.getContext();
    ng.fillStyle = CLOTH; ng.fillRect(0, 0, 128, 128); weave(ng, 128, 128, .09); ng.fillStyle = '#d9a52c'; ng.fillRect(0, 54, 128, 20); ng.fillStyle = '#1b1b1b'; ng.fillRect(0, 50, 128, 4); ng.fillRect(0, 74, 128, 4); neckTex.update();
    { const im = new Image(); im.onload = () => {                           // logo printed twice round the sack (front faces the rider at u = .5, the back copy wraps over the seam)
        const lw = 470, lh = Math.round(lw * im.naturalHeight / im.naturalWidth), y0 = Math.round(256 - lh / 2 + 6);
        for (const cx of [512, 0, 1024]) sg.drawImage(im, cx - lw / 2, y0, lw, lh);
        weave(sg, 1024, 512, .05); stitch(sg, 1024, 30); stitch(sg, 1024, 482); sackTex.update(); };
      im.src = 'assets/art/sponsor-logo.jpg'; }
    const FAB = fabric('pkSackFabricMat', sackTex), FABN = fabric('pkSackNeckMat', neckTex);
    const sackBody = (name, dia, rings, segs) => {                          // own UV sphere: u runs round the sack (front = -z at u .5, left to right as the rider sees it), v runs top to bottom
      const P = [], N = [], T = [], I = [], r = dia / 2;
      for (let i = 0; i <= rings; i++) { const ph = Math.PI * i / rings, sy = Math.cos(ph), sr = Math.sin(ph);
        for (let j = 0; j <= segs; j++) { const th = -Math.PI + 2 * Math.PI * j / segs, nx = sr * Math.sin(th), nz = -sr * Math.cos(th); P.push(nx * r, sy * r, nz * r); N.push(nx, sy, nz); T.push(j / segs, 1 - i / rings); } }
      for (let i = 0; i < rings; i++) for (let j = 0; j < segs; j++) { const a = i * (segs + 1) + j, b = a + segs + 1; I.push(a, b, a + 1, b, b + 1, a + 1); }
      const vd = new B.VertexData(); vd.positions = P; vd.normals = N; vd.uvs = T; vd.indices = I;
      const m = new B.Mesh(name, scene); vd.applyToMesh(m); return m;
    };
    const bt = new B.DynamicTexture('pkDblBadgeTex', { width: 128, height: 128 }, scene, true), bg = bt.getContext();
    { const gr = bg.createRadialGradient(52, 46, 6, 64, 64, 66); gr.addColorStop(0, '#ffe58a'); gr.addColorStop(1, '#e09a1c'); bg.fillStyle = gr; bg.fillRect(0, 0, 128, 128);
      bg.lineWidth = 9; bg.strokeStyle = '#7a4a08'; bg.beginPath(); bg.arc(64, 64, 58, 0, Math.PI * 2); bg.stroke();
      bg.fillStyle = '#3a1606'; bg.font = '800 62px Nunito, "Baloo 2", system-ui, sans-serif'; bg.textAlign = 'center'; bg.textBaseline = 'middle'; bg.fillText('\u00d72', 64, 70); bt.update(); }
    const BADGE = unlit('pkDblBadgeMat', bt);
    const make = kind => {
      const root = new B.TransformNode('pk_' + kind, scene), top = new B.TransformNode('pkTop_' + kind, scene); top.parent = root; top.position.y = 1.25; root._top = top; root.scaling.setAll(1.55);      // big, easy-to-spot power-ups
      put(B.MeshBuilder.CreateTorus('pkRing', { diameter: 2.3, thickness: .13, tessellation: 24 }, scene), root, RING[kind], 0, .12, 0);
      if (kind === 'mag') {                                                  // Yoruba magnet: camwood-red horseshoe, brass tips, indigo adire bands and a string of cowries along the bend
        const P = [V3(-.45, -.35, 0), V3(-.45, 0, 0)]; for (let a = 1; a < 12; a++) { const t = Math.PI - Math.PI * a / 12; P.push(V3(Math.cos(t) * .45, Math.sin(t) * .45, 0)); } P.push(V3(.45, 0, 0), V3(.45, -.35, 0));
        put(B.MeshBuilder.CreateTube('pkMagU', { path: P, radius: .15, tessellation: 8, cap: B.Mesh.CAP_ALL }, scene), top, M.camwood);
        for (const sx of [-1, 1]) {
          put(B.MeshBuilder.CreateCylinder('pkMagTip', { diameter: .36, height: .24, tessellation: 10 }, scene), top, M.gold, sx * .45, -.4, 0);                  // brass (idẹ) tips
          put(B.MeshBuilder.CreateTorus('pkMagBand', { diameter: .38, thickness: .07, tessellation: 12 }, scene), top, M.indigo, sx * .45, -.14, 0);              // indigo adire band
          put(B.MeshBuilder.CreateTorus('pkMagBand2', { diameter: .38, thickness: .05, tessellation: 12 }, scene), top, M.cowrie, sx * .45, -.24, 0);
        }
        for (let q = 1; q < 6; q++) { const t = Math.PI * q / 6, c = put(B.MeshBuilder.CreateSphere('pkMagCw', { diameter: .13, segments: 5 }, scene), top, M.cowrie, Math.cos(t) * .45, Math.sin(t) * .45, .15); c.scaling.set(.8, 1.25, .55); c.rotation.z = t - Math.PI / 2; }
        top.scaling.setAll(1.25);
      } else if (kind === 'boost') {                                         // Yoruba palm wine gourd (igba ẹmu): round calabash, narrow neck, foaming palm wine, indigo band and cowrie trim
        const body = put(B.MeshBuilder.CreateSphere('pkGourdB', { diameter: .95, segments: 12 }, scene), top, M.gourd, 0, 0, 0); body.scaling.y = .95;
        put(B.MeshBuilder.CreateCylinder('pkGourdN', { diameterTop: .24, diameterBottom: .42, height: .4, tessellation: 12 }, scene), top, M.gourd, 0, .53, 0);
        put(B.MeshBuilder.CreateTorus('pkGourdRim', { diameter: .3, thickness: .06, tessellation: 12 }, scene), top, M.gourdD, 0, .73, 0);
        const foam = put(B.MeshBuilder.CreateSphere('pkFoam', { diameter: .36, segments: 8 }, scene), top, M.foam, 0, .8, 0); foam.scaling.y = .62;
        for (const [fx, fz] of [[.15, .05], [-.12, .1], [.02, -.15]]) put(B.MeshBuilder.CreateSphere('pkFoamB', { diameter: .14, segments: 6 }, scene), top, M.foam, fx, .86, fz);
        put(B.MeshBuilder.CreateTorus('pkGourdBand', { diameter: .93, thickness: .06, tessellation: 20 }, scene), top, M.indigo, 0, .13, 0);
        put(B.MeshBuilder.CreateTorus('pkGourdBand2', { diameter: .9, thickness: .045, tessellation: 20 }, scene), top, M.cowrie, 0, -.2, 0);
        for (let q = 0; q < 8; q++) { const t = q * Math.PI / 4, c = put(B.MeshBuilder.CreateSphere('pkGourdCw', { diameter: .11, segments: 5 }, scene), top, M.cowrie, Math.cos(t) * .465, -.03, Math.sin(t) * .465); c.scaling.set(.6, 1.2, .8); c.rotation.y = -t; }
        top.scaling.setAll(1.25);
      } else if (kind === 'ose') {                                           // Ose Ṣàngó: carved staff topped with Ṣàngó's double-headed thunder axe (red and white), beads and a crackle of lightning
        put(B.MeshBuilder.CreateCylinder('pkOseS', { diameter: .1, height: 1.45, tessellation: 8 }, scene), top, M.wood, 0, -.1, 0);
        for (const yy of [-.55, -.3, .05]) put(B.MeshBuilder.CreateTorus('pkOseRing', { diameter: .17, thickness: .04, tessellation: 10 }, scene), top, M.gold, 0, yy, 0);
        put(B.MeshBuilder.CreateBox('pkOseHub', { width: .2, height: .46, depth: .13 }, scene), top, M.gold, 0, .78, 0);
        const bl = put(B.MeshBuilder.CreateCylinder('pkOseBl', { diameterTop: 0, diameterBottom: .62, height: .52, tessellation: 3 }, scene), top, M.sRed, -.33, .78, 0); bl.rotation.z = Math.PI / 2; bl.scaling.z = .35;
        const br = put(B.MeshBuilder.CreateCylinder('pkOseBr', { diameterTop: 0, diameterBottom: .62, height: .52, tessellation: 3 }, scene), top, M.sWhite, .33, .78, 0); br.rotation.z = -Math.PI / 2; br.scaling.z = .35;
        put(B.MeshBuilder.CreateSphere('pkOseKnob', { diameter: .17, segments: 6 }, scene), top, M.gold, 0, 1.06, 0);
        for (let q = 0; q < 6; q++) { const t = q * Math.PI / 3; put(B.MeshBuilder.CreateSphere('pkOseBead', { diameter: .09, segments: 5 }, scene), top, q % 2 ? M.sWhite : M.sRed, Math.cos(t) * .11, .5, Math.sin(t) * .11); }
        put(B.MeshBuilder.CreateTube('pkOseZap', { path: [V3(.1, .5, .1), V3(.3, .35, .12), V3(.14, .22, .1), V3(.34, .02, .12), V3(.2, -.12, .1)], radius: .028, tessellation: 5 }, scene), top, M.bolt);
        put(B.MeshBuilder.CreateTube('pkOseZap2', { path: [V3(-.1, .5, -.1), V3(-.3, .36, -.12), V3(-.14, .2, -.1), V3(-.34, .0, -.12)], radius: .028, tessellation: 5 }, scene), top, M.bolt);
        top.scaling.setAll(1.05);
      } else if (kind === 'dbl') {                                           // ×2 cowries, sponsored by Wealth Art & Decor: a sack of cowries tied at the neck and clothed head to toe in the sponsor's logo cloth (no patch, no lettering), a ×2 badge, cowries spilling out of the top
        const belly = put(sackBody('pkSackB', 1.3, 18, 36), top, FAB, 0, -.12, 0); belly.scaling.set(1.0, .92, .92);
        put(B.MeshBuilder.CreateCylinder('pkSackN', { diameterTop: .5, diameterBottom: .74, height: .34, tessellation: 12 }, scene), top, FABN, 0, .52, 0);
        put(B.MeshBuilder.CreateTorus('pkSackTie', { diameter: .52, thickness: .075, tessellation: 14 }, scene), top, M.rope, 0, .6, 0);
        const lip = put(B.MeshBuilder.CreateCylinder('pkSackLip', { diameterTop: .98, diameterBottom: .5, height: .3, tessellation: 12 }, scene), top, FABN, 0, .83, 0);
        put(B.MeshBuilder.CreateCylinder('pkSackFill', { diameter: .84, height: .06, tessellation: 12 }, scene), top, M.gourdD, 0, .95, 0);
        for (let q = 0; q < 13; q++) { const t = q * 2.4, rr = .06 + (q % 5) * .075, c = put(B.MeshBuilder.CreateSphere('pkSackCw', { diameter: .2, segments: 6 }, scene), top, M.cowrie, Math.cos(t) * rr, .99 + (q % 4) * .07, Math.sin(t) * rr * .8); c.scaling.set(.8, 1.1, .62); c.rotation.set(.3 * Math.sin(t), t, .4 * Math.cos(t)); }
        for (let q = 0; q < 3; q++) { const t = .7 + q * 2.2, c = put(B.MeshBuilder.CreateSphere('pkSackCwF', { diameter: .2, segments: 6 }, scene), top, M.cowrie, Math.cos(t) * .62, -.7 + q * .02, Math.sin(t) * .5 - .2); c.scaling.set(.8, 1.1, .6); c.rotation.y = t; }      // a few cowries that fell out at the foot of the sack
        for (let q = 0; q < 10; q++) { const t = Math.PI * 2 * q / 10 + .31; if (Math.abs(Math.cos(t - Math.PI / 2)) > .9) continue; const c = put(B.MeshBuilder.CreateSphere('pkSackTrim', { diameter: .13, segments: 5 }, scene), top, M.cowrie, Math.cos(t) * .6, -.46, Math.sin(t) * .55); c.scaling.set(.65, 1.15, .5); c.rotation.y = -t; }          // stitched cowrie trim round the belly
        put(B.MeshBuilder.CreateDisc('pkDblBadge', { radius: .22, tessellation: 28 }, scene), top, BADGE, .38, .24, -.58);
        top.scaling.setAll(1.18);
      } else {                                                               // wooden mystery crate with gold bands and a gold knob
        put(B.MeshBuilder.CreateBox('pkCrate', { size: 1 }, scene), top, M.wood);
        put(B.MeshBuilder.CreateBox('pkBandH', { width: 1.06, height: .14, depth: 1.06 }, scene), top, M.gold, 0, .3, 0);
        put(B.MeshBuilder.CreateBox('pkBandH2', { width: 1.06, height: .14, depth: 1.06 }, scene), top, M.gold, 0, -.3, 0);
        put(B.MeshBuilder.CreateBox('pkBandV', { width: .14, height: 1.06, depth: 1.06 }, scene), top, M.gold);
        put(B.MeshBuilder.CreateSphere('pkKnob', { diameter: .3, segments: 6 }, scene), top, M.gold, 0, .62, 0);
        top.scaling.setAll(1.1);
      }
      root.setEnabled(false); return root;
    };
    for (const k in POOL) for (let i = 0; i < 3; i++) POOL[k].push(make(k));
    // wind streaks (one thin-instance mesh, 28 instances) for the booster
    const b = B.MeshBuilder.CreateBox('endWind', { width: .05, height: .05, depth: 1 }, scene), mt = new B.StandardMaterial('endWindMat', scene);
    mt.disableLighting = true; mt.diffuseColor = B.Color3.Black(); mt.specularColor = B.Color3.Black(); mt.emissiveColor = new B.Color3(1, 1, 1); mt.alpha = .5; mt.fogEnabled = false;
    b.material = mt; b.isPickable = false; b.alwaysSelectAsActiveMesh = true; b.alphaIndex = 40; A.wind = b; A.windBuf = new Float32Array(NST * 16);
    b.thinInstanceSetBuffer('matrix', A.windBuf, 16, false); b.thinInstanceCount = 0; b.setEnabled(false);
    for (let i = 0; i < NST; i++) stk.push({ x: 0, y: 0, z: -40, l: 4 });
    try { buildRiders(); } catch (err) { console.warn('Rude riders skipped', err); }
  }
  function hidePk() {
    fxK = 0; try { if (RD) RD.fovBoost = 0; } catch (e) { /* ok */ }
    for (const k in POOL) POOL[k].forEach(n => n.setEnabled(false));
    if (A.wind) { A.wind.thinInstanceCount = 0; A.wind.setEnabled(false); }
    hideRiders(); NPCS.forEach(hideRoyalNpc);
  }
  function ringFx(x, y, z) { const f = A.cowFx.find(q => q.t >= .5); if (f) { f.t = 0; f.x = x; f.y = y + .6; f.z = z; f.m.setEnabled(true); } }
  function activate(k) {
    R_[k] = DURS[k]; R_.pups = (R_.pups || 0) + 1;
    if (k === 'mag') toast('MAGNET! Cowries fly to you');
    else if (k === 'boost') toast('ẸMU! Palm wine gives your horse wings — SPEED BOOST!');
    else if (k === 'dbl') toast('🐚 ×2 COWRIES! Sponsored by Wealth Art & Decor');
    else toast('🛡 GHOST CART! Ride through obstacles');
  }
  function takePk(p) {
    p.taken = 1; ringFx(p.x, p.y, p.z); snd('cowrie', 5); snd('leg');
    if (p.kind === 'ose') { save.ose = Math.min(OSE_MAX, save.ose + 1); store(); OYO.hud.eOse = save.ose; R_.pups = (R_.pups || 0) + 1; toast('⚡ OSE ṢÀNGÓ! Kept for you (' + save.ose + ') — tap ⚡ to strike a rude rider'); return; }
    if (p.kind === 'crate') { const g = ['mag', 'dbl', 'phase'][Math.floor(Math.random() * 3)]; activate(g); toast('🎁 Mystery crate! ' + OYO.hud.toast); }
    else activate(p.kind);
  }
  function updatePickups(dt, st) {
    for (const k in DURS) if (R_[k] > 0) { R_[k] -= dt; if (R_[k] <= 0) { R_[k] = 0; if (k === 'phase') { R_.invul = Math.max(R_.invul, .9); toast('Ghost cart faded'); } else if (k === 'boost') toast('Boost over'); } }
    const cart = S.cart && S.cart.state && S.cart.state.hitched ? S.cart.state : null, used = { mag: 0, boost: 0, dbl: 0, crate: 0, ose: 0 }, yaw = yawAt(st.z);
    A.chunks.forEach(ch => {
      if (ch.idx === -999 || !ch.pk) return;
      for (const p of ch.pk) {
        if (p.taken) continue;
        let dx = p.x - st.x, dz = p.z - st.z; const d2 = dx * dx + dz * dz;
        let hit = d2 < PK_HIT * PK_HIT; if (!hit && cart) { dx = p.x - cart.x; dz = p.z - cart.z; hit = dx * dx + dz * dz < PK_HIT * PK_HIT; }
        if (hit) { takePk(p); continue; }
        if (d2 > PK_SHOW * PK_SHOW) continue;
        const n = POOL[p.kind][used[p.kind]++]; if (!n) continue;
        n.setEnabled(true); n.position.set(p.x, p.y, p.z); n._top.position.y = 1.25 + Math.sin(R_.t * 2.4 + p.ph) * .18;
        if (p.kind === 'dbl') { n.rotation.y = yawAt(p.z); n._top.rotation.y = Math.sin(R_.t * 1.6 + p.ph) * .5; } else n._top.rotation.y = R_.t * 1.8 + p.ph;
      }
    });
    for (const k in POOL) for (let i = used[k]; i < POOL[k].length; i++) if (POOL[k][i].isEnabled()) POOL[k][i].setEnabled(false);
    // --- wind effect: streaks rushing past the cart + a wider field of view while boosting (the HUD adds screen-edge speed lines) ---
    fxK += ((R_.boost > 0 ? 1 : 0) - fxK) * (1 - Math.exp(-dt * 4)); if (fxK < .01) fxK = 0;
    try { RD.fovBoost = fxK; } catch (e) { /* ok */ }
    const W_ = A.wind; if (!W_) return;
    if (fxK < .03) { if (W_.isEnabled()) { W_.thinInstanceCount = 0; W_.setEnabled(false); } return; }
    const c = cart || st, sy = Math.sin(c.yaw), cy = Math.cos(c.yaw), v = Math.abs(st.speed);
    B.Quaternion.RotationYawPitchRollToRef(c.yaw, 0, 0, cq);
    for (let i = 0; i < NST; i++) {
      const q = stk[i]; q.z -= (v + 22) * dt;
      if (q.z < -16) { q.z = 14 + Math.random() * 30; q.x = (Math.random() < .5 ? -1 : 1) * (1.5 + Math.random() * 4.5); q.y = .3 + Math.random() * 3.4; q.l = 3 + Math.random() * 5; }
      ctr.set(c.x + cy * q.x + sy * q.z, c.y + q.y, c.z - sy * q.x + cy * q.z); csc.set(1, 1, q.l);
      B.Matrix.ComposeToRef(csc, cq, ctr, cmx); A.windBuf.set(cmx.m, i * 16);
    }
    W_.material.alpha = .5 * fxK; W_.setEnabled(true); W_.thinInstanceCount = NST; W_.thinInstanceBufferUpdated('matrix');
  }

  /* ---------- people: Free Roam / mission villagers lent by villagers.js (same models, animation, speech and road-crossing behaviour) ---------- */
  const VIL = () => { const o = window.OYOVillagers; return o && o.endless && o.endless.ready ? o.endless : null; };
  const PIDS = ['wA', 'agA', 'wB', 'agC', 'wC', 'trdW', 'farmB', 'agB', 'boy', 'girl'], ADULT = ['wA', 'agA', 'wB', 'agC', 'wC', 'trdW'];
  let crossers = [], walkers = [], crossT = 3, scene_ = [], scT = 0, scLive = 0, scCool = 0;
  const SCARED = [
    ['Ẹ̀gbà mi! Rider, are you trying to kill us?', 'Ẹ̀gbìn mi! My waist, my waist!', 'Ṣe pẹ̀lẹ́ ni — slow down a little!'],
    ['Eeeh! Did you see that hole?!', 'Ọlọ́run mi! I nearly bit my tongue!', 'Ẹ jọ̀wọ́, ride gently!'],
    ['Ṣàngó, save us!', 'Is this a road or a farm?', 'Rider, I did not pay to suffer!'],
    ['Mo gbé! My load!', 'Hold on tight, mama!', 'This horse will scatter my bones.'],
    ['Ẹ̀gbọ́n, ta ló gbẹ́ ọ̀nà yìí? Who dug this road?', 'Olúwa mi o!', 'Ẹ wo ọ̀nà dáadáa, Rider — look before you ride!']
  ], SCARED1 = [['Ẹ̀gbà mi! Rider, watch the road!', 'My heart nearly left my body!'], ['Ẹ pẹ̀lẹ́! A hole!', 'Ọlọ́run mi, I am shaking!']];
  /* ============================== RUDE RIDERS + OSE ṢÀNGÓ (feature-gated: oseVisible()) ==============================
     A rude NPC rider gallops up behind the player, rides alongside, abuses them and shoves the cart (slows it; no lives lost).
     One Ose Ṣàngó (collected on the road, kept in the save until used) calls down a lightning strike that throws the rider off his horse. */
  const RIDERS = [], RUDE_SAY = ['Ìwọ! Gbà ọ̀nà fún mi! — Hey you! Give me the road!', 'Ṣé o fọ́jú ni? — Are you blind?', 'Ṣé ẹṣin rẹ ti kú? — Is your horse dead? Move!', 'Ẹ̀gbẹ́ kan! Slow rider, get aside!', 'Ọ̀dọ̀ ni ẹ́! — Move, you slowpoke!'],
    CHEER = [['Ṣàngó ń bẹ! — Ṣàngó is here!', 'Ẹ ṣé, Ṣàngó! That rider got what he deserved!'], ['Olúwa mi! Did you see that lightning?', 'Ṣàngó has punished him — ẹ ṣé o!']];
  /* ============================== REALISTIC ṢÀNGÓ LIGHTNING ==============================
     Real cloud-to-ground lightning is not a zig-zag line. It happens in stages, and this follows them:
       1. a faint STEPPED LEADER feels its way down from the cloud in fast, uneven jumps, forking as it goes (fractal, midpoint-displaced path);
       2. short STREAMERS leap UP from the ground, the rider and the horse to meet it;
       3. the channel connects and the RETURN STROKE races up it: the whole tree of branches blazes white-blue at once, the ground flashes, sparks fly, and the rider is hit now;
       4. dark gaps and 2-3 fast RE-STRIKES flicker along the same channel (branches die first), then a dim continuing glow fades out.
     Each channel is a white-hot core inside a wider blue-violet glow, so it blooms like the real thing. */
  let bfx = null;
  function boltJag(a, b, disp, depth, out) {                                    // midpoint displacement: kinks at every scale, never a repeating zig-zag
    if (depth <= 0) { out.push(b); return; }
    const m = B.Vector3.Center(a, b), d = b.subtract(a).normalize();
    let rx = Math.random() - .5, ry = Math.random() - .5, rz = Math.random() - .5; const dot = rx * d.x + ry * d.y + rz * d.z; rx -= dot * d.x; ry -= dot * d.y; rz -= dot * d.z;
    const k = disp * (.4 + Math.random() * 1.2) * 2 / (Math.hypot(rx, ry, rz) || 1); m.x += rx * k; m.y += ry * k * .6; m.z += rz * k;
    boltJag(a, m, disp * .56, depth - 1, out); boltJag(m, b, disp * .56, depth - 1, out);
  }
  function boltPath(a, b, disp, depth) { const out = [a]; boltJag(a, b, disp, depth, out); return out; }
  function killBolt() {
    const f = bfx; bfx = null; if (!f) return;
    f.items.forEach(q => { try { q.core.dispose(); if (q.halo) q.halo.dispose(); } catch (err) { /* ok */ } });
    f.extra.forEach(m => { try { m.dispose(); } catch (err) { /* ok */ } });
    try { OYO.hud.thunder = 0; } catch (err) { /* ok */ }
  }
  function spawnBolt(ex, ey, ez, onHit) {
    killBolt();
    if (!A.boltCore) {
      const mk = (n, c, al) => { const m = new B.StandardMaterial(n, scene); m.disableLighting = true; m.diffuseColor = B.Color3.Black(); m.specularColor = B.Color3.Black(); m.emissiveColor = new B.Color3(c[0], c[1], c[2]); m.fogEnabled = false; m.backFaceCulling = false; m.alpha = al; m.alphaMode = B.Engine.ALPHA_ADD; return m; };
      A.boltCore = mk('seBoltCore', [1, .98, 1], 1); A.boltHalo = mk('seBoltHalo', [.5, .58, 1], .5); A.boltSpark = mk('seBoltSpark', [1, .85, .55], 1); A.boltGround = mk('seBoltGround', [.62, .7, 1], .6);
    }
    const V3 = (x, y, z) => new B.Vector3(x, y, z), items = [], extra = [];
    const top = V3(ex + (Math.random() - .5) * 46, ey + 96 + Math.random() * 20, ez + (Math.random() - .5) * 30), end = V3(ex, ey + 3.1, ez);   // from the cloud base to the rider's head
    const main = boltPath(top, end, top.subtract(end).length() * .1, 6), n = main.length;
    const tube = (nm, path, r0, taper, mat, ai) => { const m = B.MeshBuilder.CreateTube(nm, { path, radiusFunction: i => r0 * (1 - taper * i / Math.max(1, path.length - 1)), tessellation: 4, cap: B.Mesh.NO_CAP }, scene); m.material = mat; m.isPickable = false; m.alwaysSelectAsActiveMesh = true; m.alphaIndex = ai; m.isVisible = false; return m; };
    const add = (path, g, at, r0, glow) => items.push({ g, at, core: tube('seBc', path, r0, g > 0 ? .75 : 0, A.boltCore, 62), halo: glow ? tube('seBh', path, r0 * 4.6, g > 0 ? .8 : .15, A.boltHalo, 61) : null, fl: 1 });
    // 1) the stepped leader: main channel in 8 chunks that appear top to bottom in uneven jumps
    const CH = 4, tLead = .14;                                                    // fixed leader time, so the thunder crack and the hit always line up
    for (let c = 0; c < CH; c++) {
      const i0 = Math.floor(c * (n - 1) / CH), i1 = Math.floor((c + 1) * (n - 1) / CH);
      add(main.slice(i0, i1 + 1), 0, Math.min(.125, c / CH * .125 * (.9 + Math.random() * .2)), .1, true);
    }
    // forks: just 2-3, spread along the channel, mostly downward (kept few so the effect stays light on phones); core only, no glow tube
    const nf = Math.random() < .5 ? 3 : 2;
    for (let j = 0; j < nf; j++) {
      const i = 8 + Math.floor((j + .2 + Math.random() * .6) * (n - 16) / nf), p = main[i], ang = Math.random() * Math.PI * 2, len = 10 + Math.random() * 24, dn = .5 + Math.random() * .45, at = tLead * i / (n - 1);
      const dir = V3(Math.cos(ang) * .75, -dn, Math.sin(ang) * .75).normalize(), bp = boltPath(p, p.add(dir.scale(len)), len * .15, 3);
      add(bp, 1, at, .085, false);
      if (j === 0 && Math.random() < .5) { const q = bp[3 + Math.floor(Math.random() * 3)], a2 = Math.random() * 6.28, l2 = len * (.3 + Math.random() * .25), d2 = V3(Math.cos(a2) * .8, -(.3 + Math.random() * .5), Math.sin(a2) * .8).normalize(); add(boltPath(q, q.add(d2.scale(l2)), l2 * .15, 2), 2, at + tLead * .05, .055, false); }
    }
    // 2) upward streamers from the ground, horse and rider: they reach for the leader just before the return stroke
    for (let k = 0; k < 2; k++) {
      const gx = ex + (Math.random() - .5) * 6, gz = ez + (Math.random() - .5) * 6, gy = hgt(gx, gz) + (k === 1 ? 2.6 : 0), hh = 2.5 + Math.random() * 3.5;
      add(boltPath(V3(gx, gy, gz), V3(gx + (Math.random() - .5) * 2.4, gy + hh, gz + (Math.random() - .5) * 2.4), .7, 3), 3, tLead - .035, .04, false);
    }
    // 3) ground flash, hot spot and sparks at the point of contact
    const gd = B.MeshBuilder.CreateDisc('seGround', { radius: 10, tessellation: 16 }, scene); gd.material = A.boltGround; gd.rotation.x = Math.PI / 2; gd.position.set(ex, ey + .12, ez); gd.isPickable = false; gd.alphaIndex = 55; gd.isVisible = false; extra.push(gd);
    const hs = B.MeshBuilder.CreateSphere('seHot', { diameter: 3.4, segments: 6 }, scene); hs.material = A.boltCore; hs.position.set(ex, ey + 2.6, ez); hs.isPickable = false; hs.alphaIndex = 63; hs.isVisible = false; extra.push(hs);
    const sparks = []; for (let k = 0; k < 6; k++) { const m = B.MeshBuilder.CreateSphere('seSp', { diameter: .12 + Math.random() * .1, segments: 3 }, scene); m.material = A.boltSpark; m.isPickable = false; m.isVisible = false; m.position.set(ex, ey + 1.6, ez); const a = Math.random() * 6.28, s = 3 + Math.random() * 7; extra.push(m); sparks.push({ m, vx: Math.cos(a) * s, vy: 4 + Math.random() * 7, vz: Math.sin(a) * s, p: m.position }); }
    bfx = { t: 0, tLead, items, extra, gd, hs, sparks, onHit, hit: false, ex, ey, ez };
  }
  function boltEnv(t, t0) {                                                       // brightness after the return stroke: strong first stroke, quick dark gaps, weaker re-strikes, dim glow
    const u = t - t0; if (u < 0) return 0; let v = 0;
    [[0, 1, .045], [.115, .85, .04], [.24, .62, .035], [.37, .4, .03]].forEach(p => { if (u >= p[0]) v = Math.max(v, p[1] * Math.exp(-(u - p[0]) / p[2])); });
    if (u < .55) v = Math.max(v, .3 * (1 - u / .55) * (.7 + Math.random() * .3));
    return Math.min(1, v);
  }
  function updateBolt(dt) {
    const f = bfx; if (!f) return; f.t += dt; const t = f.t, t0 = f.tLead, h = OYO.hud, rs = Math.random;
    if (t < t0) {                                                                     // leader: a faint violet thread feeling its way down + streamers rising
      f.items.forEach(q => { const on = q.at <= t; q.core.isVisible = on; if (q.halo) q.halo.isVisible = false; if (on) q.core.visibility = (q.g === 3 ? .55 : .3) * (.6 + rs() * .5); });
    } else {
      if (!f.hit) { f.hit = true; try { RD.cam.kick = Math.max(RD.cam.kick || 0, .55); } catch (err) { /* ok */ } if (f.onHit) { try { f.onHit(); } catch (err) { console.warn('bolt hit', err); } } }
      const ev = boltEnv(t, t0), u = t - t0;
      f.items.forEach(q => {
        const vv = Math.min(1, Math.pow(ev, 1 + q.g * .45) * (.72 + rs() * .28) * (q.g === 3 ? (u < .06 ? 1 : 0) : 1));      // branches and streamers die sooner than the main channel
        q.core.isVisible = vv > .02; q.core.visibility = vv; if (q.halo) { q.halo.isVisible = vv > .02; q.halo.visibility = vv * .55; }
      });
      f.gd.isVisible = ev > .03; f.gd.visibility = ev * .75; f.gd.scaling.setAll(.5 + Math.min(1, u * 3) * .9);
      f.hs.isVisible = ev > .05; f.hs.visibility = ev * .9; f.hs.scaling.setAll(.7 + ev * .6);
      f.sparks.forEach(s => { s.vy -= 16 * dt; s.p.x += s.vx * dt; s.p.y += s.vy * dt; s.p.z += s.vz * dt; s.m.isVisible = u < .8 && s.p.y > f.ey + .05; s.m.visibility = Math.max(0, 1 - u / .8); });
      const fl = ev > .5 ? 1 : 0; if (h.thunder !== fl) h.thunder = fl;           // screen flashes on each stroke, not as one long pop
      if (t > t0 + .8) killBolt();
    }
  }
  function buildRiders() {
    const mt = (n, d, e) => { const m = new B.StandardMaterial(n, scene); m.diffuseColor = new B.Color3(d[0], d[1], d[2]); m.emissiveColor = new B.Color3(e[0], e[1], e[2]); m.specularColor = new B.Color3(.15, .15, .15); return m; };
    const HM = [mt('rdH1', [.38, .22, .1], [.18, .1, .04]), mt('rdH2', [.22, .22, .25], [.1, .1, .12])], skin = mt('rdSkin', [.42, .26, .16], [.2, .12, .07]), cloth = mt('rdCloth', [.86, .18, .1], [.45, .07, .04]), cap = mt('rdCap', [.14, .16, .55], [.07, .08, .3]), dark = mt('rdDark', [.12, .08, .05], [.06, .04, .03]);
    const put = (m, par, mat, x, y, z) => { m.material = mat; m.parent = par; m.position.set(x || 0, y || 0, z || 0); m.isPickable = false; return m; };
    for (let i = 0; i < 2; i++) {
      const root = new B.TransformNode('rude' + i, scene), hm = HM[i % 2], legs = [];
      put(B.MeshBuilder.CreateSphere('rdBody', { diameter: 1, segments: 8 }, scene), root, hm, 0, 1.4, 0).scaling.set(.75, .8, 1.7);
      put(B.MeshBuilder.CreateCylinder('rdNeck', { diameterTop: .2, diameterBottom: .4, height: .85, tessellation: 8 }, scene), root, hm, 0, 1.95, .95).rotation.x = .75;
      put(B.MeshBuilder.CreateBox('rdHead', { width: .26, height: .3, depth: .6 }, scene), root, hm, 0, 2.3, 1.38).rotation.x = .45;
      put(B.MeshBuilder.CreateCylinder('rdTail', { diameterTop: .06, diameterBottom: .16, height: .9, tessellation: 6 }, scene), root, dark, 0, 1.45, -1.25).rotation.x = -.5;
      for (const [sx, sz] of [[-1, 1], [1, 1], [-1, -1], [1, -1]]) { const pv = new B.TransformNode('rdLeg', scene); pv.parent = root; pv.position.set(sx * .28, 1.05, sz * .7); put(B.MeshBuilder.CreateCylinder('rdLegM', { diameter: .15, height: 1.05, tessellation: 6 }, scene), pv, hm, 0, -.52, 0); legs.push(pv); }
      const rider = new B.TransformNode('rdRider', scene); rider.parent = root; rider.position.set(0, 1.85, -.1);
      put(B.MeshBuilder.CreateBox('rdTorso', { width: .5, height: .62, depth: .3 }, scene), rider, cloth, 0, .35, 0);
      put(B.MeshBuilder.CreateSphere('rdRH', { diameter: .3, segments: 6 }, scene), rider, skin, 0, .85, 0);
      put(B.MeshBuilder.CreateCylinder('rdCapM', { diameterTop: .2, diameterBottom: .3, height: .28, tessellation: 8 }, scene), rider, cap, 0, 1.04, 0);
      const arm = new B.TransformNode('rdArm', scene); arm.parent = rider; arm.position.set(.3, .6, 0); put(B.MeshBuilder.CreateCylinder('rdArmM', { diameter: .12, height: .55, tessellation: 6 }, scene), arm, cloth, 0, -.26, 0);
      put(B.MeshBuilder.CreateCylinder('rdArm2', { diameter: .12, height: .5, tessellation: 6 }, scene), rider, cloth, -.3, .35, .22).rotation.x = Math.PI / 2.4;
      root.setEnabled(false); RIDERS.push({ root, legs, rider, arm, on: false, phase: '' });
    }
  }
  function hideRiders() {
    RIDERS.forEach(r => { if (r.on || r.root.isEnabled()) { r.on = false; r.phase = ''; try { r.rider.parent = r.root; r.rider.position.set(0, 1.85, -.1); r.rider.rotation.set(0, 0, 0); } catch (err) { /* ok */ } r.root.setEnabled(false); } });
    killBolt();
    try { const h = OYO.hud; h.oseHot = false; h.thunder = 0; } catch (err) { /* ok */ }
  }
  function rudeSay(r, t) { warnTxt(t); try { const V = VIL(), q = r.root.position; if (V) V.say(r.spk != null ? r.spk : 5, q.x, q.y + .9, q.z, t.split('—').pop().trim(), 'Rude Rider'); } catch (err) { /* ok */ } }   // HUD warning + a bubble over the rude NPC rider's head
  function warnTxt(t) { const h = OYO.hud; h.eWarn = t; R_.warnT = 2.8; }
  function spawnRude(st) {
    const r = RIDERS.find(q => !q.on); if (!r) return;
    const pl = latOf(st.x, st.z);
    Object.assign(r, { on: true, phase: 'chase', zc: st.z - 62, lat: clamp(pl, -LW, LW), v: 14, t: 0, ph: Math.random() * 6, cd: 1.2, shoves: 0, swerve: 0, side: pl > 0 ? -1 : 1, fly: null, die: 0, sc: 1, hit: false });
    r.rider.parent = r.root; r.rider.position.set(0, 1.85, -.1); r.rider.rotation.set(0, 0, 0); r.root.scaling.setAll(1); r.root.setEnabled(true);
  }
  function shoveCart(r, st, rl) {                                              // the rude rider barges into the cart
    const sg = rl >= 0 ? -1 : 1, s = slope(st.z), l = Math.sqrt(1 + s * s);
    st.speed *= .62; st.x += sg * .9 / l; st.z -= sg * .9 * s / l;
    try { if (S.cart) { S.cart.jolt = 1; S.cart.joltT0 = performance.now(); } } catch (err) { /* ok */ }
    snd('impact', 6); scaredTalk(); rudeSay(r, RUDE_SAY[Math.floor(Math.random() * RUDE_SAY.length)]);
  }
  function updateRude(dt, st) {
    const h = OYO.hud; if (!R_.oseOn) return;
    if (R_.thT > 0) { R_.thT -= dt; if (R_.thT <= 0) h.thunder = 0; }
    updateBolt(dt);
    if (!RIDERS.some(q => q.on) && !NPCS.some(Y => Y.on && Y.rude && Y.phase !== 'down')) { R_.rudeT -= dt; if (R_.rudeT <= 0 && R_.dist > 300 && !R_.exh) { spawnRude(st); R_.rudeT = 50 + Math.random() * 30; } }
    const v = Math.abs(st.speed), pl = latOf(st.x, st.z); let hot = false;
    for (const r of RIDERS) {
      if (!r.on) continue;
      r.t += dt; const rz = r.zc - st.z;
      if (r.phase === 'struck') {                                              // thrown off: the horse bolts, the rider tumbles to the ground and stays there
        r.zc += (r.v + 6) * dt; r.die -= dt; r.sc = Math.max(.01, Math.min(1, r.die / .8));
        if (r.fly) { const f = r.fly; f.vy -= 20 * dt; r.rider.position.x += f.vx * dt; r.rider.position.y += f.vy * dt; r.rider.position.z += f.vz * dt; r.rider.rotation.x += 7 * dt; r.rider.rotation.z += 4 * dt; const gy = hgt(r.rider.position.x, r.rider.position.z) + .25; if (r.rider.position.y < gy && f.vy < 0) { r.rider.position.y = gy; r.fly = null; } }
        if (r.die <= 0) { r.on = false; r.phase = ''; r.root.setEnabled(false); r.rider.parent = r.root; continue; }
      } else {
        if (r.phase === 'chase') { r.v = Math.max(v + 8, 14); r.zc += r.v * dt; r.lat += (pl - r.lat) * Math.min(1, dt * 1.2); if (rz > -5) { r.phase = 'rude'; r.t = 0; rudeSay(r, RUDE_SAY[Math.floor(Math.random() * RUDE_SAY.length)]); } }
        else if (r.phase === 'rude') {
          const dv = clamp((1.2 - rz) * 2.5, -8, 8); r.v = v + dv; r.zc += r.v * dt; r.cd -= dt;
          if (r.swerve > 0) { r.swerve -= dt; r.lat += (pl + r.side * .3 - r.lat) * Math.min(1, dt * 9); const rl = r.lat - pl; if (!r.hit && Math.abs(rl) < 1.7 && Math.abs(rz) < 3) { r.hit = true; r.shoves++; shoveCart(r, st, rl); } }
          else { r.lat += (clamp(pl + r.side * 2.1, -HW + 1, HW - 1) - r.lat) * Math.min(1, dt * 2.2); if (r.cd <= 0) { r.swerve = .7; r.cd = 2.6 + Math.random() * 1.2; r.hit = false; } }
          if (r.shoves >= 5 || r.t > 22) r.phase = 'leave';
        } else { r.v = v + 16; r.zc += r.v * dt; if (rz > 80) { r.on = false; r.phase = ''; r.root.setEnabled(false); continue; } }
        hot = hot || Math.abs(rz) < 60;
      }
      r.ph += dt * Math.max(9, r.v * .9);
      const p = pt(r.zc, r.lat), gy = hgt(p[0], p[1]); r.root.position.set(p[0], gy + Math.abs(Math.sin(r.ph)) * .07, p[1]); r.root.rotation.y = yawAt(r.zc); r.root.scaling.setAll(r.sc || 1); if (r.phase !== 'struck') { const VM = VIL(); if (VM) VM.spkMove(5, p[0], gy + .9, p[1]); }
      for (let q = 0; q < 4; q++) r.legs[q].rotation.x = Math.sin(r.ph + (q === 1 ? Math.PI * .5 : q === 2 ? Math.PI : q === 3 ? Math.PI * 1.5 : 0)) * .8;
      if (r.phase === 'rude' || r.phase === 'leave') r.arm.rotation.z = 2.5 + Math.sin(r.t * 11) * .45; else r.arm.rotation.z = 0;     // shaking a fist
    }
    hot = hot || !!E.hotH;                                                           // a rude horse rider (road riders) is within reach too
    if (h.oseHot !== hot) h.oseHot = hot;
  }
  /* ============================== ROYAL-CART RIDER (one NPC) ==============================
     A noble NPC messenger drives the ROYAL cart with passengers aboard, behind the SAME real horse and rider models the player has (own skinned meshes + own animator).
     He keeps to one lane (never the lane the player is in when he comes up from behind: he moves over), overtakes at a speed the player can match by galloping, and rides on.
     Meeting him head-on in his lane is a collision: the cart flips over backwards, passengers and rider are flung to the back, the horse breaks loose and bolts across the road. */
  const ROY = { on: false, built: false, failed: false, next: 22 + Math.random() * 18 };
  const ROY2 = { on: false, built: false, failed: false, front: true, next: 45 + Math.random() * 25 };     // second NPC rider: the same real horse + rider + royal cart, but he spawns AHEAD of the player and rides away (slower than the player's pace, so he is caught up)
  const ROY3 = { on: false, built: false, failed: false, oncoming: true, next: 25 + Math.random() * 20 };     // third NPC rider: the same real horse + rider + royal cart, but on the OTHER (oncoming) carriageway, riding TOWARDS the player (opposite direction)
  const ROY4 = { on: false, built: false, failed: false, front: true, starter: true, next: 38 + Math.random() * 20 };     // fourth NPC rider: AHEAD of the player on the player's own road, pulling the plain STARTER cart (4 seats) instead of the royal one
  const spkOf = Y => Y.spk != null ? Y.spk : Y.starter ? 7 : Y.oncoming ? 6 : Y.front ? 3 : 4, dustOf = Y => Y.dust != null ? Y.dust : Y.starter ? 4 : Y.oncoming ? 3 : Y.front ? 2 : 1;   // bubble slot + hoof-dust emitter of each NPC rider
  const STARTER_RIDER_SAY = ['Easy there, friend!', 'Slow and steady wins the road!', 'Ẹ kú ìrìn o!', 'Mind the road, rider!', 'This old cart still runs!'];

  /* ============================== MORE ROAD RIDERS (three families) ==============================
     Besides the four riders above, the road now carries more folk, in front of the player, behind him (they come up from behind and OVERTAKE) and on the oncoming carriageway:
       • ROYAL-cart riders      – the decorated royal cart (ROY, ROY2, ROY3 above + ROY5)
       • STARTER-cart riders    – the plain wooden starter cart (ROY4 above + ROY6, ROY7)
       • ORDINARY-horse riders  – a plain horse (no cart) carrying ONE passenger sitting behind the rider (HRS1 - HRS5)
     Many carry a Yoruba word or saying (YO_WORDS): painted on the name boards of carts, or on cloth hung on the horse + a little flag behind the passenger.
     Riders from behind on an ordinary horse (HRS3, HRS4) may be RUDE (only when the Ose Ṣàngó feature is live, oseVisible()): they tailgate, abuse and shove the cart like the
     rude riders above, and a Ṣàngó strike (⚡ / F key) can knock them off their horse. At most NPC_MAX riders are alive at once. */
  const NPC_MAX = 18, NPC_MAX_ON = 18;                                                    // NPC_MAX_ON: how many riders may be on the OTHER (oncoming) road at once - it is always busy
  ROY.kind = 'royal'; ROY.min = 200; ROY.sp = { z: -60, f0: 1.09, fr: .11, vm: 1.12 };
  ROY2.kind = 'royal'; ROY2.min = 350; ROY2.sp = { z: 80, f0: .62, fr: .1, vm: .7 };
  ROY3.kind = 'royal'; ROY3.min = 150; ROY3.sp = { z: 190, f0: .85, fr: .15, vm: .9 };
  ROY4.kind = 'starter'; ROY4.min = 260; ROY4.sp = { z: 115, f0: .54, fr: .08, vm: .6 };
  const mkNpc = o => Object.assign({ on: false, built: false, failed: false, next: 30 + Math.random() * 30, gap: [38, 38] }, o);
  const ROY5 = mkNpc({ kind: 'royal', front: true, lane: 'any', paint: 'indigo', spk: 8, dust: 5, min: 420, sp: { z: 150, f0: .66, fr: .08, vm: .7 }, insP: .8 });                       // a second royal cart AHEAD (indigo-painted)
  const ROY6 = mkNpc({ kind: 'starter', starter: true, paint: '', spk: 9, dust: 6, min: 300, sp: { z: -60, f0: 1.03, fr: .05, vm: 1.05 }, insP: .75 });                          // a starter cart that comes up from BEHIND and overtakes
  const ROY7 = mkNpc({ kind: 'starter', starter: true, oncoming: true, paint: 'ebony', spk: 10, dust: 7, min: 200, sp: { z: 190, f0: .8, fr: .12, vm: .9 }, insP: .7 });         // a starter cart on the oncoming carriageway
  const HRS1 = mkNpc({ kind: 'horse', front: true, lane: 'any', spk: 11, dust: 8, min: 240, sp: { z: 95, f0: .52, fr: .1, vm: .6 }, insP: .6 });                                 // slow horse + passenger AHEAD
  const HRS2 = mkNpc({ kind: 'horse', front: true, lane: 'any', spk: 12, dust: 9, min: 520, sp: { z: 140, f0: .8, fr: .1, vm: .8 }, insP: .6 });                                // quicker horse + passenger AHEAD
  const HRS3 = mkNpc({ kind: 'horse', canRude: true, spk: 13, dust: 10, min: 260, sp: { z: -62, f0: 1.2, fr: .1, vm: 1.2 }, insP: .6 });                                         // horse + passenger from BEHIND (may be rude)
  const HRS4 = mkNpc({ kind: 'horse', canRude: true, spk: 14, dust: 11, min: 560, sp: { z: -62, f0: 1.25, fr: .1, vm: 1.25 }, insP: .6 });                                       // another one, later on (may be rude)
  const HRS5 = mkNpc({ kind: 'horse', oncoming: true, spk: 15, dust: 12, min: 180, sp: { z: 190, f0: .9, fr: .12, vm: .95 }, insP: .6 });                                         // horse + passenger on the oncoming carriageway
  /* ---------- THE OTHER (ONCOMING) ROAD IS ALWAYS BUSY ----------
     A big pool of extra riders on the oncoming carriageway, in six families, each one re-appearing a second or two after it has gone by (the road is full from the very start):
       load carts (goods only, no passengers) · starter carts · plain horses with a passenger · royal carts · LONG carts (4 benches, 8 seats, second axle) · two-seater carts.
     They are quiet (no speech bubbles) so the screen is not flooded with chatter. Their lanes are kept apart by separateNpcs(). */
  const BUSY = [];
  [['load', 3], ['starter', 3], ['horse', 4], ['royal', 3], ['long', 3], ['two', 3]].forEach(([fam, n]) => {
    for (let i = 0; i < n; i++) {
      const k = BUSY.length, o = { busy: true, bi: k, oncoming: true, mute: true, jit: 70, spk: 16, dust: 13 + k, min: 0, gap: [1.2, 2.5], sp: { z: 190, f0: .66 + Math.random() * .32, fr: .14, vm: 1 }, insP: .5 };
      if (fam === 'horse') Object.assign(o, { kind: 'horse' });
      else if (fam === 'royal') Object.assign(o, { kind: 'royal', paint: ['indigo', 'gold', ''][i % 3] });
      else if (fam === 'starter') Object.assign(o, { kind: 'starter', starter: true, paint: ['', 'ebony'][i % 2] });
      else Object.assign(o, { kind: fam, starter: true, cv: fam, paint: fam === 'load' ? ['', 'ebony', 'gold'][i % 3] : ['', 'indigo', 'ebony'][i % 3] });
      const Y = mkNpc(o); Y.next = .6 + k * .9 + Math.random() * .8; BUSY.push(Y);
    }
  });
  /* ---------- THE PLAYER'S OWN ROAD IS POPULATED TOO ----------
     CALM riders in the same six families: slower ones AHEAD (the player catches them up; they start in a lane other than his and step aside as he closes in)
     and quicker ones from BEHIND that overtake him (never in his lane). Quiet (no speech bubbles), never rude. */
  const CALM = [];
  [['load', 'f'], ['starter', 'f'], ['horse', 'f'], ['horse', 'f'], ['royal', 'f'], ['long', 'f'], ['two', 'f'], ['load', 'f'],
   ['starter', 'f'], ['horse', 'f'], ['royal', 'f'], ['two', 'f'], ['long', 'f'], ['horse', 'f'], ['load', 'f'], ['starter', 'f'],
   ['horse', 'b'], ['starter', 'b'], ['two', 'b'], ['royal', 'b'], ['long', 'b'], ['horse', 'b'], ['starter', 'b']].forEach(([fam, dir], i) => {
    const k = BUSY.length + CALM.length, front = dir === 'f';
    const o = { busy: true, bi: k, calm: true, front, mute: true, jit: front ? 60 : 30, spk: 16, dust: 13 + k, min: front ? 0 : 150 + (i % 5) * 60, gap: front ? [5, 6] : [9, 10],
      sp: front ? { z: 120, f0: .52 + Math.random() * .3, fr: .1, vm: .75 } : { z: -62, f0: 1.06 + Math.random() * .1, fr: .06, vm: 1.1 }, insP: .5 };
    if (fam === 'horse') Object.assign(o, { kind: 'horse' });
    else if (fam === 'royal') Object.assign(o, { kind: 'royal', paint: ['indigo', 'gold', ''][i % 3] });
    else if (fam === 'starter') Object.assign(o, { kind: 'starter', starter: true, paint: ['', 'ebony'][i % 2] });
    else Object.assign(o, { kind: fam, starter: true, cv: fam, paint: fam === 'load' ? ['', 'ebony', 'gold'][i % 3] : ['', 'indigo', 'ebony'][i % 3] });
    const Y = mkNpc(o); Y.next = front ? .8 + CALM.length * 1.1 + Math.random() * .8 : 20 + Math.random() * 15; CALM.push(Y);
  });
  const NPCS = [ROY, ROY2, ROY3, ROY4, ROY5, ROY6, ROY7, HRS1, HRS2, HRS3, HRS4, HRS5].concat(BUSY, CALM);
  /* Yoruba words and sayings painted on the riders' carts / cloth: [Yoruba, English meaning] (kept short so they read on a plank) */
  const YO_WORDS = [
    ['Ọmọlúàbí', 'A person of good character'], ['Ìwà lẹ̀wà', 'Character is beauty'], ['Sùúrù ni baba ìwà', 'Patience is the father of character'], ['Sùúrù', 'Patience'],
    ['Ọ̀wọ̀', 'Respect'], ['Ọgbọ́n', 'Wisdom'], ['Ìrẹ̀lẹ̀', 'Humility'], ['Òótọ́', 'Truth'], ['Ìṣọ̀kan', 'Unity'], ['Ìgboyà', 'Courage'], ['Ìmọ̀', 'Knowledge'],
    ['Àlàáfíà', 'Peace and well-being'], ['Ìfẹ́', 'Love'], ['Ọ̀rẹ́', 'Friend'], ['Ẹ káàbọ̀', 'Welcome'], ['Ẹ ṣé', 'Thank you'], ['Ẹ kú ìrìn àjò', 'Greetings on your journey'],
    ['Ẹ kú àárọ̀', 'Good morning'], ['Ẹ kú iṣẹ́', 'Well done on your work'], ['Ọ̀nà kan ò wọ ọjà', 'There is more than one road to the market'], ['Ọ̀kan · Èjì · Ẹ̀ta', 'One · Two · Three'],
    ['Ọ̀nà', 'Road'], ['Ẹṣin', 'Horse'], ['Ọjà', 'Market'], ['Ọba', 'King'], ['Àṣà', 'Culture and tradition']
  ];
  let lastWord = -1;
  const pickWord = () => { let i; do { i = Math.floor(Math.random() * YO_WORDS.length); } while (i === lastWord && YO_WORDS.length > 1); lastWord = i; return YO_WORDS[i]; };
  const NPC_COATS = [{ m: [1, 1, 1] }, { m: [.62, .58, .58] }, { g: 2.6 }, { m: [1.35, 1.2, .95] }, { m: [.36, .34, .34] }];              // ordinary horses: bay, dark bay, grey, light chestnut, black
  const NPC_CLOTHES = [[1, 1, 1], [1.25, .8, .7], [.8, 1.05, .85], [.9, .95, 1.25], [1.2, 1.1, .7]];                                       // ordinary riders' clothes: tints of the messenger's outfit
  const CLOTH_LOOK = [['#1d2a6b', '#0e1640', '#fbf3dc', '#f1cf7e'], ['#8c1a1f', '#5a0e12', '#ffe39a', '#f1cf7e'], ['#1f5a3a', '#0f3a24', '#fbf3dc', '#e8c35a'], ['#5a2d6b', '#34173f', '#fbf3dc', '#f1cf7e']];
  const HRS_SAY = ['Ẹ kú ọ̀nà! — Greetings on the road!', 'Ẹ pẹ̀lẹ́ o! — Easy now!', 'Ọ̀nà jìn! — The road is long!', 'Ẹ ṣé o, Rider! — Thank you!', 'Hold on tight, my friend!', 'Ẹ kú ìrìn! — Well done riding!'];
  const HRS_PAX_SAY = ['Ẹ pẹ̀lẹ́, Baba! — Gently, please!', 'Ṣé a máa dé? — Will we arrive?', 'Ẹ ṣé, Rider! — Thank you!', 'Òyó ń dúró dè wá! — Òyó is waiting for us!'];
  const pillionHook = Y => function (q) {                          // a villager sits on the horse's rump behind the rider (same idea as the Free Roam pillion in roam-fare.js)
    const h = Y.hs, sn = Math.sin(h.yaw), cs = Math.cos(h.yaw);
    q.x = h.x - sn * .66; q.z = h.z - cs * .66; q.y = h.y + 1.42 - Math.sin(h.pitch || 0) * .66 - .92 * (q.sc || 1); q.yaw = h.yaw; q.st = 1.5;
  };
  const R_SEAT = [0, 1.44, 1.23], R_S0 = [0, 1.52, -.07];
  let NPC_BRUSH = null;                                                                  // the painted brush texture is made once and shared by every road rider
  function buildRoyalNpc(Y) {
    if (Y.built || Y.failed) return Y.built;
    try {
      const R = window.OYORig, H = window.OYOHorse, M = window.OYOMessenger, AN = window.OYORideAnim;
      if (!R || !H || !M || !AN || !window.OYOCart || !OYOCart.build) throw new Error('horse / rider / cart modules missing');
      const isH = Y.kind === 'horse';                                                  // ordinary horse (no cart): plain horse, rider sits in the saddle
      const hg = H.build({ regalia: isH ? '' : (window.OYOHorseRegalia ? window.OYOHorseRegalia() : '') }), rg = M.build();
      const hgeo = R.MB(); R.append(hgeo, hg.mesh, 0); const hV = R.nv(hgeo);
      const rgeo = R.MB(); R.append(rgeo, rg.mesh, H.NB); const rV = R.nv(rgeo);
      if (isH) {                                                                          // each ordinary horse gets its own coat, each rider his own colours
        const coat = NPC_COATS[Math.floor(Math.random() * NPC_COATS.length)], cl = NPC_CLOTHES[Math.floor(Math.random() * NPC_CLOTHES.length)];
        for (let k = 0; k < hV; k++) { const r0 = hgeo.c[k * 3], g0 = hgeo.c[k * 3 + 1], b0 = hgeo.c[k * 3 + 2]; if (coat.g) { const l = (r0 + g0 + b0) / 3 * coat.g; hgeo.c[k * 3] = Math.min(1, l * 1.02); hgeo.c[k * 3 + 1] = Math.min(1, l * 1.02); hgeo.c[k * 3 + 2] = Math.min(1, l * 1.08); } else { hgeo.c[k * 3] = Math.min(1, r0 * coat.m[0]); hgeo.c[k * 3 + 1] = Math.min(1, g0 * coat.m[1]); hgeo.c[k * 3 + 2] = Math.min(1, b0 * coat.m[2]); } }
        for (let k = 0; k < rV; k++) for (let q = 0; q < 3; q++) rgeo.c[k * 3 + q] = Math.min(1, rgeo.c[k * 3 + q] * cl[q]);
      }
      const anim = new AN.Animator(); anim.bitRest = { L: hg.anchors.bitL, R: hg.anchors.bitR }; anim.driver = !isH; anim.update(1 / 60, 0, 0);
      const wb = new Float32Array(AN.NB * 12);
      const fresh = !NPC_BRUSH, tex = NPC_BRUSH || (NPC_BRUSH = new B.DynamicTexture('royBrush', { width: 128, height: 128 }, scene, true)), g = fresh ? tex.getContext() : null;
      if (fresh) { g.fillStyle = '#f4ecde'; g.fillRect(0, 0, 128, 128); g.lineCap = 'round'; }
      if (fresh) for (let i = 0; i < 330; i++) { const x = Math.random() * 128, y = Math.random() * 128, an = Math.random() * Math.PI, l = 4 + Math.random() * 14; g.strokeStyle = Math.random() < .5 ? 'rgba(255,252,240,.32)' : 'rgba(110,86,60,.16)'; g.lineWidth = 1.2 + Math.random() * 3; for (const dx of [-128, 0, 128]) for (const dy of [-128, 0, 128]) { g.beginPath(); g.moveTo(x + dx, y + dy); g.lineTo(x + dx + Math.cos(an) * l, y + dy + Math.sin(an) * l); g.stroke(); } }
      if (fresh) { tex.wrapU = tex.wrapV = B.Texture.WRAP_ADDRESSMODE; tex.update(); }
      const fc = scene.fogColor || new B.Color3(.8, .7, .6), mat = new B.ShaderMaterial('royRiderMat', scene, { vertex: 'oyoRider', fragment: 'oyoRider' }, { attributes: ['position', 'normal', 'color', 'uv'], uniforms: ['world', 'viewProjection', 'camPos', 'toSun', 'sunCol', 'skyCol', 'gndCol', 'fogCol', 'hazeCol', 'fogD'], samplers: ['tex'] });
      mat.setTexture('tex', tex); mat.setVector3('toSun', S.world.sunDir || new B.Vector3(.55, .55, -.5).normalize()); mat.setVector3('sunCol', new B.Vector3(.85, .73, .53)); mat.setVector3('skyCol', new B.Vector3(.58, .54, .47));
      mat.setVector3('gndCol', new B.Vector3(.42, .27, .2)); mat.setVector3('fogCol', new B.Vector3(fc.r, fc.g, fc.b)); mat.setVector3('hazeCol', new B.Vector3(.93, .84, .64)); mat.setFloat('fogD', scene.fogDensity || 0); mat.setVector3('camPos', new B.Vector3(0, 0, 0)); mat.backFaceCulling = false;
      const mk = (name, geo, nv) => {
        const P = new Float32Array(nv * 3), N = new Float32Array(nv * 3), col = new Float32Array(nv * 4), uv = new Float32Array(nv * 2);
        for (let k = 0; k < nv; k++) { col[k * 4] = geo.c[k * 3]; col[k * 4 + 1] = geo.c[k * 3 + 1]; col[k * 4 + 2] = geo.c[k * 3 + 2]; col[k * 4 + 3] = 1; uv[k * 2] = geo.p[k * 3] * 1.7 + geo.p[k * 3 + 2] * .9; uv[k * 2 + 1] = geo.p[k * 3 + 1] * 2.6; }
        R.skin(geo, anim.bones, P, N, nv);
        const m = new B.Mesh(name, scene), vd = new B.VertexData(); vd.positions = P; vd.normals = N; vd.colors = col; vd.uvs = uv; vd.indices = geo.i.length > 65000 ? new Uint32Array(geo.i) : new Uint16Array(geo.i);
        vd.applyToMesh(m, true); m.isPickable = false; m.alwaysSelectAsActiveMesh = true; m.doNotSyncBoundingInfo = true; m.material = mat; m.setEnabled(false); return { m, P, N };
      };
      const hm = mk('royHorse', hgeo, hV), rm = mk('royRiderMesh', rgeo, rV);
      let cart = null;
      if (!isH) { cart = OYOCart.build(scene, S.world, { variant: Y.cv || (Y.starter ? 'starter' : 'royal'), paint: Y.paint || '', board: '·', x: 0, z: 0, yaw: 0 }); cart.setVisible(false); cart.rigid = true; try { cart.setBoard(''); } catch (e) { /* boards are cosmetic */ } }       // the name boards carry a Yoruba word when the rider spawns (setBoard)
      Object.assign(Y, { R, AN, H, anim, wb, hm, rm, hgeo, rgeo, hV, rV, mat, cart, hs: { x: 0, y: 0, z: 0, yaw: 0, pitch: 0, roll: 0, speed: 0 }, root: { position: { x: 0, y: 0, z: 0 } }, built: true });
      if (isH) { try { buildBanner(Y); } catch (e) { console.warn('Horse banner skipped', e); } }
      Y.rd = { built: true, active: true, state: Y.hs, wb };
      scene.onBeforeRenderObservable.add(() => royTick(Y));          // after the hitch has placed the cart this frame
    } catch (err) { console.warn('Royal-cart rider skipped', err); Y.failed = true; }
    return Y.built;
  }
  /* per-frame pose of the real horse + rider (and their skinning); the cart is placed by its hitch (riding) or by crashRoyal's flip (crash) */
  function royTick(Y) {
    if (!Y.on || !Y.built) return;
    try {
      const R = Y.R, AN = Y.AN, an = Y.anim, hs = Y.hs, wb = Y.wb, B0 = an.bones, nbh = AN.NBH, nb = AN.NB, C = Y.cart;
      const dzp = Math.abs(hs.z - RD.state.z);
      if (Y.posed && dzp > 140) return;                              // far out of sight (in the fog): no skinning this frame
      if (Y.posed && dzp > 70 && ((frame + (Y.uid || (Y.uid = NPCS.indexOf(Y) + 1))) & 1)) return;       // the busy oncoming road: far riders are re-skinned every other frame
      Y.posed = true;
      const dt = Math.min(.05, Math.max(.001, scene.getEngine().getDeltaTime() / 1000));
      an.update(dt, hs.speed, 0);
      if (window.OYODust && OYODust.updateNpc) { Y.dustRd = Y.dustRd || { state: hs, anim: an, active: true }; Y.dustRd.active = Math.abs(hs.z - RD.state.z) < 100; OYODust.updateNpc(dt, Y.dustRd, dustOf(Y)); }   // hoof dust for the NPC horse (same pool/look as the player's)
      const Mw = R.mMul(R.rotY(hs.yaw), R.mMul(R.rotX(hs.pitch || 0), R.rotZ(hs.roll || 0))); Mw[3] = hs.x; Mw[7] = hs.y; Mw[11] = hs.z;
      let Md;
      if (Y.rf) {                                                                   // flung off: tumbles through the air, then lies where he lands
        const f = Y.rf; Md = R.mMul(R.rotY(f.yaw), R.mMul(R.rotX(f.rx), R.rotZ(f.rz)));
        Md[3] = f.x - (Md[0] * R_S0[0] + Md[1] * R_S0[1] + Md[2] * R_S0[2]); Md[7] = f.y - (Md[4] * R_S0[0] + Md[5] * R_S0[1] + Md[6] * R_S0[2]); Md[11] = f.z - (Md[8] * R_S0[0] + Md[9] * R_S0[1] + Md[10] * R_S0[2]);
      } else if (!C) {                                                                // ordinary horse: the rider sits in the saddle, so the rider's bones ride on the horse's own matrix
        Md = Mw;
      } else {                                                                        // seated on the cart's driver bench
        const cs = C.state, D = OYOCart.dims; Md = R.mMul(R.rotY(cs.yaw), R.mMul(R.rotX(-cs.pitch), R.rotZ(cs.roll)));
        const lx = R_SEAT[0] - R_S0[0], ly = R_SEAT[1] + (cs.bob || 0) - R_S0[1], lz = R_SEAT[2] - (D.KPZ + D.RZ) / 2 - R_S0[2];
        Md[3] = cs.x + Md[0] * lx + Md[1] * ly + Md[2] * lz; Md[7] = cs.y + Md[4] * lx + Md[5] * ly + Md[6] * lz; Md[11] = cs.z + Md[8] * lx + Md[9] * ly + Md[10] * lz;
      }
      for (let b = 0; b < nb; b++) {
        const M = b < nbh ? Mw : Md, o = b * 12;
        for (let r = 0; r < 3; r++) { const a0 = M[r * 4], a1 = M[r * 4 + 1], a2 = M[r * 4 + 2];
          wb[o + r * 4] = a0 * B0[o] + a1 * B0[o + 4] + a2 * B0[o + 8]; wb[o + r * 4 + 1] = a0 * B0[o + 1] + a1 * B0[o + 5] + a2 * B0[o + 9]; wb[o + r * 4 + 2] = a0 * B0[o + 2] + a1 * B0[o + 6] + a2 * B0[o + 10]; wb[o + r * 4 + 3] = a0 * B0[o + 3] + a1 * B0[o + 7] + a2 * B0[o + 11] + M[r * 4 + 3]; }
      }
      R.skin(Y.hgeo, wb, Y.hm.P, Y.hm.N, Y.hV); an.applyFlex(Y.hgeo, Y.hm.P, 0, Y.hV, [Mw[0], Mw[4], Mw[8]], [Mw[1], Mw[5], Mw[9]], [Mw[2], Mw[6], Mw[10]]);
      R.skin(Y.rgeo, wb, Y.rm.P, Y.rm.N, Y.rV); try { an.applyFlex(Y.rgeo, Y.rm.P, 0, Y.rV, [Md[0], Md[4], Md[8]], [Md[1], Md[5], Md[9]], [Md[2], Md[6], Md[10]]); } catch (e) { /* flex is cosmetic */ }
      for (const q of [Y.hm, Y.rm]) { q.m.updateVerticesData(B.VertexBuffer.PositionKind, q.P, false, false); q.m.updateVerticesData(B.VertexBuffer.NormalKind, q.N, false, false); }
      if (scene.activeCamera) Y.mat.setVector3('camPos', scene.activeCamera.position);
      if (Y.bn) { Y.bn.position.set(hs.x, hs.y, hs.z); Y.bn.rotation.set(hs.pitch || 0, hs.yaw, hs.roll || 0); }          // cloth + flag follow the horse
    } catch (err) { if (!Y.tickErr) { Y.tickErr = 1; console.warn('Royal rider pose', err); } }
  }
  function royPose(Y, x, z, yaw, speed) {                                                 // put the real horse on the ground at (x, z)
    const hs = Y.hs, sy = Math.sin(yaw), cy = Math.cos(yaw), hf = hgt(x + sy * .9, z + cy * .9), hb = hgt(x - sy * .9, z - cy * .9), h0 = hgt(x, z);
    hs.x = x; hs.z = z; hs.yaw = yaw; hs.y = (hf + hb + h0 * 2) / 4; hs.pitch = clamp(Math.atan2(hf - hb, 1.8), -.5, .5); hs.roll = 0; hs.speed = speed;
    if (Y.root) { Y.root.position.x = x; Y.root.position.y = hs.y; Y.root.position.z = z; }
  }
  function hideRoyalNpc(Y) {
    const V = VIL();
    if (Y.cart) { try { (Y.pax || []).forEach(p => { try { Y.cart.unseatPerson(p); } catch (e) { /* ok */ } p.busy = 0; if (V) V.release(p); }); if (Y.cart.hitched) Y.cart.unhitch(); Y.cart.root.scaling.setAll(1); Y.cart.setVisible(false); } catch (err) { /* ok */ } }
    if (!Y.cart && Y.pax && Y.pax.length) Y.pax.forEach(p => { try { p.cr = null; p.busy = 0; } catch (e) { /* ok */ } if (V) V.release(p); });          // ordinary horse: the pillion passenger goes back to the pool
    if (Y.bn) Y.bn.setEnabled(false);
    Y.pax = []; Y.phase = ''; Y.rf = null; Y.fly = null; Y.rude = false; Y.ins = null; Y.posed = false;
    if (Y.dustRd) { try { Y.dustRd.active = false; OYODust.updateNpc(.016, Y.dustRd, dustOf(Y)); } catch (e) { /* ok */ } }          // reset this horse's dust state so the next spawn starts clean
    if (Y.hm) { Y.hm.m.setEnabled(false); Y.rm.m.setEnabled(false); }
    Y.on = false; Y.next = Y.busy && !Y.built ? .6 + Y.bi * .9 + Math.random() * .8 : Y.gap ? Y.gap[0] + Math.random() * Y.gap[1] : Y.starter ? 45 + Math.random() * 30 : Y.oncoming ? 25 + Math.random() * 20 : Y.front ? 40 + Math.random() * 25 : 22 + Math.random() * 18;
  }
  const ROY_RIDER_SAY = ['Ẹ gbà ọ̀nà! Royal cart!', 'Make way for the Alaafin’s cart!', 'Ẹ kú ìrìn, Rider!', 'Ride well, friend!', 'Òyó is waiting!', 'Hiyah! Faster, horse!'];
  const ROY_SAY = ['Ẹ gbà ọ̀nà, ẹ ṣé o!', 'Ẹ ṣé, Rider! Safe journey!', 'Ẹ kú ìrìn o!', 'Òyó ń dúró dè wá!'];
  const cruiseV = () => TOP * speedMul(R_.dist);                                      // the player's own steady pace (no gallop)
  function npcClear(Y, st) {                                                    // room for one more rider? (cap, and no other rider of the same carriageway near the spawn point)
    let n = 0, no = 0; const zs = st.z + Y.sp.z, gap = Y.oncoming ? 20 : 55;
    for (const O of NPCS) if (O.on) { if (O.oncoming) no++; else n++; if (O !== Y && !!O.oncoming === !!Y.oncoming && Math.abs(O.zc - zs) < gap) return false; }
    return Y.oncoming ? no < NPC_MAX_ON : n < NPC_MAX;
  }

  /* ---------- NPC riders never ride over one another ----------
     Every frame, any two riders on the same carriageway that are close together AND in the same lane (or sliding into it) are sorted out:
     the rider behind (or, if the one behind is a rude chaser, the one in front) switches to a free neighbouring lane, never into a lane another rider
     is in or heading for, and never into the player's lane when it is coming up behind him. If no lane is free he eases off to the speed of the rider
     in front until one is. Oncoming riders do the same among themselves on their own carriageway. */
  const NPC_GAP = 15, NPC_LAT = 2.6;
  function separateNpcs(dt, st) {
    const pl = latOf(st.x, st.z), sOf = Y => Y.oncoming ? -Y.zc : Y.zc, rlat = Y => Y.lat - (Y.oncoming ? -OFF : 0);
    NPCS.forEach(Y => { Y.capV = null; if (Y.avoidT > 0) Y.avoidT -= dt; });
    const live = NPCS.filter(Y => Y.on && (Y.phase === 'ride' || Y.phase === 'chase' || Y.phase === 'rude' || Y.phase === 'leave'));
    const laneFree = (Y, l) => {
      if (!Y.oncoming) { const rz = Y.zc - st.z; if (rz < 0 && rz > -70 && Math.abs(l * LW - pl) < 2.3) return false; }          // never into the player's lane from behind
      return !live.some(O => O !== Y && !!O.oncoming === !!Y.oncoming && Math.abs(sOf(O) - sOf(Y)) < NPC_GAP + 4 && (O.tl === l || Math.abs(rlat(O) - l * LW) < NPC_LAT));
    };
    for (let i = 0; i < live.length; i++) for (let j = i + 1; j < live.length; j++) {
      const a = live[i], b = live[j]; if (!!a.oncoming !== !!b.oncoming) continue;
      const rear = sOf(a) <= sOf(b) ? a : b, front = rear === a ? b : a, gap = sOf(front) - sOf(rear);
      if (gap >= NPC_GAP) continue;
      const lo = Math.abs(rlat(rear) - rlat(front)) < NPC_LAT;
      if (!lo && rear.tl !== front.tl) continue;                                   // already in different lanes
      const mv = Q => Q.oncoming || Q.zc < st.z;                                  // riders AHEAD of the player never change lane (the player steers round them): only riders behind him, or on the other road, may move over
      const Y = rear.phase === 'ride' && mv(rear) ? rear : front.phase === 'ride' && mv(front) ? front : null;
      if (Y) {
        const O = Y === rear ? front : rear;
        if (!(Y.tl !== O.tl && Y.avoidT > 0)) {                                    // not already moving over: pick a free neighbouring lane
          const cand = [Y.tl - 1, Y.tl + 1].filter(l => l >= -1 && l <= 1).sort((p, q) => Math.abs(q - O.tl) - Math.abs(p - O.tl));
          const pick = cand.find(l => l !== O.tl && laneFree(Y, l));
          if (pick != null) { Y.tl = pick; Y.avoidT = 1; }
        }
      }
      if (rear.phase === 'ride' && (lo || rear.tl === front.tl) && gap < (mv(rear) ? 9 : 11)) rear.capV = Math.min(rear.capV == null ? 99 : rear.capV, Math.max(1.5, front.v - .4));     // never ride through the rider in front: hold back to his speed
    }
  }
  /* ---------- THE PLAYER AND EVERY ROAD RIDER ARE SOLID ----------
     Riders in front of the player never change lane: the player has to steer round them. Nobody can ride through anybody:
       1. npcLaneGuard  - a lane change into a lane where a rider is alongside (or about to be) is refused, so the cart never slides into one;
       2. npcBrake      - before the cart moves, its speed is capped so it can never travel past the rear of a rider in its lane
                          (a hard hit is a collision: thud, camera shake, speed lost, one count on the rider-hit meter);
       3. npcResolve    - after everything has moved, a final positional check (so a slow frame can never let the cart tunnel through);
       4. npcHold       - a rider coming up from behind holds back instead of driving into the player's cart.
     Sizes: the player's nose is P_NOSE ahead of his centre and the cart tail P_TAIL behind it; a rider's tail depends on his cart. */
  const P_NOSE = 1.5, P_TAIL = 5.7, LAT_OV = 2.45, HIT_V = 2.2;
  const npcSolid = Y => Y.on && !Y.oncoming && (Y.phase === 'ride' || Y.phase === 'leave' || Y.phase === 'chase' || Y.phase === 'rude');
  const npcTail = Y => Y.cart ? (Y.cv === 'long' ? 7.8 : 5.7) : 1.7;
  const npcGapF = Y => npcTail(Y) + P_NOSE + .15;                      // centre-to-centre distance at which the player's nose touches the rider's tail
  function laneBlockedByNpc(l, st) {
    const pv = Math.abs(st.speed);
    for (const Y of NPCS) {
      if (!npcSolid(Y)) continue;
      if (Math.abs(Y.lat - l * LW) >= LAT_OV && Math.abs(Y.tl * LW - l * LW) >= LAT_OV) continue;
      const m = 1 + Math.abs(pv - Y.v) * .35, dz = Y.zc - st.z;         // a lane change takes ~0.35 s: leave room for the closing speed
      if (dz - npcTail(Y) < P_NOSE + m && dz + 1.6 > -P_TAIL - m) return true;
    }
    return false;
  }
  function npcLaneGuard(st) {
    const pl = latOf(st.x, st.z), cur = clamp(Math.round(pl / LW), -1, 1); if (lane === cur) return;
    const step = lane > cur ? 1 : -1;
    for (let l = cur + step; l !== lane + step; l += step) if (laneBlockedByNpc(l, st)) { lane = l - step; return; }
  }
  function npcImpact(Y, st) {                                           // a hard hit flips the rider over (cart: crashRoyal · horse: knockDown); the wreck is no longer solid, so the player rides straight through it
    if (Y.cart) crashRoyal(Y, st); else knockDown(Y, st, 'crash');
  }
  function npcBrake(dt, st) {                                           // before the cart moves: it can never travel past the rear of a rider in its own lane
    const pl = latOf(st.x, st.z); dt = Math.max(dt, .001);
    for (const Y of NPCS) {
      if (!npcSolid(Y) || Math.abs(Y.lat - pl) >= LAT_OV) continue;
      const dz = Y.zc - st.z; if (dz <= 0) continue;                    // only riders in front hold the player back
      const room = dz - npcGapF(Y), vmax = Y.v + Math.max(0, room) / dt;
      if (st.speed > vmax) { if (room < st.speed * dt + .3 && st.speed - Y.v > HIT_V) { npcImpact(Y, st); continue; } st.speed = Math.max(0, vmax); }       // hard hit: he flips, the player keeps his speed and passes through the wreck
    }
  }
  function npcResolve(dt, st) {                                         // after everything moved: a last positional check, so no frame can let the cart through
    const pl = latOf(st.x, st.z);
    for (const Y of NPCS) {
      if (Y.hitCd > 0) Y.hitCd -= dt;
      if (!npcSolid(Y)) { Y.pz = null; continue; }
      const dz = Y.zc - st.z, dl = Y.lat - pl;
      if (Math.abs(dl) < LAT_OV) {
        const gf = npcGapF(Y);
        if (dz > 0 && dz < gf && (Y.pz == null || Y.pz >= gf - 1.5)) {   // the player was behind him and has just caught up: stop at his tail
          if (st.speed - Y.v > HIT_V) { npcImpact(Y, st); Y.pz = Y.zc - st.z; continue; }      // hard hit: he flips and the player carries on through the wreck
          st.z = Y.zc - gf; st.x = cx(st.z) + pl * Math.sqrt(1 + slope(st.z) * slope(st.z)); st.speed = Math.min(st.speed, Y.v);
        } else if (Y.zc - npcTail(Y) < st.z + P_NOSE && Y.zc + 1.6 > st.z - P_TAIL) {      // slid sideways into him: back to the lane on the other side of him
          const side = dl > 0 ? -1 : dl < 0 ? 1 : (lane >= Math.round(Y.lat / LW) ? 1 : -1);
          lane = clamp(Math.round(Y.lat / LW) + side, -1, 1);
        }
      }
      Y.pz = Y.zc - st.z;
    }
  }
  function npcHold(Y, dt, st) {                                         // a rider coming up from behind never drives into the player's cart (the dodge normally takes him to another lane long before)
    if (Y.oncoming || Y.phase !== 'ride') return;
    const pl = latOf(st.x, st.z), lim = st.z - (P_TAIL + 1.7);
    if (Y.zc < st.z && Y.zc > lim && Math.abs(Y.lat - pl) < LAT_OV) { Y.zc += (lim - Y.zc) * Math.min(1, dt * 8); Y.v = Math.min(Y.v, Math.max(1, Math.abs(st.speed))); }
  }
  function npcSpawnGate(Y, dt, st) {                                            // true while Y is still waiting; spawns it once its time has come and the road has room
    if (Y.on) return false;
    Y.next -= dt; if (Y.next > 0) return true;
    if (R_.dist > Y.min && !E.over && !R_.exh && npcClear(Y, st)) spawnRoyalNpc(Y, st); else Y.next = .5;
    return !Y.on;
  }
  function spawnRoyalNpc(Y, st) {
    if (!buildRoyalNpc(Y)) return;
    const pl = latOf(st.x, st.z), V = VIL(), pln = clamp(Math.round(pl / LW), -1, 1), isH = Y.kind === 'horse', rl3 = () => Math.floor(Math.random() * 3) - 1;
    const otherL = () => { const c = [-1, 0, 1].filter(l => l !== pln); return c[Math.floor(Math.random() * 2)]; };
    const tl = Y.oncoming ? rl3() : Y.calm && Y.front ? otherL() : Y.front ? (Y.lane === 'any' && Math.random() < .45 ? rl3() : pln) : pln === 0 ? (Math.random() < .5 ? -1 : 1) : -pln;       // front: often the player's own lane; behind: never the player's lane (the opposite side lane, or either side lane if centred)
    try { const fg = (scene.fogDensity || 0) * .6; Y.mat.setFloat('fogD', fg); if (Y.cart) Y.cart.mat.setFloat('fogD', fg); } catch (e) { /* ok */ }          // riders keep more of their colour in the haze, so they read from far away
    const on3 = !!Y.oncoming, fy = on3 ? Math.PI : 0, bl = on3 ? -OFF : 0, sp = Y.sp;      // oncoming: faces back down the road (yaw + PI) on the other carriageway (lateral -OFF)
    const zc0 = Y.oncoming && R_.dist < 220 && !Y.fixedZ ? st.z + 30 + Math.random() * 170 : Y.calm && Y.front && R_.dist < 220 ? st.z + 55 + Math.random() * 135 : st.z + sp.z + (Y.jit ? Math.random() * Y.jit : 0);      // just after the start the oncoming road is already full
    Object.assign(Y, { on: true, phase: 'ride', zc: zc0, tl, lat: bl + tl * LW, f: sp.f0 + Math.random() * sp.fr, v: cruiseV() * sp.vm, t: 0, said: false, insSaid: false, pax: [], rf: null, fly: null, tickErr: 0, rt: undefined, posed: false, rude: false, ct: 0, avoidT: 0, capV: null });
    // a Yoruba word on the cart's boards / the horse's cloth (not on every rider)
    Y.ins = Math.random() < (Y.insP == null ? .7 : Y.insP) ? pickWord() : null;
    try { if (Y.cart && Y.cv) { /* plain extra carts carry no name boards */ } else if (Y.cart) Y.cart.setBoard(Y.ins ? Y.ins[0] + '|' + Y.ins[1] : ''); else if (Y.bn) { if (Y.ins) drawCloth(Y, Y.ins); Y.bn.setEnabled(!!Y.ins); } } catch (e) { /* cosmetic */ }
    // a horse from behind may be RUDE (only while Ṣàngó's strike exists in the game): it tailgates, abuses and shoves, and a strike can knock it off
    if (isH && Y.canRude && !Y.front && !on3 && R_.oseOn && Math.random() < .65) {
      Object.assign(Y, { rude: true, phase: 'chase', zc: st.z - 62, lat: clamp(pl, -LW, LW), tl: clamp(Math.round(pl / LW), -1, 1), shoves: 0, swerve: 0, side: pl > 0 ? -1 : 1, cd: 1.2, hit: false, v: Math.max(Math.abs(st.speed) + 8, 14) });
    }
    royPose(Y, ...(p => [p[0], p[1]])(pt(Y.zc, Y.lat)), yawAt(Y.zc) + fy, Y.v); Y.hs.speed = Y.v;
    Y.hm.m.setEnabled(true); Y.rm.m.setEnabled(true); Y.rd.active = true;
    if (Y.cart) { Y.cart.root.scaling.setAll(1); Y.cart.setVisible(true); Y.cart.rigid = true; Y.cart.hitch(Y.rd); }
    if (Y.bn) { Y.bn.position.set(Y.hs.x, Y.hs.y, Y.hs.z); Y.bn.rotation.set(Y.hs.pitch || 0, Y.hs.yaw, 0); }
    if (V && isH) {                                                                    // ONE passenger on the back of the horse
      const p = V.spawn(ADULT[Math.floor(Math.random() * ADULT.length)], 1e5, 1e5, 0, 0);
      if (p) { try { p.w = p.rl = null; p.rs = false; p.busy = Infinity; p.cr = pillionHook(Y); p.st = 1.5; p.cr(p); Y.pax.push(p); } catch (err) { V.release(p); } }
    } else if (V && Y.cart) { const ns = (Y.cart.anchors && Y.cart.anchors.seats ? Y.cart.anchors.seats.length : 4), n = Y.cv === 'load' ? 0 : Y.cv === 'two' ? 1 + Math.floor(Math.random() * 2) : Y.cv === 'long' ? Math.min(ns, 3 + Math.floor(Math.random() * 4)) : 2 + Math.floor(Math.random() * 3); for (let i = 0; i < n; i++) { const p = V.spawn(ADULT[Math.floor(Math.random() * ADULT.length)], 1e5, 1e5, 0, 0); if (!p) continue; try { p.w = p.rl = null; p.rs = false; if (Y.cart.seatPerson(p, i)) Y.pax.push(p); else V.release(p); } catch (err) { V.release(p); } } }
  }
  /* crash: the cart flips over backwards, passengers and rider are flung to the back, and the horse breaks loose and bolts across to the oncoming side of the road */
  function crashRoyal(Y, st) {
    const C = Y.cart, yw = yawAt(Y.zc), fx = Math.sin(yw), fz = Math.cos(yw), dz = C.dims.HORSE_Z + (C.dims.KPZ - C.dims.RZ) / 2, seat = C.toWorld(R_SEAT);
    try { C.unhitch(); } catch (e) { /* ok */ } Y.cart.rigid = true; C.setVisible(true);
    Object.assign(Y, { phase: 'crash', ct: 0, cz: Y.zc - dz, cv: Math.max(Y.v * .75, 6), ang: 0, hz: Y.zc, hv: Math.max(Y.v * .85, 12), lastLat: Y.lat, hlat: Y.lat, side: Y.lat < 0 ? -1 : 1, fly: [] });
    const fling = (o, big) => { const vb = (big ? 6 : 4) + Math.random() * 5; o.vx = -fx * vb + fz * (Math.random() - .5) * 5; o.vz = -fz * vb - fx * (Math.random() - .5) * 5; o.vy = 5 + Math.random() * 4; o.landed = false; return o; };
    Y.pax.forEach(p => { try { C.unseatPerson(p); } catch (e) { /* ok */ } p.busy = Infinity; p.st = 6.25; p.sc = p.sc || 1; Y.fly.push(fling({ p }, 0)); });
    Y.rf = fling({ x: seat[0], y: seat[1], z: seat[2], yaw: yw, rx: 0, rz: 0 }, 1);
    // hitting the royal rider has its OWN count (NPC_LIVES) and never costs an obstacle life; the obstacle counter (Hits x/3) is untouched
    let npcMsg = '';
    if (R_.invul <= 0) { R_.npcN = (R_.npcN || 0) + 1; R_.invul = INVUL; ghost = Math.max(ghost, 1.15); st.speed *= .5; try { RD.cam.kick = 1; } catch (e) { /* ok */ } npcMsg = ' (' + R_.npcN + '/' + NPC_LIVES + ')'; if (R_.npcN >= NPC_LIVES) R_.npcFatal = 1; }
    else { try { RD.cam.kick = 1; } catch (e) { /* ok */ } }
    snd('impact', 6); snd('neigh', .7); scaredTalk(); warnTxt((Y.starter ? 'Crash! You hit the cart!' : 'Crash! You hit the royal cart!') + npcMsg);
  }
  function updateRoyalNpc(Y, dt, st) {
    if (Y.kind === 'horse') return updateHorseNpc(Y, dt, st);
    if (npcSpawnGate(Y, dt, st)) return;
    const C = Y.cart, pl = latOf(st.x, st.z), dz = C.dims.HORSE_Z + (C.dims.KPZ - C.dims.RZ) / 2; Y.t += dt;
    if (Y.phase === 'ride') {
      const rz = Y.zc - st.z;
      Y.v += (cruiseV() * Y.f - Y.v) * Math.min(1, dt * 1.5);                    // his own steady pace, a little above the player's walk-gallop, below the player's full gallop
      if (Y.capV != null) Y.v = Math.min(Y.v, Y.capV);                            // stuck behind another rider with no free lane: hold back instead of riding through him
      if (Y.oncoming) {                                                          // other carriageway, coming TOWARDS the player: he can never be hit (a wall separates the roads), he just thunders past
        Y.zc -= Y.v * dt;
        Y.lat += (-OFF + Y.tl * LW - Y.lat) * Math.min(1, dt * 4.5);
        const q = pt(Y.zc, Y.lat); royPose(Y, q[0], q[1], yawAt(Y.zc) + Math.PI, Y.v);
        const VR = Y.mute ? null : VIL(), cs = C.state;
        if (VR && cs) { VR.spkMove(6, cs.x, cs.y + .1, cs.z); Y.rt = (Y.rt === undefined ? 1 : Y.rt) - dt; if (Y.rt <= 0 && rz < 55 && rz > -20) { Y.rt = 5 + Math.random() * 4; try { VR.say(6, cs.x, cs.y + .1, cs.z, ROY_RIDER_SAY[Math.floor(Math.random() * ROY_RIDER_SAY.length)], 'Rider'); } catch (err) { /* ok */ } } }
        if (!Y.said && !Y.mute && rz < 40 && Y.pax.length) { Y.said = true; const VV = window.OYOVillagers; try { if (VV && VV.say) VV.say(Y.pax[0], ROY_SAY[Math.floor(Math.random() * ROY_SAY.length)], 2.6, 'Passenger'); } catch (err) { /* ok */ } }
        if (rz < -170 || Y.t > 110) { hideRoyalNpc(Y); if (Y.busy) Y.next = Y.gap[0] + Math.random() * Y.gap[1]; else Y.next = 30 + Math.random() * 25; }
        return;
      }
      Y.zc += Y.v * dt; npcHold(Y, dt, st);
      { const VR = Y.mute ? null : VIL(), cs = C.state; if (VR && cs) { const sl = spkOf(Y), RS = Y.starter ? STARTER_RIDER_SAY : ROY_RIDER_SAY; VR.spkMove(sl, cs.x, cs.y + .1, cs.z); Y.rt = (Y.rt === undefined ? 1 : Y.rt) - dt; if (Y.rt <= 0 && Math.abs(rz) < 45) { Y.rt = 6 + Math.random() * 5; try { VR.say(sl, cs.x, cs.y + .1, cs.z, RS[Math.floor(Math.random() * RS.length)], 'Rider'); } catch (err) { /* ok */ } } } }   // the NPC rider always talks, bubble follows him
      if (!Y.said && !Y.mute && (Y.front ? rz < 25 : rz > -6) && Y.pax.length) { Y.said = true; const VV = window.OYOVillagers; try { if (VV && VV.say) VV.say(Y.pax[0], ROY_SAY[Math.floor(Math.random() * ROY_SAY.length)], 2.6, 'Passenger'); } catch (err) { /* ok */ } }
      if (rz > 170 || rz < -170 || Y.t > 110) { hideRoyalNpc(Y); if (!Y.busy) Y.next = 55 + Math.random() * 40; return; }
      let dodge = false;
      if (rz < 0 && rz > -70 && Math.abs(Y.tl * LW - pl) < 2.3) {                    // coming up from BEHIND in the player's lane: never ram him from behind, move over (riders AHEAD never change lane)
        let best = Y.tl, bd = -1; for (const l of [-1, 0, 1]) { const d = Math.abs(l * LW - pl) + (l === Y.tl ? -.01 : 0) + (l !== 0 && Math.sign(l) === Math.sign(Y.tl) ? .05 : 0); if (d > bd) { bd = d; best = l; } }
        Y.tl = best; dodge = true;
      }
      Y.lat += (Y.tl * LW - Y.lat) * Math.min(1, dt * (dodge || Y.avoidT > 0 || rz < 0 && rz > -70 ? 4.5 : 2.5));
      { const q = pt(Y.zc, Y.lat); royPose(Y, q[0], q[1], yawAt(Y.zc), Y.v); return; }        // the player can no longer ride through him: see npcBrake / npcResolve
    }
    // ---------- crash ----------
    Y.ct += dt;
    Y.cv = Math.max(0, Y.cv - 15 * dt); Y.cz += Y.cv * dt; Y.ang = Math.min(Math.PI * 1.04, Y.ang + (6.2 - 2.2 * Y.ang / Math.PI) * dt);
    const cp = pt(Y.cz, Y.lat + Y.side * Math.min(1.4, Y.ct * 1.6)), a = Y.ang;                      // the wreck skids a little sideways
    C.place(cp[0], cp[1], yawAt(Y.cz) + Y.side * .18 * Math.min(1, Y.ct)); C.update(dt, Y.cv, 0);
    const r = C.root; r.position.y += 1.1 * (1 - Math.cos(a)) / 2 + .8 * Math.sin(a) * Math.max(0, 1 - Y.ct * 1.2); r.rotation.x = -a; r.rotation.z = Y.side * .22 * Math.min(1, a / Math.PI);        // over the back: nose up and over
    if (Y.ct > 5) r.scaling.setAll(Math.max(.01, (6 - Y.ct) / 1));
    // the real horse breaks loose and bolts across to the oncoming carriageway
    Y.hz += Y.hv * dt; Y.hlat += (-OFF - Y.hlat) * Math.min(1, dt * 1.5); const dl = (Y.hlat - Y.lastLat) / Math.max(dt, .001); Y.lastLat = Y.hlat;
    { const q = pt(Y.hz, Y.hlat); royPose(Y, q[0], q[1], yawAt(Y.hz) + Math.atan2(dl, Y.hv), Y.hv); }
    // flung to the back: passengers (then up and walking away, shaken) and the rider (lies where he lands)
    const V = VIL();
    Y.fly.forEach(f => {
      if (f.landed) return; const p = f.p; f.vy -= 20 * dt; p.x += f.vx * dt; p.z += f.vz * dt; p.y += f.vy * dt; p.yaw += 7 * dt;
      const g = hgt(p.x, p.z); if (p.y <= g && f.vy < 0) { p.y = g; f.landed = true; p.busy = 0; p.st = 0; p.sc = p.sc || 1; Y.pax = Y.pax.filter(q => q !== p); if (V) { const sd = latOf(p.x, p.z) > -OFF / 2 ? 1 : -1, b = pt(p.z + 2, sd * 9); walkers.push({ p, x: b[0], z: b[1], t: 0 }); } }
    });
    const rf = Y.rf;
    if (rf && !rf.landed) { rf.vy -= 20 * dt; rf.x += rf.vx * dt; rf.z += rf.vz * dt; rf.y += rf.vy * dt; rf.rx -= 8 * dt; rf.rz += 4 * dt; rf.yaw += 2 * dt; const g = hgt(rf.x, rf.z) + .35; if (rf.y <= g && rf.vy < 0) { rf.y = g; rf.landed = true; rf.rx = -Math.PI / 2; rf.rz = 0; } }
    if (Y.ct > 6) { hideRoyalNpc(Y); if (!Y.busy) Y.next = 45 + Math.random() * 35; }
  }

  /* ============================== ORDINARY-HORSE RIDERS (HRS1 - HRS5) ==============================
     A plain horse, the same real horse + rider models, the rider in the saddle and ONE passenger sitting behind him. No cart.
     Ahead of the player: slow riders (often in his own lane, so he must steer round them or slow down) · behind: they come up and OVERTAKE (some are RUDE) · oncoming carriageway: they thunder past.
     Hit one from behind and the rider and passenger are thrown off, the horse bolts (own hit count, like the royal cart). A rude one can be knocked off by Ose Ṣàngó (E.strike). */
  function wrapText(c, text, maxW) {
    const words = String(text).split(' '), lines = []; let cur = '';
    for (const w of words) { const t = cur ? cur + ' ' + w : w; if (!cur || c.measureText(t).width <= maxW) cur = t; else { lines.push(cur); cur = w; } }
    if (cur) lines.push(cur); return lines;
  }
  function drawCloth(Y, w) {                                                         // the Yoruba word + its meaning on a dyed cloth (adire style), for the flanks and the flag
    const L = CLOTH_LOOK[Math.floor(Math.random() * CLOTH_LOOK.length)], c = Y.ctx, W = 384, HH = 256, maxW = W - 64; c.setTransform(2, 0, 0, 2, 0, 0);
    const g = c.createLinearGradient(0, 0, 0, HH); g.addColorStop(0, L[0]); g.addColorStop(1, L[1]); c.fillStyle = g; c.fillRect(0, 0, W, HH);
    c.fillStyle = 'rgba(255,255,255,.08)'; for (let i = 0; i < 46; i++) { c.beginPath(); c.arc(Math.random() * W, Math.random() * HH, 5 + Math.random() * 13, 0, 7); c.fill(); }
    c.strokeStyle = L[3]; c.lineWidth = 8; c.strokeRect(10, 10, W - 20, HH - 20); c.lineWidth = 3; c.strokeRect(22, 22, W - 44, HH - 44);
    c.textAlign = 'center'; c.textBaseline = 'middle';
    let mf = 76, ml = []; for (; mf >= 36; mf -= 4) { c.font = '800 ' + mf + 'px Fraunces, Georgia, serif'; ml = wrapText(c, w[0], maxW); if (ml.length <= (mf >= 52 ? 1 : 2)) break; }
    let sf = 34, sl = []; for (; sf >= 20; sf -= 2) { c.font = '600 ' + sf + 'px Nunito, Georgia, serif'; sl = wrapText(c, w[1], maxW); if (sl.length <= 3) break; }
    const mh = mf * 1.12, sh = sf * 1.2, tot = ml.length * mh + 14 + sl.length * sh; let y = (HH - tot) / 2 + mh / 2;
    c.font = '800 ' + mf + 'px Fraunces, Georgia, serif';
    ml.forEach(t => { c.fillStyle = 'rgba(0,0,0,.45)'; c.fillText(t, W / 2 + 2, y + 3); c.fillStyle = L[2]; c.fillText(t, W / 2, y); y += mh; });
    y += 14 - mh / 2 + sh / 2; c.font = '600 ' + sf + 'px Nunito, Georgia, serif';
    sl.forEach(t => { c.fillStyle = 'rgba(0,0,0,.4)'; c.fillText(t, W / 2 + 1, y + 2); c.fillStyle = L[3]; c.fillText(t, W / 2, y); y += sh; });
    Y.ctex.update();
  }
  function buildBanner(Y) {                                                          // cloth on both flanks + a flag on a pole behind the passenger (seen from the road behind)
    const tex = new B.DynamicTexture('npcClothTex', { width: 768, height: 512 }, scene, true), mt = new B.StandardMaterial('npcClothMat', scene), bn = new B.TransformNode('npcBn', scene);
    mt.disableLighting = true; mt.emissiveTexture = tex; mt.diffuseColor = B.Color3.Black(); mt.specularColor = B.Color3.Black(); mt.backFaceCulling = true;
    const mk = (w, h, x, y, z, ry) => { const q = B.MeshBuilder.CreatePlane('npcCloth', { width: w, height: h }, scene); q.material = mt; q.parent = bn; q.position.set(x, y, z); q.rotation.y = ry; q.isPickable = false; return q; };
    mk(.85, .57, .32, 1.1, -.1, -Math.PI / 2); mk(.85, .57, -.32, 1.1, -.1, Math.PI / 2); mk(1.15, .77, 0, 2.7, -1.1, 0);
    const pm = new B.StandardMaterial('npcPoleMat', scene); pm.diffuseColor = new B.Color3(.3, .2, .1); pm.emissiveColor = new B.Color3(.12, .08, .04); pm.specularColor = B.Color3.Black();
    const pole = B.MeshBuilder.CreateCylinder('npcPole', { diameter: .05, height: 2.1, tessellation: 6 }, scene); pole.material = pm; pole.parent = bn; pole.position.set(-.6, 2.1, -1.07); pole.isPickable = false;
    bn.setEnabled(false); Y.bn = bn; Y.ctex = tex; Y.ctx = tex.getContext();
  }
  const placeHorse = (Y, zc, lat, yo) => { const q = pt(zc, lat); royPose(Y, q[0], q[1], yawAt(zc) + yo, Y.v); };
  function horseTalk(Y, rz, dt) {                                                    // the rider's chat, the Yoruba word on his cloth (with its meaning) and the passenger's remark
    const VR = Y.mute ? null : VIL(), hp = Y.root.position; if (!VR) return;
    VR.spkMove(Y.spk, hp.x, hp.y + .1, hp.z);
    Y.rt = (Y.rt === undefined ? 1.5 : Y.rt) - dt;
    if (Y.rt <= 0 && Math.abs(rz) < 45) { Y.rt = 6 + Math.random() * 5; try { VR.say(Y.spk, hp.x, hp.y + .1, hp.z, HRS_SAY[Math.floor(Math.random() * HRS_SAY.length)], 'Rider'); } catch (e) { /* ok */ } }
    if (!Y.said && Y.pax.length && Math.abs(rz) < 18) { Y.said = true; try { const VV = window.OYOVillagers; if (VV && VV.say) VV.say(Y.pax[0], HRS_PAX_SAY[Math.floor(Math.random() * HRS_PAX_SAY.length)], 2.8, 'Passenger'); } catch (e) { /* ok */ } }
  }
  /* knock the rider (and his passenger) off: mode 'crash' = the player rode into him · 'struck' = Ose Ṣàngó's lightning. The horse bolts on its own. */
  function knockDown(Y, st, mode) {
    const hs = Y.hs, yw = yawAt(Y.zc), fx = Math.sin(yw), fz = Math.cos(yw), crash = mode === 'crash', sn = hs.x > st.x ? 1 : -1;
    const fling = (o, big) => {
      if (crash) { const vb = (big ? 6 : 4) + Math.random() * 5; o.vx = -fx * vb + fz * (Math.random() - .5) * 5; o.vz = -fz * vb - fx * (Math.random() - .5) * 5; o.vy = 5 + Math.random() * 4; }
      else { const k = big ? 1 : .8 + Math.random() * .4; o.vx = (Math.cos(yw) * sn * 3 + fx * 4) * k; o.vz = (-Math.sin(yw) * sn * 3 + fz * 4) * k; o.vy = (big ? 8 : 6.5) + Math.random(); }
      o.landed = false; return o;
    };
    Object.assign(Y, { phase: 'down', ct: 0, hz: Y.zc, hv: crash ? Math.max(Y.v * .85, 12) : Y.v + 6, hlat: Y.lat, lastLat: Y.lat, hl2: crash ? -OFF : Y.lat, fly: [] });
    Y.pax.forEach(q => { q.cr = null; q.busy = Infinity; q.st = 6.25; q.sc = q.sc || 1; Y.fly.push(fling({ p: q }, 0)); });
    Y.rf = fling({ x: hs.x - fx * .07, y: hs.y + 1.52, z: hs.z - fz * .07, yaw: yw, rx: 0, rz: 0 }, 1);
    if (!crash) return;
    let npcMsg = '';                                                                 // hitting a road rider has its OWN count (NPC_LIVES) and never costs an obstacle life
    if (R_.invul <= 0) { R_.npcN = (R_.npcN || 0) + 1; R_.invul = INVUL; ghost = Math.max(ghost, 1.15); st.speed *= .5; try { RD.cam.kick = 1; } catch (e) { /* ok */ } npcMsg = ' (' + R_.npcN + '/' + NPC_LIVES + ')'; if (R_.npcN >= NPC_LIVES) R_.npcFatal = 1; }
    else { try { RD.cam.kick = 1; } catch (e) { /* ok */ } }
    snd('impact', 7); snd('neigh', .7); scaredTalk(); warnTxt('Crash! You hit the horse rider!' + npcMsg);
  }
  function horseDown(Y, dt) {                                                        // after the fall: the horse bolts, the passenger gets up and walks away, the rider lies where he landed
    Y.ct += dt; const V = VIL();
    Y.hz += Y.hv * dt; Y.hlat += (Y.hl2 - Y.hlat) * Math.min(1, dt * 1.5); const dl = (Y.hlat - Y.lastLat) / Math.max(dt, .001); Y.lastLat = Y.hlat; Y.v = Y.hv;
    { const q = pt(Y.hz, Y.hlat); royPose(Y, q[0], q[1], yawAt(Y.hz) + Math.atan2(dl, Y.hv), Y.hv); }
    (Y.fly || []).forEach(f => {
      if (f.landed) return; const q = f.p; f.vy -= 20 * dt; q.x += f.vx * dt; q.z += f.vz * dt; q.y += f.vy * dt; q.yaw += 7 * dt;
      const g = hgt(q.x, q.z); if (q.y <= g && f.vy < 0) { q.y = g; f.landed = true; q.busy = 0; q.st = 0; q.sc = q.sc || 1; Y.pax = Y.pax.filter(o => o !== q); if (V) { const sd = latOf(q.x, q.z) > -OFF / 2 ? 1 : -1, b = pt(q.z + 2, sd * 9); walkers.push({ p: q, x: b[0], z: b[1], t: 0 }); } }
    });
    const rf = Y.rf;
    if (rf && !rf.landed) { rf.vy -= 20 * dt; rf.x += rf.vx * dt; rf.z += rf.vz * dt; rf.y += rf.vy * dt; rf.rx -= 8 * dt; rf.rz += 4 * dt; rf.yaw += 2 * dt; const g = hgt(rf.x, rf.z) + .35; if (rf.y <= g && rf.vy < 0) { rf.y = g; rf.landed = true; rf.rx = -Math.PI / 2; rf.rz = 0; } }
    if (Y.ct > 6) { hideRoyalNpc(Y); if (!Y.busy) Y.next = 45 + Math.random() * 35; }
  }
  function updateHorseNpc(Y, dt, st) {
    if (npcSpawnGate(Y, dt, st)) return;
    Y.t += dt; const ph = Y.phase;
    if (ph === 'down') { horseDown(Y, dt); return; }
    const pl = latOf(st.x, st.z), v = Math.abs(st.speed), rz = Y.zc - st.z;
    if (ph === 'ride') {
      Y.v += (cruiseV() * Y.f - Y.v) * Math.min(1, dt * 1.5);                         // his own steady pace
      if (Y.capV != null) Y.v = Math.min(Y.v, Y.capV);                                 // stuck behind another rider with no free lane: hold back instead of riding through him
      if (Y.oncoming) {                                                              // other carriageway: separated by a wall, he just thunders past
        Y.zc -= Y.v * dt; Y.lat += (-OFF + Y.tl * LW - Y.lat) * Math.min(1, dt * 4.5); placeHorse(Y, Y.zc, Y.lat, Math.PI); horseTalk(Y, rz, dt);
        if (rz < -170 || Y.t > 110) { hideRoyalNpc(Y); if (Y.busy) Y.next = Y.gap[0] + Math.random() * Y.gap[1]; else Y.next = 30 + Math.random() * 25; }
        return;
      }
      Y.zc += Y.v * dt; npcHold(Y, dt, st); horseTalk(Y, rz, dt);
      if (rz > 170 || rz < -170 || Y.t > 110) { hideRoyalNpc(Y); if (!Y.busy) Y.next = 45 + Math.random() * 35; return; }
      let dodge = false;
      if (rz < 0 && rz > -70 && Math.abs(Y.tl * LW - pl) < 2.3) {                    // coming up from BEHIND in the player's lane: never ram him from behind, move over and overtake (riders AHEAD never change lane)
        let best = Y.tl, bd = -1; for (const l of [-1, 0, 1]) { const d = Math.abs(l * LW - pl) + (l === Y.tl ? -.01 : 0) + (l !== 0 && Math.sign(l) === Math.sign(Y.tl) ? .05 : 0); if (d > bd) { bd = d; best = l; } }
        Y.tl = best; dodge = true;
      }
      Y.lat += (Y.tl * LW - Y.lat) * Math.min(1, dt * (dodge || Y.avoidT > 0 || rz < 0 && rz > -70 ? 4.5 : 2.5));
      placeHorse(Y, Y.zc, Y.lat, 0); return;
    }
    // ---------- RUDE rider from behind (same behaviour as the rude riders above, on a real horse with a passenger) ----------
    const VR = VIL(), hp = Y.root.position; if (VR) VR.spkMove(Y.spk, hp.x, hp.y + .9, hp.z);
    if (ph === 'chase') {
      Y.v = Math.max(v + 8, 14); Y.zc += Y.v * dt; Y.lat += (clamp(pl, -LW, LW) - Y.lat) * Math.min(1, dt * 1.2);
      if (rz > -5) { Y.phase = 'rude'; Y.t = 0; rudeSay(Y, RUDE_SAY[Math.floor(Math.random() * RUDE_SAY.length)]); }
    } else if (ph === 'rude') {
      const dv = clamp((1.2 - rz) * 2.5, -8, 8); Y.v = v + dv; Y.zc += Y.v * dt; Y.cd -= dt;
      if (Y.swerve > 0) { Y.swerve -= dt; Y.lat += (pl + Y.side * .3 - Y.lat) * Math.min(1, dt * 9); const rl = Y.lat - pl; if (!Y.hit && Math.abs(rl) < 1.7 && Math.abs(rz) < 3) { Y.hit = true; Y.shoves++; shoveCart(Y, st, rl); } }
      else { Y.lat += (clamp(pl + Y.side * 2.1, -HW + 1, HW - 1) - Y.lat) * Math.min(1, dt * 2.2); if (Y.cd <= 0) { Y.swerve = .7; Y.cd = 2.6 + Math.random() * 1.2; Y.hit = false; } }
      if (Y.shoves >= 5 || Y.t > 22) Y.phase = 'leave';
    } else {                                                                         // 'leave': gallops off ahead
      Y.v = v + 16; Y.zc += Y.v * dt; if (rz > 80) { hideRoyalNpc(Y); if (!Y.busy) Y.next = 50 + Math.random() * 40; return; }
    }
    if (Math.abs(rz) < 60) E.hotH = true;                                           // in reach: lights up the ⚡ button
    placeHorse(Y, Y.zc, Y.lat, 0);
  }

  E.strike = function () {                                                       // use ONE Ose Ṣàngó on the nearest rude rider (the old rude riders or a rude road rider on a horse)
    const h = OYO.hud; if (!R_.oseOn || !E.on || E.over || E.paused) return;
    if (save.ose <= 0) { toast('You have no Ose Ṣàngó — pick one up on the road.'); return; }
    const st = RD.state, r0 = RIDERS.filter(q => q.on && q.phase !== 'struck' && Math.abs(q.zc - st.z) < 70).sort((a, b) => Math.abs(a.zc - st.z) - Math.abs(b.zc - st.z))[0];
    const y0 = NPCS.filter(Y => Y.on && Y.rude && (Y.phase === 'chase' || Y.phase === 'rude' || Y.phase === 'leave') && Math.abs(Y.zc - st.z) < 70).sort((a, b) => Math.abs(a.zc - st.z) - Math.abs(b.zc - st.z))[0];
    const useY = !!y0 && (!r0 || Math.abs(y0.zc - st.z) < Math.abs(r0.zc - st.z)), r = useY ? null : r0, tgt = useY ? y0 : r0;
    if (!tgt) { toast('No rude rider to strike right now — keep your Ose Ṣàngó.'); snd('fail'); return; }
    save.ose--; store(); h.eOse = save.ose;
    const lead = pt(tgt.zc + (tgt.v || 0) * .14, tgt.lat), ex = lead ? lead[0] : tgt.root.position.x, ez = lead ? lead[1] : tgt.root.position.z, ey = hgt(ex, ez);   // where he will be when the bolt lands
    spawnBolt(ex, ey, ez, function () {                                          // the return stroke connects: only NOW is the rider hit
      ringFx(ex, ey, ez);
      if (useY) { if (y0.on) knockDown(y0, RD.state, 'struck'); }
      else if (r && r.on && r.phase !== 'struck') {
        const sn = r.root.position.x > RD.state.x ? 1 : -1, yaw = yawAt(r.zc);
        r.rider.setParent(null); r.fly = { vx: Math.cos(yaw) * sn * 3 + Math.sin(yaw) * 4, vy: 8, vz: -Math.sin(yaw) * sn * 3 + Math.cos(yaw) * 4 };
        r.phase = 'struck'; r.die = 3.4; r.t = 0;
      }
    });
    snd('thunder');
    toast('⚡ Ṣàngó has punished the rude rider!');
    const V = VIL(); if (V && R_.pax > 0) { const sc = CHEER[Math.floor(Math.random() * CHEER.length)], n = Math.min(R_.pax, 3); let at = .6; scene_ = sc.map((text, i) => { const o = { at, who: i % n, text }; at += 2.3 + text.length * .045 + .3; return o; }); scT = 0; scLive = at + 3; scCool = at + 4; }
  };
  window.addEventListener('keydown', e => { if (e.code === 'KeyF' && E.on && !e.repeat) E.strike(); });
  function scaredTalk() {                                      // passengers react to a pothole: a short, frightened back-and-forth
    const V = VIL(); if (!V || R_.pax <= 0 || scCool > 0) return;
    const n = Math.min(R_.pax, 3), pool = n > 1 ? SCARED : SCARED1, sc = pool[Math.floor(Math.random() * pool.length)]; let at = .35;
    scene_ = sc.map((text, i) => { const o = { at, who: i % n, text }; at += 2.3 + text.length * .045 + .3; return o; });
    scT = 0; scLive = at + 3; scCool = at + 4;
  }
  function releasePP(ch) { const V = window.OYOVillagers && OYOVillagers.endless; if (V) ch.pp.forEach(p => p && V.release(p)); ch.pp.length = 0; }
  function clearRiders() { const V = window.OYOVillagers && OYOVillagers.endless; (R_.pl || []).forEach(q => { if (q.p) { try { S.cart.unseatPerson(q.p); } catch (err) { /* ok */ } if (V) V.release(q.p); } }); R_.pl = []; }
  function clearPeople() {
    clearRiders();
    const V = window.OYOVillagers && OYOVillagers.endless; if (!V) return;
    A.chunks.forEach(releasePP); crossers.forEach(p => V.release(p)); walkers.forEach(w => V.release(w.p)); crossers = []; walkers = [];
  }
  function spawnPP(ch) {
    const V = VIL(); ch.pp.length = 0; if (!V) return;
    for (let q = 0; q < ch.nv; q++) {
      const o = q * 8, side = ch.vil[o], lat = ch.vil[o + 1], z = ch.vil[o + 2], rng = ch.vil[o + 3], fl = ch.vil[o + 7];
      const role = ZROLE[fl], id = role ? role[ch.vil[o + 5] % role.length] : fl === 2 ? ADULT[ch.vil[o + 5] % ADULT.length] : PIDS[(ch.vil[o + 5] * 3 + ch.vil[o + 6]) % PIDS.length];   // flags 3 / 4 / 5: guard / farmer / trader (Stage 40)
      const p0 = pt(z, side * lat - SO(side)), p = V.spawn(id, p0[0], p0[1], Math.atan2(-side, side * slope(z)), fl === 2 ? 2 : (fl === 5 && !(rng > 0)) ? 4 : 0);
      if (!p) { ch.pp[q] = null; continue; }
      if (rng > 0 && fl !== 2) { const a = pt(z - rng, side * lat - SO(side)), b = pt(z + rng, side * lat - SO(side)); V.patrol(p, a[0], a[1], b[0], b[1]); }
      ch.pp[q] = p;
    }
  }
  function initPeopleRoad() {                                  // centreline of the whole double road, so villagers cross BOTH carriageways
    const V = VIL(); if (!V) return;
    V.setRoad(zc => { const sl = slope(zc), l = Math.sqrt(1 + sl * sl), p = pt(zc, -OFF / 2); return [p[0], p[1], 1 / l, -sl / l, sl / l, 1 / l]; }, startZ - 120, startZ + 16000, HW + OFF / 2);
  }
  function updatePeople(dt, st) {
    const V = VIL(); if (!V) return;
    scCool = Math.max(0, scCool - dt);
    if (scLive > 0) {                                          // keep the bubbles riding with the cart
      scT += dt; scLive -= dt;
      const c = S.cart && S.cart.state && S.cart.state.hitched ? S.cart.state : null, bx = c ? c.x : 0, bz = c ? c.z : 0, by = c ? c.y : 0, yw = c ? c.yaw : 0, sy = Math.sin(yw), cyw = Math.cos(yw);
      for (let i = 0; i < 3; i++) V.spkMove(i, bx - sy * 1.2 + cyw * (i - 1) * .45, by + .3, bz - cyw * 1.2 - sy * (i - 1) * .45);
      while (scene_.length && scene_[0].at <= scT) { const l = scene_.shift(); V.say(l.who, bx - sy * 1.2 + cyw * (l.who - 1) * .45, by + .3, bz - cyw * 1.2 - sy * (l.who - 1) * .45, l.text, 'Passenger'); }
    }
    for (let i = crossers.length - 1; i >= 0; i--) { const p = crossers[i]; if (p.hide || p.z < st.z - 60 || p.z > st.z + 320) { V.release(p); crossers.splice(i, 1); } }
    crossT -= dt;
    if (crossT <= 0 && R_.dist > 30) { crossT = 2.5 + Math.random() * 4; if (crossers.length < 5) { const p = V.cross(st.z + 130 + Math.random() * 110, Math.random() < .5 ? -1 : 1); if (p) crossers.push(p); } }
    for (let i = walkers.length - 1; i >= 0; i--) { const w = walkers[i]; w.t += dt; if (V.walkTo(w.p, w.x, w.z, 2.2, dt) < .4 || w.t > 9) { V.release(w.p); walkers.splice(i, 1); } }
  }

  /* HUD passenger card: with passengers aboard it names the next drop-off stop they get off at; with an empty cart (or none ahead) it names the next pick-up stop.
     The caption reads "here" once the cart is within one stop's length of that stop. */
  function updateTarget(st) {
    const h = OYO.hud, aboard = R_.pl && R_.pl.length > 0;
    let best = null;
    const minK = aboard ? Math.min.apply(null, R_.pl.map(q => q.k)) : 0;
    for (const ch of A.chunks) {
      if (ch.idx === -999 || !ch.stops.length) continue;
      for (const sp of ch.stops) {
        if (sp.state === 2 || sp.z < st.z - 8) continue;
        if (aboard ? (sp.kind !== 'drop' || sp.k < minK) : sp.kind !== 'pick') continue;
        if (!best || sp.z < best.z) best = sp;
      }
    }
    let name, z;
    if (best) { name = best.area[0]; z = best.z; }
    else {                                                                           // nothing streamed in yet: work it out from the fixed stop cycle
      const curK = Math.floor(st.z / CL), off = aboard ? STOP_P - 2 : 2;
      let k = Math.max(curK, aboard ? minK : curK); while (k % STOP_P !== off) k++;
      name = areaFor(k)[0]; z = k * CL + CL / 2;
    }
    const cap = Math.abs(z - st.z) < CL ? 'here' : (aboard ? 'drop-off' : 'pick-up');
    if (h.eTgt !== name) h.eTgt = name;
    if (h.eTgtCap !== cap) h.eTgtCap = cap;
  }

  /* Stage 40: a brief animated banner when the rider crosses into a new region; fog thickens in the forest and thins on the open trade route (eased, so it never pops) */
  /* real Yoruba festivals, matched to the region you ride into (ZN order: outskirts, market, royal, farm, forest, village, trade route) */
  const FEST = [
    { yo: 'Ọdún Ọlọ́jọ́', en: 'Olojo Festival', e: '👑', b: 6 },
    { yo: 'Ọdún Aṣọ-Ofì', en: 'Aso-Ofi Festival', e: '🧵', b: 8 },
    { yo: 'Ọdún Ṣàngó', en: 'Sango Festival', e: '⚡', b: 10 },
    { yo: 'Ọdún Bẹ̀rẹ̀', en: 'Bere Festival', e: '🌾', b: 8 },
    { yo: 'Ọdún Ògún', en: 'Ogun Festival', e: '⚒️', b: 6 },
    { yo: 'Ọdún Egúngún', en: 'Egungun Festival', e: '🎭', b: 7 },
    { yo: 'Ọdún Ọ̀ṣun-Òṣogbo', en: 'Osun-Osogbo Festival', e: '💧', b: 7 }
  ];
  function festival(zi) {                                                          // drums, confetti and a few bonus cowries when the rider rides through a town gate into a new region
    const h = OYO.hud, F = FEST[zi] || FEST[0];
    h.festT = F.yo; h.festS = F.en; h.festE = F.e; h.festB = F.b; h.festOn = false;
    setTimeout(() => { if (E.on) { h.festOn = true; R_.festT = 4; } }, 30);
    R_.cow += F.b; h.cow = R_.cow; h.cowPop = true; setTimeout(() => { h.cowPop = false; }, 260);
    snd('festival');
  }
  function updateZones(dt, st) {
    const h = OYO.hud, zi = zoneIdAt(st.z);
    if (R_.zoneArmed > 0) R_.zoneArmed -= dt;
    if (zi !== R_.zone && R_.zoneArmed <= 0) {
      const first = R_.zone === -1; if (!first) festival(zi); R_.zone = zi; const Z = ZN[zi]; h.zoneT = Z.yo; h.zoneS = first ? AREAS[startTown][0] + ' · ' + Z.en : Z.en; h.locName = first ? AREAS[startTown][0] : Z.en; h.zoneN++; h.zoneOn = true; R_.zoneT = 3.6;
    }
    if (R_.zoneT > 0) { R_.zoneT -= dt; if (R_.zoneT <= 0) h.zoneOn = false; }
    if (R_.festT > 0) { R_.festT -= dt; if (R_.festT <= 0) h.festOn = false; }
    if ((frame & 7) === 0) { zoneW(st.z + 25); const f = FOG * zp('fog'); if (Math.abs(f - (R_.fogNow || FOG)) > FOG * .01) { R_.fogNow = R_.fogNow ? R_.fogNow + (f - R_.fogNow) * .35 : f; setFog(R_.fogNow); } }
  }
  function post(dt, st) {
    if (E.over) return;
    if (E.crash) { crashTick(dt, st); return; }
    const h = OYO.hud; frame++;
    if ((frame & 15) === 0) { try { if (RD.shadow && RD.shadow.isEnabled(false)) RD.shadow.setEnabled(false); } catch (err) { /* ok */ } }
    if (TOD.on) { TOD.t += dt; if ((frame & 7) === 0) { try { todApply(todSample(TOD.u0 + TOD.t / TOD.cyc)); } catch (e) { TOD.on = false; console.warn('Time of day off', e); } } }
    // --- keep the horse on the strip: soft wall beyond the hedge line, no U-turns, no riding back off the generated road ---
    const ry = yawAt(st.z), lat = latOf(st.x, st.z);
    const WL = lat > 0 ? WALL : HW + 1.3;                       // the left wall keeps the player out of the oncoming carriageway
    if (Math.abs(lat) > WL) { const c = cx(st.z), sg = lat > 0 ? 1 : -1; st.x = c + sg * WL * Math.sqrt(1 + slope(st.z) * slope(st.z)); st.speed *= 1 - Math.min(.5, dt * 2.5); }
    const rel = angDiff(ry, st.yaw); if (Math.abs(rel) > 1.2) { st.yaw = ry + Math.sign(rel) * 1.2; st.turn = 0; }
    const zMin = (curK - BEHIND) * CL + 8; if (st.z < zMin) { st.z = zMin; if (st.speed < 0) st.speed = 0; }
    st.y = Math.max(st.y, hgt(st.x, st.z));
    // --- stops: brake inside the faded blue mark. Pick-up: waiting villagers walk to the cart and board. Drop-off: everyone aboard gets off and pays the fare of that area ---
    const V = VIL(), cart = S.cart && S.cart.state && S.cart.state.hitched ? S.cart.state : st;
    for (const ch of A.chunks) {
      if (ch.idx === -999 || !ch.stops.length) continue;
      for (const sp of ch.stops) {
        if (sp.state === 2) continue;
        if (sp.kind === 'drop' && !sp.ann && sp.z > st.z && sp.z - st.z < 220) { const nOff = R_.pl.filter(q => q.k <= sp.k).length; if (nOff) { sp.ann = true; toast('Drop-off ahead: ' + sp.area[0] + ' · ' + sp.area[1] + ' cowries each (' + nOff + ' getting off) — brake in the blue box'); } }
        if (Math.abs(ch.z0 + CL / 2 - st.z) > CL + 10) continue;
        if (sp.state === 1) {                                              // pick-up in progress
          sp.t += dt / 2.2; let near = 0;
          sp.vo.forEach(q => { const p = ch.pp[q]; if (p && V) { if (V.walkTo(p, cart.x, cart.z, 2.6, dt) < 1.6) near++; } else near++; });
          if (sp.t >= 1 || near === sp.vo.length) {
            sp.state = 2; let boarders = sp.vo.map(q => { const p = ch.pp[q]; ch.pp[q] = null; return p; });
            if (V) boarders = boarders.filter(p => p);                    // never board a passenger who no longer exists
            if (!boarders.length) continue;
            const dests = []; boarders.forEach(p => {
              const r = Math.random(), kd = p._kd != null ? p._kd : planDests(sp, 1)[0], q = { k: kd, area: areaFor(kd), p, seat: -1 };
              const taken = R_.pl.map(z => z.seat); let si = 0; while (taken.indexOf(si) >= 0) si++; q.seat = si;
              try { if (p && S.cart && S.cart.seatPerson) { p.w = p.rl = null; p.rs = false; S.cart.seatPerson(p, si); } else if (p && V) { V.release(p); q.p = null; } } catch (err) { console.warn('Boarding', err); }
              p && (p._kd = null); R_.pl.push(q); dests.push(q.area[0]);       // this exact villager now rides in seat si until their own stop
            });   // every passenger has their own destination: the next, or one of the next two, drop-off stops
            R_.pax = R_.pl.length; h.ePax = R_.pax + '/' + PAXMAX; snd('cowrie', 2);
            toast((boarders.length > 1 ? 'Passengers aboard' : 'Passenger aboard') + ' for ' + dests.filter((v, i) => dests.indexOf(v) === i).join(' & ') + ' — drop them at their stops');
          }
          continue;
        }
        const inMark = Math.abs(cart.z - sp.z) < 3.1 && Math.abs(latOf(cart.x, cart.z) - sp.side * LW) < 1.4;   // the cart (not the horse) decides
        if (inMark && Math.abs(st.speed) < 1.8) {
          sp.dwell += dt;
          if (sp.dwell > .3) {
            if (sp.kind === 'drop') {
              const off = R_.pl.filter(q => q.k <= sp.k); if (!off.length) continue;       // only the passengers headed here (or whose stop was missed) get off
              const n = off.length, late = off.filter(q => q.k < sp.k).length; let fare = 0; off.forEach(q => { fare += q.k === sp.k ? q.area[1] : Math.ceil(q.area[1] / 2); });   // a missed stop pays half
              if (R_.dbl > 0) fare *= 2; R_.fare = (R_.fare || 0) + fare; R_.cow += fare; h.cow = R_.cow; h.cowPop = true; setTimeout(() => { h.cowPop = false; }, 170); snd('cowrie', 4);
              bankDeliveries(n);
              R_.pl = R_.pl.filter(q => q.k > sp.k); R_.pax = R_.pl.length; h.ePax = R_.pax + '/' + PAXMAX; sp.state = 2;
              off.forEach((q, i) => {                                                   // exactly the passengers who rode get down and walk away
                const p = q.p; if (!p) return; try { S.cart.unseatPerson(p); } catch (err) { /* ok */ }
                const a = pt(sp.z + (i - (n - 1) / 2) * 1.1, sp.side * LW + 1.2), b = pt(sp.z + (i - (n - 1) / 2) * 1.6 + 2, sp.side * 7.6);
                p.x = a[0]; p.z = a[1]; p.y = hgt(a[0], a[1]); p.yaw = Math.atan2(1, slope(sp.z)); p.hide = false; walkers.push({ p, x: b[0], z: b[1], t: 0 });
              });
              toast('Dropped ' + n + ' at ' + sp.area[0] + ' · +' + fare + ' cowries' + (late ? ' (' + late + ' late: half fare)' : ''));
            } else {
              if (V) sp.vo = sp.vo.filter(q => ch.pp[q]);                    // keep only villagers who are really still waiting here
              if (!sp.vo.length) { sp.state = 2; continue; }                  // nobody waiting at this blue spot: no boarding, no toast
              if (R_.pax + sp.vo.length > PAXMAX) { if (sp.dwell < .5) toast('The cart is full!'); sp.dwell = 1; continue; }
              sp.state = 1; sp.t = 0; const dk = planDests(sp, sp.vo.length); let di = 0;
              sp.vo.forEach((q, i) => {                                         // each waiting passenger picks a destination now and calls it out as they climb in
                const p = ch.pp[q]; if (!p) return; p.st = 0;
                p._kd = dk[di++]; const nm = areaFor(p._kd)[0], L = ['Ẹ jọ̀wọ́, ' + nm + '!', 'Mo ń lọ sí ' + nm + '.', 'Ẹ gbé mi lọ sí ' + nm + ', Rider.', 'Ọ̀nà ' + nm + ', ẹ jọ̀wọ́.', 'I am going to ' + nm + ', Rider.'];
                try { const VV = window.OYOVillagers; if (VV && VV.say) setTimeout(() => { if (E.on && !E.over && p._kd) VV.say(p, L[Math.floor(Math.random() * L.length)], 2.6, 'Passenger'); }, i * 450); } catch (err) { /* ok */ }
              });
            }
          }
        } else sp.dwell = Math.max(0, sp.dwell - dt * 2);
      }
    }
    const v = Math.abs(st.speed);
    // --- distance + difficulty ---
    if (st.z - startZ > R_.dist) R_.dist = st.z - startZ;
    const lv = lvlOf(R_.dist); if (lv > R_.lvl) R_.lvl = lv;
    const sg = stageOf(R_.dist); if (sg > R_.stage) { R_.stage = sg; h.eStage = STAGES[sg - 1][0]; h.eStageN = sg; }
    // --- streaming ---
    if (Math.floor(st.z / CL) !== curK || A.chunks.some(c => c.idx === -999) || frame % 30 === 0) stream(st.z, false);
    try { updateZones(dt, st); } catch (e) { if (!A.zErr) { A.zErr = 1; console.warn('Endless regions', e); } }
    // --- obstacle hits cost a life ---
    try { updateLivestock(dt, st); } catch (e) { if (!A.livErr) { A.livErr = 1; console.warn('Endless livestock', e); } }
    R_.invul = Math.max(0, R_.invul - dt); R_.potCd = Math.max(0, R_.potCd - dt);
    if (R_.startWorn && cartCountdown(dt)) return;                                  // a worn cart that was not repaired: warning, then collapse
    if (R_.npcFatal) { R_.npcFatal = 0; startCrash('You hit the royal rider three times.'); return; }      // third hit on the royal rider (own count)
    if (st.bump) {
      const kind = st.bump; st.bump = 0; ghost = Math.max(ghost, 1.15); RD.cam.kick = kind === 2 ? .8 : 1;
      if (kind === 3 && S.cart) { S.cart.jolt = 1; S.cart.joltT0 = performance.now(); if (R_.lives > 1 || R_.invul > 0) scaredTalk(); }      // pothole: the cart jolts and bounces, passengers cry out
      if (kind === 3) potholeHit();                                                  // potholes wear the cart instead of costing a life
      if (R_.invul <= 0 && kind !== 3) {
        try { if (S.cart && S.cart.hit) S.cart.hit(); } catch (err) { /* ok */ }        // visual only: the cart flashes red and shudders (no banner)
        R_.lives--; R_.invul = INVUL; h.eHearts = hearts(R_.lives); h.eHits = hitsOf(R_.lives); snd('impact', R_.animalHit ? 4 : kind); R_.animalHit = false; if (kind === 2) snd('neigh', .55);
        if (R_.lives <= 0) { startCrash(); return; }                                // third collision: the crash plays out, then the game-over page
        // collisions 1 and 2 are silent (no banner, toast or message): only the thud and camera shake; the third ends the run above
      }
    }
    try { updateCows(dt, st); } catch (e) { wOnce('cow', e); }
    try { updatePickups(dt, st); } catch (e) { wOnce('pick', e); }
    try { updateRude(dt, st); } catch (e) { wOnce('rude', e); }
    E.hotH = false;
    try { separateNpcs(dt, st); } catch (e) { wOnce('npcsep', e); }
    for (const Y of NPCS) {
      try { updateRoyalNpc(Y, dt, st); } catch (err) {
        console.warn('Endless NPC rider', err); Y.failed = true; try { hideRoyalNpc(Y); } catch (e2) { /* ok */ }
        if (!E.riderNoted) { E.riderNoted = true; try { window.OYOBoot && OYOBoot.note && OYOBoot.note('A road rider could not appear. Your ride goes on.'); } catch (e3) { /* ok */ } }       // subtle message, once
      }
    }
    try { npcResolve(dt, st); } catch (e) { wOnce('npcres', e); }                  // final solid check: the cart can never end a frame inside a road rider
    try { updatePeople(dt, st); } catch (e) { wOnce('ppl', e); }
    // --- HUD (throttled) ---
    if ((frame & 3) === 0) {
      h.stam = 100; h.exh = false; h.eDist = fmtD(R_.dist); h.eLvl = R_.lvl; h.eMag = Math.ceil(R_.mag); h.eBoost = Math.ceil(R_.boost); h.eDbl = Math.ceil(R_.dbl); h.ePhase = Math.ceil(R_.phase); h.ePMag = Math.round(100 * R_.mag / DURS.mag); h.ePBoost = Math.round(100 * R_.boost / DURS.boost); h.ePDbl = Math.round(100 * R_.dbl / DURS.dbl); h.ePPhase = Math.round(100 * R_.phase / DURS.phase);
      if (R_.dist > save.best) h.eBest = fmtD(R_.dist);
      try { updateTarget(st); } catch (e) { /* HUD only */ }
    }
    if (R_.toastT > 0) { R_.toastT -= dt; if (R_.toastT <= 0) h.toast = ''; }
    if (R_.warnT > 0) { R_.warnT -= dt; if (R_.warnT <= 0) h.eWarn = ''; }
  }


  /* Stage 30: read-only signals for the music director (yoruba-music.js). Nothing here changes gameplay. */
  const TREE_VI = ['acacia1', 'acacia2', 'palm1', 'palm2', 'baobab', 'tropical1', 'tropical2'];
  E.zoneInfo = function () {                      // → { royal, market, village, forest } each 0..1, from the scenery of the chunks around the rider
    const z = { royal: 0, market: 0, village: 0, forest: 0 }; if (!E.on || !A.chunks) return z; let wt = 0;
    A.chunks.forEach(ch => {
      if (ch.idx === -999) return; const d = Math.abs(ch.idx - curK); if (d > 2) return; const w = d === 0 ? 1 : d === 1 ? .6 : .25; wt += w;
      if (ch.om[DI.palace] && ch.om[DI.palace].n) z.royal += w * 1.4;
      if (ch.om[DI.market] && ch.om[DI.market].n) z.market += w * 1.1;
      z.village += w * Math.min(1, ch.houses.length / 2.5);
      let tr = 0; TREE_VI.forEach(n => { const c = ch.vm[VI[n]]; if (c) tr += c.n; }); z.forest += w * Math.min(1, tr / 8);
    });
    if (wt > 0) for (const k in z) z[k] = Math.min(1, z[k] / wt);
    try { zoneW(RD.state.z); const a = ZN[ZW.a].mu, b = ZN[ZW.b].mu; z[a] = Math.max(z[a], .75 * (1 - ZW.t)); z[b] = Math.max(z[b], .75 * ZW.t); } catch (e) { /* music link is optional */ }      // Stage 40: the region sets the atmosphere too
    return z;
  };
  E.threat = function () {                        // 0..1 music tension: only lives already lost (no warning about obstacles / livestock ahead any more)
    if (!E.on || E.over || !RD || !RD.state) return 0;
    return Math.min(1, (LIVES - R_.lives) * .12);
  };

  function bankDeliveries(n) {                                  // every passenger delivered counts for this run and, permanently, towards the Royal Cart
    R_.deliv += n; save.deliv += n;
    if (!save.royal && save.deliv >= CART_GOAL) { save.royal = true; R_.unlockedNow = true; snd('leg'); toast('👑 ROYAL CART UNLOCKED! 30 passengers delivered — pick it in the Carts menu.'); }
    store(); cartUi();
  }

  /* ---------- Stage 38: Run missions (our own set). Three are active at a time and saved; per-run ones keep the best run, the others add up across runs.
     Finishing a mission pays cowries into the total at the end of the run; finished missions are swapped for fresh ones when the next run starts. ---------- */
  const SPONSOR = 'Wealth Art & Decor';
  const MPOOL = [
    { id: 'pax_run', run: true, text: n => 'Carry ' + n + ' passengers in one run', g: [4, 6, 8, 10], val: () => R_.deliv },
    { id: 'pax_tot', run: false, text: n => 'Drop ' + n + ' passengers at their stop', g: [12, 18, 24, 32], val: () => R_.deliv },
    { id: 'cow_run', run: true, text: n => 'Gather ' + n + ' cowries in one run', g: [100, 180, 280, 400], val: () => R_.cow },
    { id: 'dist_run', run: true, text: n => 'Ride ' + (n / 1000).toFixed(1) + ' km in one run', g: [1000, 1800, 2600, 3600], val: () => R_.dist },
    { id: 'pups_tot', run: false, text: n => 'Grab ' + n + ' power-ups', g: [3, 5, 8, 11], val: () => R_.pups },
    { id: 'stage_run', run: true, text: n => 'Reach stage ' + n, g: [2, 3, 4, 5], val: () => R_.stage },
    { id: 'fare_tot', run: false, text: n => 'Earn ' + n + ' cowries in fares', g: [120, 220, 340, 480], val: () => R_.fare }
  ];
  const MREW = [30, 45, 65, 90];
  const mDef = id => MPOOL.find(m => m.id === id);
  function ensureMissions() {
    save.missions = save.missions.filter(m => m && mDef(m.id) && !m.done && isFinite(m.goal) && isFinite(m.prog));
    const tier = save.best < 1500 ? 0 : save.best < 3200 ? 1 : save.best < 5500 ? 2 : 3;
    while (save.missions.length < 3) {
      const free = MPOOL.filter(m => !save.missions.some(q => q.id === m.id)), d = free[Math.floor(Math.random() * free.length)];
      const t = Math.min(3, tier + (Math.random() < .3 ? 1 : 0));
      save.missions.push({ id: d.id, goal: d.g[t], reward: MREW[t], prog: 0, done: false });
    }
    store();
  }
  function scoreRun() { return Math.round(R_.dist + R_.cow * 5 + R_.deliv * 50); }
  function settleMissions() {                                    // run just ended: advance every mission, pay the finished ones
    let paid = 0;
    save.missions.forEach(m => {
      const d = mDef(m.id); m.fresh = false; if (!d || m.done) return;
      const v = Math.max(0, d.val() || 0); m.prog = d.run ? Math.max(m.prog, v) : m.prog + v;
      if (m.prog >= m.goal) { m.prog = m.goal; m.done = true; m.fresh = true; paid += m.reward; }
    });
    save.cow += paid; return paid;
  }
  const RANKS = [[0, 'Village Carrier'], [1500, 'Market Carrier'], [4000, 'Road Warden'], [8000, "Aláàfin's Courier"], [15000, 'Jagun of the Road']];
  const TIPS = ['Brake inside the blue mark to pick up and drop off passengers.', 'A missed stop pays only half the fare — watch for the drop-off ahead.', 'Hold GALLOP for speed. Tap BELL to ring your cart bell.', 'Cowries fly to you while the magnet is active.', 'Jump low obstacles; the tall ones you must steer around.'];
  /* ---------- share: score card image (canvas) → system share sheet, or per-app links with the image saved ---------- */
  const WA_CHANNEL = 'https://whatsapp.com/channel/0029VbDmCZY6GcG6jou4oY2p';   // ← paste your WhatsApp Channel link here
  E.waDm = /REPLACE_WITH/.test(WA_CHANNEL) ? '' : WA_CHANNEL;                       // not filled in yet → the "Updates" button stays hidden instead of opening a dead link
  const SHARE_URL = () => { try { return location.origin + location.pathname; } catch (e) { return ''; } };      // never share the address bar: it can hold a player's private ?cart=…&k=… link
  const PLAT = { telegram: ['Telegram', t => 'https://t.me/share/url?url=' + encodeURIComponent(SHARE_URL()) + '&text=' + encodeURIComponent(t)], whatsapp: ['WhatsApp', t => 'https://wa.me/?text=' + encodeURIComponent(t + ' ' + SHARE_URL())],
    facebook: ['Facebook', t => 'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(SHARE_URL())], x: ['X', t => 'https://twitter.com/intent/tweet?text=' + encodeURIComponent(t) + '&url=' + encodeURIComponent(SHARE_URL())],
    instagram: ['Instagram', () => 'https://www.instagram.com/'], snapchat: ['Snapchat', () => 'https://www.snapchat.com/'] };
  const loadImg = src => new Promise(res => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = src; });
  function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  async function makeCard(r) {
    try { await Promise.all([document.fonts.load('900 80px "Fraunces"'), document.fonts.load('700 30px "Fraunces"')]); } catch (e) { /* font optional */ }
    /* Flat card that mirrors the game-over screen. LAYOUT RULES (so nothing can ever overlap or be covered):
       1. The card is a vertical stack of sections. Each section has a fixed height and sits in its own slot; the gaps between slots are computed, not guessed.
       2. Inside a slot every piece of text has its own box. Text is shrunk to fit its box and, if it is still too wide, cut with "…" — it can never run into a neighbour.
       3. Where two texts share a row (left / right), the left one is given only the space the right one leaves free. */
    const logo = await loadImg('assets/art/sponsor-logo.jpg'), F = '"Fraunces", "Nunito", system-ui, sans-serif', W = 1080, H = 1350, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const BG = '#14110E', SURF = '#1F1A15', LINE = 'rgba(247,241,227,.14)', ACC = '#F0B44C', ACC2 = '#F6C876', IV = '#F7F1E3', IV2 = '#E9E0CB', LEAF = '#2F8F6B', LEAF2 = '#3AA67D', INK = '#3A1E0C';
    const c = cv.getContext('2d'), S = v => String(v == null ? '' : v), font = (sz, wt) => (wt || 800) + ' ' + sz + 'px ' + F;
    const meas = (t, sz, wt) => { c.font = font(sz, wt); return c.measureText(t).width; };
    const fitS = (t, max, sz, wt, min) => { t = S(t); min = min || 18; while (sz > min && meas(t, sz, wt) > max) sz -= 2; if (meas(t, sz, wt) > max) { while (t.length > 1 && meas(t + '…', sz, wt) > max) t = t.slice(0, -1); t = t.replace(/\s+$/, '') + '…'; } return [t, sz]; };
    const tx = (t, x, y, sz, col, al, wt, max, min) => { t = S(t); if (max) { const f = fitS(t, max, sz, wt, min); t = f[0]; sz = f[1]; } c.font = font(sz, wt); c.textAlign = al || 'center'; c.textBaseline = 'alphabetic'; c.fillStyle = col; c.fillText(t, x, y); return c.measureText(t).width; };
    const card = (x, y, w, h, rad, fill, line) => { c.fillStyle = fill; rr(c, x, y, w, h, rad); c.fill(); if (line) { c.strokeStyle = line; c.lineWidth = 2; rr(c, x + 1, y + 1, w - 2, h - 2, rad); c.stroke(); } };
    c.fillStyle = BG; c.fillRect(0, 0, W, H);
    const PX = 70, CW = W - PX * 2, CX = W / 2, ms = (r.missions || []).slice(0, 3);
    // ---- slots (top to bottom): [height, draw(y)] ----
    const mh = 76 + ms.length * 62;
    const slots = [
      [52, y => tx('EMPIRE DASH', CX, y + 40, 40, ACC2, 'center', 900, CW)],
      [84, y => {                                                                    // halted-on plaque (left) + cowry total (right), side by side with a gap
        const pw = CW - 250 - 24; card(PX, y, pw, 84, 16, LEAF);
        tx('HALTED ON', PX + 24, y + 31, 20, ACC2, 'left', 800, pw - 48);
        tx(r.road, PX + 24, y + 68, 34, IV, 'left', 800, pw - 48, 20);
        const x2 = W - PX - 250; card(x2, y, 250, 84, 42, SURF, LINE);
        tx('COWRIES', x2 + 125, y + 31, 17, IV2, 'center', 700, 190); tx(r.cowTotal, x2 + 125, y + 68, 38, IV, 'center', 800, 190, 20);
      }],
      [110, y => tx(S(r.head).toUpperCase(), CX, y + 96, 100, ACC2, 'center', 900, CW, 30)],
      [230, y => {                                                                   // score card
        card(CX - 330, y, 660, 230, 28, SURF, LINE);
        tx(r.scoreTxt, CX, y + 144, 170, IV, 'center', 900, 600, 40);
        tx((r.isBestScore ? 'NEW BEST · ' : '') + 'BEST ' + S(r.bestScoreTxt), CX, y + 210, 30, IV2, 'center', 700, 620);
      }],
      [180, y => {                                                                   // journey scroll: header row, rule, four stat columns
        card(PX, y, CW, 180, 24, IV);
        const L = PX + 30, Rr = PX + CW - 30, hy = y + 50;
        const wl = tx('Ìwé Ìrìn', L, hy, 34, '#A3341F', 'left', 800), wr = tx('No. ' + S(r.scrollNo), Rr, hy, 28, INK, 'right', 800, 330, 18);
        const wc = meas('Royal Road Scroll', 26, 700);
        if (CX - wc / 2 - (L + wl) >= 24 && (Rr - wr) - (CX + wc / 2) >= 24) tx('Royal Road Scroll', CX, hy, 26, '#5A3416', 'center', 700);   // centre title only when it has clear room
        c.fillStyle = 'rgba(58,30,12,.18)'; c.fillRect(PX + 24, y + 68, CW - 48, 2);
        const st = [[r.cow, 'COWRIES'], [r.km, 'DISTANCE'], [r.pax, 'PASSENGERS'], [r.stageN, S(r.stage).toUpperCase()]], cw = CW / 4;
        st.forEach((q, i) => { const cx = PX + cw * i + cw / 2;
          if (i) { c.fillStyle = 'rgba(58,30,12,.14)'; c.fillRect(PX + cw * i, y + 86, 2, 74); }
          tx(q[0], cx, y + 124, 54, INK, 'center', 800, cw - 28, 22); tx(q[1], cx, y + 156, 20, '#6B4120', 'center', 800, cw - 28, 13); });
      }]
    ];
    if (ms.length) slots.push([mh, y => {                                            // missions: text and its progress figure never share space
      card(PX, y, CW, mh, 24, SURF, LINE);
      const dn = (r.mDone || 0) + '/' + (r.mTotal || ms.length) + ' done', wd = tx(dn, PX + CW - 30, y + 46, 24, IV2, 'right', 700, 300);
      tx('MISSIONS', PX + 30, y + 46, 28, ACC2, 'left', 900, CW - 60 - wd - 24);
      ms.forEach((m, i) => { const ry = y + 76 + i * 62, rt = m.done ? 'Done' : (S(m.prog) + '/' + S(m.goal)), col = m.done ? '#7EE0B4' : IV;
        const wp = tx(rt, PX + CW - 30, ry + 22, 24, m.done ? '#7EE0B4' : IV2, 'right', 800, 220);
        tx(m.text, PX + 30, ry + 22, 26, col, 'left', 800, CW - 60 - wp - 28, 18);
        c.fillStyle = 'rgba(247,241,227,.12)'; rr(c, PX + 30, ry + 34, CW - 60, 10, 5); c.fill();
        const pw = Math.max(10, (CW - 60) * Math.min(100, Math.max(0, m.pct || 0)) / 100); c.fillStyle = m.done ? LEAF2 : ACC; rr(c, PX + 30, ry + 34, pw, 10, 5); c.fill(); });
    }]);
    slots.push([120, y => {                                                          // sponsor: logo plate on the left, text in the space that remains
      card(PX, y, CW, 120, 24, SURF, LINE);
      let x0 = PX + 28;
      if (logo) { const lh = 74, lw = Math.min(150, lh * logo.width / logo.height); c.fillStyle = '#FAF8F3'; rr(c, PX + 16, y + 17, lw + 12, lh + 12, 14); c.fill(); c.drawImage(logo, PX + 22, y + 23, lw, lh); x0 = PX + 16 + lw + 12 + 28; }
      const av = PX + CW - 24 - x0;
      tx('THIS RUN · BROUGHT TO YOU BY', x0, y + 48, 20, ACC2, 'left', 800, av, 14); tx('Wealth Art & Decor', x0, y + 92, 40, IV, 'left', 800, av, 22);
    }]);
    slots.push([96, y => {
      tx('Play at ' + location.host + (location.pathname.length > 1 ? location.pathname.replace(/index\.html$/, '') : ''), CX, y + 28, 28, IV2, 'center', 700, CW, 16);
      tx('Can you beat ' + S(r.scoreTxt) + '?', CX, y + 78, 34, ACC2, 'center', 900, CW, 20);
    }]);
    // ---- place the slots: equal computed gaps, block centred if there is spare room ----
    const TOP = 44, BOT = 36, used = slots.reduce((a, s) => a + s[0], 0), n = slots.length - 1;
    const gap = Math.max(14, Math.min(34, (H - TOP - BOT - used) / n)), top = TOP + Math.max(0, (H - TOP - BOT - used - gap * n) / 2);
    let y = top; slots.forEach(s => { s[1](y); y += s[0] + gap; });
    return await new Promise(res => cv.toBlob(res, 'image/png'));
  }
  const shareText = r => 'I scored ' + r.scoreTxt + ' on Empire Dash — ' + r.km + ' down the Royal Road. Can you beat it?';
  E.share = async function () {
    const h = OYO.hud, r = h.eRes; if (!r || E._busy) return; E._busy = true; h.eShare = 'Preparing your score card…';
    try {
      if (!E._blob || E._blobFor !== r.scrollNo) { if (E._url) URL.revokeObjectURL(E._url); E._blob = await makeCard(r); E._blobFor = r.scrollNo; E._url = URL.createObjectURL(E._blob); }
      h.eShareImg = E._url; h.eShare = ''; OYO.mission.modal('share');
    } catch (err) { h.eShare = 'Could not make the image'; setTimeout(() => { h.eShare = ''; }, 2200); }
    E._busy = false;
  };
  function saveImg() { const a = document.createElement('a'); a.href = E._url; a.download = 'empire-dash-score-' + OYO.hud.eRes.scrollNo + '.png'; document.body.appendChild(a); a.click(); a.remove(); }
  E.saveImage = function () { if (E._url) { saveImg(); OYO.hud.eShare = 'Image saved'; setTimeout(() => { OYO.hud.eShare = ''; }, 2000); } };
  E.shareTo = async function (p) {
    const h = OYO.hud, r = h.eRes, def = PLAT[p]; if (!r || !E._blob || !def) return; const text = shareText(r);
    const file = new File([E._blob], 'empire-dash-score.png', { type: 'image/png' });
    try { if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], text: text + ' ' + SHARE_URL() }); h.modal = ''; return; } }
    catch (err) { if (err && err.name === 'AbortError') return; }                                   // cancelled → stay; any other failure → fallback below
    saveImg(); h.eShare = 'Image saved — attach it in ' + def[0]; setTimeout(() => { h.eShare = ''; }, 3500);
    window.open(def[1](text), '_blank', 'noopener');
  };

  const dayKey = t => { const x = new Date(t); return x.getFullYear() + '-' + (x.getMonth() + 1) + '-' + x.getDate(); };
  function bumpStreak(score, d) {                                // daily streak + personal top-5 (Leaders)
    const today = dayKey(NOW());
    if (save.lastDay !== today) { save.streak = save.lastDay === dayKey(NOW() - 864e5) ? save.streak + 1 : 1; save.lastDay = today; }
    save.top.push({ s: score, km: (d / 1000).toFixed(2), t: NOW() }); save.top.sort((a, b) => b.s - a.s); save.top.length = Math.min(5, save.top.length);
  }
  /* ---------- cart wear: potholes, warning + collapse, repair ---------- */
  const dmgPct = v => Math.min(100, v * DMG_STEP);
  function cartFields() { const h = OYO.hud, br = save.cartState === 'broken'; h.cState = save.cartState; h.cPctB = br ? 100 : dmgPct(save.dmgB); h.cPctW = br ? 100 : dmgPct(save.dmgW); h.cBal = save.cow | 0; }
  function addDmg(b, w) { save.dmgB = Math.min(DMG_MAX, save.dmgB + b); save.dmgW = Math.min(DMG_MAX, save.dmgW + w); if (save.cartState === 'ok') save.cartState = 'worn'; store(); }
  function potholeHit() {
    if (R_.potCd > 0) return; R_.potCd = .6;
    const wheel = Math.random() < .5; R_.pot++; if (wheel) R_.pW++; else R_.pB++;
    if (save.cartState !== 'ok') addDmg(wheel ? 0 : 1, wheel ? 1 : 0);                 // already worn: every pothole adds to the damage
    else if (R_.pot === CART_HITS) { addDmg(R_.pB, R_.pW); toast('🔧 Your cart is damaged — repair it before your next run!'); snd('thud', 3); }
    else if (R_.pot < CART_HITS) toast('Pothole! Cart damage ' + R_.pot + '/' + CART_HITS);
  }
  function cartCountdown(dt) {
    const h = OYO.hud;
    if (!R_.cWarned) { if (R_.dist < R_.warnAt) return false; R_.cWarned = true; R_.collT = COLLAPSE_SECS; snd('thud', 3); }
    R_.collT -= dt; R_.cJ -= dt;
    if (R_.cJ <= 0) { R_.cJ = 1.4; try { if (S.cart) { S.cart.jolt = 1; S.cart.joltT0 = performance.now(); } } catch (err) { /* ok */ } snd('thud', 3); }
    const sec = Math.max(0, Math.ceil(R_.collT));
    if (sec !== R_.cSec) { R_.cSec = sec; h.eCart = '⚠ Your cart is falling apart — it will collapse in ' + sec + 's!'; }
    if (R_.collT <= 0) { save.cartState = 'broken'; save.dmgB = Math.max(4, save.dmgB); save.dmgW = Math.max(4, save.dmgW); store(); startCrash('Your cart collapsed — it needs a full repair.'); return true; }
    return false;
  }
  /* ---------- crash sequence: the horse is pulled up hard, the cart tips onto its side with a bounce, the camera shakes, a CRASH! flash — then the game-over page ---------- */
  function startCrash(why) {
    if (E.crash || E.over) return;
    const h = OYO.hud, st = RD && RD.state;
    h.eWarn = ''; h.eCart = ''; h.toast = ''; h.crashFx = true;
    R_.boost = R_.dbl = R_.mag = R_.phase = 0; h.eMag = h.eBoost = h.eDbl = h.ePhase = h.ePMag = h.ePBoost = h.ePDbl = h.ePPhase = 0; hidePk();
    E.crash = { t: 0, why, side: st && latOf(st.x, st.z) >= 0 ? 1 : -1, s1: false, s2: false, s3: false };
    try { core.releaseInput(); } catch (err) { /* ok */ }
  }
  function crashTick(dt, st) {
    const C = E.crash, h = OYO.hud, DUR = 1.5, V = VIL(); C.t += dt; const t = C.t;
    st.bump = 0; st.speed *= Math.exp(-dt * (t < .35 ? 6 : 11)); if (Math.abs(st.speed) < .12) st.speed = 0;
    if (t < .8) RD.cam.kick = Math.max(RD.cam.kick || 0, .9 * (1 - t / .8));                        // camera shake, fading
    const cr = S.cart;
    if (cr) {
      const k = clamp((t - .06) / .6, 0, 1), ease = 1 - Math.pow(1 - k, 3), bnc = k >= 1 ? 0 : Math.sin(k * Math.PI * 3) * .09 * (1 - k);
      const roll = (ease * 1.22 + bnc) * C.side, hop = Math.abs(Math.sin(t * 12)) * .5 * Math.max(0, 1 - t / .5);
      cr.crashK = 1; cr.crashRoll = roll; cr.crashPitch = -ease * .2 + Math.sin(t * 14) * .05 * Math.max(0, 1 - t / .6); cr.crashY = Math.sin(Math.min(1.3, Math.abs(roll))) * .75 + hop;
    }
    if (!C.s1) { C.s1 = true; snd('impact', 5); }
    if (!C.s2 && t > .14) { C.s2 = true; snd('neigh', .6); }
    if (!C.s3 && t > .42) { C.s3 = true; snd('thud', 1); }
    // --- passengers are flung out of the cart, tumble, land, then stagger away dazed ---
    if (!C.fly && t > .08) {
      C.fly = []; const yw = st.yaw, fx = Math.sin(yw), fz = Math.cos(yw), rx = fz, rz = -fx;
      (R_.pl || []).forEach(q => {
        const p = q.p; if (!p) return; try { S.cart.unseatPerson(p); } catch (err) { /* ok */ }
        const sd = C.side * (.6 + Math.random() * .8), fw = 2 + Math.random() * 3;
        p.busy = Infinity; p.st = 6.25; p.hide = false; p.sc = p.sc || 1;
        C.fly.push({ p, vx: fx * fw + rx * sd * 3.2, vz: fz * fw + rz * sd * 3.2, vy: 3.6 + Math.random() * 3, landed: false, lt: 0, spin: (Math.random() < .5 ? -1 : 1) * (6 + Math.random() * 4), tx: 0, tz: 0 });
      });
      R_.pl = []; R_.pax = 0; h.ePax = '0/' + PAXMAX;
    }
    if (C.fly) C.fly.forEach(f => {
      const p = f.p;
      if (!f.landed) {
        f.vy -= 20 * dt; p.x += f.vx * dt; p.z += f.vz * dt; p.y += f.vy * dt; p.yaw += f.spin * dt;
        const g = hgt(p.x, p.z); if (p.y <= g && f.vy < 0) { p.y = g; f.landed = true; p.busy = 0; p.st = 0; const sd = C.side, b = pt(p.z + 1.5, latOf(p.x, p.z) + sd * 5); f.tx = b[0]; f.tz = b[1]; snd('thud', 1); }
      } else { f.lt += dt; if (V) { try { V.walkTo(p, f.tx, f.tz, 1.1, dt); } catch (err) { /* ok */ } } p.yaw += Math.sin(f.lt * 9) * .05; }     // dazed stagger
    });
    if (t >= DUR) { E.crash = null; h.crashFx = false; gameOver(C.why); }
  }
  function gameOver(why) {
    const h = OYO.hud; E.over = true; const d = Math.round(R_.dist), isBest = d > save.best;
    const score = scoreRun(), isBestScore = score > save.bestScore; if (isBestScore) save.bestScore = score;
    if (isBest) save.best = d; save.runs++; save.cow += R_.cow; const paid = settleMissions(); bumpStreak(score, d); store(); try { window.OYOTrack && window.OYOTrack.run(score, d, R_.deliv, R_.cow); } catch (e) { /* stats optional */ }
    scene_ = []; scLive = 0; h.eWarn = ''; h.eCart = ''; h.eMag = h.eBoost = h.eDbl = h.ePhase = h.ePMag = h.ePBoost = h.ePDbl = h.ePPhase = 0; hidePk(); cartUi();
    h.eRes = { dist: fmtD(d), pax: R_.deliv, lvl: R_.lvl, stage: STAGES[R_.stage - 1][0], cow: R_.cow, hits: hitsOf(R_.lives) + '/' + LIVES, best: fmtD(save.best), isBest, unlocked: R_.unlockedNow, royal: save.royal, reason: why || 'Three collisions — the cart can go no further.' };
    const rk = RANKS.filter(q => score >= q[0]).pop()[1], ar = areaFor(curK + 1)[0], ms = save.missions;
    Object.assign(h.eRes, {
      score, scoreTxt: score.toLocaleString('en-US'), bestScoreTxt: save.bestScore.toLocaleString('en-US'), isBestScore, km: (d / 1000).toFixed(2) + ' KM', rank: rk, road: ar + ' road',
      head: isBestScore ? 'ROYAL RIDE!' : score >= save.bestScore * .6 ? 'WELL RIDDEN!' : 'THE ROAD WINS!', cowTotal: Number(save.cow).toLocaleString('en-US'),
      stageN: R_.stage, fare: R_.fare || 0, pups: R_.pups || 0, scrollNo: String(score).padStart(6, '0'), paid, sponsor: SPONSOR, tip: 'Tomorrow: come back to keep your ' + save.streak + '-day streak',
      leaders: save.top.map((q, i) => ({ n: i + 1, s: q.s.toLocaleString('en-US'), km: q.km + ' KM', me: q.s === score && i === save.top.findIndex(z => z.s === score) })),
      missions: ms.map(m => ({ text: mDef(m.id).text(m.goal), prog: m.prog, goal: m.goal, pct: Math.round(100 * Math.min(1, m.prog / m.goal)), reward: m.reward, done: m.done })), mDone: ms.filter(m => m.done).length, mTotal: ms.length
    });
    h.eBest = fmtD(save.best); h.screen = 'eover'; MS.paused = true; core.releaseInput(); snd('fail');
  }

  /* ---------- wrap the shared mission hooks: active only while a run is on ---------- */
  const preO = MS.pre, postO = MS.post, titleO = MS.toTitle, pauseO = MS.togglePause;
  MS.pre = function (dt, inp, st) { if (E.on) return pre(dt, inp, st); return preO.apply(this, arguments); };
  MS.post = function (dt, st) { if (E.on) return post(dt, st); return postO.apply(this, arguments); };
  MS.toTitle = function () { cleanup(); return titleO.apply(this, arguments); };
  MS.togglePause = function () { if (E.on) return E.toggle(); return pauseO.apply(this, arguments); };

  /* ---------- public API (used by the menu / HUD buttons) ---------- */
  E.start = function (force) {
    if (save.cartState !== 'ok' && force !== true) { openRepair(); return; }          // damaged cart: the repair prompt comes first
    ensureMissions();
    core = OYO.core; if (!core.S || !core.S.riding || !core.S.riding.built) { return; }
    try { cleanup(); begin(); } catch (e) { console.error('Endless Run failed to start', e); cleanup(); try { MS.toTitle(); } catch (e2) { /* ignore */ } }
  };
  E.restart = function () { snd('click'); E.start(); };
  /* ---------- repair prompt: Not Now / Repair Now → Body 1000 · Wheels 750 · Full 2500 cowries ---------- */
  function openRepair() { const h = OYO.hud; cartFields(); h.repStage = 'ask'; h.repMsg = ''; h.modal = 'repair'; }
  E.repairNotNow = function () {
    const h = OYO.hud;
    if (save.cartState === 'broken') { h.repMsg = 'Your cart is completely broken — it cannot run until it is repaired.'; snd('fail'); return; }   // a collapsed cart cannot be ridden
    snd('click'); h.modal = ''; h.repMsg = ''; E.start(true);
  };
  E.repairNow = function () { snd('click'); const h = OYO.hud; cartFields(); h.repMsg = ''; h.repStage = 'shop'; };
  E.repairBack = function () { snd('click'); const h = OYO.hud; h.repMsg = ''; h.repStage = 'ask'; };
  E.repairLeave = function () { snd('click'); const h = OYO.hud; h.modal = ''; h.repMsg = ''; };
  E.repair = function (kind) {
    const h = OYO.hud, cost = REP[kind]; if (!cost) return;
    const need = kind === 'body' ? save.cartState === 'broken' || save.dmgB > 0 : kind === 'wheel' ? save.cartState === 'broken' || save.dmgW > 0 : save.cartState !== 'ok';
    if (!need) { h.repMsg = 'Nothing to repair there.'; return; }
    if (!E.spendCowries(cost)) { h.repMsg = 'Not enough cowries — you need ' + cost + ' 🐚 (you have ' + (save.cow | 0) + ').'; snd('fail'); return; }
    if (kind !== 'wheel') save.dmgB = 0; if (kind !== 'body') save.dmgW = 0;
    save.cartState = !save.dmgB && !save.dmgW ? 'ok' : 'worn'; store(); cartUi(); cartFields(); snd('cowrie', 4);
    const nm = kind === 'body' ? 'Body repaired' : kind === 'wheel' ? 'Wheels repaired' : 'Cart fully repaired';
    h.repMsg = '✅ ' + nm + ' · −' + cost + ' 🐚';
    if (save.cartState === 'ok') setTimeout(() => { if (h.modal === 'repair') { h.modal = ''; h.repMsg = ''; E.start(true); } }, 1100);
    else setTimeout(() => { if (h.modal === 'repair') h.repStage = 'ask'; }, 1100);
  };
  E.shift = function (d) { if (!E.on || E.over || E.crash || E.paused) return; const n = clamp(lane + d, -1, 1); if (n !== lane) { lane = n; snd('click'); } OYO.hud.hint = false; };
  let swipeBound = false;
  function bindSwipe() {                                      // horizontal swipe anywhere on the canvas = change lane
    if (swipeBound || !S.canvas) return; swipeBound = true; const cv = S.canvas, pts = new Map();
    cv.addEventListener('pointerdown', e => { pts.set(e.pointerId, { x: e.clientX, y: e.clientY }); });
    cv.addEventListener('pointermove', e => {
      const p = pts.get(e.pointerId); if (!p || !E.on) return; const dx = e.clientX - p.x, dy = e.clientY - p.y;
      if (Math.abs(dx) > SWIPE && Math.abs(dx) > Math.abs(dy) * 1.2) { E.shift(dx > 0 ? 1 : -1); p.x = e.clientX; p.y = e.clientY; }
    });
    const up = e => { pts.delete(e.pointerId); }; cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
  }
  function pauseRows() {                                          // this run's missions with LIVE progress (same rule as settleMissions, but nothing is saved)
    return (save.missions || []).map(m => { const d = mDef(m.id); let prog = m.prog; if (d && !m.done) { let v = 0; try { v = Math.max(0, d.val() || 0); } catch (err) { /* ok */ } prog = d.run ? Math.max(m.prog, v) : m.prog + v; }
      prog = Math.min(m.goal, prog); return { text: d ? d.text(m.goal) : '', prog: Math.floor(prog), goal: m.goal, pct: Math.round(100 * Math.min(1, prog / m.goal)), reward: m.reward, done: !!m.done || prog >= m.goal }; }).filter(m => m.text);
  }
  E.pause = function () { if (!E.on || E.over || E.crash || E.paused) return; E.paused = true; const h = OYO.hud; try { h.pMiss = pauseRows(); } catch (err) { h.pMiss = []; } h.screen = 'epause'; h.modal = ''; h.homeAsk = false; MS.paused = true; snd('suspend'); core.releaseInput(); };
  E.resume = function () { if (!E.on || E.over || !E.paused) return; E.paused = false; const h = OYO.hud; h.festOn = false; R_.festT = 0; h.screen = 'endless'; h.modal = ''; h.homeAsk = false; MS.paused = false; snd('resume'); };
  E.toggle = function () { if (E.over || E.crash) return; E.paused ? E.resume() : E.pause(); };
  E.quit = function () { snd('click'); cleanup(); core && core.releaseInput(); MS.toTitle(); OYO.hud.homeAsk = false; };
  E.askHome = function () { snd('click'); OYO.hud.homeAsk = true; };                 // pause menu Home: ask first
  E.stayHere = function () { snd('click'); OYO.hud.homeAsk = false; };               // No: back to the pause menu
  E.goHome = function () { OYO.hud.homeAsk = false; E.quit(); };                     // Yes: leave the run
  document.addEventListener('visibilitychange', () => { if (document.hidden && E.on && !E.over && !E.paused) E.pause(); });

  E._t = { zoneReset, zoneW, zoneIdAt, ZN, ZI, ZNAMES, ZMSG, pt, cx, hgt, latOf, lvlOf, speedMul, stageOf, STAGES, DIFF, vGal, laneFeasible, genChunk, A, rngOf, updateLivestock, state: () => ({ R: R_, chunks: A.chunks.map(c => c.idx), save }) };
})();
