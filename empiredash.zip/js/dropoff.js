/* EMPIRE DASH — dropoff.js  (Stage 12d: passenger drop-off)
   Roadside drop-off points along the Royal Road. Free Roam only. Bring the hitched cart (with passengers aboard) to a stop beside a
   marker: an indicator appears, slow down / hold S and the passengers climb out one by one (or tap the button / press G for all at once).
   The passenger count updates the moment each person leaves, and every delivered passenger pays DROP_FARE cowries with a floating coin animation.
   Cowries only raise the on-screen session total (same as roam-fare.js); nothing is saved. Uses cart.passengers / p.cr hooks as they are.
   Self-contained. To remove: delete this file, its <script> line in boot.js + sw.js, and the "dropoff.js" block in style.css. */
(function () {
  'use strict';
  const OYO = window.OYO, MS = OYO && OYO.mission, C = window.OYOCart; if (!MS || !C) return;
  const B = window.BABYLON, TAU = Math.PI * 2;
  const DROP_FARE = 12, REACH = 11, SLOW = 4.5, GAP = .55, SIDE = 4.4, SPACING = 62, FIRST = 42;
  const NAMES = ['Ẹ̀gbẹ́ Stop', 'Oja Stop', 'Baba Isalẹ̀ Stop', 'Ṣaki Junction', 'Palace Gate Stop', 'Odò Stop', 'Ọ̀tún Stop'];
  const snd = (f, a) => { try { window.OYOAudio && OYOAudio[f] && OYOAudio[f](a); } catch (e) { /* audio optional */ } };
  let cart = null, RD = null, World = null, scene = null, stops = [], leaving = [], timer = 0, active = null, onB = false;
  let el = null, elCount, elMax, elBanner, elBtn, lastCount = -1, lastKey = '', lastT = 0;

  /* capture the cart the game spawns (no change to cart.js / game.js) */
  ['spawnHitched', 'spawnParked'].forEach(k => { const f = C[k]; if (typeof f === 'function') C[k] = function () { const c = f.apply(this, arguments); if (c) cart = c; return c; }; });

  /* ---------- drop-off points ---------- */
  function build() {
    if (stops.length || !B || !scene || !World) return;
    const r = World.byId.royal; if (!r) return;
    const mat = (c, a) => { const m = new B.StandardMaterial('dropMat', scene); m.disableLighting = true; m.emissiveColor = new B.Color3(c[0], c[1], c[2]); m.diffuseColor = B.Color3.Black(); m.specularColor = B.Color3.Black(); m.alpha = a; m.fogEnabled = false; return m; };
    const wood = new B.StandardMaterial('dropWood', scene); wood.diffuseColor = new B.Color3(.36, .22, .12); wood.specularColor = B.Color3.Black();
    const mPad = mat([1, .8, .25], .55), mPadOn = mat([.4, 1, .55], .8), mSign = mat([1, .82, .3], 1), mBeam = mat([1, .8, .25], .22);
    let k = 0;
    for (let i = FIRST; i < r.n - 30; i += SPACING, k++) {
      const side = k % 2 ? -1 : 1, off = World.widthAt(r, i) * .5 + SIDE;
      const x = r.x[i] + r.nx[i] * off * side, z = r.z[i] + r.nz[i] * off * side, y = World.height(x, z);
      const pad = B.MeshBuilder.CreateCylinder('dropPad' + k, { diameter: 6.4, height: .06, tessellation: 40 }, scene);
      const ring = B.MeshBuilder.CreateTorus('dropRing' + k, { diameter: 6.4, thickness: .18, tessellation: 40 }, scene);
      const post = B.MeshBuilder.CreateCylinder('dropPost' + k, { diameter: .16, height: 2.6, tessellation: 8 }, scene);
      const sign = B.MeshBuilder.CreateBox('dropSign' + k, { width: 1.5, height: .62, depth: .1 }, scene);
      const beam = B.MeshBuilder.CreateCylinder('dropBeam' + k, { diameterTop: .3, diameterBottom: 1.4, height: 34, tessellation: 10 }, scene);
      pad.position.set(x, y + .05, z); ring.position.set(x, y + .12, z); pad.material = mPad; ring.material = mSign;
      post.position.set(x + r.nx[i] * side * -1.5, y + 1.3, z + r.nz[i] * side * -1.5); post.material = wood;
      sign.position.set(post.position.x, y + 2.55, post.position.z); sign.material = mSign;
      sign.rotation.y = Math.atan2(r.tx[i], r.tz[i]) + Math.PI / 2 * 0;
      beam.position.set(x, y + 17, z); beam.material = mBeam;
      [pad, ring, post, sign, beam].forEach(m => { m.isPickable = false; m.alphaIndex = 40; });
      stops.push({ x, z, y, name: NAMES[k % NAMES.length], pad, ring, post, sign, mPad, mPadOn, tx: r.tx[i], tz: r.tz[i], nx: r.nx[i] * side, nz: r.nz[i] * side });
    }
  }
  function nearest(s) {
    let best = null, bd = REACH * REACH;
    for (const d of stops) { const dx = d.x - s.x, dz = d.z - s.z, q = dx * dx + dz * dz; if (q < bd) { bd = q; best = d; } }
    return best;
  }

  /* ---------- passengers leave the cart ---------- */
  function walkHook(p) {        // climbed down: walk to the stop pad, then stand there
    const now = performance.now() / 1000, dt = Math.min(.1, now - (p._dt || now)); p._dt = now;
    const w = p._walk; if (!w) return;
    const dx = w.x - p.x, dz = w.z - p.z, d = Math.hypot(dx, dz);
    if (d > .25 && w.t > 0) {
      const v = 1.5; p.x += dx / d * v * dt; p.z += dz / d * v * dt; w.t -= dt;
      p.yaw += Math.atan2(Math.sin(Math.atan2(dx, dz) - p.yaw), Math.cos(Math.atan2(dx, dz) - p.yaw)) * .2;
      p.gp = (p.gp || 0) + TAU * 1.7 * dt; p.vm = 1.2; p.st = 7;
    } else { p.st = 0; w.hold = (w.hold || 0) + dt; if (w.hold > 6) release(p); }
    p.y = World.height(p.x, p.z);
  }
  walkHook.stand = true;
  function release(p) { if (p.cr === walkHook) { p.cr = null; p.busy = 0; p.w = null; p.rl = null; } p._walk = null; const i = leaving.indexOf(p); if (i >= 0) leaving.splice(i, 1); }
  function dropOne(d) {
    if (!cart || !cart.passengers.length) return false;
    const it = cart.passengers.pop(), p = it.p, s = cart.state, sn = Math.sin(s.yaw), cs = Math.cos(s.yaw);
    const sg = d.nx * cs - d.nz * sn > 0 ? 1 : -1;               // climb down on the stop's side of the cart (rear step)
    p.x = s.x - sn * 2.3 + cs * 1.2 * sg; p.z = s.z - cs * 2.3 - sn * 1.2 * sg; p.y = World.height(p.x, p.z);
    p.cartSeat = null; p.st = 0; p.busy = Infinity; p.nm = null;
    const a = Math.random() * TAU, rr = 1 + Math.random() * 1.8;
    p._walk = { x: d.x + Math.cos(a) * rr, z: d.z + Math.sin(a) * rr, t: 7 }; p._dt = performance.now() / 1000; p.cr = walkHook; leaving.push(p);
    const h = OYO.hud; h.score += DROP_FARE; h.cow = DROP_FARE; h.cowPop = true; setTimeout(() => { h.cowPop = false; }, 170);
    snd('cowrie', 2 + (leaving.length % 4)); coinFx(DROP_FARE);
    syncCount(true);
    return true;
  }

  /* ---------- HUD (plain DOM, appended to #hud; no changes to the Alpine markup) ---------- */
  function ui() {
    if (el) return; const hud = document.getElementById('hud'); if (!hud) return;
    el = document.createElement('div'); el.className = 'drop-box'; el.style.display = 'none';
    el.innerHTML = '<div class="drop-count hud-card">🧑‍🤝‍🧑 Passengers <b>0</b>/<span class="drop-max">6</span></div><div class="drop-banner hud-card" style="display:none"></div><button class="btn btn-success btn-sm drop-btn" style="display:none">Drop off passengers</button>';
    hud.appendChild(el); elCount = el.querySelector('.drop-count b'); elMax = el.querySelector('.drop-max'); elBanner = el.querySelector('.drop-banner'); elBtn = el.querySelector('.drop-btn');
    elBtn.addEventListener('click', () => { if (active) { while (dropOne(active)); } });
  }
  function syncCount(force) {
    const mx = cart && cart.anchors && cart.anchors.seats ? cart.anchors.seats.length : 6; if (elMax && elMax.textContent !== String(mx)) elMax.textContent = mx;      // starter cart seats 4, royal cart 6
    const n = cart ? cart.passengers.length : 0; if (!force && n === lastCount) return; lastCount = n;
    if (elCount) { elCount.textContent = n; elCount.parentNode.classList.remove('bump'); void elCount.offsetWidth; elCount.parentNode.classList.add('bump'); }
  }
  function coinFx(n) {          // little coins pop up and fade toward the score
    const hud = document.getElementById('hud'); if (!hud) return;
    const f = document.createElement('div'); f.className = 'drop-fx'; f.style.left = (46 + Math.random() * 8) + '%';
    f.innerHTML = '<span class="drop-plus">+' + n + ' 🐚</span><i class="cw"><svg class="cwr" aria-hidden="true"><use href="#cwr-sym"/></svg></i><i class="cw"><svg class="cwr" aria-hidden="true"><use href="#cwr-sym"/></svg></i><i class="cw"><svg class="cwr" aria-hidden="true"><use href="#cwr-sym"/></svg></i>';
    hud.appendChild(f); setTimeout(() => f.remove(), 1400);
  }

  /* ---------- per-frame ---------- */
  function tick() {
    const h = OYO.hud, s = cart && cart.state; if (!h || !RD || !s) return;
    const live = h.screen === 'free' && h.mode === 'ride' && RD.built && cart.hitched;
    ui(); if (!el) return;
    if (!live) { if (el.style.display !== 'none') el.style.display = 'none'; active = null; return; }
    build(); if (el.style.display === 'none') el.style.display = '';
    const dt = Math.min(.05, scene.getEngine().getDeltaTime() / 1000), t = performance.now() / 1000, rs = RD.state;
    syncCount(false);
    const n = cart.passengers.length, d = nearest(s); active = n ? d : null;
    stops.forEach(q => { const on = q === d && n > 0; if (q._on !== on) { q._on = on; q.pad.material = on ? q.mPadOn : q.mPad; } q.ring.scaling.setAll(1 + (on ? .06 * Math.sin(t * 6) : 0)); });
    const slow = Math.abs(rs.speed) < SLOW;
    let txt = '', btn = false;
    if (active) { txt = slow ? '📍 ' + active.name + ' — passengers getting off…' : '📍 ' + active.name + ' — hold S to slow down'; btn = true; }
    if (txt !== lastKey) { lastKey = txt; elBanner.textContent = txt; elBanner.style.display = txt ? '' : 'none'; }
    elBtn.style.display = btn ? '' : 'none';
    if (active && slow) { timer -= dt; if (timer <= 0) { dropOne(active); timer = GAP; } } else if (!active) timer = .25;
  }

  /* manual key: G drops everyone at a stop in range */
  window.addEventListener('keydown', (e) => { if (e.code === 'KeyG' && !e.repeat && active && OYO.hud.screen === 'free') while (dropOne(active)); });

  const prev = MS.init;
  MS.init = function (world, riding, scn) {
    const r = prev.apply(this, arguments); RD = riding; World = world; scene = scn;
    if (!onB) { onB = true; scene.onBeforeRenderObservable.add(tick); } return r;
  };
})();
