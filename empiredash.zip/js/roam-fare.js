/* EMPIRE DASH — roam-fare.js  (Free Roam "danfo" passenger service)
   Free Roam only. The horse runs like a Lagos danfo:
   - Villagers wait by the roadside, glowing gold, and HAIL you ("Rider! Weavers’ Village! 34 🐚").
   - Brake (hold S) beside one and they hop on automatically — conductor shouts "Wọlé, wọlé!". Up to 3 can ride at once.
   - Every passenger has their OWN stop, shown with a coloured beam + ring, and a compass arrow / live fare on the right.
   - Fares are fixed by the distance of the trip; arrive on time for +25% tip, run late and the fare melts toward half,
     take far too long and the passenger jumps off angry (no fare). Stop inside the ring (slow down) and they alight and pay.
   Fares only raise the on-screen cowrie total for the session; nothing is written to the save file.
   Self-contained. To remove: delete this file, its <script> line and .fare-box block in index.html, the .fare-box/.fare-chip rules
   in style.css, and the villagers.js hooks (search "roam-fare"). */
(function () {
  'use strict';
  const OYO = window.OYO, MS = OYO && OYO.mission; if (!MS) return;
  const B = window.BABYLON, PI = Math.PI;
  const SEATED = 1.5, REACH = 5, MAX_SPEED = 6, AUTO_SPEED = 4, RUMP = .62, SLOT = .5, SEAT_Y = 1.42, MAX_SEATS = 3, MAX_SEEK = 4;
  const SEEK_NEAR = 22, SEEK_FAR = 110, SEEK_DROP = 170, HAIL_R = 30, DWELL = .5, QUIT_X = 2.2;
  const COL = [[1, .78, .2], [.3, .9, .62], [1, .45, .72]], css = (c) => 'rgb(' + c.map(v => Math.round(v * 255)).join(',') + ')';
  Object.assign((window.OYOUI = window.OYOUI || { state: {} }).state, { fareBtn: '', fareMsg: '', fareList: [] });
  const snd = (f, a) => { try { window.OYOAudio && OYOAudio[f] && OYOAudio[f](a); } catch (e) { /* audio is optional */ } };
  const angD = (a, b) => Math.atan2(Math.sin(b - a), Math.cos(b - a));
  const fmt = (s) => { s = Math.max(0, Math.ceil(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  let RD = null, scene = null, msgT = 0, shown = '', listKey = '', listT = 0, seekT = 0, dwell = 0, warnT = 0, uid = 0, hinted = false, near = null;
  let riders = [], seekers = [], beams = [], marks = [];

  const H = () => OYO.hud;
  const say = (t) => { H().fareMsg = t; msgT = 3.4; };
  const talk = (p, text, secs) => { try { window.OYOVillagers && OYOVillagers.say && OYOVillagers.say(p, text, secs, 'Passenger'); } catch (e) { /* bubbles are optional */ } };
  const people = () => (window.OYOVillagers && OYOVillagers.people) || [];

  /* ---------- trips ---------- */
  function stops() { const D = (MS._t && MS._t.DEST && MS._t.DEST()) || {}; return Object.keys(D).map(k => ({ id: k, name: D[k].name, x: D[k].x, z: D[k].z, r: D[k].r })); }
  function pickStop(x, z) {
    const all = stops(); if (!all.length) return null;
    const ok = all.filter(d => { const L = Math.hypot(d.x - x, d.z - z) - d.r; return L > 120 && L < 650; });
    if (ok.length) return ok[(Math.random() * ok.length) | 0];
    return all.slice().sort((a, b) => Math.hypot(b.x - x, b.z - z) - Math.hypot(a.x - x, a.z - z))[0];
  }
  const baseFare = (d) => Math.max(8, Math.min(60, Math.round(d / 16)));
  function fareNow(p) {
    const f = p.fs, over = f.t - f.limit;
    return over <= 0 ? Math.round(f.base * 1.25) : Math.max(Math.round(f.base * .5), Math.round(f.base * (1 - .5 * over / f.limit)));
  }

  /* ---------- body hooks (villagers.js calls p.cr(p) each frame instead of the walking code) ---------- */
  function stand(p) {            // waiting at the roadside: hold still, face the rider as they approach
    const s = RD.state; p.y = RD.World.height(p.x, p.z); p.st = 0;
    const dx = s.x - p.x, dz = s.z - p.z; if (dx * dx + dz * dz < 45 * 45) p.yaw += angD(p.yaw, Math.atan2(dx, dz)) * .08;
  }
  stand.stand = true;            // lets villagers.js keep the ground shadow for standing people
  function seat(p) {             // pillion behind the rider, one seat further back for each extra passenger
    const s = RD.state, sn = Math.sin(s.yaw), cs = Math.cos(s.yaw); p.sl += (p.slT - p.sl) * .15;
    const back = RUMP + p.sl * SLOT;
    p.x = s.x - sn * back; p.z = s.z - cs * back; p.y = s.y + SEAT_Y - .92 * p.sc; p.yaw = s.yaw;
  }

  /* ---------- meshes: stop beams (one colour per seat) + gold markers over waiting passengers ---------- */
  function ensureMeshes() {
    if (beams.length || !B || !scene) return;
    const mat = (c, a) => { const m = new B.StandardMaterial('fareMat', scene); m.disableLighting = true; m.emissiveColor = new B.Color3(c[0], c[1], c[2]); m.diffuseColor = B.Color3.Black(); m.specularColor = B.Color3.Black(); m.alpha = a; m.fogEnabled = false; return m; };
    const prep = (m) => { m.isPickable = false; m.alphaIndex = 42; m.setEnabled(false); };
    for (let i = 0; i < MAX_SEATS; i++) {
      const beam = B.MeshBuilder.CreateCylinder('fareBeam' + i, { diameterTop: .5, diameterBottom: 2.6, height: 64, tessellation: 12 }, scene);
      const ring = B.MeshBuilder.CreateTorus('fareStopRing' + i, { diameter: 2, thickness: .05, tessellation: 48 }, scene);
      beam.material = mat(COL[i], .32); ring.material = mat(COL[i], .7); prep(beam); prep(ring); beams.push({ beam, ring, owner: null });
    }
    const gold = mat([1, .8, .25], .95), goldRing = mat([1, .8, .25], .55);
    for (let i = 0; i < MAX_SEEK; i++) {
      const orb = B.MeshBuilder.CreateSphere('fareOrb' + i, { diameter: .5, segments: 8 }, scene), ring = B.MeshBuilder.CreateTorus('fareHail' + i, { diameter: 2, thickness: .06, tessellation: 32 }, scene);
      orb.material = gold; ring.material = goldRing; prep(orb); prep(ring); marks.push({ orb, ring });
    }
  }
  function showBeam(p, on) {
    const slot = on ? beams.find(b => !b.owner) : beams.find(b => b.owner === p); if (!slot) return;
    if (!on) { slot.owner = null; slot.beam.setEnabled(false); slot.ring.setEnabled(false); return; }
    const d = p.fs.dest, y = RD.World.height(d.x, d.z); slot.owner = p; p.fs.ci = beams.indexOf(slot);
    slot.beam.position.set(d.x, y + 30, d.z); slot.ring.position.set(d.x, y + .6, d.z); slot.ring.scaling.set(d.r, d.r, d.r);
    slot.beam.setEnabled(true); slot.ring.setEnabled(true);
  }

  /* ---------- roadside passengers ---------- */
  function makeSeeker(p) {
    const d = pickStop(p.x, p.z); if (!d) return false;
    const dist = Math.hypot(d.x - p.x, d.z - p.z);
    p.fs = { id: ++uid, dest: d, base: baseFare(dist), limit: dist / 7 + 35, t: 0, x0: p.x, z0: p.z, st0: p.st, hailed: false, ci: 0 };
    p.cr = stand; p.busy = Infinity; p.nm = 'Passenger'; seekers.push(p); return true;
  }
  function dropSeeker(p) { p.cr = null; p.busy = 0; p.nm = null; p.fs = null; const i = seekers.indexOf(p); if (i >= 0) seekers.splice(i, 1); }
  function upkeep(dt) {
    seekT -= dt; if (seekT > 0) return; seekT = .8;
    const s = RD.state;
    for (let i = seekers.length - 1; i >= 0; i--) { const p = seekers[i], d = Math.hypot(p.x - s.x, p.z - s.z); if (d > SEEK_DROP) dropSeeker(p); }
    if (seekers.length >= MAX_SEEK) return;
    let best = null, bd = 1e9;
    for (const p of people()) {
      if (p.cr || p.k === 'kid' || p.pr) continue;
      const d = Math.hypot(p.x - s.x, p.z - s.z); if (d < SEEK_NEAR || d > SEEK_FAR) continue;
      const score = d * (.6 + Math.random() * .8); if (score < bd) { bd = score; best = p; }
    }
    if (best) makeSeeker(best);
  }
  function nearestSeeker() {
    const s = RD.state; let best = null, bd = REACH * REACH;
    for (const p of seekers) { const dx = p.x - s.x, dz = p.z - s.z, d = dx * dx + dz * dz; if (d < bd) { bd = d; best = p; } }
    return best;
  }

  /* ---------- boarding / alighting ---------- */
  const SHOUT = ['Wọlé, wọlé!', 'Enter! Enter!', 'Oya, enter!'];
  function board(p) {
    const i = seekers.indexOf(p); if (i >= 0) seekers.splice(i, 1);
    p.sl = p.slT = riders.length; riders.push(p); p.st = SEATED; p.cr = seat; p.fs.t = 0; seat(p); showBeam(p, true);
    const f = p.fs; talk(p, f.dest.name + ', please!', 3);
    snd('click'); say(SHOUT[(Math.random() * SHOUT.length) | 0] + ' ' + f.dest.name + ' · +' + fareNow(p) + ' 🐚'); dwell = 0;
  }
  function alight(p, mode) {     // mode: 'pay' | 'early' | 'angry'
    const i = riders.indexOf(p); if (i < 0) return; riders.splice(i, 1); riders.forEach((q, k) => { q.slT = k; });
    const h = H(), s = RD.state, sn = Math.sin(s.yaw), cs = Math.cos(s.yaw), sg = (uid++ % 2) ? 1 : -1;
    showBeam(p, false);
    p.x = s.x - cs * 1.7 * sg; p.z = s.z + sn * 1.7 * sg; p.y = RD.World.height(p.x, p.z); p.yaw = s.yaw + sg * 1.2;
    p.cr = null; p.w = null; p.rl = null; p.st = 0; p.busy = 0;     // they have arrived: they stand where they got off
    if (mode === 'pay') {
      const fare = fareNow(p), tip = p.fs.t <= p.fs.limit;
      h.score += fare; h.cow = fare; h.cowPop = true; setTimeout(() => { h.cowPop = false; }, 170);
      snd('cowrie', 3); talk(p, tip ? 'Ẹ ṣé! Fast rider — tip for you!' : 'Ẹ ṣé! You are slow, but thanks.', 3.2);
      say('Fare paid: +' + fare + ' 🐚' + (tip ? ' (tip included)' : ' (late fare)') + ' — ' + p.fs.dest.name);
    } else if (mode === 'angry') {
      talk(p, 'Ẹ pẹ́ jù! Rider, you are too slow — mo ń lọ!', 3.4); say('A passenger jumped off — you took too long. No fare.');
    } else { talk(p, 'Rider, this is not my stop!', 3); }
    const q = p; setTimeout(() => { if (!q.cr) q.nm = null; }, 3800); p.fs = null;
  }
  function letOffAll() {
    if (!riders.length) return; const n = riders.length; riders.slice().forEach(p => alight(p, 'early'));
    snd('click'); say('Everyone off early — no fare. Take them to their stop for pay!');
  }
  function abort() {             // left Free Roam mid-ride: put everyone back where they were
    riders.slice().forEach(p => { showBeam(p, false); p.cr = null; p.x = p.fs.x0; p.z = p.fs.z0; p.y = RD.World.height(p.x, p.z); p.st = p.fs.st0; p.busy = 0; p.nm = null; p.fs = null; });
    riders = []; seekers.slice().forEach(dropSeeker); near = null; dwell = 0;
    marks.forEach(m => { m.orb.setEnabled(false); m.ring.setEnabled(false); });
  }

  function press() {
    const h = H(); if (h.screen !== 'free' || h.mode !== 'ride' || !RD || !RD.built) return;
    if (near) {
      if (riders.length >= MAX_SEATS) { say('The horse is full! (' + MAX_SEATS + ' aboard) — drop someone at their stop first.'); return; }
      if (Math.abs(RD.state.speed) < MAX_SPEED) board(near); else say('Slow down first — hold S beside the passenger.');
    } else if (riders.length) letOffAll();
  }
  OYO.fare = { press };

  /* ---------- per-frame ---------- */
  function tick() {
    const h = H(), s = RD && RD.state; if (!h || !s) return;
    const live = h.screen === 'free' && h.mode === 'ride' && RD.built;
    if (!live) { if (riders.length || seekers.length) abort(); if (shown) { h.fareBtn = shown = ''; } if (listKey) { h.fareList = []; listKey = ''; } return; }
    ensureMeshes();
    const dt = Math.min(.05, scene.getEngine().getDeltaTime() / 1000), now = performance.now() / 1000;
    if (msgT > 0) { msgT -= dt; if (msgT <= 0) h.fareMsg = ''; }
    if (warnT > 0) warnT -= dt;
    upkeep(dt);

    // waiting passengers: hail when you come close, gold marker over their head
    for (let i = 0; i < marks.length; i++) {
      const m = marks[i], p = seekers[i];
      if (!p) { if (m.orb.isEnabled()) { m.orb.setEnabled(false); m.ring.setEnabled(false); } continue; }
      m.orb.position.set(p.x, p.y + 2.3 * p.sc + .3 + Math.sin(now * 4 + i) * .12, p.z); m.ring.position.set(p.x, p.y + .1, p.z);
      const k = 1.2 + Math.sin(now * 3 + i) * .12; m.ring.scaling.set(k, k, k);
      if (!m.orb.isEnabled()) { m.orb.setEnabled(true); m.ring.setEnabled(true); }
      if (!p.fs.hailed && Math.hypot(p.x - s.x, p.z - s.z) < HAIL_R) {
        p.fs.hailed = true; talk(p, 'Rider! ' + p.fs.dest.name + '! ' + p.fs.base + ' 🐚', 5);
        if (!hinted) { hinted = true; say('Passenger waiting! Hold S beside them to pick them up.'); }
      }
    }

    // pick-up: brake beside a waiting passenger and they climb on by themselves
    near = nearestSeeker();
    if (near && riders.length < MAX_SEATS && Math.abs(s.speed) < AUTO_SPEED) { dwell += dt; if (dwell >= DWELL) board(near); } else dwell = 0;

    // riders: timers, drop-off at their own stop, impatience
    for (const p of riders.slice()) {
      const f = p.fs; f.t += dt;
      const dd = Math.hypot(f.dest.x - s.x, f.dest.z - s.z);
      if (dd < f.dest.r) {
        if (Math.abs(s.speed) < MAX_SPEED) { alight(p, 'pay'); continue; }
        if (warnT <= 0) { warnT = 4; say('Hold S! Passengers cannot jump off at gallop.'); }
      }
      if (f.t > f.limit * QUIT_X) alight(p, 'angry');
    }

    // right-hand panel
    listT -= dt;
    if (listT <= 0) {
      listT = .25;
      const list = riders.map(p => {
        const f = p.fs, dx = f.dest.x - s.x, dz = f.dest.z - s.z, left = f.limit - f.t;
        return { id: f.id, name: f.dest.name, fare: fareNow(p), late: left <= 0, tl: left > 0 ? fmt(left) : 'LATE', rot: Math.round(angD(s.yaw, Math.atan2(dx, dz)) * 180 / PI), d: Math.max(0, Math.round(Math.hypot(dx, dz) - f.dest.r)) + ' m', col: css(COL[f.ci] || COL[0]) };
      });
      const key = JSON.stringify(list); if (key !== listKey) { listKey = key; h.fareList = list; }
    }
    let label = '';
    if (near) label = riders.length >= MAX_SEATS ? 'Horse full' : Math.abs(s.speed) < MAX_SPEED ? 'Pick up passenger' : 'Hold S to slow down';
    else if (riders.length) label = 'Let everyone off';
    if (label !== shown) h.fareBtn = shown = label;
  }

  const prev = MS.init;
  MS.init = function (world, riding, scn, coreRef) {
    const r = prev.apply(this, arguments); RD = riding; scene = scn;
    scene.onBeforeRenderObservable.add(tick); return r;
  };
  window.addEventListener('keydown', (e) => { if (e.code === 'KeyE' && !e.repeat) press(); });
})();
