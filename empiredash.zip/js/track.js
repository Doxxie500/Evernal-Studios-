/* Anonymous play stats → /api/track (device id only, no names or personal data). Fails silently; the game never waits for it. */
(function () {
  'use strict';
  function dev() { try { var d = localStorage.getItem('jagun-dev'); if (d && /^[a-z0-9]{16,40}$/.test(d)) return d; } catch (e) { /* none */ } return ''; }
  function send(o) {
    try { o.dev = o.dev || dev(); if (!o.dev) { var a = new Uint8Array(12); crypto.getRandomValues(a); o.dev = Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); try { localStorage.setItem('jagun-dev', o.dev); } catch (e) { /* ok */ } }
      fetch('api/track', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(o), keepalive: true }).catch(function () {}); } catch (e) { /* ok */ }
  }
  var q = {}; try { q = new URLSearchParams(location.search); } catch (e) { q = { get: function () { return null; } }; }
  send({ t: 'visit', cart: q.get('cart') || '' });
  window.OYOTrack = { run: function (sc, km, pax, cow) { send({ t: 'run', sc: sc, km: km, pax: pax, cow: cow }); } };
})();
