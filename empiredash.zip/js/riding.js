/* EMPIRE DASH — Stage 7 · riding.js
   Puts the royal messenger + horse into the Babylon scene:
   - one CPU-skinned mesh (horse, tack, rider, reins) = 1 draw call, cel-shaded to match the villagers
   - projected cast shadow (1 extra draw call) that follows the animated body
   - riding controller (W/S/A/D, touch stick), terrain following, building/wall collision
   - third-person chase camera with orbit, speed pull-back and terrain/building collision.
   Depends on rig.js, horse.js, messenger.js, rideanim.js. */
(function () {
  'use strict';
  const R = window.OYORig, H = window.OYOHorse, M = window.OYOMessenger, A = window.OYORideAnim;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v)), lerp = (a, b, t) => a + (b - a) * t;
  const angDiff = (a, b) => { let d = (b - a) % (Math.PI * 2); if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2; return d; };
  const PI = Math.PI;

  /* ---------- shader (same lighting model as the villagers: banded sun, hemisphere ambient, rim, haze, exp2 fog) ---------- */
  const VS = `precision highp float;
attribute vec3 position;attribute vec3 normal;attribute vec4 color;attribute vec2 uv;
uniform mat4 world;uniform mat4 viewProjection;uniform vec3 camPos;
varying vec3 vN;varying vec3 vC;varying vec2 vUV;varying float vD;varying vec3 vV;
void main(){
  vec4 wp=world*vec4(position,1.);
  vC=color.rgb;vN=normal;
  vUV=uv;
  vD=length(wp.xyz-camPos);vV=camPos-wp.xyz;
  gl_Position=viewProjection*wp;
}`;
  const FS = `precision highp float;varying vec3 vN;varying vec3 vC;varying vec2 vUV;varying float vD;varying vec3 vV;
uniform sampler2D tex;uniform vec3 toSun;uniform vec3 sunCol;uniform vec3 skyCol;uniform vec3 gndCol;uniform vec3 fogCol;uniform vec3 hazeCol;uniform float fogD;
void main(){
  vec3 alb=texture2D(tex,vUV).rgb*vC;
  vec3 N=normalize(vN);if(!gl_FrontFacing)N=-N;
  float ndl=dot(N,toSun);
  float band=.5*smoothstep(-.05,.12,ndl)+.5*smoothstep(.28,.45,ndl);
  float lit=mix(band,clamp(ndl,0.,1.),.22);
  vec3 hemi=mix(gndCol,skyCol,N.y*.5+.5);
  vec3 col=alb*(hemi*1.08+sunCol*lit*1.05);
  col=mix(col,col*vec3(.80,.74,1.),(1.-lit)*.4);
  vec3 V=normalize(vV);
  float rim=pow(1.-clamp(dot(N,V),0.,1.),3.)*smoothstep(-.3,.5,ndl)*.24;
  col+=sunCol*alb*rim*1.3;
  float sp=pow(clamp(dot(N,normalize(toSun+V)),0.,1.),28.)*.10*step(.3,lit);
  col+=sunCol*sp;
  col=mix(col,hazeCol,smoothstep(300.,1500.,vD)*.55);
  float f=1.-exp(-fogD*fogD*vD*vD);
  gl_FragColor=vec4(mix(col,fogCol,f),1.);
}`;
  /* Register the rider shader at load (not only when the game builds its rider) so the Carts-menu preview and the start-menu cart pictures can harness the real horse. */
  try { if (window.BABYLON && BABYLON.Effect) { BABYLON.Effect.ShadersStore.oyoRiderVertexShader = VS; BABYLON.Effect.ShadersStore.oyoRiderFragmentShader = FS; } } catch (e) { /* the rider build registers it again */ }

  function brushTexture(scene) {
    const B = BABYLON, S = 128, t = new B.DynamicTexture('riderBrush', { width: S, height: S }, scene, true), g = t.getContext();
    g.fillStyle = '#f4ecde'; g.fillRect(0, 0, S, S); g.lineCap = 'round';
    for (let i = 0; i < 330; i++) {
      const x = Math.random() * S, y = Math.random() * S, a = Math.random() * PI, l = 4 + Math.random() * 14, light = Math.random() < .5;
      g.strokeStyle = light ? 'rgba(255,252,240,.32)' : 'rgba(110,86,60,.16)'; g.lineWidth = 1.2 + Math.random() * 3;
      for (const dx of [-S, 0, S]) for (const dy of [-S, 0, S]) { g.beginPath(); g.moveTo(x + dx, y + dy); g.lineTo(x + dx + Math.cos(a) * l, y + dy + Math.sin(a) * l); g.stroke(); }
    }
    t.wrapU = t.wrapV = B.Texture.WRAP_ADDRESSMODE; t.anisotropicFilteringLevel = 2; t.update(); return t;
  }

  /* ---------- tunables ---------- */
  const SPEED_CURVE = [[0, 0], [.12, 1.2], [.35, 3.5], [.55, 6.5], [.75, 10.7], [1, 15]];   // Stage 37: horse is ~30% faster (top 15 m/s, was 11.5)
  const speedOf = t => { for (let i = 1; i < SPEED_CURVE.length; i++) if (t <= SPEED_CURVE[i][0]) { const a = SPEED_CURVE[i - 1], b = SPEED_CURVE[i]; return lerp(a[1], b[1], (t - a[0]) / (b[0] - a[0])); } return SPEED_CURVE[SPEED_CURVE.length - 1][1]; };
  const REVERSE = -1.7;
  /* Stage 9: auto-gallop. The horse always runs; the rider only steers, brakes and jumps. */
  const AUTO_RAMP = .5, BRAKE_RATE = 2.8, JUMP_V = 6.0, GRAV = 12.5, JUMP_CLEAR = .5;   // JUMP_CLEAR: fraction of an obstacle's height you must be above to clear it
  const turnMax = v => { v = Math.abs(v); return v < 3 ? lerp(1.25, 1.15, v / 3) : v < 7 ? lerp(1.15, .85, (v - 3) / 4) : lerp(.85, .62, clamp((v - 7) / 4.5, 0, 1)); };

  const Riding = {
    built: false, active: false,
    state: { x: 0, z: 0, y: 0, yaw: 0, speed: 0, turn: 0, gait: 'idle', gaitLabel: 'Standing', air: false, jy: 0, jv: 0 },
    cam: { x: 0, y: 3, z: 0, yaw: 0, yawOff: 0, pitchOff: 0, idle: 0, fov: 1.0, dist: 7, drag: false, snap: true },
    obs: { x: [], z: [], r: [], h: [], k: [] }, palace: null,
    kb: { hold: 0 }, houses: [], fences: []
  };

  /* ====================== BUILD ====================== */
  Riding.build = function (scene, World) {
    const B = BABYLON;
    Riding.scene = scene; Riding.World = World;
    const construct = () => {
    if (Riding.mesh) { Riding.mesh.dispose(false, true); Riding.shadow.dispose(false, true); }
    const hg = H.build({ regalia: window.OYOHorseRegalia ? window.OYOHorseRegalia() : '' }), rg = M.build(), mesh = R.MB();
    R.append(mesh, hg.mesh, 0); Riding.horseV = R.nv(mesh); R.append(mesh, rg.mesh, H.NB);
    const bodyV = R.nv(mesh);
    // reins: 2 × (9 points × 4-ring tube); positions written every frame
    const RN = 9, RS = 4, reinV0 = bodyV, REIN = [.34, .15, .09];
    for (let s = 0; s < 2; s++) {
      const v0 = R.nv(mesh);
      for (let i = 0; i < RN; i++) for (let k = 0; k < RS; k++) R.vert(mesh, 0, 0, 0, i % 3 === 1 ? [.74, .18, .13] : REIN, [0, 0, 0], null);
      for (let i = 0; i < RN - 1; i++) for (let k = 0; k < RS; k++) { const k1 = (k + 1) % RS, a = v0 + i * RS + k, b = v0 + i * RS + k1, c = a + RS, d = b + RS; mesh.i.push(a, c, b, b, c, d); }
    }
    // driver's whip (Endless Run): 9-point, 4-ring tube, positions written every frame while the driver mode is on
    const WN = 9, WCOL = [[.3, .17, .09], [.46, .27, .13], [.86, .8, .64], [.86, .8, .64], [.86, .8, .64], [.8, .74, .58], [.8, .74, .58], [.7, .64, .5], [.12, .08, .06]];
    Riding.whipV0 = R.nv(mesh); Riding.WN = WN; Riding.WRAD = [.017, .012, .008, .0075, .007, .0065, .006, .005, .0045];
    { const v0 = R.nv(mesh); for (let i = 0; i < WN; i++) for (let k = 0; k < RS; k++) R.vert(mesh, 0, 0, 0, WCOL[i], [0, 0, 0], null);
      for (let i = 0; i < WN - 1; i++) for (let k = 0; k < RS; k++) { const k1 = (k + 1) % RS, a = v0 + i * RS + k, b = v0 + i * RS + k1, c = a + RS, d = b + RS; mesh.i.push(a, c, b, b, c, d); } }
    const nvv = R.nv(mesh);
    const anim = new A.Animator(); anim.bitRest = { L: hg.anchors.bitL, R: hg.anchors.bitR };
    anim.update(1 / 60, 0, 0);

    const P = new Float32Array(nvv * 3), N = new Float32Array(nvv * 3), col = new Float32Array(nvv * 4);
    for (let k = 0; k < nvv; k++) { col[k * 4] = mesh.c[k * 3]; col[k * 4 + 1] = mesh.c[k * 3 + 1]; col[k * 4 + 2] = mesh.c[k * 3 + 2]; col[k * 4 + 3] = 1; }
    R.skin(mesh, anim.bones, P, N, bodyV);

    const uvs = new Float32Array(nvv * 2); for (let k = 0; k < nvv; k++) { const x = mesh.p[k * 3], y = mesh.p[k * 3 + 1], z = mesh.p[k * 3 + 2]; uvs[k * 2] = x * 1.7 + z * .9; uvs[k * 2 + 1] = y * 1.7 + y * .9; }
    const rm = new B.Mesh('royalRider', scene), vd = new B.VertexData();
    vd.positions = P; vd.normals = N; vd.colors = col; vd.uvs = uvs; vd.indices = mesh.i.length > 65000 ? new Uint32Array(mesh.i) : new Uint16Array(mesh.i);
    vd.applyToMesh(rm, true);
    rm.isPickable = false; rm.alwaysSelectAsActiveMesh = true; rm.doNotSyncBoundingInfo = true;

    // material
    B.Effect.ShadersStore.oyoRiderVertexShader = VS; B.Effect.ShadersStore.oyoRiderFragmentShader = FS;
    const fogC = new B.Vector3(scene.fogColor.r, scene.fogColor.g, scene.fogColor.b), mat = new B.ShaderMaterial('riderMat', scene, { vertex: 'oyoRider', fragment: 'oyoRider' }, {
      attributes: ['position', 'normal', 'color', 'uv'], uniforms: ['world', 'viewProjection', 'camPos', 'toSun', 'sunCol', 'skyCol', 'gndCol', 'fogCol', 'hazeCol', 'fogD'], samplers: ['tex']
    });
    mat.setTexture('tex', brushTexture(scene)); mat.setVector3('toSun', World.sunDir); mat.setVector3('sunCol', new B.Vector3(.85, .73, .53)); mat.setVector3('skyCol', new B.Vector3(.58, .54, .47));
    mat.setVector3('gndCol', new B.Vector3(.42, .27, .2)); mat.setVector3('fogCol', fogC); mat.setVector3('hazeCol', new B.Vector3(.93, .84, .64)); mat.setFloat('fogD', scene.fogDensity);
    mat.setVector3('camPos', new B.Vector3(0, 0, 0)); mat.backFaceCulling = false;
    mat.onError = (e, errs) => console.warn('Rider shader error', errs);
    rm.material = mat;

    // projected shadow (world-space vertices flattened on the ground along the sun direction)
    const SP = new Float32Array(nvv * 3), SN = new Float32Array(nvv * 3); for (let k = 0; k < nvv; k++) SN[k * 3 + 1] = 1;
    const shadowIdx = []; for (let t = 0; t < mesh.i.length; t += 3) if (mesh.i[t] < bodyV) shadowIdx.push(mesh.i[t], mesh.i[t + 1], mesh.i[t + 2]);
    const sm = new B.Mesh('royalShadow', scene), sd = new B.VertexData();
    sd.positions = SP; sd.normals = SN; sd.indices = new Uint16Array(shadowIdx); sd.applyToMesh(sm, true);
    const smat = new B.StandardMaterial('royalShadowMat', scene);
    smat.disableLighting = true; smat.emissiveColor = new B.Color3(.13, .07, .17); smat.diffuseColor = B.Color3.Black(); smat.specularColor = B.Color3.Black();
    smat.alpha = .36; smat.backFaceCulling = false; smat.zOffset = -5; smat.fogEnabled = true;
    try { smat.depthFunction = 513; /* LESS: overlapping triangles cannot double-darken */ } catch (e) { /* older Babylon */ }
    sm.material = smat; sm.alphaIndex = 30; sm.isPickable = false; sm.alwaysSelectAsActiveMesh = true; sm.doNotSyncBoundingInfo = true;

    Riding.mesh = rm; Riding.shadow = sm; Riding.mat = mat; Riding.geo = mesh; Riding.anim = anim; Riding.P = P; Riding.N = N; Riding.SP = SP; Riding.bodyV = bodyV; Riding.nvv = nvv;
    Riding.reinV0 = reinV0; Riding.RN = RN; Riding.RS = RS; Riding.frame = 0; Riding.avgDt = .016; Riding.slow = false;
    Riding.tris = mesh.i.length / 3;
    };
    construct();
    Riding.refit = function () {       // regalia changed in Ọjà Ìlú: rebuild the horse mesh with it
      if (!Riding.built) return; construct(); Riding.setActive(Riding.active); Riding.pushMesh(0, true);
    };
    buildObstacles(World);
    Riding.setActive(false);
    Riding.built = true;
    return Riding;
  };

  /* ====================== OBSTACLES ====================== */
  function buildObstacles(World) {
    Riding.houses.length = 0;
    const o = Riding.obs; o.x.length = o.z.length = o.r.length = o.h.length = o.k.length = 0;
    const S = World.settlements;
    if (S && S.compounds) S.compounds.forEach(c => {
      if (c.hidden || !c.L) return;
      const cs = Math.cos(c.yaw), sn = Math.sin(c.yaw);
      c.L.forEach(bd => {
        if (bd.skip) return;
        const x = c.x + bd.x * cs + bd.z * sn, z = c.z - bd.x * sn + bd.z * cs, pro = bd.pro || {}, sc = bd.sc || 1;
        const r = Math.max(.9, (bd.r || 2) * .88 * (pro.kind === 'rack' || pro.kind === 'shed' ? .8 : 1));
        const isHouse = pro.w && pro.d && ['main', 'rect', 'round', 'oval'].indexOf(pro.kind) >= 0;
        o.x.push(x); o.z.push(z); o.r.push(r); o.h.push(((pro.hgt || 3.2) * sc) + 1.2); o.k.push(isHouse ? -1 : 0);   // -1: camera-only (houses use wall collision below)
        if (isHouse) {
          const yw = c.yaw + (bd.yaw || 0), hx = pro.w / 2 * sc, hz = pro.d / 2 * sc;
          Riding.houses.push({ x, z, cs: Math.cos(yw), sn: Math.sin(yw), hx, hz, box: pro.kind === 'main' || pro.kind === 'rect', dx: (pro.doorX || 0) * sc, b2: Math.pow(Math.max(hx, hz) + 1.6, 2) });
        }
      });
    });
    // Stage 8b: compound perimeter walls (the fences) are solid. Same superellipse as buildings.js, gate gap at local +z.
    Riding.fences.length = 0;
    if (S && S.compounds) S.compounds.forEach(c => {
      if (c.hidden || !c.L || !c.a || !c.b) return;
      const e = c.kind === 'round' ? 2 : 8, ex = 2 / e, M = 240, cs = Math.cos(c.yaw), sn = Math.sin(c.yaw), dense = [], cum = [0];
      for (let k = 0; k <= M; k++) { const th = Math.PI / 2 + k / M * 2 * Math.PI, ct = Math.cos(th), st = Math.sin(th); dense.push([c.a * Math.sign(ct) * Math.pow(Math.abs(ct), ex), c.b * Math.sign(st) * Math.pow(Math.abs(st), ex)]); }
      for (let k = 1; k <= M; k++) cum.push(cum[k - 1] + Math.hypot(dense[k][0] - dense[k - 1][0], dense[k][1] - dense[k - 1][1]));
      const Lt = cum[M], gap = c.farm ? 3.2 : 3.0, s0 = gap / 2, s1 = Lt - gap / 2, n = Math.max(12, Math.round((s1 - s0) / 2.2)), pts = []; let j = 0;
      for (let k = 0; k <= n; k++) {
        const s = s0 + (s1 - s0) * k / n; while (j < M - 1 && cum[j + 1] < s) j++;
        const f = (s - cum[j]) / Math.max(1e-6, cum[j + 1] - cum[j]), lx = dense[j][0] + (dense[j + 1][0] - dense[j][0]) * f, lz = dense[j][1] + (dense[j + 1][1] - dense[j][1]) * f;
        pts.push(c.x + lx * cs + lz * sn, c.z - lx * sn + lz * cs);
      }
      Riding.fences.push({ x: c.x, z: c.z, b2: Math.pow(Math.max(c.a, c.b) + 3, 2), pts });
    });
    const PA = window.OYOPalace && OYOPalace.site;
    Riding.palace = PA && PA.a ? { x: PA.x, z: PA.z, yaw: PA.yaw, a: PA.a, b: PA.b, cs: Math.cos(PA.yaw), sn: Math.sin(PA.yaw) } : null;
    Riding.obsCount = o.x.length;
  }
  function palaceDist(x, z) {   // signed distance to the palace wall rectangle (+outside), local coords, gate flag
    const p = Riding.palace; if (!p) return null;
    const dx = x - p.x, dz = z - p.z, lx = dx * p.cs - dz * p.sn, lz = dx * p.sn + dz * p.cs;
    const ex = Math.abs(lx) - p.a, ez = Math.abs(lz) - p.b;
    const sd = Math.hypot(Math.max(ex, 0), Math.max(ez, 0)) + Math.min(Math.max(ex, ez), 0);
    const gate = lz > p.b - 4 && Math.abs(lx) < 4.2;
    return { sd, lx, lz, ex, ez, gate };
  }
  function collide(x, z, rad, jh) {
    const o = Riding.obs; let hit = 0, kind = 0; jh = jh || 0;
    for (let k = 0; k < o.x.length; k++) {
      if (o.k[k] < 0) continue;
      if (jh > o.h[k] * JUMP_CLEAR) continue;     // Stage 9: airborne high enough to clear rocks, logs and low props
      const dx = x - o.x[k], dz = z - o.z[k], min = o.r[k] + rad, d2 = dx * dx + dz * dz;
      if (d2 < min * min) { const d = Math.sqrt(d2) || .001; x = o.x[k] + dx / d * min; z = o.z[k] + dz / d * min; hit = 1; if (o.k[k] > kind) kind = o.k[k]; }
    }
    // Stage 8: houses are hollow solid walls; the only opening is the main entrance (front, +z local)
    const HW = .72, GAP = 1.15, hs = Riding.houses;
    for (let k = 0; k < hs.length; k++) {
      const h = hs[k], dx = x - h.x, dz = z - h.z; if (dx * dx + dz * dz > h.b2) continue;
      const lx = dx * h.cs - dz * h.sn, lz = dx * h.sn + dz * h.cs; let sd, nx, nz;
      if (h.box) { const ex = Math.abs(lx) - h.hx, ez = Math.abs(lz) - h.hz; if (ex > ez) { sd = ex; nx = lx < 0 ? -1 : 1; nz = 0; } else { sd = ez; nx = 0; nz = lz < 0 ? -1 : 1; } }
      else { const u = lx / h.hx, v = lz / h.hz, rr = Math.hypot(u, v) || 1e-4, gx = u / h.hx, gz = v / h.hz, gl = Math.hypot(gx, gz) || 1; sd = (rr - 1) * Math.min(h.hx, h.hz); nx = gx / gl; nz = gz / gl; }
      if (Math.abs(sd) >= HW) continue;
      if (lz > h.hz * .5 && Math.abs(lx - h.dx) < GAP) continue;      // doorway
      const s = sd >= 0 ? 1 : -1, push = (HW - Math.abs(sd)) * s, wx = nx * h.cs + nz * h.sn, wz = -nx * h.sn + nz * h.cs;
      x += wx * push; z += wz * push; hit = 1; if (kind < 1) kind = 1;
    }
    // Stage 8b: solid fence walls (segment push-out; the gate gap has no segments so it stays open)
    const FW = .62 + rad * .35, fs = Riding.fences;
    for (let k = 0; k < fs.length; k++) {
      const f = fs[k], dx = x - f.x, dz = z - f.z; if (dx * dx + dz * dz > f.b2) continue;
      const P = f.pts;
      for (let i = 0; i < P.length - 2; i += 2) {
        const ax = P[i], az = P[i + 1], bx = P[i + 2], bz = P[i + 3], ex = bx - ax, ez = bz - az, l2 = ex * ex + ez * ez || 1e-6;
        const t = Math.max(0, Math.min(1, ((x - ax) * ex + (z - az) * ez) / l2)), qx = ax + ex * t, qz = az + ez * t, ox = x - qx, oz = z - qz, d2 = ox * ox + oz * oz;
        if (d2 < FW * FW) { const d = Math.sqrt(d2) || .001; x = qx + ox / d * FW; z = qz + oz / d * FW; hit = 1; if (kind < 1) kind = 1; }
      }
    }
    const pd = palaceDist(x, z);
    if (pd && !pd.gate && Math.abs(pd.sd) < 1.0 + rad && Math.abs(pd.lx) < Riding.palace.a + 3 && Math.abs(pd.lz) < Riding.palace.b + 3) {
      const p = Riding.palace, push = (1.0 + rad) - Math.abs(pd.sd), sgn = pd.sd >= 0 ? 1 : -1;
      let nlx = 0, nlz = 0; if (pd.ex > pd.ez) nlx = Math.sign(pd.lx) * sgn; else nlz = Math.sign(pd.lz) * sgn;
      x += (nlx * p.cs + nlz * p.sn) * push; z += (-nlx * p.sn + nlz * p.cs) * push; hit = 1;
    }
    return { x, z, hit, kind };
  }
  function camBlocked(x, y, z) {
    const o = Riding.obs, W = Riding.World;
    if (y < W.height(x, z) + .75) return true;
    for (let k = 0; k < o.x.length; k++) { if (o.k[k] > 0) continue; const dx = x - o.x[k], dz = z - o.z[k], r = o.r[k] * .95; if (dx * dx + dz * dz < r * r && y < o.h[k]) return true; }
    const pd = palaceDist(x, z); if (pd && !pd.gate && Math.abs(pd.sd) < .7 && y < 7.5) return true;
    return false;
  }

  /* ====================== PLACEMENT ====================== */
  Riding.setActive = function (on) {
    Riding.active = !!on;
    if (Riding.mesh) { Riding.mesh.setEnabled(!!on); Riding.shadow.setEnabled(!!on && !(window.OYO && OYO.endless && OYO.endless.on)); }
  };
  Riding.place = function (x, z, yaw) {
    const s = Riding.state, W = Riding.World; s.x = x; s.z = z; s.yaw = yaw; s.speed = 0; s.turn = 0; s.y = W.height(x, z); s.pitch = 0; s.roll = 0; s.air = false; s.jy = 0; s.jv = 0; Riding.kb.hold = 0;
    Riding.cam.yaw = yaw; Riding.cam.yawOff = 0; Riding.cam.pitchOff = 0; Riding.cam.snap = true; Riding.cam.idle = 0;
    Riding.pushMesh(0, true);
  };
  Riding.addObstacle = function (x, z, r, h, kind) { const o = Riding.obs; o.x.push(x); o.z.push(z); o.r.push(r); o.h.push(h); o.k.push(kind || 1); };
  Riding.orbit = function (dyaw, dpitch) { const c = Riding.cam; c.yawOff = clamp(c.yawOff + dyaw, -PI, PI); c.pitchOff = clamp(c.pitchOff + dpitch, -.12, .85); c.idle = 0; };

  /* ====================== PER-FRAME ====================== */
  /* inp: { fwd:0|1, back:0|1, steer:-1..1, analog:-1..1 (stick y), boost:bool, stick:bool } */
  Riding.update = function (dt, inp) {
    if (!Riding.built) return;
    const s = Riding.state, W = Riding.World, kb = Riding.kb;
    dt = Math.min(dt, .05);
    // ---- throttle → target speed
    let tgt = 0;
    if (inp.auto) {
      if (inp.brake && !s.air) { kb.hold = Math.max(0, (kb.hold || 0) - dt * BRAKE_RATE); tgt = 0; }
      else { kb.hold = Math.min(1, (kb.hold || 0) + dt * AUTO_RAMP); tgt = speedOf(kb.hold); }
    } else if (Math.abs(inp.analog) > .12) { tgt = inp.analog > 0 ? speedOf(clamp((inp.analog - .1) / .9, 0, 1)) : REVERSE * Math.min(1, -inp.analog); kb.hold = 0; }
    else if (inp.fwd) { kb.hold = Math.min(1.0, (kb.hold || .3) + dt * (inp.boost ? 1.6 : .34)); tgt = speedOf(kb.hold); }
    else if (inp.back) { tgt = REVERSE; kb.hold = 0; }
    else kb.hold = 0;
    if (inp.cap != null) { kb.hold = Math.min(kb.hold, inp.cap); if (tgt > 0) tgt = Math.min(tgt, speedOf(inp.cap)); }   // Stage 8: stamina / terrain throttle cap
    const boosted = inp.spd > 1 && tgt > 0;      // speed power-up (missions.js): lifts the top speed for a short while
    if (boosted) tgt *= inp.spd;
    const accel = (tgt > s.speed ? (s.speed < 0 ? 5 : 1.5 + .05 * Math.abs(tgt)) : (tgt === 0 ? 3.2 : 4.2)) * (boosted ? 1.8 : 1);
    s.speed = lerp(s.speed, tgt, 1 - Math.exp(-dt * accel));
    if (Math.abs(s.speed) < .02 && tgt === 0) s.speed = 0;
    // ---- steering
    const turnTarget = clamp(inp.steer, -1, 1) * turnMax(s.speed);
    s.turn = lerp(s.turn, turnTarget, 1 - Math.exp(-dt * (Math.abs(inp.steer) > .05 ? 7 : 9)));
    s.yaw += s.turn * dt * (s.speed < -.3 ? -1 : 1);
    // ---- move + collide
    let nx = s.x + Math.sin(s.yaw) * s.speed * dt, nz = s.z + Math.cos(s.yaw) * s.speed * dt;
    const lim = W.endless ? 1e9 : W.HALF - 8; nx = clamp(nx, -lim, lim); nz = clamp(nz, -lim, lim);   // Endless Run (endless.js) has no map edge; Free Roam keeps its boundary
    const c = collide(nx, nz, .85, s.air ? s.jy : 0);
    if (c.hit) { const moved = Math.hypot(c.x - nx, c.z - nz); s.speed *= (1 - clamp(moved * 1.5, 0, .5)); }
    kb.cd = Math.max(0, (kb.cd || 0) - dt);
    if (c.kind && kb.cd <= 0 && Math.abs(s.speed) > 1.2) { s.speed *= c.kind === 2 ? .3 : .5; s.bump = c.kind; kb.cd = .9; }   // Stage 8: obstacle impact (read by missions.js)
    s.x = c.x; s.z = c.z;
    // ---- terrain following
    const sy = Math.sin(s.yaw), cy = Math.cos(s.yaw), hf = W.height(s.x + sy * .9, s.z + cy * .9), hb = W.height(s.x - sy * .9, s.z - cy * .9),
      hr = W.height(s.x + cy * .45, s.z - sy * .45), hl = W.height(s.x - cy * .45, s.z + sy * .45), h0 = W.height(s.x, s.z);
    const gy = (hf + hb + h0 * 2) / 4, k = 1 - Math.exp(-dt * 10);
    // Stage 9: jump (tap) — arcs over rocks and fallen branches; fences, houses and the palace stay solid
    if (inp.jump && !s.air) { s.air = true; s.jv = JUMP_V * (.82 + .18 * clamp(Math.abs(s.speed) / 11, 0, 1)); s.jy = 0; Riding.justJumped = true; }
    if (s.air) {
      s.jv -= GRAV * dt; s.jy += s.jv * dt;
      if (s.jy <= 0) { s.jy = 0; s.jv = 0; s.air = false; Riding.justLanded = true; }
    }
    if (s.air) s.y = gy + s.jy; else s.y = lerp(s.y, gy, k);
    s.pitch = lerp(s.pitch || 0, clamp(Math.atan2(hf - hb, 1.8) + (s.air ? -clamp(s.jv * .045, -.3, .3) : 0), -.5, .5), 1 - Math.exp(-dt * (s.air ? 9 : 6)));
    s.roll = lerp(s.roll || 0, clamp(Math.atan2(hr - hl, .9), -.3, .3), 1 - Math.exp(-dt * 6));
    // ---- animation
    const an = Riding.anim; an.update(s.air ? dt * .35 : dt, s.speed, s.turn);   // legs glide while airborne
    s.gait = an.info.gait; s.gaitLabel = ({ idle: 'Standing', walk: 'Walk', trot: 'Trot', gallop: 'Gallop' })[s.gait] || '';
    Riding.avgDt = lerp(Riding.avgDt, dt, .05); Riding.slow = Riding.avgDt > .026;
    Riding.frame++;
    const still = s.gait === 'idle' && s.speed === 0 && Math.abs(s.turn) < .02;     // idle breathing needs only ~20 Hz
    if (!still || (Riding.frame % 3) === 0) Riding.pushMesh(dt, false, gy, hf, hb, hr, hl);
    // Stage 11i: realistic road dust (hoof strikes, kicked grit, hanging trail) — see dust.js
    if (window.OYODust) { if (!Riding.dustOn) { Riding.dustOn = true; try { OYODust.build(Riding.scene, Riding.World); } catch (e) { OYODust.dead = true; console.warn('Dust unavailable', e); } } OYODust.update(dt, Riding); }
  };

  /* skin + flex + world transform + reins + shadow → GPU */
  Riding.pushMesh = function (dt, force, gy, hf, hb, hr, hl) {
    if (!Riding.built) return;
    const s = Riding.state, an = Riding.anim, P = Riding.P, N = Riding.N, SP = Riding.SP, W = Riding.World;
    if (gy == null) { gy = s.y; hf = hb = hr = hl = s.y; }
    // world matrix: T · Ry(yaw) · Rx(pitch) · Rz(roll)
    let Mw = R.mMul(R.rotY(s.yaw), R.mMul(R.rotX(s.pitch || 0), R.rotZ(s.roll || 0)));
    Mw[3] = s.x; Mw[7] = s.y; Mw[11] = s.z;
    // bones → world
    const nb = A.NB, wb = Riding.wb || (Riding.wb = new Float32Array(nb * 12)), B0 = an.bones;
    for (let b = 0; b < nb; b++) {
      const o = b * 12;
      for (let r = 0; r < 3; r++) {
        const a0 = Mw[r * 4], a1 = Mw[r * 4 + 1], a2 = Mw[r * 4 + 2];
        wb[o + r * 4] = a0 * B0[o] + a1 * B0[o + 4] + a2 * B0[o + 8];
        wb[o + r * 4 + 1] = a0 * B0[o + 1] + a1 * B0[o + 5] + a2 * B0[o + 9];
        wb[o + r * 4 + 2] = a0 * B0[o + 2] + a1 * B0[o + 6] + a2 * B0[o + 10];
        wb[o + r * 4 + 3] = a0 * B0[o + 3] + a1 * B0[o + 7] + a2 * B0[o + 11] + Mw[r * 4 + 3];
      }
    }
    const drv = Riding.driver, nSk = drv ? Riding.horseV : Riding.bodyV;      // driver mode: only the horse is skinned here; the rider is posed on the cart in driverTick
    R.skin(Riding.geo, wb, P, N, nSk);
    // secondary motion in world axes
    const ex = [Mw[0], Mw[4], Mw[8]], ey = [Mw[1], Mw[5], Mw[9]], ez = [Mw[2], Mw[6], Mw[10]];
    an.applyFlex(Riding.geo, P, 0, nSk, ex, ey, ez);
    if (drv) { Riding._pend = { Mw, gy, hf, hb, hr, hl }; return; }
    finishPush(Mw, gy, hf, hb, hr, hl, null);
  };
  function finishPush(Mw, gy, hf, hb, hr, hl, Md) {
    const s = Riding.state, an = Riding.anim, P = Riding.P, N = Riding.N, SP = Riding.SP, W = Riding.World;
    writeReins(Mw, an, Md); if (Md) writeWhip(Md, an);
    // GPU upload
    const B = BABYLON, rm = Riding.mesh;
    rm.updateVerticesData(B.VertexBuffer.PositionKind, P, false, false);
    rm.updateVerticesData(B.VertexBuffer.NormalKind, N, false, false);
    // shadow: flatten along the sun direction onto the local ground plane
    const sun = W.sunDir, sx = sun.x / sun.y, sz = sun.z / sun.y, gx = (hr - hl) / .9, gz = (hf - hb) / 1.8, x0 = s.x, z0 = s.z, y0 = gy + .09;
    const nv = Riding.bodyV;
    for (let k = 0; k < nv; k++) {
      const px = P[k * 3], py = P[k * 3 + 1], pz = P[k * 3 + 2];
      const pl = y0 + gx * (px - x0) + gz * (pz - z0);
      let t = py - pl; if (t < 0) t = 0;
      const qx = px - sx * t, qz = pz - sz * t;
      SP[k * 3] = qx; SP[k * 3 + 1] = y0 + gx * (qx - x0) + gz * (qz - z0); SP[k * 3 + 2] = qz;
    }
    if (window.OYO && OYO.endless && OYO.endless.on) { if (Riding.shadow.isEnabled(false)) Riding.shadow.setEnabled(false); }   // Endless Run: the player's horse + cart casts no ground shadow
    else { if (!Riding.shadow.isEnabled(false) && Riding.mesh && Riding.mesh.isEnabled(false)) Riding.shadow.setEnabled(true); Riding.shadow.updateVerticesData(B.VertexBuffer.PositionKind, SP, false, false); }
  }

  /* ---- Endless Run: the messenger drives the cart (sits on the driver bench, whips the horse) ---- */
  const SEAT = [0, 1.44, 1.23], S0 = [0, 1.52, -.07], IDM = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0];
  const xf = (M, p) => [M[0] * p[0] + M[1] * p[1] + M[2] * p[2] + M[3], M[4] * p[0] + M[5] * p[1] + M[6] * p[2] + M[7], M[8] * p[0] + M[9] * p[1] + M[10] * p[2] + M[11]];
  Riding.driverTick = function () {
    const d = Riding.driver, pend = Riding._pend; if (!d || !pend || !Riding.built) return;
    const cs = d.cart.state, D = window.OYOCart.dims, an = Riding.anim, nb = A.NB, nbh = A.NBH, B0 = an.bones, wb = Riding.wb;
    const Md = R.mMul(R.rotY(cs.yaw), R.mMul(R.rotX(-cs.pitch), R.rotZ(cs.roll)));
    const lx = SEAT[0] - S0[0], ly = SEAT[1] + (cs.bob || 0) - S0[1], lz = SEAT[2] - (D.KPZ + D.RZ) / 2 - S0[2];
    Md[3] = cs.x + Md[0] * lx + Md[1] * ly + Md[2] * lz; Md[7] = cs.y + Md[4] * lx + Md[5] * ly + Md[6] * lz; Md[11] = cs.z + Md[8] * lx + Md[9] * ly + Md[10] * lz;
    for (let b = nbh; b < nb; b++) {
      const o = b * 12;
      for (let r = 0; r < 3; r++) {
        const a0 = Md[r * 4], a1 = Md[r * 4 + 1], a2 = Md[r * 4 + 2];
        wb[o + r * 4] = a0 * B0[o] + a1 * B0[o + 4] + a2 * B0[o + 8];
        wb[o + r * 4 + 1] = a0 * B0[o + 1] + a1 * B0[o + 5] + a2 * B0[o + 9];
        wb[o + r * 4 + 2] = a0 * B0[o + 2] + a1 * B0[o + 6] + a2 * B0[o + 10];
        wb[o + r * 4 + 3] = a0 * B0[o + 3] + a1 * B0[o + 7] + a2 * B0[o + 11] + Md[r * 4 + 3];
      }
    }
    R.skin(Riding.geo, wb, Riding.P, Riding.N, Riding.bodyV, Riding.horseV);
    an.applyFlex(Riding.geo, Riding.P, Riding.horseV, Riding.bodyV, [Md[0], Md[4], Md[8]], [Md[1], Md[5], Md[9]], [Md[2], Md[6], Md[10]]);
    finishPush(pend.Mw, pend.gy, pend.hf, pend.hb, pend.hr, pend.hl, Md);
  };
  Riding.setDriver = function (cart) {
    const B = BABYLON;
    if (cart && Riding.built && window.OYOCart) {
      Riding.driver = { cart }; Riding.anim.driver = true; Riding.anim.whip = null;
      if (!Riding._drvObs) Riding._drvObs = Riding.scene.onBeforeRenderObservable.add(() => Riding.driverTick());     // after the cart's own pose update
      Riding.pushMesh(0, true);
    } else {
      const was = Riding.driver; Riding.driver = null; Riding._pend = null; if (Riding.anim) Riding.anim.driver = false;
      if (was && Riding.built) { Riding.P.fill(0, Riding.whipV0 * 3, Riding.nvv * 3); Riding.pushMesh(0, true); }
    }
  };
  function writeWhip(Md, an) {
    const pts = an.whipPts; if (!pts) return;
    const P = Riding.P, N = Riding.N, RS = Riding.RS, WN = Riding.WN, W = pts.map(p => xf(Md, p));
    for (let i = 0; i < WN; i++) {
      const a = W[Math.max(0, i - 1)], b = W[Math.min(WN - 1, i + 1)]; let tx = b[0] - a[0], ty = b[1] - a[1], tz = b[2] - a[2]; const tl = Math.hypot(tx, ty, tz) || 1; tx /= tl; ty /= tl; tz /= tl;
      let ux = -tz, uy = 0, uz = tx, ul = Math.hypot(ux, uz); if (ul < 1e-4) { ux = 1; uz = 0; ul = 1; } ux /= ul; uz /= ul;
      const vx = ty * uz - tz * uy, vy = tz * ux - tx * uz, vz = tx * uy - ty * ux, r = Riding.WRAD[i];
      for (let k = 0; k < RS; k++) {
        const th = PI * 2 * k / RS, cc = Math.cos(th), ss = Math.sin(th), nx = ux * cc + vx * ss, ny = vy * ss, nz = uz * cc + vz * ss, vi = Riding.whipV0 + i * RS + k;
        P[vi * 3] = W[i][0] + nx * r; P[vi * 3 + 1] = W[i][1] + ny * r; P[vi * 3 + 2] = W[i][2] + nz * r; N[vi * 3] = nx; N[vi * 3 + 1] = ny; N[vi * 3 + 2] = nz;
      }
    }
  }

  function writeReins(Mw0, an, Md) {
    const P = Riding.P, N = Riding.N, RN = Riding.RN, RS = Riding.RS, hands = an.hands; if (!hands) return;
    const sp = clamp(Math.abs(an.v) / 9, 0, 1), sag = .11 * (1 - sp) + .012;
    for (let s = 0; s < 2; s++) {
      const hd = hands[s]; let p0 = hd.bitC, p3 = [hd.hand[0], hd.hand[1] - .005, hd.hand[2] + .012], Mw = Mw0;
      if (Md) { p0 = xf(Mw0, p0); p3 = xf(Md, p3); Mw = IDM; }          // driver mode: bit on the horse, hand on the cart
      const mid = [(p0[0] + p3[0]) / 2, (p0[1] + p3[1]) / 2 - sag, (p0[2] + p3[2]) / 2];
      let prevU = null;
      for (let i = 0; i < RN; i++) {
        const u = i / (RN - 1), a = (1 - u) * (1 - u), b = 2 * u * (1 - u), c = u * u;
        const pm = [a * p0[0] + b * mid[0] + c * p3[0], a * p0[1] + b * mid[1] + c * p3[1], a * p0[2] + b * mid[2] + c * p3[2]];
        const tx = 2 * (1 - u) * (mid[0] - p0[0]) + 2 * u * (p3[0] - mid[0]), ty = 2 * (1 - u) * (mid[1] - p0[1]) + 2 * u * (p3[1] - mid[1]), tz = 2 * (1 - u) * (mid[2] - p0[2]) + 2 * u * (p3[2] - mid[2]);
        const tl = Math.hypot(tx, ty, tz) || 1, t = [tx / tl, ty / tl, tz / tl];
        let ux = t[1] * 0 - t[2] * 1, uy = t[2] * 0 - t[0] * 0, uz = t[0] * 1 - t[1] * 0;   // t × up(0,1,0)
        let ul = Math.hypot(ux, uy, uz); if (ul < 1e-4) { ux = 1; uy = 0; uz = 0; ul = 1; } ux /= ul; uy /= ul; uz /= ul;
        const vx = t[1] * uz - t[2] * uy, vy = t[2] * ux - t[0] * uz, vz = t[0] * uy - t[1] * ux, r = .0085;
        for (let k = 0; k < RS; k++) {
          const th = PI * 2 * k / RS, cc = Math.cos(th), ss = Math.sin(th);
          const nx = ux * cc + vx * ss, ny = uy * cc + vy * ss, nz = uz * cc + vz * ss;
          const lx = pm[0] + nx * r, ly = pm[1] + ny * r, lz = pm[2] + nz * r;
          const vi = Riding.reinV0 + s * RN * RS + i * RS + k;
          P[vi * 3] = Mw[0] * lx + Mw[1] * ly + Mw[2] * lz + Mw[3]; P[vi * 3 + 1] = Mw[4] * lx + Mw[5] * ly + Mw[6] * lz + Mw[7]; P[vi * 3 + 2] = Mw[8] * lx + Mw[9] * ly + Mw[10] * lz + Mw[11];
          N[vi * 3] = Mw[0] * nx + Mw[1] * ny + Mw[2] * nz; N[vi * 3 + 1] = Mw[4] * nx + Mw[5] * ny + Mw[6] * nz; N[vi * 3 + 2] = Mw[8] * nx + Mw[9] * ny + Mw[10] * nz;
        }
      }
    }
  }

  /* ====================== CAMERA ====================== */
  /* returns { x,y,z, yaw, pitch, fov } for the FreeCamera used by game.js */
  /* ENDLESS RUN chase camera (only used while World.endless is set; Free Roam never reaches this).
     Fixed boom behind the cart, orbit ignored, looks past the horse so the road ahead stays open, eases on turns, kicks on hits. */
  function endlessCamera(dt, camera) {
    const s = Riding.state, c = Riding.cam, W = Riding.World;
    const spF = clamp(Math.abs(s.speed) / 11, 0, 1), k = 1 - Math.exp(-dt * 5);
    const asp = (camera && camera.getEngine) ? camera.getEngine().getAspectRatio(camera) : 1.6, port = asp < 1;
    c.yawOff = 0; c.pitchOff = 0; c.idle = 0;
    c.turnS = lerp(c.turnS || 0, clamp(s.turn || 0, -1, 1), k);                    // smoothed steering lean
    c.kick = Math.max(0, (c.kick || 0) - dt * 2.6);                                  // obstacle-hit shake, decays
    const want = s.yaw - c.turnS * .1;                                               // slight lag into the turn
    if (c.snap) c.yaw = want; else c.yaw += angDiff(c.yaw, want) * (1 - Math.exp(-dt * 4.2));
    const dist = lerp(10.4, 12.8, spF) + (port ? 2.6 : 0), elev = .46 - spF * .03 + (port ? .04 : 0);      // zoomed IN: closer behind the cart so the cart, road and scenery look bigger
    const fy = Math.sin(c.yaw), fz = Math.cos(c.yaw), ay = Math.sin(s.yaw), az = Math.cos(s.yaw);
    const side = c.turnS * .9, rx = fz, rz = -fy;                                    // camera slides a little outward on turns
    const sh = c.kick * c.kick, shx = Math.sin(Riding.anim.t * 47) * .16 * sh, shy = Math.cos(Riding.anim.t * 39) * .2 * sh;
    const ty = s.y + 1.5, tx = s.x + ay * 9.5, tz = s.z + az * 9.5;                  // aim ahead of the horse: horse low, road ahead high
    const px = s.x - fy * Math.cos(elev) * dist + rx * side + shx, pz = s.z - fz * Math.cos(elev) * dist + rz * side;
    let py = ty + Math.sin(elev) * dist + .9 + shy; py = Math.max(py, W.height(px, pz) + 1.4);
    if (c.snap) { c.x = px; c.y = py; c.z = pz; c.snap = false; }
    else { const f = 1 - Math.exp(-dt * 6.5); c.x = lerp(c.x, px, f); c.y = lerp(c.y, py, f); c.z = lerp(c.z, pz, f); }
    const lx = tx - c.x, ly = ty - c.y, lz = tz - c.z;
    c.fov = lerp(c.fov, (port ? 1.16 : 1.06) + spF * .1 + sh * .04 + (Riding.fovBoost || 0) * .22, 1 - Math.exp(-dt * 3));
    return { x: c.x, y: c.y, z: c.z, yaw: Math.atan2(lx, lz), pitch: Math.atan2(-ly, Math.hypot(lx, lz)), fov: c.fov, roll: -c.turnS * .025 + shx * .05 };
  }
  Riding.camera = function (dt, camera) {
    const s = Riding.state, c = Riding.cam, W = Riding.World; dt = Math.min(dt, .05);
    if (W.endless) return endlessCamera(dt, camera);
    const spF = clamp(Math.abs(s.speed) / 11, 0, 1);
    if (c.drag) c.idle = 0; else c.idle += dt;
    if (c.idle > 1.4 && Math.abs(s.speed) > .6) { c.yawOff *= Math.exp(-dt * 1.5); c.pitchOff *= Math.exp(-dt * 1.2); }
    const want = s.yaw + c.yawOff;
    if (c.snap) c.yaw = want; else c.yaw += angDiff(c.yaw, want) * (1 - Math.exp(-dt * (2.4 + spF * 1.6)));
    const elev = clamp(.26 + c.pitchOff - spF * .04, .05, 1.1), dist = lerp(6.6, 9.2, spF) * (1 + c.pitchOff * .25);
    const fy = Math.sin(c.yaw), fz = Math.cos(c.yaw), ay = Math.sin(s.yaw), az = Math.cos(s.yaw);
    const ty = s.y + 2.05 + Math.sin(Riding.anim.t * 2) * 0, tx = s.x + ay * 1.4, tz = s.z + az * 1.4;
    const dx = -fy * Math.cos(elev) * dist, dz = -fz * Math.cos(elev) * dist, dy = Math.sin(elev) * dist + .6;
    // collision along the boom
    let tmax = 1; const STEPS = 12;
    for (let i = 1; i <= STEPS; i++) { const t = i / STEPS; if (camBlocked(tx + dx * t, ty + dy * t, tz + dz * t)) { tmax = Math.max(.22, (i - 1) / STEPS); break; } }
    let px = tx + dx * tmax, py = ty + dy * tmax, pz = tz + dz * tmax;
    py = Math.max(py, W.height(px, pz) + 1.0);
    if (c.snap) { c.x = px; c.y = py; c.z = pz; c.snap = false; }
    else {
      const f = 1 - Math.exp(-dt * (tmax < 1 ? 14 : 7));
      c.x = lerp(c.x, px, f); c.y = lerp(c.y, py, f); c.z = lerp(c.z, pz, f);
      if (camBlocked(c.x, c.y, c.z)) { c.x = px; c.y = py; c.z = pz; }
    }
    const lx = tx - c.x, ly = ty - c.y, lz = tz - c.z, hz = Math.hypot(lx, lz);
    c.fov = lerp(c.fov, 1.0 + spF * .13, 1 - Math.exp(-dt * 2.5));
    return { x: c.x, y: c.y, z: c.z, yaw: Math.atan2(lx, lz), pitch: Math.atan2(-ly, hz), fov: c.fov };
  };

  window.OYORiding = Riding;
})();
