/* EMPIRE DASH — Stage 12a · cart.js
   The Oba's passenger cart (kẹ̀kẹ́ ẹlẹ́ṣin): a four-wheeled, horse-drawn wooden passenger cart, c. 1650, in the same stylised
   cel-shaded look as the rider (same shader model, same OYORig mesh toolkit, same vertex-colour + brush-texture albedo).

   ONLY the cart (and its harness) lives here. It never edits the horse, the rider, the camera, the controls or any mission code.
   Stage 12c: cart.seatPassengers(n) seats existing villagers on the benches (they ride along, seated, idle-breathing; ?pax=N sets the count, 0 = empty).
   Stage 12b: OYOCart.spawnHitched(scene, World, riding) / cart.hitch(riding) couples the cart to the rider's horse (read-only use of riding.state / riding.wb).

   What you get
   ------------
   OYOCart.build(scene, World, opts)  → a cart object (Babylon meshes + a small API), see the end of this file.
   OYOCart.geometry()                 → pure-JS geometry (no Babylon needed; used by tests / previews).

   Model space (same as the horse): +z forward, +y up, +x right, ground y = 0, metres.
     • body: 4 m long, 1.7 m wide, roof ridge 2.8 m
     • 6 passenger seats (3 benches × 2) facing forward, 1 driver's seat at the FRONT, open rear entrance with a step
     • rear wheels r = .68 m, front wheels r = .52 m (a four-wheel "fore-carriage" wagon: the front axle + draw-shafts swivel)
     • two draw-shafts run forward from the front axle; the horse stands between them (anchors.horse)

   Meshes / draw calls: body, frontFrame (steers), frontWheels (spin), rearWheels (spin) = 4.

   Design notes (historical inspiration, not a reconstruction): Old Oyo c. 1650 is known for camwood (osùn) red, indigo (àrò) adire
   cloth, cowrie (owó ẹyọ) strings, brass and bead work, carved wooden doors and house-posts, and the thunder-god Ṣàngó's double-axe
   (oṣé Ṣàngó), the royal emblem of the Aláàfin's line. Those motifs are used for the carving, the cloth roof and the fringe.
   Wheeled carts were not in everyday use in Old Oyo (the kingdom's strength was its cavalry), so this is a stylised, imagined vehicle.
*/
(function (root) {
  'use strict';
  const R = root.OYORig || require('./rig.js');
  const { MB, nv, vert, strip, shade, mixc, lerp, clamp, mMul, rotY, rotZ, trans, xformRange, PI, TAU } = R;

  /* OYORig.box / ellipsoid / tube wind some faces the other way round to their normals. The rider's shader copes with that by
     flipping normals on back-faces, which would light those faces wrongly here, so every primitive added below is re-wound so that
     its triangles agree with its (outward) vertex normals — the same convention Babylon's own meshes use. */
  function fixWinding(m, i0) {
    const P = m.p, N = m.n, I = m.i;
    for (let t = i0; t < I.length; t += 3) {
      const a = I[t], b = I[t + 1], c = I[t + 2];
      const ux = P[b * 3] - P[a * 3], uy = P[b * 3 + 1] - P[a * 3 + 1], uz = P[b * 3 + 2] - P[a * 3 + 2], vx = P[c * 3] - P[a * 3], vy = P[c * 3 + 1] - P[a * 3 + 1], vz = P[c * 3 + 2] - P[a * 3 + 2];
      const g = (uy * vz - uz * vy) * (N[a * 3] + N[b * 3] + N[c * 3]) + (uz * vx - ux * vz) * (N[a * 3 + 1] + N[b * 3 + 1] + N[c * 3 + 1]) + (ux * vy - uy * vx) * (N[a * 3 + 2] + N[b * 3 + 2] + N[c * 3 + 2]);
      if (g < 0) { I[t + 1] = c; I[t + 2] = b; }
    }
  }
  const wrap = f => function (m) { const i0 = m.i.length, r = f.apply(null, arguments); fixWinding(m, i0); return r; };
  const box = wrap(R.box), ellipsoid = wrap(R.ellipsoid), tube = wrap(R.tube);

  /* ---------------- palette (shares the horse's colours) ---------------- */
  const WOOD = [.50, .30, .15], WOOD_D = [.31, .18, .09], WOOD_L = [.64, .42, .22];
  const CAMW = [.70, .22, .12];              // camwood red (osùn) paint
  const RED = [.76, .18, .13], INDIGO = [.16, .23, .58], INDIGO_D = [.10, .15, .40], PALE = [.62, .70, .90];
  const GOLD = [.97, .77, .30], BRASS = [.88, .64, .24], CREAM = [.94, .88, .74], IRON = [.30, .28, .27], TEAL = [.14, .45, .48];
  const LEATHER = [.34, .18, .09];

  /* ---------------- dimensions ---------------- */
  const D = {
    FLOOR: .80, BW: .84, KPZ: 1.18, RZ: -1.28, RR: .68, FR: .52, TRACK: 1.02,
    EAVE: 2.50, RISE: .30, RW: 1.02, ZR0: -2.34, ZR1: 1.14, FRONT: .95, REAR: -2.10, DECK: 2.05, MAXSTEER: .2,
    SHAFT_X: .40, SHAFT_L: 3.1, HORSE_Z: 1.97   // HORSE_Z: horse origin along the draw-shafts (front-frame space): the horse's chest sits just behind the breast-bar (z 2.9)
  };
  let KIND = '';                              // 'load' | 'long' | 'two' while one of the extra plain-wood road carts is being generated (built on the starter cart's chassis)
  let PLAIN = false;                          // true while the plain wooden STARTER cart is being generated (shared chassis, wheels' size, shafts and horse anchor)
  const hb = () => PLAIN ? LEATHER : BRASS;
  const roofY = x => D.EAVE + D.RISE * (1 - (x / D.RW) * (x / D.RW));
  const BAYS = [-1.55, -.58, .40], POSTZ = [-2.08, -1.08, -.10, .92];

  /* ---------------- small helpers ---------------- */
  const hash = (x, y, z) => { const h = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453; return h - Math.floor(h); };
  const wd = (c, x, y, z, a) => shade(c, 1 + (hash(x, y, z) - .5) * 2 * (a == null ? .09 : a));
  const bx = (m, c, s, col, o) => box(m, c, s, Object.assign({ col: wd(col, c[0], c[1], c[2]) }, o));
  const sstep = (a, b, x) => { x = clamp((x - a) / (b - a), 0, 1); return x * x * (3 - 2 * x); };

  /* vertex with an explicit normal */
  function V(m, p, n, col) { const i = vert(m, p[0], p[1], p[2], col); m.n[i * 3] = n[0]; m.n[i * 3 + 1] = n[1]; m.n[i * 3 + 2] = n[2]; return i; }
  /* push triangle a,b,c wound so that its geometric normal agrees with (nx,ny,nz)  (same convention as OYORig.box) */
  function orient(m, a, b, c, nx, ny, nz) {
    const P = m.p, ax = P[a * 3], ay = P[a * 3 + 1], az = P[a * 3 + 2];
    const ux = P[b * 3] - ax, uy = P[b * 3 + 1] - ay, uz = P[b * 3 + 2] - az, vx = P[c * 3] - ax, vy = P[c * 3 + 1] - ay, vz = P[c * 3 + 2] - az;
    const g = (uy * vz - uz * vy) * nx + (uz * vx - ux * vz) * ny + (ux * vy - uy * vx) * nz;
    if (g >= 0) m.i.push(a, b, c); else m.i.push(a, c, b);
  }
  /* flat polygon (3-D points, fan from the centroid), one explicit normal. Two-sided shading is handled by the shader. */
  function poly3(m, pts, n, col) {
    const c = [0, 0, 0]; pts.forEach(p => { c[0] += p[0]; c[1] += p[1]; c[2] += p[2]; }); c[0] /= pts.length; c[1] /= pts.length; c[2] /= pts.length;
    const ci = V(m, c, n, col), ids = pts.map(p => V(m, p, n, col));
    for (let i = 0; i < ids.length; i++) orient(m, ci, ids[i], ids[(i + 1) % ids.length], n[0], n[1], n[2]);
  }
  /* extruded 2-D polygon on a frame F = {o,u,v,n}: point = o + u·pu + v·pv + n·w.  Front cap at w0+d, optional back cap at w0. */
  function prism(m, poly, o) {
    const O = o.o, U = o.u, Vv = o.v, Nn = o.n, d = o.d == null ? .03 : o.d, w0 = o.w0 || 0, col = o.col, cs = o.colSide || shade(col, .78);
    const P3 = (pu, pv, w) => [O[0] + U[0] * pu + Vv[0] * pv + Nn[0] * w, O[1] + U[1] * pu + Vv[1] * pv + Nn[1] * w, O[2] + U[2] * pu + Vv[2] * pv + Nn[2] * w];
    const n = poly.length; let ar = 0, cu = 0, cv = 0;
    for (let i = 0; i < n; i++) { const a = poly[i], b = poly[(i + 1) % n]; ar += a[0] * b[1] - b[0] * a[1]; cu += a[0]; cv += a[1]; }
    cu /= n; cv /= n; const sg = ar >= 0 ? 1 : -1;
    const cap = (w, nn, cc) => {
      const ci = V(m, P3(cu, cv, w), nn, cc), ids = poly.map(p => V(m, P3(p[0], p[1], w), nn, cc));
      for (let i = 0; i < n; i++) orient(m, ci, ids[i], ids[(i + 1) % n], nn[0], nn[1], nn[2]);
    };
    cap(w0 + d, Nn, col);
    if (o.back) cap(w0, [-Nn[0], -Nn[1], -Nn[2]], col);
    if (d > .011 || o.back) for (let i = 0; i < n; i++) {
      const a = poly[i], b = poly[(i + 1) % n], du = b[0] - a[0], dv = b[1] - a[1], l = Math.hypot(du, dv); if (l < 1e-7) continue;
      const e0 = dv / l * sg, e1 = -du / l * sg, nn = [U[0] * e0 + Vv[0] * e1, U[1] * e0 + Vv[1] * e1, U[2] * e0 + Vv[2] * e1];
      const q = [V(m, P3(a[0], a[1], w0), nn, cs), V(m, P3(b[0], b[1], w0), nn, cs), V(m, P3(b[0], b[1], w0 + d), nn, cs), V(m, P3(a[0], a[1], w0 + d), nn, cs)];
      orient(m, q[0], q[1], q[2], nn[0], nn[1], nn[2]); orient(m, q[0], q[2], q[3], nn[0], nn[1], nn[2]);
    }
  }
  /* solid of revolution about the local X axis.  prof = closed loop of [r, x]; flat-shaded per profile segment. */
  function lathe(m, prof, o) {
    o = o || {}; const N = o.N || 12, v0 = nv(m), n = prof.length, cols = o.col || WOOD;
    let ar = 0; for (let i = 0; i < n; i++) { const a = prof[i], b = prof[(i + 1) % n]; ar += a[0] * b[1] - b[0] * a[1]; }
    const sg = ar >= 0 ? 1 : -1;
    for (let i = 0; i < n; i++) {
      const a = prof[i], b = prof[(i + 1) % n], dr = b[0] - a[0], dx = b[1] - a[1], l = Math.hypot(dr, dx); if (l < 1e-6) continue;
      const nr = dx / l * sg, nx = -dr / l * sg, rows = [];
      for (const p of [a, b]) {
        const row = [];
        for (let k = 0; k < N; k++) {
          const th = TAU * k / N, c = Math.cos(th), s = Math.sin(th), col = typeof cols === 'function' ? cols({ i, k, th, r: p[0], x: p[1] }) : cols;
          row.push(V(m, [p[1], p[0] * c, p[0] * s], [nx, nr * c, nr * s], col));
        }
        rows.push(row);
      }
      for (let k = 0; k < N; k++) {
        const k1 = (k + 1) % N, tm = TAU * (k + .5) / N, qn = [nx, nr * Math.cos(tm), nr * Math.sin(tm)];
        orient(m, rows[0][k], rows[1][k], rows[0][k1], qn[0], qn[1], qn[2]); orient(m, rows[0][k1], rows[1][k], rows[1][k1], qn[0], qn[1], qn[2]);
      }
    }
    if (o.M) xformRange(m, { v0, v1: nv(m) }, o.M);
  }
  /* lathe placed at p with its axis along 'x' | 'y' | 'z' */
  function turned(m, p, axis, prof, o) {
    const rot = axis === 'y' ? rotZ(PI / 2) : axis === 'z' ? rotY(-PI / 2) : null;
    lathe(m, prof, Object.assign({}, o, { M: rot ? mMul(trans(p[0], p[1], p[2]), rot) : trans(p[0], p[1], p[2]) }));
  }
  const rect = (u0, v0, u1, v1) => [[u0, v0], [u1, v0], [u1, v1], [u0, v1]];
  const diamond = (cu, cv, hw, hh) => [[cu, cv - hh], [cu + hw, cv], [cu, cv + hh], [cu - hw, cv]];
  const disc = (cu, cv, r, N) => { const a = []; N = N || 14; for (let k = 0; k < N; k++) a.push([cu + Math.cos(TAU * k / N) * r, cv + Math.sin(TAU * k / N) * r]); return a; };
  function zig(u0, u1, v, amp, th, teeth) {          // thick zig-zag line
    const top = [], bot = [];
    for (let i = 0; i <= teeth * 2; i++) { const u = lerp(u0, u1, i / (teeth * 2)), y = v + (i % 2 ? amp : 0); top.push([u, y + th]); bot.push([u, y]); }
    return top.concat(bot.reverse());
  }
  const tri = (cu, cv, hw, h) => [[cu - hw, cv], [cu + hw, cv], [cu, cv + h]];
  const rod = (m, a, b, r, col, seg) => tube(m, [a, b], [r, r], { seg: seg || 6, col });

  /* Ṣàngó's double axe (oṣé Ṣàngó) on a frame: staff, two flared blades, a head-disc. Built at scale s, base at v0. */
  function ose(m, F, cu, v0, s, o) {
    o = o || {}; const d = (o.d == null ? .03 : o.d) * 1, back = !!o.back, w0 = o.w0 || 0;
    const P = (pts, col, dd, ww) => prism(m, pts.map(p => [cu + p[0] * s, v0 + p[1] * s]), { o: F.o, u: F.u, v: F.v, n: F.n, d: dd == null ? d : dd, w0: ww == null ? w0 : ww, col, back });
    P(rect(-.035, 0, .035, .78), o.stem || BRASS);                                           // staff
    P([[-.10, 0], [.10, 0], [.06, .10], [-.06, .10]], o.stem || BRASS);                      // foot
    for (const sx of [-1, 1]) {                                                              // two flared blades (wide cutting edges, narrow at the staff)
      const B = [[.03, .50], [.16, .49], [.30, .40], [.42, .30], [.46, .52], [.44, .76], [.39, .92], [.28, .82], [.15, .64], [.03, .60]].map(p => [p[0] * sx, p[1]]);
      P(B, o.blade || CREAM, d + .008, w0 + .006);
      P([[.10, .53], [.22, .50], [.32, .43], [.38, .39], [.40, .53], [.38, .72], [.34, .80], [.26, .72], [.16, .62], [.10, .59]].map(p => [p[0] * sx, p[1]]), o.edge || CAMW, d + .014, w0 + .012);
      P(disc(.33 * sx, .60, .04, 8), o.stem || BRASS, d + .02, w0 + .018);
    }
    P(disc(0, .53, .085, 14), o.stem || BRASS, d + .02, w0 + .006);                          // the head
    P(disc(0, .53, .045, 10), o.eye || INDIGO, d + .028, w0 + .012);
    P([[-.05, .78], [.05, .78], [0, .90]], o.stem || BRASS);                                 // finial
  }
  /* concentric "eye" discs (ojú) */
  function eyes(m, F, cu, cv, r, cols, d) {
    cols = cols || [CAMW, CREAM, INDIGO, BRASS]; d = d || .014;
    cols.forEach((c, i) => prism(m, disc(cu, cv, r * (1 - i * .24), 14), { o: F.o, u: F.u, v: F.v, n: F.n, d, w0: i * d * .9, col: c }));
  }

  /* ================================================================= WHEELS ================================================================= */
  function wheelAt(m, Rw, spokes) {
    const k = Rw / .68, st = [CREAM, INDIGO];
    if (PLAIN) {                                       // starter cart: plain wooden wheel — rim, spokes, hub; no iron studs, paint or brass
      lathe(m, [[Rw - .11, -.066], [Rw, -.066], [Rw, .066], [Rw - .11, .066]], { N: 22, col: WOOD_D });
      for (let q = 0; q < spokes; q++) { const th = TAU * q / spokes + .12, r0 = .10 * k, r1 = Rw - .105, mid = (r0 + r1) / 2; box(m, [0, mid * Math.sin(th), mid * Math.cos(th)], [.056, .05, r1 - r0], { col: wd(WOOD_L, q, Rw, 1, .08), pitch: th }); }
      lathe(m, [[0, -.14 * k], [.10 * k, -.14 * k], [.125 * k, 0], [.10 * k, .14 * k], [0, .14 * k]], { N: 10, col: WOOD_D });
      return;
    }
    // iron tyre + wooden felloe (rim)
    lathe(m, [[Rw - .036, -.078], [Rw, -.078], [Rw, .078], [Rw - .036, .078]], { N: 28, col: IRON });
    lathe(m, [[Rw - .125, -.064], [Rw - .035, -.064], [Rw - .035, .064], [Rw - .125, .064]], { N: 28, col: i => i.i === 2 ? CAMW : WOOD_L });
    // painted dash band on the outer face of the felloe
    lathe(m, [[Rw - .108, .064], [Rw - .052, .064], [Rw - .052, .071], [Rw - .108, .071]], { N: 48, col: i => st[Math.floor(i.k / 2) % 2] });
    // spokes (tapered feel: fat at the hub, slim at the rim)
    for (let s = 0; s < spokes; s++) {
      const th = TAU * s / spokes + .12, r0 = .10 * k, r1 = Rw - .115, L = r1 - r0, mid = (r0 + r1) / 2, dy = Math.sin(th), dz = Math.cos(th);
      box(m, [0, mid * dy, mid * dz], [.058, .052, L], { col: wd(CAMW, s, Rw, 1, .08), pitch: th });
      box(m, [0, (r1 - .05) * dy, (r1 - .05) * dz], [.045, .04, .11], { col: shade(CAMW, .8), pitch: th });
    }
    // hub: turned barrel, brass bands, brass boss
    lathe(m, [[0, -.16 * k], [.07 * k, -.16 * k], [.092 * k, -.13 * k], [.125 * k, -.07 * k], [.135 * k, 0], [.125 * k, .07 * k], [.10 * k, .12 * k], [.085 * k, .15 * k], [0, .15 * k]], { N: 14, col: WOOD_D });
    for (const x of [-.115 * k, .095 * k]) lathe(m, [[.098 * k, x - .016], [.138 * k, x - .016], [.138 * k, x + .016], [.098 * k, x + .016]], { N: 14, col: BRASS });
    lathe(m, [[0, .15 * k], [.085 * k, .15 * k], [.092 * k, .17 * k], [.07 * k, .20 * k], [.035 * k, .222 * k], [0, .23 * k]], { N: 14, col: GOLD });
    // brass studs on the tyre edge
    const ns = Math.round(Rw * 26);
    for (let s = 0; s < ns; s++) {
      const th = TAU * (s + .5) / ns;
      ellipsoid(m, [.082, (Rw - .018) * Math.sin(th), (Rw - .018) * Math.cos(th)], [.011, .016, .016], { col: BRASS, seg: 5, rings: 3 });
    }
  }
  function wheelPair(Rw, spokes) {
    const m = MB();
    for (const s of [1, -1]) {
      const v0 = nv(m); wheelAt(m, Rw, spokes);
      xformRange(m, { v0, v1: nv(m) }, mMul(trans(s * D.TRACK, 0, 0), s > 0 ? [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0] : rotY(PI)));
    }
    bx(m, [0, 0, 0], [2 * D.TRACK - .36, .105, .105], WOOD_D);                                // axle beam
    for (const s of [-1, 1]) turned(m, [s * (D.TRACK - .16), 0, 0], 'x', [[.03, -.05], [.075, -.05], [.075, .05], [.03, .05]], { N: 8, col: IRON });
    return m;
  }

  /* ================================================================= FRONT FRAME (steers) =================================================================
     origin = king-pin at ground level. Bolster, axle perch, two draw-shafts, whippletree and brass/tassel ends. */
  function frontFrame() {
    const m = MB(), ay = D.FR, SX = D.SHAFT_X, L = D.SHAFT_L;
    bx(m, [0, ay + .13, 0], [1.7, .09, .22], WOOD);                                           // bolster
    bx(m, [0, ay + .10, 0], [.18, .26, .20], WOOD_D);                                         // king-post block
    for (const s of [-1, 1]) bx(m, [s * .62, ay + .08, 0], [.12, .18, .16], WOOD_D);          // perch blocks
    if (!PLAIN) turned(m, [0, ay + .185, 0], 'y', [[0, 0], [.13, 0], [.13, .018], [.07, .05], [.04, .09], [0, .09]], { N: 12, col: BRASS });   // brass king-pin cap
    // shafts
    const pts = [], rad = [];
    for (let i = 0; i <= 8; i++) { const t = i / 8; pts.push([0, 0, 0]); rad.push(lerp(.052, .034, t)); }
    for (const s of [-1, 1]) {
      const P = [], Rr = [];
      for (let i = 0; i <= 8; i++) { const t = i / 8; P.push([s * lerp(.34, SX, Math.min(1, t * 3)), lerp(.74, 1.0, t), lerp(-.2, L, t)]); Rr.push(lerp(.052, .034, t)); }
      tube(m, P, Rr, { seg: 7, col: WOOD_L });
      if (!PLAIN) for (const t of [.22, .50, .78]) {                                                       // brass bands
        const p = P[Math.round(t * 8)]; turned(m, p, 'z', [[.04, -.03], [.062, -.03], [.062, .03], [.04, .03]], { N: 8, col: BRASS });
      }
      const tip = P[8];
      if (!PLAIN) ellipsoid(m, [tip[0], tip[1], tip[2] + .03], [.05, .05, .06], { col: BRASS, seg: 8, rings: 5 });
      if (!PLAIN) ellipsoid(m, [tip[0], tip[1], tip[2] + .07], [.03, .03, .03], { col: CREAM, seg: 6, rings: 4 });
      if (!PLAIN) for (let q = -1; q <= 1; q++)                                                            // red wool tassel
        strip(m, [[tip[0] + q * .02, tip[1] - .03, tip[2] - .05], [tip[0] + q * .02, tip[1] - .17, tip[2] - .05], [tip[0] + q * .02, tip[1] - .27, tip[2] - .05]], [.035, .04, .02], [1, 0, 0], { color: (j) => j === 2 ? GOLD : RED });
    }
    // cross-bars
    for (const z of [1.2, 3.0]) {      // (front bar sits just ahead of the horse's chest, rear bar just behind its hindquarters)
      const y = lerp(.74, 1.0, (z + .2) / (L + .2)) + .02;
      tube(m, [[-SX - .05, y, z], [SX + .05, y, z]], [.032, .032], { seg: 6, col: WOOD_D });
      if (!PLAIN) for (const s of [-1, 1]) ellipsoid(m, [s * (SX + .05), y, z], [.04, .04, .04], { col: BRASS, seg: 6, rings: 4 });
    }
    // brass-studded breast-bar leather
    tube(m, [[-SX, 1.0 + .02, 2.9], [0, .94, 2.9], [SX, 1.0 + .02, 2.9]], [.022, .022, .022], { seg: 5, col: LEATHER });
    return m;
  }


  /* ================================================================= STARTER CART BODY =================================================================
     The plain wooden passenger cart every new player begins with: bare planks, two plain benches (4 passenger seats), a driver's bench at the SAME place as the royal
     cart's (so the messenger sits correctly), no roof, no carving, paint, brass, cloth or cowries. Same chassis, wheel size, shafts and hitch as the royal cart. */
  const BAYS_S = [-1.45, -.45];
  function buildStarter() {
    const K = KIND, m = MB(), A = { seats: [], posts: [] }, FL = D.FLOOR, BW = D.BW;
    const zF = 2.05, zR = K === 'long' ? -4.6 : K === 'two' ? -1.55 : -2.15, len = zF - zR, zMid = (zF + zR) / 2;         // body runs from the rear edge zR to the driver deck at zF
    for (const s of [-1, 1]) bx(m, [s * .58, .675, zMid], [.12, .12, len + .1], WOOD_D);                                   // sills
    const beams = [-2.0, -1.28, -.4, .5, 1.45].filter(z => z > zR + .1); if (K === 'long') beams.push(-2.6, -3.3, -4.0, -4.5);
    beams.forEach(z => bx(m, [0, .665, z], [1.9, .095, .11], WOOD_D));                                                     // cross-beams
    for (let i = 0; i < 12; i++) bx(m, [-.77 + i * .14, FL - .03, zMid], [.138, .06, len], i % 2 ? WOOD : WOOD_L);           // floor planks
    bx(m, [0, .60, D.RZ], [1.4, .10, .24], WOOD_D); bx(m, [0, .60, D.KPZ], [1.0, .06, .5], WOOD_D);
    for (const s of [-1, 1]) bx(m, [s * .45, .53, D.RZ], [.12, .12, .2], WOOD_D);
    /* low plank side walls (two boards + top rail) with plain corner posts */
    const w0 = zR + .005, w1 = .975, wl = w1 - w0, wc = (w0 + w1) / 2, posts = []; for (let z = zR + .07; z < .85; z += 1) posts.push(z); posts.push(.92);
    for (const s of [-1, 1]) {
      const x = s * (BW - .03);
      bx(m, [x, .93, wc], [.05, .15, wl], WOOD);  bx(m, [x, 1.12, wc], [.05, .15, wl], WOOD_L);  bx(m, [x, 1.23, wc], [.07, .06, wl + .08], WOOD_D);
      for (const z of posts) bx(m, [x, 1.05, z], [.08, .46, .08], WOOD_D);
      bx(m, [x, .93, 1.5], [.05, .15, 1.1], WOOD);                                                                         // driver-deck board
    }
    if (K === 'load') {                                                                                                    // goods cart: tall slatted sides and a tail-board, then the load itself
      for (const s of [-1, 1]) { const x = s * (BW - .03); bx(m, [x, 1.38, wc], [.05, .15, wl], WOOD); bx(m, [x, 1.55, wc], [.07, .06, wl + .08], WOOD_D); for (const z of posts) bx(m, [x, 1.42, z], [.08, .34, .08], WOOD_D); }
      bx(m, [0, 1.02, zR + .06], [1.64, .40, .05], WOOD); bx(m, [0, 1.30, zR + .06], [1.64, .12, .05], WOOD_L);
      const SACK = [.82, .74, .56], SACK2 = [.70, .62, .46], YAM = [.62, .42, .22], BAND = IRON;
      const crate = (x, y, z, w, h, d) => { bx(m, [x, y, z], [w, h, d], WOOD_L); bx(m, [x, y, z], [w + .02, .05, d + .02], WOOD_D); bx(m, [x, y + h * .34, z], [w + .02, .05, d + .02], WOOD_D); for (const q of [-1, 1]) bx(m, [x + q * (w / 2 - .03), y, z], [.05, h + .02, d + .02], WOOD_D); };
      const sack = (x, y, z, c) => { ellipsoid(m, [x, y, z], [.27, .32, .22], { col: c, seg: 8, rings: 5 }); ellipsoid(m, [x, y + .3, z], [.1, .07, .09], { col: SACK2, seg: 6, rings: 3 }); };
      const barrel = (x, y, z) => { turned(m, [x, y, z], 'y', [[0, -.34], [.26, -.34], [.31, -.1], [.31, .1], [.26, .34], [0, .34]], { N: 12, col: WOOD_D }); for (const dy of [-.2, .2]) turned(m, [x, y + dy, z], 'y', [[.255, -.02], [.325, -.02], [.325, .02], [.255, .02]], { N: 12, col: BAND }); };
      crate(-.38, 1.02, zR + .55, .62, .46, .62); crate(.38, 1.02, zR + .55, .62, .46, .62); crate(0, 1.5, zR + .55, .6, .44, .6);
      barrel(-.40, 1.14, -1.35); barrel(.40, 1.14, -1.35); sack(0, 1.12, -1.35, SACK); sack(0, 1.12, -1.0, SACK2);
      for (let r = 0; r < 3; r++) for (const q of [-1, 0, 1]) sack(q * .46, 1.12, -.35 + r * .3 - (r === 2 ? .1 : 0), (r + q) % 2 ? SACK : SACK2);
      for (let k = 0; k < 7; k++) ellipsoid(m, [-.45 + (k % 4) * .3, 1.64 + (k > 3 ? .16 : 0), -.35 + (k > 3 ? .12 : 0)], [.28, .12, .13], { col: YAM, seg: 6, rings: 4 });
      tube(m, [[-.78, 1.5, zR + .2], [.78, 1.56, -.1], [-.78, 1.52, -.7]], [.022, .022, .022], { seg: 5, col: LEATHER });   // lashing rope
    } else {
      /* passenger benches: plank seat, plank backrest, plain legs */
      const bays = K === 'long' ? [-3.45, -2.45, -1.45, -.45] : K === 'two' ? [-.60] : [-1.45, -.45];
      bays.forEach((zc, bi) => {
        bx(m, [0, 1.195, zc], [1.56, .06, .46], WOOD_L);
        for (const q of [-1, 1]) { A.seats.push({ x: q * .37, y: 1.22, z: zc, yaw: 0, row: bi, side: q }); bx(m, [q * .66, 1.0, zc], [.07, .40, .36], WOOD_D); }
        const zb = zc - .24;
        bx(m, [0, 1.40, zb], [1.5, .13, .045], WOOD); bx(m, [0, 1.62, zb], [1.5, .13, .045], WOOD_L);
        for (const q of [-1, 1]) bx(m, [q * .72, 1.45, zb], [.07, .56, .06], WOOD_D);
      });
      if (K === 'two') bx(m, [0, 1.0, zR + .1], [1.5, .34, .06], WOOD);                                                    // small tail-board behind the two-seater's bench
    }
    /* board behind the driver, driver's bench (same seat position as the royal cart) */
    bx(m, [0, 1.05, D.FRONT], [1.7, .5, .06], WOOD); bx(m, [0, 1.42, D.FRONT], [1.7, .14, .06], WOOD_L);
    { const zc = 1.26;
      bx(m, [0, 1.34, zc], [1.5, .12, .48], WOOD_L);
      for (const q of [-1, 1]) bx(m, [q * .66, 1.05, zc], [.07, .40, .4], WOOD_D);
      bx(m, [0, 1.04, zc], [1.3, .34, .06], WOOD_D);
      A.driver = { x: 0, y: 1.32, z: zc, yaw: 0 }; }
    /* footboard, plain dash board and a wooden rein bar */
    bx(m, [0, .98, 1.82], [1.64, .06, .5], WOOD_L, { pitch: -.18 });
    bx(m, [0, 1.02, D.DECK - .02], [1.64, .40, .06], WOOD);
    for (const s of [-1, 1]) bx(m, [s * .5, 1.32, D.DECK - .02], [.06, .24, .06], WOOD_D);
    tube(m, [[-.5, 1.40, D.DECK - .02], [.5, 1.40, D.DECK - .02]], [.022, .022], { seg: 6, col: WOOD_D });
    A.footboard = { x: 0, y: 1.0, z: 1.82 };
    /* rear step */
    if (K !== 'load') { bx(m, [0, .50, zR - .21], [1.1, .06, .30], WOOD_L); for (const s of [-1, 1]) bx(m, [s * .5, .60, zR - .13], [.07, .24, .08], WOOD_D); }
    A.size = { w: 2 * D.TRACK + .12, l: D.DECK - zR, h: 1.75 };
    return { mesh: m, anchors: A };
  }

  /* ================================================================= BODY ================================================================= */
  function buildBody() {
    if (PLAIN) return buildStarter();
    const m = MB(), A = { seats: [], posts: [] };
    const FL = D.FLOOR, BW = D.BW, zMid = -.05, len = 4.2;
    const sideF = s => ({ o: [s * BW, 0, 0], u: [0, 0, 1], v: [0, 1, 0], n: [s, 0, 0] });

    /* ---- chassis: sills, cross-beams, floor ---- */
    for (const s of [-1, 1]) bx(m, [s * .58, .675, zMid], [.12, .12, len + .1], WOOD_D);
    [-2.0, -1.28, -.4, .5, 1.45].forEach(z => bx(m, [0, .665, z], [1.9, .095, .11], WOOD_D));
    for (const z of [-2.0, -.4, .5, 1.45]) for (const s of [-1, 1]) ellipsoid(m, [s * .96, .665, z], [.04, .052, .06], { col: BRASS, seg: 6, rings: 4 });   // beam-end caps
    for (let i = 0; i < 12; i++) bx(m, [-.77 + i * .14, FL - .03, zMid], [.138, .06, len], i % 2 ? WOOD : WOOD_L);                                   // floor planks
    bx(m, [0, .60, D.RZ], [1.4, .10, .24], WOOD_D);                                            // rear axle bolster
    for (const s of [-1, 1]) bx(m, [s * .45, .53, D.RZ], [.12, .12, .2], WOOD_D);
    bx(m, [0, .60, D.KPZ], [1.0, .06, .5], WOOD_D);                                            // fifth-wheel plate above the front axle
    // leather suspension straps (thorough-braces) hanging from the rear posts
    for (const s of [-1, 1]) {
      const P = []; for (let i = 0; i <= 8; i++) { const t = i / 8; P.push([s * (.9 + Math.sin(t * PI) * .03), lerp(.95, .72, t) - Math.sin(t * PI) * .05, lerp(-2.05, -1.2, t)]); }
      tube(m, P, [.022, .022, .022, .022, .022, .022, .022, .022, .022], { seg: 5, col: LEATHER });
    }

    /* ---- side walls: carved camwood panels in three bays + driver-deck guard ---- */
    for (const s of [-1, 1]) {
      const F = sideF(s);
      bx(m, [s * (BW - .03), .94, -.585], [.06, .42, 3.12], CAMW);                              // lower wall
      bx(m, [s * (BW - .03), .745, -.585], [.07, .06, 3.14], WOOD_D);                           // sill plank
      bx(m, [s * (BW - .005), 1.17, -.585], [.10, .07, 3.2], WOOD_D);                           // top rail
      for (let i = 0; i < 26; i++) ellipsoid(m, [s * (BW + .05), 1.17, -2.05 + i * .12], [.012, .014, .014], { col: BRASS, seg: 5, rings: 3 });   // brass studs
      BAYS.forEach((zc, bi) => {
        prism(m, rect(zc - .41, .78, zc + .41, 1.12), { ...F, d: .012, col: INDIGO });
        prism(m, rect(zc - .41, 1.09, zc + .41, 1.12), { ...F, d: .018, col: CREAM });
        prism(m, rect(zc - .41, .78, zc + .41, .81), { ...F, d: .018, col: CREAM });
        prism(m, diamond(zc, .95, .25, .155), { ...F, d: .02, w0: .012, col: CREAM });
        prism(m, diamond(zc, .95, .18, .108), { ...F, d: .02, w0: .032, col: CAMW });
        prism(m, diamond(zc, .95, .085, .052), { ...F, d: .02, w0: .052, col: GOLD });
        for (const q of [-1, 1]) { prism(m, diamond(zc + q * .335, .95, .045, .08), { ...F, d: .02, w0: .012, col: bi % 2 ? GOLD : CREAM }); }
        for (let t = 0; t < 7; t++) prism(m, tri(zc - .36 + t * .12, .81, .05, .06), { ...F, d: .014, w0: .012, col: t % 2 ? RED : TEAL });   // teeth along the base
      });
      // driver-deck guard
      bx(m, [s * (BW - .03), .94, 1.5], [.06, .30, 1.1], CAMW);
      for (let t = 0; t < 8; t++) prism(m, tri(1.05 + t * .125, .80, .05, .075), { ...F, d: .018, col: t % 2 ? CREAM : GOLD });
      for (const zz of [1.2, 1.5, 1.8]) prism(m, diamond(zz, .96, .085, .09), { ...F, d: .018, col: zz === 1.5 ? GOLD : CREAM });
      prism(m, rect(.98, 1.07, 2.0, 1.12), { ...F, d: .02, col: WOOD_D });
      bx(m, [s * (BW - .005), 1.12, 1.5], [.10, .06, 1.14], WOOD_D);
    }

    /* ---- turned roof posts ---- */
    POSTZ.forEach(z => {
      for (const s of [-1, 1]) {
        const x = s * .80, y0 = 1.16, y1 = roofY(.8) - .02, L = y1 - y0;
        turned(m, [x, y0, z], 'y', [[0, 0], [.05, 0], [.062, .05], [.062, .09], [.044, .13], [.04, .22], [.052, L * .3], [.064, L * .34], [.052, L * .38], [.04, L * .44], [.04, L * .8], [.052, L * .86], [.066, L * .9], [.05, L * .96], [0, L]],
          { N: 10, col: i => (i.i > 0 && i.i < 13 && (i.r > .055 && i.x > .3 * L && i.x < .4 * L)) ? BRASS : (i.x < .13 || i.x > L * .84) ? CAMW : WOOD });
        A.posts.push([x, y0, z]);
        ellipsoid(m, [x, y1 + .02, z], [.05, .045, .05], { col: BRASS, seg: 7, rings: 5 });
      }
    });

    /* ---- front wall (behind the driver): big carved Ṣàngó panel ---- */
    {
      const z = D.FRONT, pts = [[-BW, .80], [BW, .80]]; for (let k = 0; k <= 8; k++) { const x = BW - 2 * BW * k / 8; pts.push([x, roofY(x) - .10]); }
      const F = { o: [0, 0, z + .03], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1] };
      prism(m, pts, { o: [0, 0, z - .03], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1], d: .06, col: CAMW, back: true });
      prism(m, rect(-BW + .07, 1.02, BW - .07, 2.12), { ...F, d: .01, col: INDIGO });
      prism(m, rect(-BW + .07, 1.02, BW - .07, 1.06), { ...F, d: .018, col: CREAM }); prism(m, rect(-BW + .07, 2.08, BW - .07, 2.12), { ...F, d: .018, col: CREAM });
      for (let t = 0; t < 11; t++) prism(m, tri(-.70 + t * .14, .81, .06, .1), { ...F, d: .018, col: t % 2 ? CREAM : GOLD });
      ose(m, F, 0, 1.12, 1.02, { d: .03, w0: .01 });
      for (const s of [-1, 1]) { eyes(m, F, s * .56, 1.58, .2); prism(m, diamond(s * .56, 1.98, .07, .09), { ...F, d: .02, w0: .01, col: GOLD }); prism(m, diamond(s * .56, 1.16, .07, .08), { ...F, d: .02, w0: .01, col: GOLD }); }
      // driver's high back (rear face) + passengers' front panel
      const G = { o: [0, 0, z - .03], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, -1] };
      prism(m, rect(-.7, 1.0, .7, 1.04), { ...G, d: .012, col: CREAM });
    }

    /* ---- driver's bench (front) ---- */
    {
      const zc = 1.26;
      bx(m, [0, 1.29, zc], [1.5, .055, .48], WOOD_L);
      for (const q of [-1, 1]) {
        ellipsoid(m, [q * .36, 1.345, zc], [.31, .05, .21], { col: q > 0 ? INDIGO : RED, seg: 10, rings: 5 });
        prism(m, [[-.24, 0], [.24, 0], [.24, .52], [.12, .45], [0, .50], [-.12, .45], [-.24, .52]].map(p => [p[0], p[1]]), { o: [q * .74, .80, zc], u: [0, 0, 1], v: [0, 1, 0], n: [q, 0, 0], d: .045, w0: -.02, col: CAMW, back: true });
        prism(m, diamond(0, .30, .12, .14), { o: [q * .74, .80, zc], u: [0, 0, 1], v: [0, 1, 0], n: [q, 0, 0], d: .02, w0: .028, col: CREAM });
      }
      bx(m, [0, 1.04, zc], [1.3, .34, .06], WOOD_D);
      A.driver = { x: 0, y: 1.32, z: zc, yaw: 0 };
    }
    /* footboard (slanted) + carved dash + rein bar */
    {
      bx(m, [0, .98, 1.82], [1.64, .06, .5], WOOD_L, { pitch: -.18 });
      const F = { o: [0, 0, D.DECK + .01], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1] };
      prism(m, rect(-BW, .80, BW, 1.2), { o: [0, 0, D.DECK - .05], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1], d: .06, col: CAMW, back: true });
      prism(m, rect(-BW + .05, .84, BW - .05, 1.16), { ...F, d: .01, col: INDIGO });
      for (const x of [-.52, 0, .52]) eyes(m, F, x, 1.0, .13, [CREAM, CAMW, BRASS, INDIGO]);
      for (const x of [-.26, .26]) prism(m, diamond(x, 1.0, .07, .09), { ...F, d: .02, w0: .01, col: GOLD });
      for (const s of [-1, 1]) { turned(m, [s * .5, 1.2, D.DECK - .02], 'y', [[0, 0], [.04, 0], [.04, .14], [.055, .17], [.04, .2], [0, .2]], { N: 8, col: BRASS }); }
      tube(m, [[-.5, 1.40, D.DECK - .02], [.5, 1.40, D.DECK - .02]], [.022, .022], { seg: 6, col: WOOD_D });                       // rein bar
      A.footboard = { x: 0, y: 1.0, z: 1.82 };
    }

    /* ---- passenger benches (3 rows × 2) ---- */
    BAYS.forEach((zc, bi) => {
      bx(m, [0, 1.195, zc], [1.56, .05, .46], WOOD_L);
      bx(m, [0, 1.17, zc + .22], [1.56, .06, .04], WOOD_D);
      for (const q of [-1, 1]) {
        ellipsoid(m, [q * .37, 1.25, zc], [.31, .05, .2], { col: (bi + (q > 0 ? 1 : 0)) % 2 ? INDIGO : RED, seg: 10, rings: 5 });
        A.seats.push({ x: q * .37, y: 1.22, z: zc, yaw: 0, row: bi, side: q });
        bx(m, [q * .5, 1.0, zc], [.06, .40, .36], WOOD_D);                                    // seat support
        // bench end board (scalloped)
        prism(m, [[-.23, 0], [.23, 0], [.23, .40], [.16, .36], [.10, .40], [.0, .36], [-.10, .40], [-.16, .36], [-.23, .40]], { o: [q * .78, .80, zc], u: [0, 0, 1], v: [0, 1, 0], n: [q, 0, 0], d: .035, w0: -.02, col: CAMW, back: true });
      }
      // backrest (rear face carved)
      const zb = zc - .24, yb = 1.22;
      prism(m, [[-.76, 0], [.76, 0], [.76, .42], [.5, .47], [.2, .50], [0, .52], [-.2, .50], [-.5, .47], [-.76, .42]], { o: [0, yb, zb], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, -1], d: .05, w0: -.025, col: WOOD_L, back: true });
      const G = { o: [0, yb, zb - .03], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, -1] };
      prism(m, rect(-.7, .06, .7, .36), { ...G, d: .008, col: CAMW });
      for (let t = 0; t < 12; t++) prism(m, tri(-.66 + t * .12, .06, .05, .07), { ...G, d: .014, w0: .008, col: (t + bi) % 2 ? CREAM : GOLD });
      for (const x of [-.45, 0, .45]) { prism(m, diamond(x, .26, .075, .075), { ...G, d: .014, w0: .008, col: INDIGO }); prism(m, diamond(x, .26, .035, .035), { ...G, d: .02, w0: .014, col: CREAM }); }
      for (let i = 0; i < 9; i++) ellipsoid(m, [-.64 + i * .16, yb + .485 - Math.abs(i - 4) * .005, zb - .03], [.017, .017, .017], { col: BRASS, seg: 5, rings: 3 });
    });

    /* ---- rear entrance: carved arch (lintel), step ---- */
    {
      const z = D.REAR, pts = [];
      for (let k = 0; k <= 10; k++) { const x = -BW + 2 * BW * k / 10; pts.push([x, 2.0 + .2 * (1 - (x / BW) * (x / BW))]); }
      for (let k = 10; k >= 0; k--) { const x = -BW + 2 * BW * k / 10; pts.push([x, roofY(x) - .06]); }
      prism(m, pts, { o: [0, 0, z + .03], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, -1], d: .06, col: CAMW, back: true });
      const F = { o: [0, 0, z - .03], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, -1] };
      eyes(m, F, 0, 2.43, .17, [CREAM, CAMW, BRASS, INDIGO]);
      for (const s of [-1, 1]) {
        eyes(m, F, s * .52, 2.34, .095, [CREAM, INDIGO, GOLD]);
        prism(m, diamond(s * .30, 2.36, .06, .095), { ...F, d: .018, col: GOLD });
        prism(m, diamond(s * .72, 2.18, .045, .06), { ...F, d: .018, col: CREAM });
      }
      for (let t = 0; t < 12; t++) { const x = -.66 + t * .12; prism(m, tri(x, 2.0 + .2 * (1 - (x / BW) * (x / BW)) - .002, .05, -.075).map(p => p), { ...F, d: .016, col: t % 2 ? RED : INDIGO }); }
      // step
      bx(m, [0, .50, -2.36], [1.1, .06, .30], WOOD_L);
      for (const s of [-1, 1]) bx(m, [s * .5, .60, -2.28], [.07, .24, .08], WOOD_D);
      for (let t = 0; t < 8; t++) prism(m, tri(-.49 + t * .14, .47, .06, .05), { o: [0, 0, -2.51], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, -1], d: .01, col: t % 2 ? CREAM : INDIGO });
      prism(m, rect(-.55, .46, .55, .53), { o: [0, 0, -2.51], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, -1], d: .02, col: CAMW });
      // rear tail-lamp gourd + oil lamp on the rear posts
      ellipsoid(m, [.88, 1.62, -2.18], [.075, .085, .075], { col: [.80, .55, .22], seg: 8, rings: 6 });
      ellipsoid(m, [.88, 1.72, -2.18], [.045, .06, .045], { col: [.80, .55, .22], seg: 8, rings: 5 });
      tube(m, [[.80, 2.0, -2.14], [.88, 1.9, -2.18], [.88, 1.78, -2.18]], [.01, .01, .01], { seg: 4, col: LEATHER });
      ellipsoid(m, [-.9, 1.62, -2.18], [.06, .075, .06], { col: BRASS, seg: 8, rings: 5 });   // brass oil lamp
      ellipsoid(m, [-.9, 1.60, -2.18], [.035, .05, .035], { col: [1, .82, .35], seg: 6, rings: 4 });
    }

    /* ---- roof: indigo adire cloth on wooden hoops, red/gold bands, cowrie-and-flap fringe ---- */
    {
      const NX = 46, NZ = 74, W = D.RW, z0 = D.ZR0, z1 = D.ZR1, v0 = nv(m), i0 = m.i.length;
      const cell = .56;
      for (let j = 0; j <= NZ; j++) for (let i = 0; i <= NX; i++) {
        const x = -W + 2 * W * i / NX, z = lerp(z0, z1, j / NZ), y = roofY(x) + .014;
        const r = Math.floor((z + 9) / cell), cz = (r + .5) * cell - 9, cx = Math.round((x - (r % 2 ? cell / 2 : 0)) / cell) * cell + (r % 2 ? cell / 2 : 0);
        const dd = Math.hypot(x - cx, z - cz);
        let c = INDIGO_D;
        c = mixc(c, INDIGO, sstep(.14, .24, dd) * .6);
        c = mixc(c, PALE, sstep(.08, .105, dd) * (1 - sstep(.135, .165, dd)) * .95);
        c = mixc(c, CREAM, 1 - sstep(.035, .06, dd));
        const ax = Math.abs(x), ez = Math.min(z - z0, z1 - z);
        c = mixc(c, CAMW, sstep(.84, .87, ax) * (1 - sstep(.95, .97, ax)));
        c = mixc(c, GOLD, sstep(.965, .985, ax) * 1);
        c = mixc(c, CAMW, (1 - sstep(.16, .19, ez)));
        c = mixc(c, GOLD, (1 - sstep(.035, .055, ez)));
        const id = vert(m, x, y, z, c); m.n[id * 3 + 1] = 1;
      }
      for (let j = 0; j < NZ; j++) for (let i = 0; i < NX; i++) { const a = v0 + j * (NX + 1) + i, b = a + 1, c = a + NX + 1, d = c + 1; m.i.push(a, c, b, b, c, d); }
      R.normals(m, v0, i0, k => [0, 1, 0]);
      // wooden hoops under the cloth
      [-2.30, -2.08, -1.58, -1.08, -.6, -.1, .4, .92, 1.1].forEach(z => {
        const P = []; for (let k = 0; k <= 14; k++) { const x = -W + .03 + (2 * W - .06) * k / 14; P.push([x, roofY(x) - .028, z]); }
        tube(m, P, [.026, .026, .026, .026, .026, .026, .026, .026, .026, .026, .026, .026, .026, .026, .026], { seg: 5, col: WOOD_D });
      });
      for (const s of [-1, 1]) { tube(m, [[s * .8, roofY(.8) - .05, D.ZR0 + .05], [s * .8, roofY(.8) - .05, D.ZR1 - .02]], [.04, .04], { seg: 6, col: WOOD_D }); }  // wall plates
      tube(m, [[0, roofY(0) - .03, D.ZR0], [0, roofY(0) - .03, D.ZR1]], [.032, .032], { seg: 6, col: WOOD_D });                                         // ridge pole
      // edge trims
      for (const s of [-1, 1]) tube(m, [[s * W, D.EAVE + .012, D.ZR0], [s * W, D.EAVE + .012, D.ZR1]], [.03, .03], { seg: 6, col: CAMW });
      for (const z of [D.ZR0, D.ZR1]) { const P = []; for (let k = 0; k <= 14; k++) { const x = -W + 2 * W * k / 14; P.push([x, roofY(x) + .012, z]); } tube(m, P, new Array(15).fill(.03), { seg: 6, col: CAMW }); }
      // fringe: coloured flaps with a cowrie at each tip
      const flap = (pts, n, col) => poly3(m, pts, n, col), FC = [RED, CREAM, INDIGO, GOLD];
      const cowrie = (x, y, z) => { ellipsoid(m, [x, y, z], [.017, .026, .017], { col: CREAM, seg: 6, rings: 4 }); ellipsoid(m, [x, y + .004, z], [.006, .02, .018], { col: [.55, .42, .28], seg: 4, rings: 3 }); };
      for (const s of [-1, 1]) { const nF = 17; for (let t = 0; t < nF; t++) { const z = lerp(z0 + .1, z1 - .1, t / (nF - 1)), hw = (z1 - z0 - .2) / (nF - 1) / 2 * .96, c = FC[t % 4];
        flap([[s * W, D.EAVE, z - hw], [s * W, D.EAVE, z + hw], [s * W, D.EAVE - .2, z]], [s, 0, 0], c); cowrie(s * W, D.EAVE - .235, z); } }
      for (const zz of [[z1, 1], [z0, -1]]) { const nF = 11; for (let t = 0; t < nF; t++) {
        const xa = lerp(-W + .1, W - .1, t / (nF - 1)), hw = (2 * W - .2) / (nF - 1) / 2 * .96, c = FC[(t + 1) % 4], ya = roofY(xa);
        flap([[xa - hw, roofY(xa - hw), zz[0]], [xa + hw, roofY(xa + hw), zz[0]], [xa, ya - .2, zz[0]]], [0, 0, zz[1]], c); cowrie(xa, ya - .235, zz[0]); } }
      // roof crest: Ṣàngó's double axe at the front, gold finials at the back
      const FF = { o: [0, 0, D.ZR1 - .06], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, 1] };
      ose(m, FF, 0, roofY(0) - .02, .55, { d: .02, back: true, w0: -.01 });
      for (const q of [-1, 1]) ose(m, { o: [0, 0, D.ZR1 - .06], u: [1, 0, 0], v: [0, 1, 0], n: [0, 0, -1] }, 0, roofY(0) - .02, .55, { d: .0, w0: -.04, back: false, blade: GOLD, edge: INDIGO });
      ellipsoid(m, [0, roofY(0) + .08, D.ZR0 + .1], [.085, .085, .085], { col: GOLD, seg: 10, rings: 7 });
      ellipsoid(m, [0, roofY(0) + .17, D.ZR0 + .1], [.045, .06, .045], { col: BRASS, seg: 8, rings: 5 });
      for (let i = 0; i < 8; i++) { const a = TAU * i / 8; ellipsoid(m, [Math.cos(a) * .1, roofY(0) + .08 + Math.sin(a) * .1, D.ZR0 + .1], [.014, .02, .014], { col: CREAM, seg: 5, rings: 3 }); }
    }

    /* ---- cowrie string curtains across the rear arch + bead strings ---- */
    for (let s = -2; s <= 2; s++) {
      const x = s * .28, y0 = 2.0 + .2 * (1 - (x / D.BW) * (x / D.BW)) - .01;
      for (let q = 0; q < 6; q++) ellipsoid(m, [x, y0 - .07 - q * .062, D.REAR - .075], [.015, .024, .015], { col: q % 2 ? CREAM : [.45, .55, .95], seg: 5, rings: 3 });
    }
    A.size = { w: 2 * D.TRACK + .12, l: D.DECK + 2.5, h: roofY(0) + .3 };
    return { mesh: m, anchors: A };
  }

  /* ================================================================= LOW-POLY SHADOW CASTER (local space) ================================================================= */
  function shadowBoxes() {
    const m = MB(), b = (c, s, o) => box(m, c, s, Object.assign({ col: [0, 0, 0] }, o));
    b([0, .95, -.05], [1.76, .60, 4.2]); if (!PLAIN) b([0, 2.58, -.6], [2.04, .22, 3.5]);
    if (!PLAIN) for (const z of POSTZ) for (const s of [-1, 1]) b([s * .8, 1.8, z], [.1, 1.2, .1]);
    for (const s of [-1, 1]) {
      for (const [R_, z, sp] of [[D.RR, D.RZ, 1], [D.FR, D.KPZ, 1]]) { b([s * D.TRACK, R_, z], [.14, R_ * 1.86, R_ * 1.86]); b([s * D.TRACK, R_, z], [.14, R_ * 1.5, R_ * 1.5], { pitch: PI / 4 }); }
      b([s * D.SHAFT_X, .95, D.KPZ + 1.6], [.1, .1, 3.2]);
    }
    return m;
  }

  /* ================================================================= PURE GEOMETRY (also used by tests / previews) ================================================================= */
  /* PAINTS (Ọjà Ìlú cart skins): the shared palette arrays (plus the wood family) are recoloured in place while the model is generated. */
  const PAINT_REF = { WOOD, WOOD_D, WOOD_L, CAMW, RED, INDIGO, INDIGO_D, PALE, TEAL, GOLD, BRASS, CREAM };
  const PAINTS = {
    indigo: { WOOD: [.20, .27, .52], WOOD_D: [.12, .16, .36], WOOD_L: [.30, .40, .70], CAMW: [.14, .22, .55], RED: [.92, .90, .82], INDIGO: [.10, .16, .45], INDIGO_D: [.06, .10, .30], PALE: [.80, .86, .98], TEAL: [.35, .65, .75], GOLD: [.95, .78, .38], BRASS: [.88, .66, .26], CREAM: [.96, .93, .84] },
    ebony:  { WOOD: [.14, .11, .10], WOOD_D: [.07, .05, .05], WOOD_L: [.24, .18, .15], CAMW: [.11, .09, .09], RED: [.72, .52, .20], INDIGO: [.12, .12, .16], INDIGO_D: [.07, .07, .10], PALE: [.55, .55, .60], TEAL: [.20, .32, .32], GOLD: [.97, .77, .30], BRASS: [.90, .66, .22], CREAM: [.85, .80, .70] },
    gold:   { WOOD: [.74, .56, .22], WOOD_D: [.48, .34, .12], WOOD_L: [.90, .74, .38], CAMW: [.62, .10, .10], RED: [.70, .10, .12], INDIGO: [.55, .08, .12], INDIGO_D: [.38, .05, .08], PALE: [.98, .90, .70], TEAL: [.15, .45, .40], GOLD: [1, .84, .36], BRASS: [.98, .80, .34], CREAM: [.99, .95, .82] }
  };
  function geometry(variant, paint) {
    KIND = variant === 'load' || variant === 'long' || variant === 'two' ? variant : ''; PLAIN = variant === 'starter' || !!KIND;
    const sw = PAINTS[paint] || null, keep = {};
    if (sw) Object.keys(sw).forEach(k => { keep[k] = PAINT_REF[k].slice(); PAINT_REF[k].splice(0, 3, ...sw[k]); });
    try { return geometryRaw(variant); } finally { PLAIN = false; KIND = ''; Object.keys(keep).forEach(k => PAINT_REF[k].splice(0, 3, ...keep[k])); }
  }
  /* NAME BOARD: the player's name painted on a plank on both sides and the tail of the cart (flat planes with a canvas texture, parented to the body). */
  const BOARD_LOOK = { '': ['#8a5a2b', '#5a3416', '#fbf3dc', '#d8a23a'], indigo: ['#1d2a6b', '#0e1640', '#fbf3dc', '#f1cf7e'], ebony: ['#1b1513', '#0a0706', '#f1cf7e', '#d8a23a'], gold: ['#8c1a1f', '#5a0e12', '#ffe39a', '#f1cf7e'] };
  function makeBoard(B, scene, name, paint, bodyN) {
    const L = BOARD_LOOK[paint] || BOARD_LOOK[''], tex = new B.DynamicTexture('cartBoardTex', { width: 1024, height: 256 }, scene, true), c = tex.getContext();
    /* draw(name): "Word" paints one big line (the player's name); "Word|Meaning" paints the word with its English meaning under it (Yoruba sayings on road riders' carts) */
    const draw = nm => {
      c.setTransform(2, 0, 0, 2, 0, 0);
      const parts = String(nm).split('|'), main = parts[0], sub = parts[1] || '';
      const g = c.createLinearGradient(0, 0, 0, 128); g.addColorStop(0, L[0]); g.addColorStop(1, L[1]); c.fillStyle = g; c.fillRect(0, 0, 512, 128);
      c.strokeStyle = L[3]; c.lineWidth = 6; c.strokeRect(8, 8, 496, 112); c.lineWidth = 2; c.strokeRect(17, 17, 478, 94);
      c.fillStyle = L[3]; for (const x of [34, 478]) { c.beginPath(); c.ellipse(x, 64, 7, 11, 0, 0, 7); c.fill(); }
      c.textAlign = 'center'; c.textBaseline = 'middle';
      let fs = sub ? 64 : 72; const lim = sub ? 30 : 26, y0 = sub ? 50 : 67;
      for (; fs > lim; fs -= 4) { c.font = '800 ' + fs + 'px Fraunces, Georgia, serif'; if (c.measureText(main).width < 390) break; }
      c.lineJoin = 'round'; if (sub) { c.lineWidth = 7; c.strokeStyle = 'rgba(0,0,0,.65)'; c.strokeText(main, 256, y0); }
      c.fillStyle = 'rgba(0,0,0,.45)'; c.fillText(main, 258, y0 + 3); c.fillStyle = L[2]; c.fillText(main, 256, y0);
      if (sub) {
        let f2 = 28; for (; f2 > 14; f2 -= 2) { c.font = '600 ' + f2 + 'px Nunito, Georgia, serif'; if (c.measureText(sub).width < 400) break; }
        c.lineWidth = 5; c.strokeStyle = 'rgba(0,0,0,.6)'; c.strokeText(sub, 256, 89); c.fillStyle = '#fff6d8'; c.fillText(sub, 256, 89);
      }
      tex.update();
    };
    draw(name);
    const mt = new B.StandardMaterial('cartBoardMat', scene); mt.disableLighting = true; mt.emissiveTexture = tex; mt.diffuseColor = B.Color3.Black(); mt.specularColor = B.Color3.Black(); mt.backFaceCulling = true;
    const mk = (w, h, x, y, z, ry) => { const p = B.MeshBuilder.CreatePlane('cartBoard', { width: w, height: h }, scene); p.material = mt; p.parent = bodyN; p.position.set(x, y, z); p.rotation.y = ry; p.isPickable = false; return p; };
    const planes = [mk(1.2, .30, .915, .93, .03, -Math.PI / 2), mk(1.2, .30, -.915, .93, .03, Math.PI / 2), mk(1.6, .40, 0, .98, D.REAR - .06, 0)];
    return { tex, mt, planes, draw };
  }
  function geometryRaw(variant) {
    const body = buildBody(), g = {
      body: body.mesh, frontFrame: frontFrame(), frontWheels: wheelPair(D.FR, 10), rearWheels: wheelPair(D.RR, 12), shadow: shadowBoxes(), anchors: body.anchors, D
    };
    g.rearWheels2 = KIND === 'long' ? wheelPair(D.RR, 12) : null;                    // the long cart rides on a second rear axle
    g.harness = harness();
    g.anchors.horse = [0, 0, D.HORSE_Z];                 // horse model origin, in FRONT-FRAME space (frame origin = king-pin at ground)
    g.anchors.horseWorldZ = D.KPZ + D.HORSE_Z;    // same point in cart space when the cart is driving straight
    g.anchors.kingPin = [0, 0, D.KPZ];
    g.anchors.rearAxle = [0, D.RR, D.RZ];
    g.anchors.entry = [0, D.FLOOR, D.REAR - .3];
    g.anchors.step = [0, .53, -2.36];
    g.variant = KIND || (variant === 'starter' ? 'starter' : 'royal');
    g.stats = { body: nv(g.body), frontFrame: nv(g.frontFrame), frontWheels: nv(g.frontWheels), rearWheels: nv(g.rearWheels) };
    g.stats.total = g.stats.body + g.stats.frontFrame + g.stats.frontWheels + g.stats.rearWheels;
    g.stats.tris = (g.body.i.length + g.frontFrame.i.length + g.frontWheels.i.length + g.rearWheels.i.length) / 3;
    return g;
  }


  /* ================================================================= HARNESS (horse space) =================================================================
     Wooden hames-collar, leather tugs to the shafts, girth tugs and hold-back (breeching) straps. Built in the horse's REST model space
     (+z forward, ground y = 0) and glued to three horse bones at run time, so it moves with the neck, barrel and hindquarters. */
  const shaftY = zh => .74 + .26 * clamp((zh + D.HORSE_Z + .2) / (D.SHAFT_L + .2), 0, 1);     // draw-shaft height at horse-space z
  const shaftPt = (zh, s) => [s * D.SHAFT_X, shaftY(zh), zh];
  function ring(m, c, ax, ay, rx, ry, r, col, N) {        // closed loop in the plane spanned by ax (x-ish) and ay
    const P = [], R = []; N = N || 28;
    for (let k = 0; k <= N; k++) { const t = TAU * k / N, cx = Math.cos(t) * rx, cy = Math.sin(t) * ry; P.push([c[0] + ax[0] * cx + ay[0] * cy, c[1] + ax[1] * cx + ay[1] * cy, c[2] + ax[2] * cx + ay[2] * cy]); R.push(r); }
    tube(m, P, R, { seg: 6, col });
  }
  function shaftLoop(m, p, s) {                              // leather wrap + brass stud where a strap meets the shaft
    ring(m, p, [0, 1, 0], [0, 0, 1], .05, .05, .011, LEATHER, 10);
    ellipsoid(m, [p[0] - s * .004, p[1] + .045, p[2]], [.016, .016, .016], { col: BRASS, seg: 6, rings: 4 });
  }
  function harness() {
    const C = [0, 1.285, .70], U = [1, 0, 0], Vv = [0, .69, -.73];                 // collar centre + plane (tilted to follow the neck base)
    const collar = MB(), tugs = MB(), breech = MB();
    ring(collar, C, U, Vv, .24, .345, .042, INDIGO_D, 28);                          // padded leather collar
    ring(collar, C, U, Vv, .285, .385, .03, WOOD_L, 30);                            // wooden hames
    ring(collar, C, U, Vv, .262, .365, .012, hb(), 30);                            // brass binding between the two
    ellipsoid(collar, [0, C[1] + Vv[1] * .385, C[2] + Vv[2] * .385], [.04, .04, .04], { col: hb(), seg: 8, rings: 5 });   // hame-top knob
    for (const s of [-1, 1]) ellipsoid(collar, [s * .29, C[1], C[2]], [.028, .04, .04], { col: hb(), seg: 8, rings: 5 });  // trace bosses
    for (const s of [-1, 1]) {
      // collar boss → shaft-tip tug
      const a = [s * .29, C[1], C[2]], b = shaftPt(1.0, s), mid = [(a[0] + b[0]) / 2 + s * .02, (a[1] + b[1]) / 2 - .04, (a[2] + b[2]) / 2];
      tube(tugs, [a, mid, b], [.014, .014, .014], { seg: 5, col: LEATHER }); shaftLoop(tugs, b, s);
      // girth ring → shaft tug
      const g0 = [s * .235, .945, .14], g1 = shaftPt(.14, s);
      ellipsoid(tugs, g0, [.025, .025, .025], { col: hb(), seg: 6, rings: 4 });
      tube(tugs, [g0, [(g0[0] + g1[0]) / 2, (g0[1] + g1[1]) / 2 - .01, .14], g1], [.015, .015, .015], { seg: 5, col: LEATHER }); shaftLoop(tugs, g1, s);
      // hold-back strap: hindquarters → shaft
      const h0 = [s * .165, 1.24, -.80], h1 = shaftPt(-.62, s);
      ellipsoid(breech, h0, [.026, .026, .026], { col: hb(), seg: 6, rings: 4 });
      tube(breech, [h0, [s * .29, 1.06, -.72], h1], [.015, .015, .015], { seg: 5, col: LEATHER }); shaftLoop(breech, h1, s);
    }
    return { collar, tugs, breech };
  }

  /* ================================================================= BABYLON LAYER ================================================================= */
  const VS = `precision highp float;
attribute vec3 position;attribute vec3 normal;attribute vec4 color;attribute vec2 uv;
uniform mat4 world;uniform mat4 viewProjection;uniform vec3 camPos;
varying vec3 vN;varying vec3 vC;varying vec2 vUV;varying float vD;varying vec3 vV;
void main(){
  vec4 wp=world*vec4(position,1.);
  vC=color.rgb;vN=normalize((world*vec4(normal,0.)).xyz);
  vUV=uv;
  vD=length(wp.xyz-camPos);vV=camPos-wp.xyz;
  gl_Position=viewProjection*wp;
}`;
  /* identical lighting model to the rider / villagers (banded sun, hemisphere ambient, rim, haze, exp2 fog) */
  const FS = `precision highp float;varying vec3 vN;varying vec3 vC;varying vec2 vUV;varying float vD;varying vec3 vV;
uniform sampler2D tex;uniform vec3 toSun;uniform vec3 sunCol;uniform vec3 skyCol;uniform vec3 gndCol;uniform vec3 fogCol;uniform vec3 hazeCol;uniform float fogD;uniform float hitK;
void main(){
  vec3 alb=texture2D(tex,vUV).rgb*vC;
  vec3 N=normalize(vN);if(!gl_FrontFacing)N=-N;
  float ndl=dot(N,toSun);
  float band=.5*smoothstep(-.05,.12,ndl)+.5*smoothstep(.28,.45,ndl);
  float lit=mix(band,clamp(ndl,0.,1.),.22);
  vec3 hemi=mix(gndCol,skyCol,N.y*.5+.5);
  vec3 col=alb*(hemi*1.08+sunCol*lit*1.05);
  col=mix(col,col*vec3(.80,.74,1.),(1.-lit)*.4);
  vec3 V=normalize(vV);
  float rim=pow(1.-clamp(dot(N,V),0.,1.),3.)*smoothstep(-.3,.5,ndl)*.24;
  col+=sunCol*alb*rim*1.3;
  float sp=pow(clamp(dot(N,normalize(toSun+V)),0.,1.),28.)*.10*step(.3,lit);
  col+=sunCol*sp;
  col=mix(col,hazeCol,smoothstep(300.,1500.,vD)*.55);
  col=mix(col,vec3(1.,.26,.16),hitK*.62);
  float f=1.-exp(-fogD*fogD*vD*vD);
  gl_FragColor=vec4(mix(col,fogCol,f),1.);
}`;

  function woodTexture(scene) {   // painterly brush strokes with a faint grain, like the rider's, so the cart sits in the same world
    const B = root.BABYLON, S = 128, t = new B.DynamicTexture('cartBrush', { width: S, height: S }, scene, true), g = t.getContext();
    g.fillStyle = '#f4ecde'; g.fillRect(0, 0, S, S); g.lineCap = 'round';
    for (let i = 0; i < 300; i++) {
      const x = Math.random() * S, y = Math.random() * S, a = Math.random() * PI, l = 4 + Math.random() * 14, light = Math.random() < .5;
      g.strokeStyle = light ? 'rgba(255,252,240,.30)' : 'rgba(110,86,60,.16)'; g.lineWidth = 1.2 + Math.random() * 3;
      for (const dx of [-S, 0, S]) for (const dy of [-S, 0, S]) { g.beginPath(); g.moveTo(x + dx, y + dy); g.lineTo(x + dx + Math.cos(a) * l, y + dy + Math.sin(a) * l); g.stroke(); }
    }
    for (let i = 0; i < 26; i++) { const y = Math.random() * S; g.strokeStyle = 'rgba(95,70,45,.10)'; g.lineWidth = 1; g.beginPath(); g.moveTo(0, y); g.lineTo(S, y + (Math.random() - .5) * 6); g.stroke(); }
    t.wrapU = t.wrapV = B.Texture.WRAP_ADDRESSMODE; t.anisotropicFilteringLevel = 2; t.update(); return t;
  }

  function toMesh(B, scene, name, g, mat, parent) {
    const n = nv(g), C = new Float32Array(n * 4), UV = new Float32Array(n * 2);
    for (let k = 0; k < n; k++) {
      C[k * 4] = g.c[k * 3]; C[k * 4 + 1] = g.c[k * 3 + 1]; C[k * 4 + 2] = g.c[k * 3 + 2]; C[k * 4 + 3] = 1;
      const x = g.p[k * 3], y = g.p[k * 3 + 1], z = g.p[k * 3 + 2]; UV[k * 2] = x * 1.7 + z * .9; UV[k * 2 + 1] = y * 2.6;
    }
    const vd = new B.VertexData(); vd.positions = new Float32Array(g.p); vd.normals = new Float32Array(g.n); vd.colors = C; vd.uvs = UV;
    vd.indices = n > 65000 ? new Uint32Array(g.i) : new Uint16Array(g.i);
    const mesh = new B.Mesh(name, scene); vd.applyToMesh(mesh, false);
    mesh.material = mat; mesh.isPickable = false; mesh.parent = parent || null; mesh.alwaysSelectAsActiveMesh = true;
    return mesh;
  }

  /* build(scene, World, opts) → cart.  opts: { x, z, yaw, visible }.  World supplies height() and sunDir (both optional → flat ground / default sun). */
  function build(scene, World, opts) {
    const B = root.BABYLON; if (!B) throw new Error('OYOCart.build: Babylon.js is not loaded');
    opts = opts || {}; World = World || {};
    const variant = opts.variant || (root.OYOCartSel ? root.OYOCartSel() : 'starter'), eq = root.OYOCartPaint ? root.OYOCartPaint() : { paint: '', name: '' };
    const paintId = 'paint' in opts ? opts.paint : eq.paint, boardName = 'board' in opts ? opts.board : eq.name, g = geometry(variant, paintId), A = g.anchors;
    const fogC = scene.fogColor ? new B.Vector3(scene.fogColor.r, scene.fogColor.g, scene.fogColor.b) : new B.Vector3(.8, .7, .6);
    const sun = World.sunDir || new B.Vector3(.55, .55, -.5).normalize();

    B.Effect.ShadersStore.oyoCartVertexShader = VS; B.Effect.ShadersStore.oyoCartFragmentShader = FS;
    const mat = new B.ShaderMaterial('cartMat', scene, { vertex: 'oyoCart', fragment: 'oyoCart' }, {
      attributes: ['position', 'normal', 'color', 'uv'], uniforms: ['world', 'viewProjection', 'camPos', 'toSun', 'sunCol', 'skyCol', 'gndCol', 'fogCol', 'hazeCol', 'fogD', 'hitK'], samplers: ['tex']
    });
    mat.setTexture('tex', woodTexture(scene)); mat.setVector3('toSun', sun); mat.setVector3('sunCol', new B.Vector3(.85, .73, .53)); mat.setVector3('skyCol', new B.Vector3(.58, .54, .47));
    mat.setVector3('gndCol', new B.Vector3(.42, .27, .2)); mat.setVector3('fogCol', fogC); mat.setVector3('hazeCol', new B.Vector3(.93, .84, .64)); mat.setFloat('fogD', scene.fogDensity || 0);
    mat.setVector3('camPos', new B.Vector3(0, 0, 0)); mat.setFloat('hitK', 0); mat.backFaceCulling = false;
    mat.onError = (e, errs) => console.warn('Cart shader error', errs);

    // node tree:  root → bodyNode → body mesh
    //                  → frontSteer (king-pin) → frontFrame mesh, frontSpin → frontWheels mesh
    //                  → rearSpin → rearWheels mesh
    const rootN = new B.TransformNode('cartRoot', scene), bodyN = new B.TransformNode('cartBody', scene), frontSteer = new B.TransformNode('cartFrontSteer', scene);
    const frontSpin = new B.TransformNode('cartFrontSpin', scene), rearSpin = new B.TransformNode('cartRearSpin', scene), shaftN = new B.TransformNode('cartShafts', scene);
    bodyN.parent = rootN; frontSteer.parent = rootN; rearSpin.parent = rootN; frontSpin.parent = frontSteer;
    shaftN.parent = frontSteer; shaftN.position.set(0, D.FR, 0);      // shafts swing up/down about the front axle (follow the horse); wheels stay on the ground
    frontSteer.position.set(0, 0, D.KPZ); frontSpin.position.set(0, D.FR, 0); rearSpin.position.set(0, D.RR, D.RZ);
    const rearSpin2 = g.rearWheels2 ? new B.TransformNode('cartRearSpin2', scene) : null; if (rearSpin2) { rearSpin2.parent = rootN; rearSpin2.position.set(0, D.RR, D.RZ - 2.45); }
    const meshes = {
      body: toMesh(B, scene, 'cartBodyMesh', g.body, mat, bodyN), frontFrame: toMesh(B, scene, 'cartFrontFrame', g.frontFrame, mat, shaftN),
      frontWheels: toMesh(B, scene, 'cartFrontWheels', g.frontWheels, mat, frontSpin), rearWheels: toMesh(B, scene, 'cartRearWheels', g.rearWheels, mat, rearSpin)
    };
    if (rearSpin2) meshes.rearWheels2 = toMesh(B, scene, 'cartRearWheels2', g.rearWheels2, mat, rearSpin2);

    meshes.frontFrame.position.y = -D.FR;
    let boardObj = null; if (boardName) { try { boardObj = makeBoard(B, scene, boardName, paintId || '', bodyN); } catch (e) { console.warn('Name board skipped', e); } }

    // (no projected ground shadow under the cart)

    // simple brass bell on a bracket above the left post of the front rein bar; cart.ringBell() swings it (the HUD BELL button / B key)
    const brass = new B.StandardMaterial('cartBellMat', scene); brass.diffuseColor = new B.Color3(.86, .62, .16); brass.emissiveColor = new B.Color3(.42, .29, .05); brass.specularColor = new B.Color3(.5, .45, .3);
    const bellPivot = new B.TransformNode('cartBell', scene); bellPivot.parent = bodyN; bellPivot.position.set(-.36, 1.74, D.DECK - .02);
    { const part = (m, par, x, y) => { m.material = brass; m.parent = par; m.position.set(x, y, 0); m.isPickable = false; return m; };
      part(B.MeshBuilder.CreateCylinder('bellPost', { diameter: .04, height: .36, tessellation: 8 }, scene), bodyN, -.5, 1.58).position.z = D.DECK - .02;
      const arm = part(B.MeshBuilder.CreateCylinder('bellArm', { diameter: .035, height: .16, tessellation: 8 }, scene), bodyN, -.43, 1.74); arm.position.z = D.DECK - .02; arm.rotation.z = Math.PI / 2;      // static bracket arm (does not swing)
      part(B.MeshBuilder.CreateSphere('bellKnob', { diameter: .08, segments: 6 }, scene), bellPivot, 0, -.03);
      part(B.MeshBuilder.CreateCylinder('bellBody', { diameterTop: .10, diameterBottom: .30, height: .24, tessellation: 14 }, scene), bellPivot, 0, -.16);
      part(B.MeshBuilder.CreateTorus('bellLip', { diameter: .30, thickness: .035, tessellation: 14 }, scene), bellPivot, 0, -.285);
      part(B.MeshBuilder.CreateSphere('bellClap', { diameter: .075, segments: 6 }, scene), bellPivot, 0, -.32); }
    let bellT = 9, bellAmp = 0;
    let hitShown = 0;

    const hgt = World.height ? (x, z) => World.height(x, z) : () => 0;
    const cart = {
      built: true, variant: g.variant, root: rootN, body: bodyN, frontSteer, frontSpin, rearSpin, meshes, mat, anchors: A, geo: g, stats: g.stats, dims: D,
      state: { x: 0, z: 0, y: 0, yaw: 0, pitch: 0, roll: 0, speed: 0, steer: 0, spinF: 0, spinR: 0, bob: 0, hitched: false, hitchSteer: 0, shaftPitch: 0, shadowDirty: true }, enabled: true
    };

    /* world → ground fitting: the four wheel contacts give height, pitch and roll */
    cart.place = function (x, z, yaw) {
      const s = cart.state, sn = Math.sin(yaw), cs = Math.cos(yaw), T = D.TRACK;
      const at = (lx, lz) => hgt(x + lx * cs + lz * sn, z - lx * sn + lz * cs);         // local (right, forward) → world
      const hRL = at(-T, D.RZ), hRR = at(T, D.RZ), hFL = at(-T, D.KPZ), hFR = at(T, D.KPZ);
      const hR = (hRL + hRR) / 2, hF = (hFL + hFR) / 2, wb = D.KPZ - D.RZ;
      s.x = x; s.z = z; s.yaw = yaw; s.y = (hR + hF) / 2;                                 // origin = middle of the wheelbase, wheels touch the ground
      s.pitch = Math.atan2(hF - hR, wb); s.roll = Math.atan2((hRR + hFR) / 2 - (hRL + hFL) / 2, 2 * T);
      s.gF = (hF - hR) / wb; s.gR = ((hRR + hFR) / 2 - (hRL + hFL) / 2) / (2 * T);       // ground slope forward / to the right
      if (cart.jolt > 0) {                                                                 // pothole jolt: hop, rock side to side, pitch (decays in ~1 s)
        const t = (performance.now() - (cart.joltT0 || 0)) / 1000, k = Math.max(0, 1 - t / 1.1); cart.jolt = k;
        if (k > 0) { s.y += Math.abs(Math.sin(t * 17)) * .3 * k; s.roll += Math.sin(t * 26) * .14 * k; s.pitch += Math.sin(t * 21) * .09 * k; }
      }
      if (cart.hitOn) {                                                                    // obstacle hit: a quick shudder (the red flash is driven in applyPose)
        const t = (performance.now() - (cart.hitT0 || 0)) / 1000, k = Math.max(0, 1 - t / .5);
        if (k > 0) { s.y += Math.abs(Math.sin(t * 34)) * .1 * k; s.roll += Math.sin(t * 55) * .11 * k; s.pitch += Math.sin(t * 40) * .05 * k; }
      }
      if (cart.crashK) { s.roll += cart.crashRoll || 0; s.pitch += cart.crashPitch || 0; s.y += cart.crashY || 0; }          // Endless Run crash: tips onto its side
      applyPose();
    };
    function applyPose() {
      const s = cart.state;
      if (cart.hitOn || hitShown) {                                                        // obstacle hit: the whole cart blinks red-hot for a moment, then settles
        let hv = 0; if (cart.hitOn) { const t = (performance.now() - (cart.hitT0 || 0)) / 1000; hv = Math.max(0, 1 - t / .7) * (.55 + .45 * Math.cos(t * 26)); if (t > .7) cart.hitOn = false; }
        if (Math.abs(hv - hitShown) > .01 || (!hv && hitShown)) { hitShown = hv; mat.setFloat('hitK', hv); }
      }
      rootN.position.set(s.x, s.y, s.z); rootN.rotation.set(-s.pitch, s.yaw, s.roll);
      bodyN.position.y = s.bob; bodyN.rotation.z = s.bob * .6;
      frontSteer.rotation.y = s.hitched ? s.hitchSteer : s.steer * D.MAXSTEER; shaftN.rotation.x = -s.shaftPitch; frontSpin.rotation.x = s.spinF; rearSpin.rotation.x = s.spinR; if (rearSpin2) rearSpin2.rotation.x = s.spinR;
      s.shadowDirty = true;
    }
    /* per-frame: speed in m/s (>0 forward), steer in -1..1. Spins the wheels, adds a little suspension bob. Cheap; safe to call every frame or never. */
    cart.update = function (dt, speed, steer) {
      const s = cart.state; if (!cart.enabled) return;
      if (speed != null) s.speed = speed; if (steer != null) s.steer = clamp(steer, -1, 1);
      s.spinR += s.speed * dt / D.RR; s.spinF += s.speed * dt / D.FR;
      s.spinR %= TAU; s.spinF %= TAU;
      const sp = clamp(Math.abs(s.speed) / 8, 0, 1); s.phase = (s.phase || 0) + dt * (4 + 10 * sp);
      s.bob = sp * .012 * Math.sin(s.phase) * (1 + .4 * Math.sin(s.phase * .37));
      applyPose();
    };
    /* the body mesh origin is the axle mid-point on the ground; shift the model so (0,0,0) of cart space is under the middle of the wheelbase */
    meshes.body.parent = bodyN; bodyN.position.z = 0;
    [bodyN, frontSteer, rearSpin].concat(rearSpin2 ? [rearSpin2] : []).forEach(n => { n.position.z = n.position.z - (D.KPZ + D.RZ) / 2; });

    /* Road riders' carts: write a Yoruba word (or "Word|Meaning") on the name boards, or pass '' to hide the boards. Safe to call any time. */
    cart.setBoard = function (name) {
      try {
        if (!boardObj) { if (!name) return; boardObj = makeBoard(B, scene, name, paintId || '', bodyN); return; }
        if (name) { boardObj.draw(name); const k = String(name).indexOf('|') >= 0 ? 1.4 : 1; boardObj.planes.forEach(p => { p.setEnabled(true); p.scaling.set(k, k, 1); }); } else boardObj.planes.forEach(p => p.setEnabled(false));
      } catch (e) { console.warn('Cart board skipped', e); }
    };
    cart.hit = function () { cart.hitT0 = performance.now(); cart.hitOn = true; };          // Endless Run: the cart ran into an obstacle (silent, visual only)
    cart.ringBell = function () { bellT = 0; bellAmp = .75; };
    cart.setVisible = function (on) {
      cart.enabled = !!on; rootN.setEnabled(!!on);
    };
    cart.dispose = function () { try { brass.dispose(); } catch (e) { /* ok */ } cart.unseatPassengers(); if (cart.hitched) cart.unhitch(); try { scene.onBeforeRenderObservable.remove(obs); } catch (e) { /* ignore */ } Object.values(meshes).forEach(m => m.dispose()); [bodyN, frontSteer, shaftN, frontSpin, rearSpin, rearSpin2, rootN].filter(Boolean).forEach(n => n.dispose()); mat.dispose(); smat.dispose(); try { if (boardObj) { boardObj.planes.forEach(p => p.dispose()); boardObj.mt.dispose(); boardObj.tex.dispose(); } } catch (e) { /* ignore */ } };
    /* world position of a cart-space point (for a future rider/passenger/horse attach) */
    cart.toWorld = function (p) {
      const s = cart.state, cs = Math.cos(s.yaw), sn = Math.sin(s.yaw), mz = p[2] - (D.KPZ + D.RZ) / 2;
      return [s.x + p[0] * cs + mz * sn, s.y + p[1], s.z - p[0] * sn + mz * cs];
    };


    /* ---------- HITCH: couple the (unchanged) horse to the cart so they travel as one vehicle ----------
       The horse (riding.js) drives; the cart is derived from its pose every frame, just before drawing. The draw-shafts are fixed to the
       swivelling front frame and held at the horse's harness point (D.HORSE_Z along the shafts); the body trails the king-pin like a real
       four-wheel wagon (rear wheels roll without slipping, front frame swivels to the horse's heading, shafts tilt about the axle over bumps). */
    cart.hitch = function (rd) {
      if (!rd || !rd.built || !rd.state) return cart;
      if (cart.hitched) cart.unhitch();
      const H = root.OYOHorse, bone = H && H.B ? H.B : { NECK1: 3, CHEST: 2, PELVIS: 1 }, hs = rd.state, st = cart.state;
      const L = D.KPZ - D.RZ, HZ = D.HORSE_Z, MAXD = .75, gh = g.harness;
      const parts = [['collar', bone.NECK1], ['tugs', bone.CHEST], ['breech', bone.PELVIS]].map(([k, b]) => {
        const mesh = toMesh(B, scene, 'cartHarness_' + k, gh[k], mat, null), M = new B.Matrix(), arr = new Float32Array(16); arr[15] = 1;
        mesh.doNotSyncBoundingInfo = true; mesh.freezeWorldMatrix(M);
        return { mesh, M, arr, b };
      });
      let seeded = false, rx = 0, rz = 0, yawB = 0, pkx = 0, pkz = 0, pmx = 0, pmz = 0, shown = null;
      const wrapPi = a => { a = (a + PI) % TAU; if (a < 0) a += TAU; return a - PI; };
      const tick = () => {
        if (!cart.hitched) return;
        const on = !!rd.active; if (on !== shown) { shown = on; cart.setVisible(on); parts.forEach(q => q.mesh.setEnabled(on)); }
        if (!on) return;
        const dt = Math.min(.05, Math.max(.001, scene.getEngine().getDeltaTime() / 1000));
        // king-pin = the horse's harness point pulled back along the horse's heading
        const kx = hs.x - Math.sin(hs.yaw) * HZ, kz = hs.z - Math.cos(hs.yaw) * HZ;
        if (!seeded || Math.hypot(kx - pkx, kz - pkz) > 6) {          // first frame / teleport (mission respawn): line the cart up straight behind the horse
          yawB = hs.yaw; rx = kx - Math.sin(yawB) * L; rz = kz - Math.cos(yawB) * L; pmx = kx - Math.sin(yawB) * L / 2; pmz = kz - Math.cos(yawB) * L / 2; seeded = true;
        }
        pkx = kx; pkz = kz;
        let vx = kx - rx, vz = kz - rz; const l = Math.hypot(vx, vz) || 1; vx /= l; vz /= l;
        if (cart.rigid) { vx = Math.sin(hs.yaw); vz = Math.cos(hs.yaw); }                 // Endless Run: body stays square behind the horse
        let d = wrapPi(hs.yaw - Math.atan2(vx, vz));
        if (Math.abs(d) > MAXD) { d = d > 0 ? MAXD : -MAXD; const y = hs.yaw - d; vx = Math.sin(y); vz = Math.cos(y); }   // front frame at full lock: the body is dragged round
        rx = kx - vx * L; rz = kz - vz * L; yawB = Math.atan2(vx, vz);
        const mx = kx - vx * L / 2, mz = kz - vz * L / 2;
        cart.place(mx, mz, yawB);
        // shafts follow the horse's height (slopes, jumps) by swinging about the front axle
        const hF = hgt(kx, kz);
        st.hitched = true; st.hitchSteer = d; st.shaftPitch = clamp(Math.atan2(hs.y - hF, HZ) - st.pitch, -.4, .4);
        const v = ((mx - pmx) * vx + (mz - pmz) * vz) / dt; pmx = mx; pmz = mz;
        cart.update(dt, clamp(v, -20, 20), null);
        // harness → horse bones (same 3×4 bone matrices the horse mesh is skinned with)
        const wb = rd.wb; if (!wb) return;
        for (const q of parts) {
          const o = q.b * 12, a = q.arr;
          a[0] = wb[o]; a[1] = wb[o + 4]; a[2] = wb[o + 8]; a[4] = wb[o + 1]; a[5] = wb[o + 5]; a[6] = wb[o + 9]; a[8] = wb[o + 2]; a[9] = wb[o + 6]; a[10] = wb[o + 10]; a[12] = wb[o + 3]; a[13] = wb[o + 7]; a[14] = wb[o + 11];
          B.Matrix.FromArrayToRef(a, 0, q.M); q.mesh.freezeWorldMatrix(q.M);
        }
      };
      const hobs = scene.onBeforeRenderObservable.add(tick, -1, true);   // insertFirst: pose is final before the cart's own shadow update runs
      cart.hitched = true; st.hitched = true; cart.horse = rd; cart.harness = parts.map(q => q.mesh);
      cart.snapToHorse = function () { seeded = false; tick(); };          // place the cart straight behind the horse right now (run start / teleport)
      cart.unhitch = function () {
        cart.snapToHorse = null; cart.hitched = false; st.hitched = false; st.shaftPitch = 0; try { scene.onBeforeRenderObservable.remove(hobs); } catch (e) { /* ignore */ }
        parts.forEach(q => q.mesh.dispose()); cart.harness = null; cart.horse = null; cart.setVisible(true); applyPose();
      };
      return cart;
    };


    /* ---------- PASSENGERS: villagers (existing OYOVillagers people) sit on the benches and ride along ----------
       Each recruited villager gets a per-frame body hook (the same p.cr mechanism roam-fare.js uses for its pillion riders), so villagers.js
       draws them with the seated-on-a-bench pose (st 6.25), positioned on a seat of the moving cart. Nothing is added to the villager system. */
    const PAX_IDS = ['agA', 'agB', 'agC', 'wA', 'wB', 'wC'];          // plain, prop-free archetypes (no head-loads, tools or spears)
    cart.passengers = [];
    const mkHook = seat => function (q) {
          const s = cart.state, cp = Math.cos(s.pitch), sp_ = Math.sin(s.pitch), cr = Math.cos(s.roll), sr = Math.sin(s.roll), cy = Math.cos(s.yaw), sy = Math.sin(s.yaw);
          // seat point in body space (cushion top, hips a little behind the cushion centre), then Rz(roll) → Rx(-pitch) → Ry(yaw) → translate (same order as the cart's own node)
          const lx = seat.x, ly = 1.30 + s.bob, lz = seat.z - .12 - (D.KPZ + D.RZ) / 2;
          const x1 = lx * cr - ly * sr, y1 = lx * sr + ly * cr, y2 = y1 * cp + lz * sp_, z2 = -y1 * sp_ + lz * cp;
          q.x = s.x + x1 * cy + z2 * sy; q.z = s.z - x1 * sy + z2 * cy;
          q.y = s.y + y2 + .06 - .92 * q.sc; q.yaw = s.yaw; q.st = 6.25;
        };
    const seatOrder = A.seats.slice().sort((a, b) => (b.row - a.row) || (a.side - b.side));   // front bench first (same order seatPassengers uses)
    cart.riders = [];
    /* Endless Run: seat one SPECIFIC villager (the very person who boarded) in seat number `i`; it stays there until unseatPerson(p), whatever else boards or leaves. */
    cart.seatPerson = function (p, i) {
      const seat = seatOrder[i]; if (!p || !seat) return false;
      cart.unseatPerson(p); p.cr = mkHook(seat); p.busy = Infinity; p.st = 6.25; p.cartSeat = seat; p.cr(p); cart.riders.push(p); return true;
    };
    cart.unseatPerson = function (p) { const k = cart.riders.indexOf(p); if (k < 0) return; cart.riders.splice(k, 1); p.cr = null; p.busy = 0; p.cartSeat = null; p.st = 0; };
    cart.seatPassengers = function (count) {
      const V = root.OYOVillagers; if (!V || !V.people || !V._t || !V._t.ARCH) return [];
      cart.unseatPassengers();
      const ids = V._t.ARCH.map(a => a.id), seats = A.seats.slice().sort((a, b) => (b.row - a.row) || (a.side - b.side));   // front bench first
      const n = Math.min(count == null ? seats.length : count, seats.length), s0 = cart.state;
      const pool = V.people.filter(p => PAX_IDS.indexOf(ids[p.a]) >= 0 && !p.cr && !p.pr && !p.busy && p.k !== 'kid')
        .sort((a, b) => Math.hypot(a.x - s0.x, a.z - s0.z) - Math.hypot(b.x - s0.x, b.z - s0.z));
      for (let i = 0; i < n && i < pool.length; i++) {
        const p = pool[i], seat = seats[i], keep = { x: p.x, y: p.y, z: p.z, yaw: p.yaw, st: p.st, busy: p.busy, cr: p.cr };
        const hook = mkHook(seat);
        p.cr = hook; p.busy = Infinity; p.st = 6.25; p.cartSeat = seat; hook(p);
        cart.passengers.push({ p, keep });
      }
      return cart.passengers.map(r => r.p);
    };
    cart.unseatPassengers = function () {       // put everyone back where they were
      cart.passengers.forEach(({ p, keep }) => { p.cr = keep.cr || null; p.busy = keep.busy || 0; p.cartSeat = null; p.x = keep.x; p.z = keep.z; p.y = keep.y; p.yaw = keep.yaw; p.st = keep.st; });
      cart.passengers = [];
    };

    // keep the camera-distance uniform fresh (no changes needed in game.js's update loop)
    const obs = scene.onBeforeRenderObservable.add(() => {
      const cam = scene.activeCamera; if (cam && cart.enabled) mat.setVector3('camPos', cam.position);
      if (bellAmp > .002) { bellT += Math.min(.05, scene.getEngine().getDeltaTime() / 1000); bellAmp *= Math.exp(-Math.min(.05, scene.getEngine().getDeltaTime() / 1000) * 3.4); bellPivot.rotation.z = bellAmp * Math.sin(bellT * 22); } else if (bellPivot.rotation.z !== 0) bellPivot.rotation.z = 0;
    });

    cart.place(opts.x || 0, opts.z || 0, opts.yaw || 0);
    if (opts.visible === false) cart.setVisible(false);
    return cart;
  }


  function boardPassengers(cart) {      // villagers climb aboard; add ?pax=N to the address for N passengers (0 = empty cart)
    let n = null; try { const m = /[?&]pax=(\d+)/.exec(root.location.search); if (m) n = Math.min(6, +m[1]); } catch (e) { /* no location (tests) */ }
    try { if (n !== 0) cart.seatPassengers(n); } catch (e) { console.warn('Passengers skipped:', e); }
    return cart;
  }

  /* A parked display cart on the road shoulder close to the player's spawn (display only: no collisions, no gameplay hooks). */
  function spawnParked(scene, World, road, i) {
    try { if (/[?&]cart=0(&|$)/.test(root.location.search)) return null; } catch (e) { /* no location (tests) */ }
    const t = [road.tx[i], road.tz[i]], n = [road.nx[i], road.nz[i]], yaw = Math.atan2(t[0], t[1]);
    const x = road.x[i] - n[0] * 7.2 + t[0] * 16, z = road.z[i] - n[1] * 7.2 + t[1] * 16;
    return boardPassengers(build(scene, World, { x, z, yaw: yaw - .32 }));
  }


  /* The cart hitched to the rider's horse (riding.js object): same vehicle, horse unchanged. Hidden/shown together with the horse. */
  function spawnHitched(scene, World, riding) {
    try { if (/[?&]cart=0(&|$)/.test(root.location.search)) return null; } catch (e) { /* no location (tests) */ }
    if (!riding || !riding.built) return null;
    const s = riding.state, c = build(scene, World, { x: s.x, z: s.z, yaw: s.yaw });
    return boardPassengers(c.hitch(riding));
  }

  const api = { build, geometry, spawnParked, spawnHitched, dims: D, palette: { WOOD, CAMW, RED, INDIGO, GOLD, BRASS, CREAM, TEAL } };
  root.OYOCart = Object.assign(root.OYOCart || {}, api);
  if (typeof module !== 'undefined' && module.exports) module.exports = root.OYOCart;
})(typeof window !== 'undefined' ? window : globalThis);
