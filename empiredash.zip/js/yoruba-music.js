/* EMPIRE DASH — Stage 30 · yoruba-music.js  (v2 — "never skips" engine)
   Original Yoruba-inspired music, synthesised with WebAudio (no sound files, nothing to license, nothing to download).

   WHY v2: the first version scheduled every drum hit, flute note and shaker tick from a JavaScript timer, hundreds of live oscillators
   at a time. Whenever the game stalled (a slow frame, garbage collection, a heavy scene) the timer was late, the look-ahead ran dry and
   the music stuttered or stopped, and the audio thread itself could be starved by the same load.

   NOW: the music is rendered ONCE, in the background, by an OfflineAudioContext (off the main thread, a bar at a time so the game never
   hitches) into a short seamless loop for each atmosphere, split into 9 "stems" (flute, dùndún, gángan, bàtá, sékèrè, agogo, gudugudu,
   a "high energy" stem and a "danger" stem). While you play, the browser's audio thread just loops those buffers and the game only
   moves 9 volume knobs, a few times a second. If the game freezes for a second, the music keeps playing exactly on time, because the
   main thread is no longer involved in making it. Playing 9 looping buffers is also hundreds of times cheaper for the CPU than the
   live synth was, so there is nothing left to crackle.

   Same instruments, same 12/8 cycle on one tonic (D), same atmospheres (VILLAGE · MARKET · FOREST · ROYAL, cross-faded as you move),
   same intensity (speed) and danger (hazards, crashes, tired horse) behaviour — now expressed as stem volumes. Everything goes into
   ONE bus -> A.mus, so Settings -> Music on/off and Music volume keep working. If rendering is impossible on a device, the old simple
   loop in audio.js keeps playing. */
(function () {
  'use strict';
  const OYO = window.OYO = window.OYO || {}, A = window.OYOAudio;
  if (!A) return;
  const R = Math.random, clamp = (v, a, b) => v < a ? a : v > b ? b : v, lerp = (a, b, t) => a + (b - a) * t;
  const sm01 = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); }, ramp = (v, a, b) => clamp((v - a) / (b - a), 0, 1);
  const M = OYO.music = { zone: 'royal', intensity: 0, danger: 0, speedN: 0, running: false, force: null, bar: 0 };
  const ROOT = 146.83, LOOK = 3.2;                                           // D3; seconds scheduled ahead

  /* ---------------------------------- scales, atmospheres, material ---------------------------------- */
  const SC = { maj6: [0, 2, 4, 5, 7, 9], pent: [0, 2, 4, 7, 9], sus: [0, 2, 5, 7, 9], dor: [0, 2, 3, 5, 7, 9, 10] };
  const semi = (sc, n) => { const L = sc.length, o = Math.floor(n / L); return sc[((n % L) + L) % L] + 12 * o; };
  // pd = seconds per pulse (12 per bar); mix = layer weights; sek/gud = 12-pulse patterns (>= .8 accent, smaller = ghost note); call/fast/fl = how much each voice speaks
  const ZONES = {
    village: { pd: .24, sc: 'maj6', send: .22, mix: { fl: 1, dun: .8, gan: .55, bata: .45, sek: .75, ago: .3, gud: .85 },
      sek: [1, 0, .4, .5, 0, .4, .9, 0, .4, .5, 0, .4], gud: [1, 0, 0, 0, 0, 0, .8, 0, 0, .4, 0, 0], call: .7, fast: .2, fl: [0, 1, 2, 5], flRest: .2, ago: 0 },
    market: { pd: .205, sc: 'pent', send: .12, mix: { fl: .7, dun: 1, gan: .85, bata: .6, sek: 1, ago: .8, gud: .9 },
      sek: [1, .45, .45, .9, .45, .45, 1, .45, .45, .9, .45, .45], gud: [1, 0, 0, .5, 0, 0, .8, 0, .5, .5, 0, 0], call: .95, fast: .45, fl: [1, 3, 2, 0], flRest: .35, ago: 1 },
    forest: { pd: .26, sc: 'sus', send: .5, mix: { fl: 1.15, dun: .5, gan: .3, bata: .2, sek: .45, ago: 0, gud: .7 },
      sek: [.5, 0, 0, .35, 0, 0, .5, 0, 0, .35, 0, .3], gud: [.8, 0, 0, 0, 0, 0, .5, 0, 0, 0, 0, 0], call: .4, fast: .1, fl: [4, 5, 0], flRest: .05, ago: 0 },
    royal: { pd: .235, sc: 'dor', send: .3, mix: { fl: .85, dun: .9, gan: .7, bata: 1, sek: .6, ago: .55, gud: 1 },
      sek: [1, 0, .4, 0, .4, 0, .9, 0, .4, 0, .4, .4], gud: [1, 0, 0, .5, 0, 0, .9, 0, 0, .5, 0, 0], call: .85, fast: .3, fl: [6, 0, 2, 4], flRest: .3, ago: .7 }
  };
  // talking-drum phrases: [pulse, startDegree, endDegree, seconds, velocity]; degrees are steps of the atmosphere's scale
  const CALL = [   // dùndún (low): the "question"
    [[0, 2, 4, .4, .9], [3, 4, 3, .2, .65], [4.5, 3, 3, .15, .55], [6, 1, 5, .5, 1], [9, 4, 2, .4, .8]],
    [[0, 0, 3, .35, .9], [2, 3, 2, .2, .6], [3, 2, 4, .3, .8], [6, 5, 1, .55, 1], [10, 2, 3, .25, .6]],
    [[0, 4, 4, .2, .8], [1.5, 4, 5, .2, .7], [3, 5, 2, .4, .95], [6, 2, 2, .2, .6], [7.5, 2, 4, .3, .8], [9, 4, 0, .6, 1]],
    [[0, 1, 3, .3, .9], [3, 3, 6, .4, 1], [6, 6, 3, .3, .8], [8, 3, 3, .15, .6], [9, 3, 1, .5, .9]],
    [[0, 3, 0, .9, .9], [6, 2, 4, .5, .7]],
    [[0, 2, 2, .2, .7], [1, 2, 2, .2, .6], [2, 2, 5, .35, .9], [6, 4, 1, .5, 1], [9, 1, 1, .2, .6], [10, 1, 3, .3, .8]]];
  const RESP = [   // gángan (high): the "answer"
    [[0, 4, 6, .2, .8], [1.5, 6, 3, .2, .7], [3, 3, 5, .25, .8], [4.5, 5, 2, .25, .7], [6, 2, 2, .15, .6], [7, 2, 4, .2, .7], [9, 4, 0, .5, .9]],
    [[0, 0, 5, .2, .8], [2, 5, 3, .2, .7], [3, 3, 3, .12, .6], [4, 3, 3, .12, .6], [5, 3, 6, .3, .9], [8, 6, 2, .4, .8], [10, 2, 4, .25, .7]],
    [[0, 3, 3, .12, .7], [.5, 3, 3, .12, .6], [1, 3, 6, .25, .9], [3, 6, 4, .2, .7], [4.5, 4, 4, .2, .6], [6, 4, 1, .45, .9], [9, 2, 5, .3, .8], [10.5, 5, 0, .4, .8]],
    [[0, 5, 2, .6, .8], [6, 3, 0, .7, .9]],
    [[0, 6, 6, .12, .7], [1, 6, 5, .12, .7], [2, 5, 3, .2, .8], [3, 3, 5, .2, .8], [4, 5, 7, .25, .9], [6, 7, 4, .5, 1], [9, 4, 2, .3, .7], [10, 2, 0, .4, .8]]];
  const FILL = [[8, 2, 5, .1, .7], [8.5, 5, 3, .1, .7], [9, 3, 6, .1, .8], [9.5, 6, 4, .1, .8], [10, 4, 7, .12, .9], [10.5, 7, 5, .1, .9], [11, 5, 2, .35, 1]];
  // bàtá: [pulse, head ('e' open low enu / 'c' slapped chacha), velocity]
  const OKON = [[[0, 'c', .9], [3, 'c', .6], [5, 'e', .7], [6, 'c', .9], [9, 'c', .6], [11, 'e', .5]], [[0, 'c', .9], [2, 'e', .5], [3, 'c', .6], [6, 'c', .9], [8, 'e', .5], [9, 'c', .6]]];
  const ITOT = [[[0, 'e', .8], [4, 'c', .6], [6, 'e', .7], [7, 'c', .5], [10, 'c', .7]], [[0, 'e', .8], [3, 'c', .5], [6, 'e', .7], [8, 'c', .6], [10, 'c', .6], [11, 'c', .4]]];
  const IYA = [[[0, 'e', 1], [2, 'c', .7], [3, 'c', .6], [4.5, 'c', .5], [6, 'e', 1], [8, 'c', .7], [9, 'e', .8], [10.5, 'c', .6]],
    [[0, 'e', 1], [1.5, 'c', .6], [3, 'e', .8], [4, 'c', .6], [5, 'c', .6], [6, 'e', 1], [9, 'e', .8], [10, 'c', .7], [11, 'c', .6]],
    [[0, 'e', 1], [3, 'c', .7], [5, 'c', .6], [6, 'e', 1], [7.5, 'c', .6], [9, 'c', .7], [10, 'e', .9]]];
  const AGO = [[0, 1], [2, 0], [4, 1], [5, 1], [7, 0], [9, 1], [11, 0]];                 // the standard 12/8 bell timeline (hi / lo)
  // fèrè phrases: [pulse, degree, length in pulses, velocity] (degree 0 = D4)
  const FLUTE = [
    [[0, 4, 3, .8], [3, 5, 1.5, .65], [4.5, 4, 1.5, .6], [6, 2, 3, .7], [9, 0, 3, .8]],
    [[0, 2, 1.5, .7], [1.5, 4, 1.5, .7], [3, 5, 3, .85], [6, 4, 1.5, .65], [7.5, 2, 1.5, .6], [9, 3, 3, .7]],
    [[0, 5, 2, .8], [2, 4, 1, .6], [3, 2, 3, .7], [6, 3, 1, .6], [7, 2, 1, .6], [8, 0, 4, .8]],
    [[0, 7, 1, .7], [1, 6, 1, .65], [2, 4, 1, .6], [3, 5, 3, .8], [6, 4, 1.5, .65], [7.5, 2, 1.5, .6], [9, 4, 3, .75]],
    [[0, 4, 9, .7], [9, 2, 3, .6]],
    [[0, 2, 6, .7], [6, 4, 3, .65], [9, 3, 3, .6]],
    [[0, 0, 2, .85], [3, 4, 1.5, .8], [4.5, 4, 1.5, .8], [6, 5, 3, .9], [9, 4, 1.5, .7], [10.5, 2, 1.5, .7]]];
  const ALARM = [[0, 5, 1, .8], [1.5, 5, 1, .8], [3, 5, 1, .8], [4.5, 6, 1, .9], [6, 5, 1, .8], [7.5, 5, 1, .8], [9, 6, 2.5, .95]];   // urgent repeated-note figure


  const STEMS = ['fl', 'dun', 'gan', 'bata', 'sek', 'ago', 'gud', 'hi', 'dg'];
  const SENDS = { fl: .55, dun: .12, gan: .3, bata: .1, sek: .05, ago: .15, gud: 0, hi: .1, dg: .2 };
  const BARS = 8, PDK = .9, T0 = .12, TAIL = 1.9, CACHE_MAX = 2;      // 8-bar loop at 90 % of the zone's base pulse length; chunk start pad; reverb tail; zones kept in memory

  let rc = null, c = null, L = null, remap = null, NB = null, mix = null, trans = null, timer = null;   // rc = the real (realtime) context · c = the context voices are being built in (an offline one while rendering)
  const OC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  const D = k => (L[remap || k] || L[k]).g;

  /* ---------------------------------- voices (unchanged instruments) ---------------------------------- */
  function env(g, t, a, pk, d) { g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(Math.max(.0003, pk), t + a); g.gain.exponentialRampToValueAtTime(.0001, t + a + d); }
  function tn(dst, t, f0, f1, dur, type, pk, atk) {
    const o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.setValueAtTime(f0, t); if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + Math.min(dur, .2));
    env(g, t, atk || .004, pk, dur); o.connect(g); g.connect(dst); o.start(t); o.stop(t + (atk || .004) + dur + .05);
  }
  function nz(dst, t, dur, type, f, q, pk) {
    const s = c.createBufferSource(), fl = c.createBiquadFilter(), g = c.createGain(); s.buffer = NB; fl.type = type; fl.frequency.value = f; fl.Q.value = q;
    env(g, t, .003, pk, dur); s.connect(fl); fl.connect(g); g.connect(dst); s.start(t, R() * .6); s.stop(t + dur + .05);
  }
  // dùndún / gángan: a drum whose pitch is bent by squeezing the cords; the second, inharmonic partial is the membrane
  function talk(dst, t, f0, f1, dur, vel, high) {
    const pk = (high ? .3 : .42) * vel; tn(dst, t, f0, f1, dur, 'sine', pk, .003); tn(dst, t, f0 * 1.58, f1 * 1.58, dur * .55, 'triangle', pk * .28, .002);
    nz(dst, t, .018, 'bandpass', high ? 2600 : 1700, 1.1, pk * .55);
  }
  function gudu(t, vel) { const d = D('gud'); tn(d, t, 112, 76, .3, 'sine', .55 * vel, .004); nz(d, t, .02, 'bandpass', 420, 1, .18 * vel); }
  const BSZ = [1, 1.3, 1.75];                                                               // iyá-ìlù, ìtótèlé, òkònkòlò
  function bata(t, head, size, vel) {
    const d = D('bata'), z = BSZ[size];
    if (head === 'e') { tn(d, t, 138 * z, 104 * z, .3, 'sine', .46 * vel, .003); tn(d, t, 138 * z * 2.1, 104 * z * 2.1, .09, 'triangle', .1 * vel, .002); nz(d, t, .03, 'bandpass', 780, 1, .16 * vel); }
    else {
      tn(d, t, 410 * z, 340 * z, .12, 'sine', .3 * vel, .002); nz(d, t, .035, 'bandpass', 2700, 1.1, .3 * vel);
      if (R() < .6) { const f = 3300 + R() * 900; tn(d, t + .004, f, f * .99, .07, 'sine', .035 * vel, .002); tn(d, t + .004, f * 1.42, f * 1.4, .06, 'sine', .022 * vel, .002); }   // ide bells
    }
  }
  function sekere(t, vel, acc) {
    const d = D('sek');
    if (acc) { nz(d, t, .07, 'bandpass', 4300, .7, .15 * vel); nz(d, t + .026, .05, 'bandpass', 5600, .8, .1 * vel); tn(d, t, 230, 200, .05, 'sine', .08 * vel, .002); }
    else nz(d, t, .035, 'bandpass', 5200, .8, .075 * vel);
  }
  function agogo(t, hi, vel) {
    const d = D('ago'), f = hi ? 1010 : 790; [[1, .1], [2.76, .06], [5.4, .025]].forEach(p => tn(d, t, f * p[0], f * p[0] * .998, .13 + (hi ? 0 : .03), 'sine', p[1] * vel, .001));
  }
  function flute(t, f, dur, vel, o) {
    o = o || {}; const d = D('fl'), a = c.createOscillator(), b = c.createOscillator(), g = c.createGain(), bg = c.createGain(), dep = c.createGain();
    a.type = 'sine'; b.type = 'sine'; const f0 = f * (o.scoop === false ? 1 : .965); a.frequency.setValueAtTime(f0, t); a.frequency.exponentialRampToValueAtTime(f, t + .07);
    b.frequency.setValueAtTime(f0 * 2, t); b.frequency.exponentialRampToValueAtTime(f * 2, t + .07);
    if (o.fall) { a.frequency.setValueAtTime(f, t + dur - .16); a.frequency.exponentialRampToValueAtTime(f * .92, t + dur); b.frequency.setValueAtTime(f * 2, t + dur - .16); b.frequency.exponentialRampToValueAtTime(f * 1.84, t + dur); }
    dep.gain.setValueAtTime(0, t); dep.gain.linearRampToValueAtTime(f * (o.trill ? .02 : .0065), t + Math.min(.35, dur * .6)); const lfo = c.createOscillator(); lfo.frequency.value = 4.9 + R() * .8; lfo.connect(dep); lfo.start(t); lfo.stop(t + dur + .15);      // per-note vibrato (dies with the note: no leaked nodes)
    dep.connect(a.frequency); dep.connect(b.frequency);
    const at = Math.min(.09, dur * .4), pk = .21 * vel; g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(pk, t + at); g.gain.setTargetAtTime(pk * .85, t + at, .2); g.gain.setValueAtTime(pk * .85, t + Math.max(at, dur - .09)); g.gain.exponentialRampToValueAtTime(.0001, t + dur + .08);
    bg.gain.value = .13; a.connect(g); b.connect(bg); bg.connect(g); g.connect(d); a.start(t); b.start(t); a.stop(t + dur + .15); b.stop(t + dur + .15);
    nz(d, t, .05, 'bandpass', f * 2.2, 1.3, .11 * vel);                                      // chiff: the burst of air on the attack
    const s = c.createBufferSource(), bf = c.createBiquadFilter(), sg = c.createGain(); s.buffer = NB; bf.type = 'bandpass'; bf.frequency.value = f * 3; bf.Q.value = 1.4;   // steady breath
    sg.gain.setValueAtTime(.0001, t); sg.gain.linearRampToValueAtTime(.022 * vel, t + at); sg.gain.setValueAtTime(.022 * vel, t + Math.max(at, dur - .08)); sg.gain.linearRampToValueAtTime(.0001, t + dur + .06);
    s.loop = true; s.connect(bf); bf.connect(sg); sg.connect(d); s.start(t, R() * .5); s.stop(t + dur + .1);
  }


  /* ---------------------------------- composing one bar into the stems ---------------------------------- */
  const S = { zone: 'royal', pending: null, lastSwitch: 0, cand: null, candT: 0, gx: 0, gz: 0, spd: 0, lastT: 0, impactSeen: 0, dI: 0, dD: 0, bag: {} };
  const pickBag = (key, n) => { let b = S.bag[key]; if (!b || !b.length) { b = S.bag[key] = Array.from({ length: n }, (_, i) => i).sort(() => R() - .5); } return b.pop(); };
  const quality = () => { const h = OYO.hud; return h && h.quality; };

  function composeBar(zone, ph, perf) {                              // everything that happens in one bar of 12 pulses, written straight into the stems
    const P = ZONES[zone], sc = SC[P.sc], pd = P.pd * PDK, base = ROOT, dpitch = (deg, b) => b * Math.pow(2, semi(sc, deg) / 12);
    const at = (pos, fn) => fn(T0 + pos * pd / 2);                    // pos is in half-pulses, like the original
    const hi = fn => { remap = 'hi'; try { fn(); } finally { remap = null; } }, dg = fn => { remap = 'dg'; try { fn(); } finally { remap = null; } };
    // --- groove: shaker, bell, kettle bass ---
    for (let p = 0; p < 12; p++) { const v = P.sek[p]; if (v > 0 && !(perf && v < .6)) at(p, tt => sekere(tt, v > .8 ? 1 : v * 1.4, v >= .8)); }
    if (!perf) hi(() => { for (let p = 0; p < 12; p++) if (R() < .75) at(p + .5, tt => sekere(tt, .5, false)); });
    if (!perf && P.mix.ago > 0) AGO.forEach(e => at(e[0], tt => agogo(tt, e[1], .9)));
    for (let p = 0; p < 12; p++) { const v = P.gud[p]; if (v > 0) at(p, tt => gudu(tt, v)); }
    dg(() => [0, 3, 6, 9].forEach(p => at(p + .02, tt => gudu(tt, .95))));                  // heartbeat under danger
    // --- bàtá ---
    const ab = ph % 2; OKON[ab].forEach(e => at(e[0], tt => bata(tt, e[1], 2, e[2]))); ITOT[ab].forEach(e => at(e[0], tt => bata(tt, e[1], 1, e[2] * .9)));
    hi(() => {
      IYA[pickBag('iya', IYA.length)].forEach(e => at(e[0], tt => bata(tt, e[1], 0, e[2])));
      if (ph === 3 && !perf) for (let q = 0; q < 6; q++) at(9 + q * .5, tt => bata(tt, 'c', q % 2 ? 1 : 2, .45 + q * .09));
    });
    dg(() => { for (let q = 0; q < 6; q++) at(9 + q * .5, tt => bata(tt, 'c', q % 2 ? 1 : 2, .45 + q * .09)); });
    // --- talking drums: call (dùndún) and answer (gángan) ---
    const drum = (pat, b, who, high) => pat.forEach(e => at(e[0], tt => talk(D(who), tt, dpitch(e[1], b), dpitch(e[2], b), e[3], e[4], high)));
    const call = () => CALL[R() < P.fast ? pickBag('c', CALL.length) : [0, 1, 4][Math.floor(R() * 3)] % CALL.length], resp = () => RESP[R() < P.fast ? pickBag('r', RESP.length) : 3 % RESP.length];
    const evenBar = ph === 0 || ph === 2;
    if (evenBar && R() < P.call) drum(call(), base, 'dun', false);
    if (!evenBar && R() < P.call) drum(resp(), base * 2, 'gan', true);
    hi(() => { if (!evenBar && R() < P.call) drum(call(), base, 'dun', false); if (evenBar && R() < P.call) drum(resp(), base * 2, 'gan', true); });
    if (!perf && ph === 3) FILL.forEach(e => at(e[0], tt => talk(D('gan'), tt, dpitch(e[1], base * 2), dpitch(e[2], base * 2), e[3], e[4] * .9, true)));
    dg(() => { for (let q = 0; q < 8; q++) at(8.5 + q * .4, tt => talk(D('gan'), tt, dpitch(4, base * 2), dpitch(4, base * 2) * 1.03, .09, .5 + q * .06, true)); });   // tremolo roll
    // --- fèrè ---
    if (ph % 2 === 0 || P.flRest < .1) {
      if (R() > P.flRest * (1 - .45)) {
        const ph1 = FLUTE[P.fl[pickBag('f' + zone, P.fl.length)]], shift = ph === 2 && R() < .5 ? -1 : 0, orn = .4;
        ph1.forEach((e, n) => {
          const f = base * 2 * Math.pow(2, semi(sc, e[1] + shift) / 12), last = n === ph1.length - 1;
          at(e[0], tt => {
            if (R() < orn && e[2] <= 3 && n > 0) flute(tt - .07, f * Math.pow(2, (sc[1] || 2) / 12), .08, e[3] * .5, { scoop: false });
            flute(tt, f, e[2] * pd * (last ? .95 : .92), e[3], { fall: last || e[2] >= 4, trill: false });
          });
        });
      }
    }
    dg(() => ALARM.forEach(e => at(e[0], tt => flute(tt, base * 2 * Math.pow(2, semi(sc, e[1]) / 12), e[2] * pd * .9, e[3], { scoop: false, trill: false }))));   // urgent repeated-note figure
  }

  /* ---------------------------------- offline rendering (one bar per job, off the main thread) ---------------------------------- */
  const cache = {}, inflight = {};
  const startRender = oc => new Promise((res, rej) => { try { const p = oc.startRendering(); if (p && p.then) p.then(res, rej); else oc.oncomplete = e => res(e.renderedBuffer); } catch (e) { rej(e); } });
  const nap = ms => new Promise(r => setTimeout(r, ms));

  function chunkGraph(oc, zone) {                                    // 9 mono stems -> 9 channels; each stem has its own little feedback "space"
    const P = ZONES[zone], mg = oc.createChannelMerger(STEMS.length), g = {}; mg.connect(oc.destination);
    STEMS.forEach((k, i) => {
      const b = oc.createGain(); b.connect(mg, 0, i); g[k] = { g: b };
      const snd = SENDS[k] * (P.send / .25); if (snd <= 0) return;
      const s = oc.createGain(), d = oc.createDelay(1), lp = oc.createBiquadFilter(), fb = oc.createGain(), wet = oc.createGain();
      s.gain.value = snd; d.delayTime.value = .34; fb.gain.value = .34; wet.gain.value = .55; lp.type = 'lowpass'; lp.frequency.value = 2300;
      b.connect(s); s.connect(d); d.connect(lp); lp.connect(fb); fb.connect(d); lp.connect(wet); wet.connect(mg, 0, i);
    });
    return g;
  }

  async function renderZone(zone) {
    if (!OC || !rc || !NB) throw new Error('offline rendering unavailable');
    const perf = quality() === 'perf', sr = perf ? 16000 : 22050, pdz = ZONES[zone].pd * PDK, barS = Math.round(12 * pdz * sr), N = barS * BARS;
    const out = rc.createBuffer(STEMS.length, N, sr), ch = STEMS.map((k, i) => out.getChannelData(i));
    S.bag = {};
    for (let bar = 0; bar < BARS; bar++) {
      const len = Math.ceil((T0 + 12 * pdz + TAIL) * sr);
      let oc; try { oc = new OC(STEMS.length, len, sr); } catch (e) { oc = new OC(STEMS.length, Math.ceil((T0 + 12 * pdz + TAIL) * 44100), 44100); }   // some engines only allow standard rates
      const rate = oc.sampleRate, saveC = c, saveL = L;
      c = oc; L = chunkGraph(oc, zone);
      try { composeBar(zone, bar % 4, perf); } finally { c = saveC; L = saveL; remap = null; }
      const rb = await startRender(oc);
      const off = bar * barS - Math.round(T0 * sr), ratio = rate / sr;
      for (let k = 0; k < STEMS.length; k++) {
        const s = rb.getChannelData(k), d = ch[k], n = s.length;
        for (let i = 0; i < n; i++) { const j = Math.round(off + i / ratio); d[((j % N) + N) % N] += s[i]; }      // overlap-add; the tail of the last bar wraps onto the first = a seamless loop
      }
      await nap(40);                                                                                           // let the game draw a frame between jobs
    }
    return { buf: out, N, sr, used: performance.now() };
  }
  function ensure(zone) {
    if (cache[zone]) { cache[zone].used = performance.now(); return Promise.resolve(cache[zone]); }
    if (inflight[zone]) return inflight[zone];
    return inflight[zone] = renderZone(zone).then(z => {
      cache[zone] = z; delete inflight[zone];
      const keys = Object.keys(cache); while (keys.length > CACHE_MAX) {                 // keep memory small: drop the least recently used zone that is not playing
        let old = null; keys.forEach(k => { if (k !== S.zone && k !== zone && (!old || cache[k].used < cache[old].used)) old = k; });
        if (!old) break; delete cache[old]; keys.splice(keys.indexOf(old), 1);
      }
      return z;
    }, e => { delete inflight[zone]; throw e; });
  }

  /* ---------------------------------- playback: just looping buffers + volume knobs ---------------------------------- */
  const V = { cur: null };
  function voice(z, fade) {
    const when = rc.currentTime + .05, bus = rc.createGain(), src = rc.createBufferSource(), sp = rc.createChannelSplitter(STEMS.length), g = {};
    bus.gain.setValueAtTime(0, when); bus.gain.setTargetAtTime(1, when, fade); bus.connect(mix);
    src.buffer = z.buf; src.loop = true; src.loopStart = 0; src.loopEnd = z.N / z.sr; src.connect(sp);
    STEMS.forEach((k, i) => { const n = rc.createGain(); n.gain.value = 0; sp.connect(n, i); n.connect(bus); g[k] = n; });
    src.start(when);
    return { src, bus, g, sp };
  }
  function retire(v, now, tau) {                                       // fade out and stop on the AUDIO clock (no timers involved)
    try { v.bus.gain.cancelScheduledValues(now); v.bus.gain.setTargetAtTime(0, now, tau); v.src.stop(now + tau * 6 + .2); } catch (e) { /* ignore */ }
    setTimeout(() => { try { v.bus.disconnect(); } catch (e) { /* ignore */ } }, (tau * 6 + 1) * 1000);
  }
  function switchTo(zone) {
    const z = cache[zone]; if (!z || !rc) return; const now = rc.currentTime;
    const old = V.cur; V.cur = voice(z, .7); if (old) retire(old, now, .6);
    S.zone = zone; M.zone = zone; S.lastSwitch = now; S.pending = null; M.bar++; levels(now, true);
  }

  /* ---------------------------------- where is the player, how hard is the game ---------------------------------- */
  let W = null, markets = [], sites = [], grid = null, treeN = 0, learned = null;
  function learn() {
    const core = OYO.core, w = core && core.S && core.S.world; if (!w || learned === w) return; learned = w; W = w; const V = window.OYOVillagers;
    try { markets = (V && V.markets || []).map(m => ({ x: m.x, z: m.z, R: m.R || 8, big: !!m.big })); } catch (e) { markets = []; }
    sites = []; try { const st = W.settlements; (st && st.sites || []).forEach(s => { if (s.x != null && (s.type === 'farm' || s.type === 'village' || s.type === 'town')) sites.push({ x: s.x, z: s.z, R: s.type === 'farm' ? 30 : s.type === 'village' ? 46 : 62 }); }); } catch (e) { sites = []; }
    W.royal = null; try { const p = W.settlements && W.settlements.palace; if (p && p.x != null) W.royal = { x: p.x, z: p.z }; } catch (e) { /* optional */ }
    grid = new Map(); treeN = 0; try { (W.treePts || []).forEach(p => { const k = Math.floor(p[0] / 20) * 4099 + Math.floor(p[1] / 20); grid.set(k, (grid.get(k) || 0) + 1); treeN++; }); } catch (e) { /* optional */ }
  }
  const forestAt = (x, z) => { if (grid && treeN > 20) { const ix = Math.floor(x / 20), iz = Math.floor(z / 20); let n = 0; for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) n += grid.get((ix + a) * 4099 + iz + b) || 0; return sm01((n - 4) / 12); } return 0; };
  const near = (list, x, z, reach) => { let b = 0; for (let q = 0; q < list.length; q++) { const s = list[q]; b = Math.max(b, sm01(1 - Math.hypot(s.x - x, s.z - z) / reach(s))); } return b; };

  function sense(dt) {
    const h = OYO.hud || {}, scr = h.screen, core = OYO.core, now = rc.currentTime;
    const menu = !scr || scr === 'title' || scr === 'select' || scr === 'eover' || scr === 'loading' || h.loading;
    let zone = 'royal', sc = { royal: 1 }, v = 0, ti = .14, td = 0, top = 11.5;
    if (M.force) { zone = M.force.zone || zone; ti = M.force.i != null ? M.force.i : .3; td = M.force.d || 0; v = null; sc = null; }
    else if (!menu && core && core.S) {
      const st = core.S.riding && core.S.riding.state, P = core.P, E = OYO.endless;
      if (E && E.on && !E.over) {                                    // Endless Run: the scenery along the road decides
        const z = E.zoneInfo(); sc = { royal: z.royal * 1.2, market: z.market * 1.1, village: z.village * .95, forest: z.forest * .9 + .1 }; top = 15;
        v = st ? Math.abs(st.speed) : 0; td = E.threat();
      } else {                                                       // free roam / walking / tour: position in the world decides
        learn();
        if (P && W) {
          const rp = W.royal ? sm01(1 - Math.hypot(W.royal.x - P.x, W.royal.z - P.z) / 120) : 0;
          sc = { royal: rp * 1.2, market: near(markets, P.x, P.z, m => m.R + (m.big ? 52 : 38)) * 1.1, village: near(sites, P.x, P.z, s => s.R + 14) * .9, forest: forestAt(P.x, P.z) + .28 };
          const dd = Math.hypot(P.x - S.gx, P.z - S.gz) / Math.max(dt, .03); S.gx = P.x; S.gz = P.z; if (dd < 150) S.spd += (dd - S.spd) * .5; v = (h.mode === 'ride' && st && !h.tour) ? Math.abs(st.speed) : S.spd;
        }
        try { const o = OYO.obstacles && OYO.obstacles.threat ? OYO.obstacles.threat() : 0; td = (h.mode === 'ride' && !h.tour) ? o : 0; } catch (e) { td = 0; }
        if (h.mode === 'ride' && !h.tour) { if (h.exh) td = Math.max(td, .5); else if (h.stam < 25) td = Math.max(td, .25); }
      }
      if (v != null) { M.speedN = clamp((v - 1.5) / (top - 1.5), 0, 1); ti = .1 + .62 * M.speedN; }
    }
    if (v == null) M.speedN = ti;
    const hit = 0; td = Math.max(td, hit);
    if (A.impactAt && A.impactAt !== S.impactSeen) { S.impactSeen = A.impactAt; }   /* sound effects never dip or change the music */   // let the crash be heard
    // smooth: intensity rises in ~1.5 s, relaxes in ~5 s; danger rises in ~0.6 s, relaxes in ~3 s
    const tI = clamp(ti + .5 * td, 0, 1); S.dI += (tI - S.dI) * (1 - Math.exp(-dt / (tI > S.dI ? 1.5 : 5))); S.dD += (td - S.dD) * (1 - Math.exp(-dt / (td > S.dD ? .6 : 3)));
    M.intensity = S.dI; M.danger = S.dD;
    // zone choice with hysteresis (stay put unless another place clearly wins and has for a few seconds)
    if (M.force || !sc) { if (zone !== S.zone && zone !== S.pending) S.pending = zone; }
    else {
      let best = S.zone, bs = -1; for (const k in sc) { const s = sc[k] + (k === (S.pending || S.zone) ? .14 : 0); if (s > bs) { bs = s; best = k; } }
      if (best !== (S.pending || S.zone) && bs > .2) { if (S.cand !== best) { S.cand = best; S.candT = now; } else if (now - S.candT > 4 && now - S.lastSwitch > 14) { S.pending = best; S.cand = null; } } else S.cand = null;
    }
    if (menu && !M.force && S.zone !== 'royal' && S.pending !== 'royal') S.pending = 'royal';
  }


  function levels(now, snap) {
    const v = V.cur; if (!v) return; const P = ZONES[S.zone], i = M.intensity, d = M.danger, m = P.mix;
    const T = { fl: m.fl * (1 - .35 * ramp(i, .55, 1)) * (1 + .2 * d) * (1 - .85 * ramp(d, .45, .65)), dun: m.dun * (.35 + .65 * ramp(i, .05, .4)), gan: m.gan * ramp(i, .25, .6), bata: m.bata * ramp(i, .4, .75),
      sek: m.sek * (.55 + .45 * ramp(i, 0, .5)), ago: m.ago * ramp(i, .15, .5), gud: m.gud * (.6 + .4 * ramp(i, 0, .4)),
      hi: ramp(i, .5, .8) * Math.min(1, (m.dun + m.bata + m.sek) / 2.4), dg: ramp(d, .3, .6) * 1.05 };
    if (d > .5) { T.gan = Math.max(T.gan, .5 * m.gan + .3); T.bata = Math.max(T.bata, .6 * Math.max(m.bata, .5)); }
    STEMS.forEach(k => { const p = v.g[k].gain; if (snap) p.setValueAtTime(T[k] * .9, now); else p.setTargetAtTime(T[k] * .9, now, k === 'dg' ? .4 : .9); });
    try { v.src.playbackRate.setTargetAtTime(.99 + .035 * i + .015 * d, now, 2); } catch (e) { /* ignore */ }       // a very gentle lift in tempo with speed and danger; all stems share it, so they stay in sync
  }

  /* ---------------------------------- control tick (only moves knobs — never makes sound, so a late tick changes nothing audible) ---------------------------------- */
  function tick() {
    if (!A.ctx || A.ctx !== rc) return; const wall = performance.now(), dt = Math.min(1, Math.max(.05, (wall - S.lastT) / 1000 || .3)); S.lastT = wall;
    if (rc.state !== 'running') return;
    const now = rc.currentTime;
    try { sense(dt); levels(now); } catch (e) { if (!S.err) { S.err = 1; console.warn('Music sensing', e); } }
    if (S.pending && S.pending !== S.zone) { if (cache[S.pending]) switchTo(S.pending); else ensure(S.pending).catch(e => { S.pending = null; console.warn('Music zone render failed', e); }); }
  }

  let starting = false, tries = 0;
  function start() {
    if (M.running || starting) return; if (!A.ctx || !A.ready || !A.mus || !OC || tries >= 3) return;
    starting = true; tries++;
    try {
      rc = A.ctx; NB = A.nb; if (!rc || !NB) { starting = false; return; }
      mix = rc.createGain(); mix.gain.value = .85; trans = rc.createGain(); trans.gain.value = 1;
      const comp = rc.createDynamicsCompressor(); comp.threshold.value = -20; comp.knee.value = 14; comp.ratio.value = 3.2; comp.attack.value = .012; comp.release.value = .3;
      mix.connect(trans); trans.connect(comp); comp.connect(A.mus);
    } catch (e) { starting = false; console.warn('Music setup failed', e); return; }
    ensure('royal').then(() => {
      if (A.ctx !== rc) { starting = false; return; }
      S.lastT = performance.now(); S.zone = 'royal'; M.zone = 'royal';
      const z = cache.royal, now = rc.currentTime; V.cur = voice(z, 1.2); levels(now, true);
      if (A.stopLegacyMusic) A.stopLegacyMusic();                                                  // the old loop fades out, so only one theme ever plays
      timer = setInterval(tick, 250); M.running = true; starting = false; tick();
    }).catch(e => { starting = false; console.warn('Yoruba music unavailable, keeping the original theme', e); });
  }
  M.setZone = z => { if (ZONES[z]) M.force = { zone: z, i: M.force ? M.force.i : .3, d: M.force ? M.force.d : 0 }; };      // debug / testing helpers
  M.setLevel = (i, d) => { M.force = { zone: M.force ? M.force.zone : S.zone, i, d: d || 0 }; };
  M.auto = () => { M.force = null; };
  /* Keep-alive: any time the audio context is not running while the page is visible (autoplay lock, iOS 'interrupted', browser
     auto-suspend) we resume it - on a timer, on every tap/key, on focus and on state change. */
  const keep = () => { try { const x = A.ctx; if (x && x.state !== 'running' && !document.hidden) { const p = x.resume(); if (p && p.catch) p.catch(() => {}); } } catch (e) { /* ignore */ } };
  setInterval(keep, 700);
  ['pointerdown', 'touchstart', 'touchend', 'click', 'keydown'].forEach(t => document.addEventListener(t, keep, true));
  window.addEventListener('focus', keep); window.addEventListener('pageshow', keep); document.addEventListener('visibilitychange', keep);
  const hookState = () => { if (A.ctx && !A.ctx.__jk) { A.ctx.__jk = 1; A.ctx.onstatechange = keep; } };
  setInterval(hookState, 1000);
  const wait = setInterval(() => { if (M.running) { clearInterval(wait); return; } if (tries >= 3 && !starting) { clearInterval(wait); return; } if (A.ctx && A.ready && A.mus) start(); }, 400);
})();
