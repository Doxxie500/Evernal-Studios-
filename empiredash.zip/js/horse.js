/* EMPIRE DASH — Stage 7 · horse.js
   A stylised West-African riding horse (bay, black points, white blaze + sock) with traditional tack.
   Geometry is built once (lofted rings with two-bone skin weights) and posed on the CPU by OYOHorse.pose().
   Model space: +z forward, +y up, +x = the horse's right.  Ground y = 0.  Withers ≈ 1.50 m.                */
(function (root) {
  'use strict';
  const R = root.OYORig || require('./rig.js');
  const { MB, nv, loft, ellipsoid, strip, tube, box, mixc, shade, smooth, lerp, clamp, norm, sub, add, mul, cross, PI, TAU } = R;

  /* ---------------- palette ---------------- */
  const BAY = [.47, .25, .13], BAY_D = [.31, .16, .085], BAY_L = [.63, .40, .23], BLACK = [.085, .065, .055], WHITE = [.95, .92, .87], HOOF = [.17, .14, .12];
  const LEATHER = [.34, .18, .09], LEATHER_L = [.50, .30, .15], RED = [.76, .18, .13], INDIGO = [.16, .23, .58], GOLD = [.97, .77, .30], CREAM = [.94, .88, .74], IRON = [.56, .53, .50], TEAL = [.14, .45, .48];

  /* ---------------- bones ---------------- */
  const BN = ['ROOT', 'PELVIS', 'CHEST', 'NECK1', 'NECK2', 'HEAD', 'EAR_L', 'EAR_R', 'TAIL1', 'TAIL2', 'TAIL3',
    'FL_U', 'FL_F', 'FL_C', 'FL_P', 'FR_U', 'FR_F', 'FR_C', 'FR_P', 'HL_T', 'HL_G', 'HL_C', 'HL_P', 'HR_T', 'HR_G', 'HR_C', 'HR_P'];
  const B = {}; BN.forEach((n, i) => B[n] = i);
  const NB = BN.length;

  /* rest pivots [x,y,z] */
  const PIV = {
    ROOT: [0, 1.0, 0], PELVIS: [0, 1.2, -.5], CHEST: [0, 1.2, .45], NECK1: [0, 1.20, .62], NECK2: [0, 1.52, .94], HEAD: [0, 1.78, 1.20],
    EAR_L: [-.055, 1.90, 1.15], EAR_R: [.055, 1.90, 1.15], TAIL1: [0, 1.37, -.88], TAIL2: [0, 1.15, -.97], TAIL3: [0, .86, -1.0]
  };
  /* limb rest joints [y,z] — front: S(shoulder pivot) E(elbow) K(knee) F(fetlock) ; hind: S(hip) St(stifle) K(hock) F(fetlock); G = hoof sole centre */
  const LIMB = {
    front: { x: .155, S: [1.10, .52], E: [.90, .46], K: [.52, .47], F: [.19, .465], G: [0, .55] },
    hind: { x: .165, S: [1.14, -.48], E: [.90, -.27], K: [.50, -.58], F: [.18, -.52], G: [0, -.455] }
  };
  const len2 = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
  for (const k of ['front', 'hind']) {
    const L = LIMB[k];
    L.l1 = len2(L.S, L.E); L.l2 = len2(L.E, L.K); L.l3 = len2(L.K, L.F); L.p = [L.G[0] - L.F[0], L.G[1] - L.F[1]]; L.lp = Math.hypot(L.p[0], L.p[1]);
  }
  for (const [n, k, s] of [['FL', 'front', -1], ['FR', 'front', 1], ['HL', 'hind', -1], ['HR', 'hind', 1]]) {
    const L = LIMB[k], x = s * L.x, a = n + (k === 'front' ? '_U' : '_T'), b = n + (k === 'front' ? '_F' : '_G');
    PIV[a] = [x, L.S[0], L.S[1]]; PIV[b] = [x, L.E[0], L.E[1]]; PIV[n + '_C'] = [x, L.K[0], L.K[1]]; PIV[n + '_P'] = [x, L.F[0], L.F[1]];
  }

  /* ---------------- torso table: z, top, bottom, half-width ---------------- */
  const TZ = [.90, .84, .74, .60, .42, .22, .0, -.2, -.4, -.58, -.74, -.86, -.92];
  const TT = [1.12, 1.28, 1.42, 1.49, 1.50, 1.46, 1.41, 1.43, 1.46, 1.47, 1.43, 1.34, 1.22];
  const TB = [.98, .88, .79, .77, .78, .80, .84, .90, .93, .91, .90, .94, 1.05];
  const TX = [.10, .17, .23, .26, .27, .265, .25, .25, .275, .28, .24, .17, .09];
  function torsoAt(z) {   // → [cy, ry, rx]
    z = clamp(z, TZ[TZ.length - 1], TZ[0]);
    for (let i = 0; i < TZ.length - 1; i++) if (z <= TZ[i] && z >= TZ[i + 1]) {
      const t = (TZ[i] - z) / (TZ[i] - TZ[i + 1]), top = lerp(TT[i], TT[i + 1], t), bot = lerp(TB[i], TB[i + 1], t);
      return [(top + bot) / 2, (top - bot) / 2, lerp(TX[i], TX[i + 1], t)];
    }
    return [1.1, .3, .2];
  }
  /* point on the torso surface at height-angle th (0 = right side, 90° = top) pushed out by off */
  function torsoPt(z, th, off) {
    const [cy, ry, rx] = torsoAt(z), c = Math.cos(th), s = Math.sin(th);
    const nx = c / rx, ny = s / ry, nl = Math.hypot(nx, ny);
    return [rx * c + (nx / nl) * off, cy + ry * s + (ny / nl) * off, z];
  }
  const spineW = z => [B.PELVIS, B.CHEST, smooth(-.30, .30, z)];

  /* neck path: [y, z, rx, ry] */
  const NK = [[1.20, .62, .14, .27], [1.37, .78, .122, .235], [1.54, .94, .104, .2], [1.69, 1.07, .092, .175], [1.81, 1.19, .082, .15]];
  const neckW = t => t < .30 ? [B.CHEST, B.NECK1, smooth(0, .30, t)] : t < .65 ? [B.NECK1, B.NECK2, smooth(.30, .65, t)] : [B.NECK2, B.HEAD, smooth(.65, 1.0, t) * .9];

  /* head axis */
  const HA = .91, HS = Math.sin(HA), HC = Math.cos(HA), HP = [0, 1.80, 1.185];
  const hAxis = [0, -HS, HC], hUp = [0, HC, HS];
  const hp = (s, v, x) => [x || 0, HP[1] + hAxis[1] * s + hUp[1] * v, HP[2] + hAxis[2] * s + hUp[2] * v];

  function build(opts) {
    const m = MB(), anchors = {};
    const W1 = b => [b, b, 0];

    /* ===== torso ===== */
    {
      const secs = TZ.map((z, i) => ({ p: [0, (TT[i] + TB[i]) / 2, z], rx: TX[i], ry: (TT[i] - TB[i]) / 2, e: 2.2 }));
      loft(m, secs, {
        N: 16, cap0: .06, cap1: .05,
        color: f => {
          const z = f.z, up = f.sn, lo = clamp(-f.sn * 1.2 - .1, 0, 1);
          let c = mixc(BAY, BAY_D, clamp(up * .55, 0, 1)); c = mixc(c, BAY_L, lo * .8);
          const belly = smooth(.2, 1.0, -f.sn); c = mixc(c, [.52, .33, .19], belly * .5);
          return c;
        },
        weight: f => spineW(f.z)
      });
    }
    /* haunch + shoulder muscle, gluteal bulge */
    for (const s of [-1, 1]) {
      const col = BAY;
          }

    /* ===== neck ===== */
    const neckSecs = NK.map(n => ({ p: [0, n[0], n[1]], rx: n[2], ry: n[3], e: 2.1 }));
    {
      loft(m, neckSecs, {
        N: 14,
        color: f => { const up = f.sn; let c = mixc(BAY, BAY_D, clamp(up * .6, 0, 1)); c = mixc(c, BAY_L, clamp(-up, 0, 1) * .35); return c; },
        weight: f => neckW(f.t)
      });
    }
    const neckPt = (t, th, off) => {   // point on neck surface
      const f = t * (NK.length - 1), i = Math.min(NK.length - 2, Math.floor(f)), k = f - i, a = NK[i], b = NK[i + 1];
      const y = lerp(a[0], b[0], k), z = lerp(a[1], b[1], k), rx = lerp(a[2], b[2], k), ry = lerp(a[3], b[3], k);
      const tt = norm([0, b[0] - a[0], b[1] - a[1]]), V = norm(cross(tt, [1, 0, 0]));
      const c = Math.cos(th), s = Math.sin(th);
      return [rx * c, y + V[1] * (ry + off) * s, z + V[2] * (ry + off) * s];
    };

    /* ===== head ===== */
    const HEAD = W1(B.HEAD);
    {
      const rows = [[-.05, .085, .095, -.02], [.04, .105, .115, -.03], [.13, .108, .125, -.045], [.23, .092, .125, -.055], [.33, .07, .095, -.03], [.43, .062, .075, -.012], [.51, .066, .076, -.004], [.575, .058, .066, 0]];
      const secs = rows.map(r => ({ p: [0, HP[1] + hAxis[1] * r[0], HP[2] + hAxis[2] * r[0]], rx: r[1], ry: r[2], dv: r[3], e: 2.1 }));
      loft(m, secs, {
        N: 12, cap0: .05, cap1: .03,
        color: f => {
          const t = f.t, top = f.sn, x = Math.abs(f.cs);
          let c = mixc(BAY_D, BAY, .6); c = mixc(c, BLACK, smooth(.55, .9, t) * .85);      // black muzzle
          if (top > .55 && t > .08 && t < .86 && Math.abs(f.x) < .026 + .012 * (1 - t)) c = mixc(c, WHITE, .95);   // white blaze
          if (top < -.3) c = mixc(c, BAY_D, .4);
          return c;
        },
        weight: () => HEAD
      });
      // cheeks (masseter) and lip/chin
      for (const s of [-1, 1]) {
        ellipsoid(m, hp(.16, -.062, s * .082), [.032, .058, .075], { col: mixc(BAY, BAY_D, .3), w: HEAD, seg: 8, rings: 5, pitch: HA - 1.5707 });
        ellipsoid(m, hp(.54, -.008, s * .04), [.02, .013, .024], { col: [.03, .02, .02], w: HEAD, seg: 7, rings: 4, pitch: HA - 1.5707 });       // nostrils
        // eyes: dark, glossy, with highlight
        const ep = hp(.105, .028, s * .104);
        ellipsoid(m, ep, [.016, .024, .026], { col: [.06, .035, .03], w: HEAD, seg: 8, rings: 5, pitch: HA - 1.5707 });
        ellipsoid(m, [ep[0] + s * .004, ep[1] + .008, ep[2] + .008], [.006, .008, .006], { col: [.95, .95, .92], w: HEAD, seg: 5, rings: 3 });
        ellipsoid(m, [ep[0] - s * .003, ep[1] + .018, ep[2] - .004], [.019, .008, .028], { col: BAY_D, w: HEAD, seg: 6, rings: 3, pitch: HA - 1.5707 });     // eyelid
      }
      ellipsoid(m, hp(.50, -.075, 0), [.045, .02, .05], { col: BLACK, w: HEAD, seg: 8, rings: 4, pitch: HA - 1.5707 });   // chin
      // ears (bones EAR_L / EAR_R)
      for (const s of [-1, 1]) {
        const base = [s * .055, 1.895, 1.14], ex = [s * (.052 + .02), 2.035, 1.215], B0 = s < 0 ? B.EAR_L : B.EAR_R;
        const lp = t => [lerp(base[0], ex[0], t), lerp(base[1], ex[1], t), lerp(base[2], ex[2], t)];
        const secs2 = [{ p: base, rx: .026, ry: .016 }, { p: lp(.45), rx: .031, ry: .018 }, { p: lp(.82), rx: .02, ry: .013 }, { p: ex, rx: .006, ry: .006 }];
        loft(m, secs2, { N: 7, cap1: .02, color: f => f.k >= 0 && f.sn > .3 ? mixc(BAY_D, [.65, .42, .34], .5) : BAY_D, weight: () => [B0, B0, 0] });
      }
      // forelock tuft
      for (let i = 0; i < 3; i++) {
        const x = (i - 1) * .02, st = hp(.02, .12, x), pts = [st, hp(.07, .11, x * 1.5), hp(.12, .09, x * 2), hp(.17, .06, x * 2.4)];
        strip(m, pts, [.035, .034, .028, .01], [1, 0, 0], { col: BLACK, w: HEAD, color: (j, t) => shade(BLACK, 1 + t * .3) });
      }
    }

    /* ===== mane (falls on the horse's right) ===== */
    {
      let seed = 71; const rn = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
      const NT = 30;
      for (let j = 0; j < NT; j++) {
        const t = 1 - j / (NT - 1) * .93 - .02, th0 = PI / 2 - .12 + rn() * .1;
        const base = neckPt(clamp(t, 0, 1), th0, .004), tt = clamp(t, 0, 1);
        const L = lerp(.20, .36, 1 - tt) * (.85 + rn() * .3), pts = [];
        const hang = norm([.35 + rn() * .2, -1, -.25 - tt * .1]);
        for (let q = 0; q < 6; q++) {
          const u = q / 5, curve = Math.sin(u * 1.3) * .02;
          pts.push([base[0] + hang[0] * L * u + .02 * (1 - u), base[1] + hang[1] * L * u * (.92 + .3 * u) + curve, base[2] + hang[2] * L * u - .03 * u * u]);
        }
        const ph = rn() * TAU, nw = neckW(tt), tone = .75 + rn() * .45;
        strip(m, pts, [.012, .05, .058, .052, .036, .008].map(w => w * (.9 + rn() * .3)), [0, 0.2, 1], {
          color: (i, u) => shade(BLACK, tone * (1 + u * .25)), weight: () => nw, flex: (i, u) => [1, u * u, ph]
        });
      }
    }

    /* ===== tail ===== */
    {
      loft(m, [{ p: [0, 1.42, -.80], rx: .05, ry: .05 }, { p: [0, 1.39, -.9], rx: .048, ry: .05 }, { p: [0, 1.30, -.98], rx: .04, ry: .045 }, { p: [0, 1.15, -1.0], rx: .03, ry: .036 }], {
        N: 8, color: () => BLACK, weight: f => f.s < 1 ? [B.PELVIS, B.TAIL1, f.s / 2] : f.s < 2 ? [B.TAIL1, B.TAIL2, f.s - 1] : [B.TAIL2, B.TAIL2, 0]
      });
      let seed = 303; const rn = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
      const NS = 26;
      for (let j = 0; j < NS; j++) {
        const a = (j / NS) * TAU + rn() * .4, rx = Math.cos(a) * .05, ry = Math.sin(a) * .035, L = .72 + rn() * .32, spread = (rx * 2.2), pts = [];
        const st = [rx * .8, 1.37 + ry * .8, -.9];
        for (let q = 0; q < 9; q++) {
          const u = q / 8;
          pts.push([st[0] + spread * u * 1.3, st[1] - L * u * (.92 + .1 * u) + .06 * Math.sin(u * 2.8), st[2] - .08 - .16 * Math.sin(u * 2.2) - .05 * u]);
        }
        const ph = rn() * TAU, tone = .7 + rn() * .6;
        strip(m, pts, [.012, .055, .062, .06, .056, .05, .04, .028, .008].map(w => w * (.9 + rn() * .25)), [.55, 0, .45], {
          color: (i, u) => shade(BLACK, tone * (1 + u * .2)),
          weight: (i, u) => { const d = u * L; return d < .22 ? [B.TAIL1, B.TAIL2, smooth(0, .22, d) * .6] : d < .5 ? [B.TAIL2, B.TAIL3, smooth(.22, .5, d)] : [B.TAIL3, B.TAIL3, 0]; },
          flex: (i, u) => [2, u * u, ph]
        });
      }
    }

    /* ===== legs ===== */
    const legCol = (y, sock) => {
      let c = BAY; c = mixc(c, BAY_L, smooth(.95, 1.1, y) * .3);
      c = mixc(c, BLACK, smooth(.64, .44, y) * .92);
      if (sock) c = mixc(c, WHITE, smooth(.34, .22, y));
      return c;
    };
    function leg(side, sock, front) {
      const s = side, L = front ? LIMB.front : LIMB.hind, x = s * L.x, n = (side < 0 ? 'L' : 'R'), pre = (front ? 'F' : 'H') + n + '_';
      const bU = B[pre + (front ? 'U' : 'T')], bF = B[pre + (front ? 'F' : 'G')], bC = B[pre + 'C'], bP = B[pre + 'P'];
      // sections: [y, z, rx, ry]  (ry measured front-to-back)
      let pts, wts;
      if (front) {
        pts = [[.97, .47, .11, .125], [.84, .47, .098, .108], [.70, .47, .084, .092], [.58, .47, .078, .084], [.52, .47, .08, .086], [.46, .47, .054, .06], [.36, .47, .043, .054], [.26, .467, .042, .052], [.19, .465, .056, .062], [.145, .48, .05, .054]];
        wts = [[bU, bU, 0], [bU, bF, .5], [bF, bF, 0], [bF, bF, 0], [bF, bC, .5], [bC, bC, 0], [bC, bC, 0], [bC, bC, 0], [bC, bP, .5], [bP, bP, 0]];
      } else {
        pts = [[1.02, -.34, .125, .17], [.92, -.33, .112, .15], [.80, -.40, .09, .125], [.66, -.49, .07, .105], [.54, -.57, .062, .098], [.45, -.56, .048, .062], [.34, -.545, .04, .05], [.25, -.53, .04, .05], [.18, -.52, .054, .06], [.14, -.50, .05, .054]];
        wts = [[B.PELVIS, bU, .2], [bU, bU, 0], [bU, bF, .5], [bF, bF, 0], [bF, bC, .5], [bC, bC, 0], [bC, bC, 0], [bC, bC, 0], [bC, bP, .5], [bP, bP, 0]];
      }
      const secs = pts.map((q, i) => ({ p: [x, q[0], q[1]], rx: q[2], ry: q[3], e: 2.3, w: wts[i] }));
      loft(m, secs, { N: 10, color: f => legCol(f.y, sock), weight: f => f.pole ? wts[f.s] : wts[f.s] });
      // hoof: slanted cone from coronet to ground
      const c0 = [x, L.F[0] - (front ? .11 : .09), L.F[1] + (front ? .045 : .035)], tz = L.G[1];
      const hsecs = [{ p: [x, c0[1] + .01, c0[2] - .01], rx: .05, ry: .052, w: [bP, bP, 0] }, { p: [x, c0[1] - .02, c0[2] + .005], rx: .062, ry: .07, w: [bP, bP, 0] }, { p: [x, .018, tz - .01], rx: .074, ry: .088, w: [bP, bP, 0] }, { p: [x, .0, tz - .005], rx: .074, ry: .09, w: [bP, bP, 0] }];
      loft(m, hsecs, { N: 10, cap1: .004, color: f => f.s === 0 ? shade(HOOF, 1.25) : f.s === 1 ? shade(HOOF, 1.15) : HOOF, weight: f => [bP, bP, 0] });
      // hock point / knee boss / chestnut
      if (!front) ellipsoid(m, [x, .52, -.62], [.04, .055, .05], { col: BLACK, w: [bC, bC, 0], seg: 7, rings: 4 });
      else ellipsoid(m, [x, .52, .515], [.045, .05, .035], { col: BLACK, w: [bF, bC, .5], seg: 7, rings: 4 });
      // fetlock feather
      ellipsoid(m, [x, .17, L.F[1] - (front ? .025 : .03)], [.03, .045, .028], { col: sock ? WHITE : BLACK, w: [bC, bP, .5], seg: 7, rings: 4 });
    }
    leg(-1, false, true); leg(1, false, true); leg(-1, true, false); leg(1, false, false);

    /* ===== body-conforming tack ===== */
    /* grid panel on the torso: z0..z1, theta from a0 to a1 (right side, mirrored by s) */
    function panel(s, z0, z1, a0, a1, off, nz, na, col, wfn, colfn) {
      const v0 = nv(m);
      const P = (i, j) => { const z = lerp(z0, z1, i / nz), th = lerp(a0, a1, j / na), p = torsoPt(z, th, off), t = torsoAt(z), c = Math.cos(th), sn = Math.sin(th), nx = c / t[2], ny = sn / t[1], nl = Math.hypot(nx, ny); return { p: [s * p[0], p[1], p[2]], n: [s * nx / nl, ny / nl, 0], z }; };
      for (let i = 0; i < nz; i++) for (let j = 0; j < na; j++) {
        const c = colfn ? colfn(i, j, nz, na) : col, base = nv(m);
        for (const [qi, qj] of [[i, j], [i + 1, j], [i, j + 1], [i + 1, j + 1]]) { const q = P(qi, qj), k = R.vert(m, q.p[0], q.p[1], q.p[2], c, wfn(q.z), null); m.n[k * 3] = q.n[0]; m.n[k * 3 + 1] = q.n[1]; m.n[k * 3 + 2] = q.n[2]; }
        m.i.push(base, base + 1, base + 2, base + 2, base + 1, base + 3);
      }
      return { v0, v1: nv(m) };
    }
    const o_edge = (i, j, nz, na) => i === 0 || j === 0 || i === nz || j === na;
    const stripes = (i, j, nz, na) => {
      const eb = Math.min(i, nz - 1 - i, na - 1 - j);       // distance in cells from the free edges (top seam excluded)
      if (eb === 0) return RED;
      if (eb === 1) return GOLD;
      const c = (i + .5) / nz;
      if (c > .38 && c < .62 && j > 1 && j < na - 2) return mixc(CREAM, GOLD, .2);
      return ((i + j) & 1) ? INDIGO : mixc(INDIGO, TEAL, .35);
    };

    for (const s of [-1, 1]) {
      // saddle blanket (embroidered): spans top → down the flank
      panel(s, .30, -.40, 1.571, .12, .012, 11, 9, INDIGO, spineW, stripes);
      // tassels along blanket lower edge
      for (let i = 0; i <= 7; i++) {
        const z = lerp(.30, -.40, i / 7), p = torsoPt(z, .12, .02), wt = spineW(z);
        strip(m, [[s * p[0], p[1], p[2]], [s * (p[0] + .01), p[1] - .05, p[2]], [s * (p[0] + .015), p[1] - .10, p[2]]], [.03, .03, .018], [0, 0, 1], { col: RED, color: (j, u) => j === 2 ? GOLD : RED, weight: () => spineW(z), flex: (j, u) => [3, u * .5, i] });
      }
      // leather saddle flaps
      panel(s, .12, -.30, 1.30, .50, .028, 5, 4, LEATHER, spineW, (i, j, nz, na) => (i === 0 || i === nz || j === na) ? LEATHER_L : LEATHER);
      // stirrup leather + iron
      const sx = s * (.27), top = [sx, 1.20, -.06], bot = [s * .31, .88, -.05];
      tube(m, [top, [s * .29, 1.0, -.055], bot], [.014, .014, .014], { seg: 5, col: LEATHER, w: spineW(-.05).slice(), weight: () => spineW(-.05) });
      // stirrup (iron, flat box-ish loop)
      const stir = [[s * .31, .88, -.05], [s * .31, .80, -.125], [s * .315, .755, -.05], [s * .31, .80, .075], [s * .31, .88, -.05]];
      tube(m, stir, [.011, .011, .011, .011, .011], { seg: 5, col: IRON, weight: () => spineW(-.05) });
      ellipsoid(m, [s * .31, .76, -.04], [.012, .008, .075], { col: IRON, w: spineW(-.05), seg: 5, rings: 3 });
    }
    // seat, pommel, cantle (Sudanic high-horned saddle)
    {
      const wf = z => spineW(z);
      loft(m, [{ p: [0, 1.435, .20], rx: .085, ry: .03 }, { p: [0, 1.455, .08], rx: .13, ry: .035 }, { p: [0, 1.445, -.08], rx: .15, ry: .035 }, { p: [0, 1.46, -.22], rx: .14, ry: .04 }, { p: [0, 1.48, -.34], rx: .1, ry: .05 }],
        { N: 10, e: 2.4, cap0: .03, cap1: .03, color: f => mixc(LEATHER_L, LEATHER, clamp(-f.sn, 0, 1) * .6), weight: f => wf(f.z) });
      // pommel horn
      loft(m, [{ p: [0, 1.46, .20], rx: .055, ry: .04 }, { p: [0, 1.545, .225], rx: .045, ry: .035 }, { p: [0, 1.62, .25], rx: .06, ry: .04 }], { N: 8, cap1: .03, color: f => f.s === 2 ? GOLD : LEATHER, weight: () => spineW(.22) });
      ellipsoid(m, [0, 1.655, .255], [.05, .026, .03], { col: GOLD, w: spineW(.22), seg: 8, rings: 4 });
      // cantle (curved back)
      loft(m, [{ p: [0, 1.46, -.28], rx: .13, ry: .04 }, { p: [0, 1.54, -.335], rx: .12, ry: .035 }, { p: [0, 1.60, -.37], rx: .1, ry: .03 }], { N: 8, e: 3, cap1: .02, color: f => f.s === 2 ? GOLD : LEATHER, weight: () => spineW(-.32) });
      // girth band
      const gp = [], gz = .14;
      for (let a = -.35; a >= -2.8 + .0; a -= .25) { const q = torsoPt(gz, a, .02); gp.push([q[0], q[1], q[2]]); }
      for (const s of [-1, 1]) {
        const pts = gp.map(q => [s * q[0], q[1], q[2]]);
        strip(m, pts, pts.map(() => .07), [0, 0, 1], { col: LEATHER_L, weight: () => spineW(gz) });
      }
    }
    // breast collar with tassels & medallion
    {
      const bc = [];
      for (const s of [-1, 1]) {
        const pts = [[s * .26, 1.30, .22], [s * .27, 1.18, .42], [s * .21, 1.02, .66], [s * .12, .96, .80], [0, .94, .85]].map(q => q);
        tube(m, pts, [.016, .018, .02, .02, .02], { seg: 6, col: RED, weight: (i, t) => i < 2 ? spineW(.3) : [B.CHEST, B.CHEST, 0] });
        const d = [s * .272, 1.19, .44];
        ellipsoid(m, d, [.012, .03, .03], { col: GOLD, w: W1(B.CHEST), seg: 8, rings: 4 });
      }
      ellipsoid(m, [0, .93, .855], [.04, .045, .02], { col: GOLD, w: W1(B.CHEST), seg: 9, rings: 5 });
      ellipsoid(m, [0, .93, .87], [.022, .026, .01], { col: RED, w: W1(B.CHEST), seg: 8, rings: 4 });
      for (const [x, y] of [[-.1, .93], [-.05, .9], [0, .89], [.05, .9], [.1, .93]]) {
        strip(m, [[x, y - .02, .83], [x * 1.1, y - .1, .84], [x * 1.15, y - .2, .83]], [.03, .036, .02], [1, 0, 0], { color: (j, u) => j === 2 ? GOLD : RED, weight: () => [B.CHEST, B.CHEST, 0], flex: (j, u) => [3, u * .6, x * 20] });
      }
    }
    // crupper strap with tassels over the croup
    {
      const pts = [[0, 1.492, -.30], [0, 1.486, -.55], [0, 1.43, -.80], [0, 1.40, -.88]];
      tube(m, pts, [.016, .017, .017, .016], { seg: 6, col: RED, weight: (i) => i === 0 ? spineW(-.3) : [B.PELVIS, B.PELVIS, 0] });
      for (const s of [-1, 1]) {
        const p = torsoPt(-.6, .95, .015);
        tube(m, [[0, 1.5, -.55], [s * .12, 1.49, -.6], [s * p[0] * .9, p[1] - .12, -.62]], [.012, .012, .012], { seg: 5, col: LEATHER, weight: () => [B.PELVIS, B.PELVIS, 0] });
        strip(m, [[s * p[0] * .9, p[1] - .12, -.62], [s * p[0], p[1] - .2, -.625], [s * p[0] * 1.02, p[1] - .3, -.63]], [.03, .04, .02], [1, 0, 0], { color: (j) => j === 2 ? GOLD : RED, weight: () => [B.PELVIS, B.PELVIS, 0], flex: (j, u) => [3, u * .7, s] });
      }
    }

    /* ===== bridle (all bone HEAD) ===== */
    {
      const ring = (s, v0, xs, ys, off, n, sMax) => {  // loop around head at axial position s
        const pts = [], c = [0, HP[1] + hAxis[1] * s, HP[2] + hAxis[2] * s];
        for (let k = 0; k <= n; k++) { const th = TAU * k / n, cx = Math.cos(th), sn = Math.sin(th); pts.push([cx * (xs + off), c[1] + hUp[1] * (sn * (ys + off) + v0), c[2] + hUp[2] * (sn * (ys + off) + v0)]); }
        return pts;
      };
      // noseband
      tube(m, ring(.40, -.012, .07, .082, .008, 14), 0.011, { seg: 5, col: LEATHER_L, weight: () => HEAD });
      // browband
      const bb = []; for (let k = 0; k <= 8; k++) { const x = lerp(-.112, .112, k / 8), q = hp(.045, .108 + .02 * Math.cos((k / 8 - .5) * 3), x); bb.push(q); }
      tube(m, bb, 0.011, { seg: 5, col: RED, weight: () => HEAD });
      // crownpiece + throatlatch
      for (const s of [-1, 1]) {
        tube(m, [hp(.045, .1, s * .108), hp(-.01, .12, s * .09), [s * .09, 1.905, 1.12]], [.011, .011, .011], { seg: 5, col: LEATHER_L, weight: () => HEAD });
        tube(m, [hp(.045, .108, s * .112), hp(.10, .02, s * .115), hp(.16, -.07, s * .1), hp(.20, -.14, s * .06)], 0.011, { seg: 5, col: LEATHER_L, weight: () => HEAD });   // cheekpiece
        tube(m, [hp(.40, -.012 + .0, s * .075), hp(.30, -.04, s * .095), hp(.19, -.03, s * .108)], 0.009, { seg: 5, col: LEATHER_L, weight: () => HEAD });
        ellipsoid(m, hp(.045, .108, s * .114), [.014, .02, .02], { col: GOLD, w: HEAD, seg: 7, rings: 4 });
        ellipsoid(m, hp(.14, -.01, s * .113), [.01, .02, .02], { col: GOLD, w: HEAD, seg: 6, rings: 3 });
        // bit ring
        const bp = hp(.50, -.034, s * .069);
        const rp = [], cc = bp; for (let k = 0; k <= 10; k++) { const a = TAU * k / 10; rp.push([cc[0] + s * .012, cc[1] + Math.cos(a) * .026 * hUp[1] + Math.sin(a) * .026 * hAxis[1], cc[2] + Math.cos(a) * .026 * hUp[2] + Math.sin(a) * .026 * hAxis[2]]); }
        tube(m, rp, 0.0085, { seg: 5, col: IRON, weight: () => HEAD });
        anchors[s < 0 ? 'bitL' : 'bitR'] = [bp[0] + s * .02, bp[1], bp[2]];
      }
      const t2 = []; for (let k = 0; k < 7; k++) t2.push(hp(.50, -.034, lerp(-.069, .069, k / 6)));
      tube(m, t2, 0.007, { seg: 4, col: IRON, weight: () => HEAD });
      // brow tassels
      for (const x of [-.07, -.035, 0, .035, .07]) strip(m, [hp(.045, .105, x), hp(.05, .075, x), hp(.055, .04, x)], [.022, .026, .014], [1, 0, 0], { color: (j) => j === 2 ? GOLD : RED, weight: () => HEAD, flex: (j, u) => [3, u * .4, x * 40] });
    }

    /* ===== horse regalia (Ọjà Ìlú): cloth trappings, brass and plumes — chosen by opts.regalia =====
       cow3k / cow5k / cow8k are bought with earned cowries (simple → richer); 'regalia' is the full royal set (paid). All cosmetic. */
    const RG = opts && opts.regalia;
    if (RG === 'cow3k' || RG === 'cow5k' || RG === 'cow8k' || RG === 'regalia') {
      const HW = W1(B.HEAD), CR = [.62, .08, .12], DEEP = [.46, .06, .1];
      const mk = (base, alt, edge, trim, gem) => (i, j, nz, na) => {
        const eb = Math.min(i, nz - 1 - i, na - 1 - j); if (eb === 0) return edge; if (eb === 1) return trim;
        if (gem && i % 3 === 1 && j % 3 === 1) return gem; return ((i + j) & 1) ? base : alt;
      };
      const cloth = (z0, z1, a0, a1, off, nz, na, fn) => { for (const s of [-1, 1]) panel(s, z0, z1, a0, a1, off, nz, na, RED, spineW, fn); };
      const fringe = (z0, z1, th, n, c1, c2, len, off) => {
        for (const s of [-1, 1]) for (let i = 0; i <= n; i++) {
          const z = lerp(z0, z1, i / n), p = torsoPt(z, th, off || .04), wt = spineW(z);
          strip(m, [[s * p[0], p[1], p[2]], [s * (p[0] + .01), p[1] - len * .5, p[2]], [s * (p[0] + .016), p[1] - len, p[2]]], [.03, .03, .016], [0, 0, 1], { col: c1, color: (j) => j === 2 ? c2 : c1, weight: () => wt, flex: (j, u) => [3, u * .5, i + s] });
        }
      };
      const forehead = (r, plate, boss) => {      // brass disc / plate on the brow
        ellipsoid(m, hp(.22, .082, 0), [.046 * r, .011, .11 * r], { col: plate, w: HW, seg: 10, rings: 5, pitch: HA - 1.5707 });
        ellipsoid(m, hp(.235, .092, 0), [.02, .013, .02], { col: boss, w: HW, seg: 8, rings: 4, pitch: HA - 1.5707 });
      };
      const plume = (c1, c2, h) => {
        const b = hp(.02, .115, 0);
        for (const x of [-.02, 0, .02]) strip(m, [[x, b[1], b[2]], [x * 2, b[1] + h * .4, b[2] - .02], [x * 3, b[1] + h * .75, b[2] - .045], [x * 3.4, b[1] + h, b[2] - .02]], [.03, .045, .04, .01], [1, 0, 0], { color: (j, u) => mixc(c1, c2, u), weight: () => HW, flex: (j, u) => [3, u * .6, x * 30] });
      };
      const chestBells = (n, c) => { for (let k = 0; k < n; k++) { const x = lerp(-.11, .11, n === 1 ? .5 : k / (n - 1)); ellipsoid(m, [x, .985 - .035 * (1 - Math.abs(x) / .11), .87], [.02, .028, .02], { col: c, w: W1(B.CHEST), seg: 7, rings: 4 }); } };

      if (RG === 'cow3k') {                         // simple: red & cream cloth over shoulder and hip, fringe, brass brow disc
        const fn = mk(CR, mixc(CR, CREAM, .18), CREAM, GOLD);
        cloth(.64, .36, 1.25, -.25, .04, 6, 6, fn); cloth(-.40, -.78, 1.25, -.25, .04, 6, 6, fn);
        fringe(.64, .36, -.25, 5, RED, CREAM, .09); fringe(-.40, -.78, -.25, 5, RED, CREAM, .09);
        forehead(.55, GOLD, CREAM);
      } else if (RG === 'cow5k') {                  // teal & gold cloth, breast bells, brass brow plate and cheek studs
        const fn = mk(TEAL, mixc(TEAL, INDIGO, .45), GOLD, CREAM);
        cloth(.68, .34, 1.35, -.32, .042, 7, 7, fn); cloth(-.38, -.82, 1.35, -.32, .042, 7, 7, fn);
        fringe(.68, .34, -.32, 6, TEAL, GOLD, .11); fringe(-.38, -.82, -.32, 6, TEAL, GOLD, .11);
        forehead(.8, GOLD, RED); chestBells(5, GOLD);
        for (const s of [-1, 1]) ellipsoid(m, hp(.16, .01, s * .112), [.01, .026, .026], { col: GOLD, w: HW, seg: 7, rings: 4 });
      } else if (RG === 'cow8k') {                  // quilted indigo caparison, chest fringe, gilded face plate, red plume
        const fn = mk(INDIGO, mixc(INDIGO, TEAL, .4), RED, GOLD, CREAM);
        cloth(.70, .32, 1.45, -.4, .045, 8, 8, fn); cloth(-.36, -.86, 1.45, -.4, .045, 8, 8, fn);
        fringe(.70, .32, -.4, 7, RED, GOLD, .13); fringe(-.36, -.86, -.4, 7, RED, GOLD, .13);
        forehead(1, GOLD, RED); ellipsoid(m, hp(.42, .068, 0), [.036, .009, .09], { col: GOLD, w: HW, seg: 8, rings: 4, pitch: HA - 1.5707 });
        plume(RED, GOLD, .22); chestBells(7, GOLD);
      } else {                                      // 'regalia' — full royal set: crimson & gold embroidered caparison, horned gilded frontlet, tall plume, cowrie collar
        const fn = mk(CR, DEEP, GOLD, CREAM, GOLD);
        cloth(.72, .30, 1.5, -.55, .05, 9, 9, fn); cloth(-.34, -.90, 1.5, -.55, .05, 9, 9, fn);
        fringe(.72, .30, -.55, 8, RED, GOLD, .16, .05); fringe(-.34, -.90, -.55, 8, RED, GOLD, .16, .05);
        forehead(1.15, GOLD, RED); ellipsoid(m, hp(.42, .068, 0), [.04, .01, .1], { col: GOLD, w: HW, seg: 8, rings: 4, pitch: HA - 1.5707 });
        tube(m, [hp(.26, .09, 0), hp(.28, .13, 0), hp(.29, .19, 0)], [.014, .01, .004], { seg: 5, col: GOLD, weight: () => HW });
        plume(RED, GOLD, .34); chestBells(9, GOLD);
        const ring = []; for (let k = 0; k <= 16; k++) ring.push(neckPt(.12, TAU * k / 16, .03));       // collar of cowries round the neck base
        tube(m, ring, .012, { seg: 5, col: GOLD, weight: () => neckW(.12) });
        for (let k = 0; k < 14; k++) { const q = neckPt(.12, TAU * k / 14 + .2, .035); ellipsoid(m, q, [.02, .028, .02], { col: CREAM, w: neckW(.12), seg: 6, rings: 4 }); }
        const tr = []; for (let k = 0; k <= 10; k++) { const a = TAU * k / 10; tr.push([Math.cos(a) * .062, 1.385 + Math.sin(a) * .062, -.93]); }
        tube(m, tr, .01, { seg: 5, col: GOLD, weight: () => [B.TAIL1, B.TAIL1, 0] });                 // gold tail band
      }
    }

    anchors.seat = [0, 1.465, -.06];
    anchors.stirrupL = [-.31, .76, -.03]; anchors.stirrupR = [.31, .76, -.03];
    return { mesh: m, anchors };
  }

  const api = { build, BN, B, NB, PIV, LIMB, TZ, TT, TB, TX, torsoAt, torsoPt, spineW, NK, HP, hAxis, hUp, palette: { BAY, BLACK, WHITE, LEATHER, RED, GOLD, INDIGO, CREAM, IRON, HOOF } };
  root.OYOHorse = Object.assign(root.OYOHorse || {}, api);
  if (typeof module !== 'undefined' && module.exports) module.exports = root.OYOHorse;
})(typeof window !== 'undefined' ? window : globalThis);
