/* EMPIRE DASH — Stage 28 · dust.js
   Realistic road dust behind the galloping horse. One billboard mesh (1 draw call), CPU particles, depth-sorted.
   - hoof STRIKE puffs (planted-foot detection from the gait engine, so dust lands exactly when a hoof lands)
   - hoof LIFT-OFF kick: soil thrown backwards + tiny dark grit that flies ballistically
   - hanging TRAIL: big low-alpha haze behind the hindquarters that drifts with the wind and lingers 3-6 s
   - brake SKID clouds, jump LANDING bursts
   - strong on the red laterite roads, faint on grass/off-road; fades near the camera so it never blocks the view
   Depends on riding.js (calls OYODust.build / OYODust.update lazily). */
(function () {
  'use strict';
  const PI = Math.PI, clamp = (v, a, b) => Math.min(b, Math.max(a, v)), lerp = (a, b, t) => a + (b - a) * t;
  const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const N = 320;                                     // particle pool
  let ROAD = [.80, .58, .40], OFF = [.66, .58, .42], HAZE = [.88, .75, .60], GRIT = [.36, .22, .14];
  const PAL_E = { r: [.93, .78, .60], o: [.88, .77, .58], h: [.96, .88, .74], g: [.78, .62, .45] };   // Endless Run: light laterite dust, never dark

  const D = { built: false, dead: false };
  let mesh, P, C, UV, ord, dist, lastCount = 0, T = 0, ptr = 0;
  const px = new Float32Array(N), py = new Float32Array(N), pz = new Float32Array(N), vx = new Float32Array(N), vy = new Float32Array(N), vz = new Float32Array(N),
    age = new Float32Array(N), life = new Float32Array(N), s0 = new Float32Array(N), s1 = new Float32Array(N), rot = new Float32Array(N), rv = new Float32Array(N),
    a0 = new Float32Array(N), gyA = new Float32Array(N), drag = new Float32Array(N), buoy = new Float32Array(N),
    cr = new Float32Array(N), cg = new Float32Array(N), cb = new Float32Array(N), typ = new Uint8Array(N), cell = new Uint8Array(N), alive = new Uint8Array(N);
  const newEm = () => ({ grounded: [true, true, true, true], ta: 0, tb: 0, prevAir: false, prevSpeed: 0 });   // one per horse that emits dust
  const EM_PL = newEm(), EM_NPC = newEm(), EM_NPC2 = newEm(), EM_NPC3 = newEm(), EM_NPC4 = newEm(), EM_MORE = {};   // EM_MORE: emitters for the extra road riders (slots 5 and up), made on first use
  const R = Math.random;

  /* ---------- soft dust-cloud atlas (2 x 2 cells: three puffs + one hard grit speck) ----------
     Stage 28: the atlas is now an OPAQUE white-on-black luminance map used as an opacity map (getAlphaFromRGB), and the puff colour comes
     purely from the vertex colours. The old RGBA atlas had black, fully transparent texels around every puff; bilinear/mip filtering blended
     them in and gave every cloud a dark, dirty rim (worst on the light Endless Run palette). */
  function makeAtlas(scene) {
    const B = BABYLON, S = 256, H = S / 2, t = new B.DynamicTexture('oyoDustAtlas', { width: S, height: S }, scene, true), g = t.getContext();
    g.globalCompositeOperation = 'source-over'; g.fillStyle = '#000'; g.fillRect(0, 0, S, S);
    for (let c = 0; c < 4; c++) {
      const ox = (c % 2) * H, oy = Math.floor(c / 2) * H, cx = ox + H / 2, cy = oy + H / 2;
      g.save(); g.beginPath(); g.rect(ox, oy, H, H); g.clip();
      if (c < 3) {
        const blobs = 20 + c * 4;
        for (let i = 0; i < blobs; i++) {
          const a = R() * PI * 2, d = Math.pow(R(), .7) * H * .27, r = H * (.12 + R() * .17), x = cx + Math.cos(a) * d, y = cy + Math.sin(a) * d * .85;
          const gr = g.createRadialGradient(x, y, 0, x, y, r), al = .13 + R() * .17;
          gr.addColorStop(0, 'rgba(255,255,255,' + al + ')'); gr.addColorStop(.55, 'rgba(255,255,255,' + al * .45 + ')'); gr.addColorStop(1, 'rgba(255,255,255,0)');
          g.fillStyle = gr; g.fillRect(ox, oy, H, H);
        }
        const m = g.createRadialGradient(cx, cy, H * .2, cx, cy, H * .5);      // fade every cell to pure black at its border so cells never bleed
        m.addColorStop(0, 'rgba(0,0,0,0)'); m.addColorStop(.62, 'rgba(0,0,0,.1)'); m.addColorStop(1, 'rgba(0,0,0,1)');
        g.fillStyle = m; g.fillRect(ox, oy, H, H);
      } else {
        const gr = g.createRadialGradient(cx, cy, 0, cx, cy, H * .34);
        gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(.6, 'rgba(255,255,255,.95)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
        g.fillStyle = gr; g.fillRect(ox, oy, H, H);
      }
      g.restore();
    }
    t.hasAlpha = false; t.getAlphaFromRGB = true; t.wrapU = t.wrapV = B.Texture.CLAMP_ADDRESSMODE; t.update(); return t;
  }

  D.build = function (scene, World) {
    const B = BABYLON;
    D.scene = scene; D.World = World;
    P = new Float32Array(N * 12); C = new Float32Array(N * 16); UV = new Float32Array(N * 8); ord = new Int16Array(N); dist = new Float32Array(N);
    const nrm = new Float32Array(N * 12), idx = [];
    for (let i = 0; i < N; i++) { for (let k = 0; k < 4; k++) nrm[i * 12 + k * 3 + 1] = 1; idx.push(i * 4, i * 4 + 1, i * 4 + 2, i * 4, i * 4 + 2, i * 4 + 3); }
    mesh = new B.Mesh('oyoDust', scene);
    const vd = new B.VertexData(); vd.positions = P; vd.normals = nrm; vd.colors = C; vd.uvs = UV; vd.indices = idx; vd.applyToMesh(mesh, true);
    const mat = new B.StandardMaterial('oyoDustMat', scene);
    mat.opacityTexture = makeAtlas(scene); mat.diffuseColor = new B.Color3(0, 0, 0); mat.emissiveColor = new B.Color3(1, 1, 1); mat.specularColor = new B.Color3(0, 0, 0);   // unlit: final colour = vertex colour
    mat.disableLighting = true; mat.backFaceCulling = false; mat.disableDepthWrite = true; mat.alphaMode = B.Engine.ALPHA_COMBINE;
    mesh.material = mat; mesh.hasVertexAlpha = true; mesh.isPickable = false; mesh.alwaysSelectAsActiveMesh = true; mesh.alphaIndex = 30;
    D.mesh = mesh; D.built = true;
  };

  function spawn(type, x, y, z, ux, uy, uz, a, b, lf, al, cl, col, gy, dr, bu) {
    const i = ptr; ptr = (ptr + 1) % N;
    typ[i] = type; px[i] = x; py[i] = y; pz[i] = z; vx[i] = ux; vy[i] = uy; vz[i] = uz; s0[i] = a; s1[i] = b; life[i] = lf; age[i] = 0; a0[i] = al; cell[i] = cl;
    const sh = D.World && D.World.endless ? .97 + R() * .06 : .93 + R() * .12; cr[i] = col[0] * sh; cg[i] = col[1] * sh; cb[i] = col[2] * sh; gyA[i] = gy; drag[i] = dr; buoy[i] = bu;
    rot[i] = R() * PI * 2; rv[i] = (R() - .5) * (type ? 6 : 1.1); alive[i] = 1;
  }

  /* how dusty is the ground here: 1 on the road, ~0 on grass */
  function surf(W, x, z) {
    const q = W.queryRoad(x, z); if (!q) return 0;
    const r = q.d / (q.hw || 3); return r <= 1.05 ? 1 : r >= 1.6 ? 0 : 1 - (r - 1.05) / .55;
  }
  function colFor(k) { return [lerp(OFF[0], ROAD[0], k), lerp(OFF[1], ROAD[1], k), lerp(OFF[2], ROAD[2], k)]; }

  D.update = function (dt, Rd) {
    if (!D.built || D.dead) return;
    try { step(dt, Rd); } catch (e) { D.dead = true; mesh.setEnabled(false); console.warn('Dust disabled', e); }
  };

  /* hoof strikes, lift-off kicks, trail, skids and landing bursts for ONE horse (player or NPC); particles go into the shared pool */
  function emit(dt, Rd, E) {
    const s = Rd.state, an = Rd.anim, W = Rd.World || D.World;
    const sy = Math.sin(s.yaw), cy = Math.cos(s.yaw), v = s.speed, av = Math.abs(v), q = Rd.slow ? .6 : 1, sgn = v < 0 ? -1 : 1;
    const fx = sy * sgn, fz = cy * sgn;                       // direction of travel on the ground
    const wx = .9 + .5 * Math.sin(T * .27), wz = .35 + .3 * Math.sin(T * .19 + 1.3);   // light breeze that drifts the dust sideways
    const gyHere = W.height(s.x, s.z);
    if (W.endless) { ROAD = PAL_E.r; OFF = PAL_E.o; HAZE = PAL_E.h; GRIT = PAL_E.g; } else { ROAD = [.80, .58, .40]; OFF = [.66, .58, .42]; HAZE = [.88, .75, .60]; GRIT = [.36, .22, .14]; }
    const SPD = W.endless ? 19 : 10;                                   // Endless Run reaches ~19 m/s: scale the dust over the whole speed range
    const sp = clamp((av - 1) / SPD, 0, 1);

    /* ---- hoof events from the gait engine ---- */
    if (an.feet && !s.air) {
      for (let li = 0; li < an.feet.length && li < 4; li++) {
        const f = an.feet[li]; if (!f) continue;
        const g = f.world[1] < .035, fx0 = f.world[0], fz0 = f.world[2];
        const x = s.x + sy * fz0 + cy * fx0, z = s.z + cy * fz0 - sy * fx0, gy = W.height(x, z);
        if (g && !E.grounded[li] && av > 1.2) {                          // STRIKE
          const k = surf(W, x, z), inten = lerp(.28, 1, k) * (.35 + .65 * sp), n = av > 7 ? 3 : av > 4 ? 2 : 1, col = colFor(k);
          for (let i = 0; i < n; i++) {
            if (R() > inten * 1.5 * q + .15) continue;
            const a = R() * PI * 2, out = .45 + R() * (.7 + 1.1 * sp), s_ = .26 + R() * .2 + sp * .14;
            spawn(0, x, gy + .05, z, Math.cos(a) * out + wx * .2 + sy * v * .16, .5 + R() * (.6 + .9 * sp), Math.sin(a) * out + wz * .2 + cy * v * .16, s_, s_ * (3.3 + R() * 2), 1.3 + R() * 1.1 + sp * .7, (.19 + R() * .12) * inten * (.55 + .45 * sp), (R() * 3) | 0, col, gy, 1.9, .45);
          }
        } else if (!g && E.grounded[li] && av > 2.5) {                   // LIFT-OFF: soil thrown backwards
          const k = surf(W, x, z), inten = lerp(.25, 1, k), col = colFor(k), n = av > 7 ? 2 : 1;
          for (let i = 0; i < n; i++) {
            if (R() > inten * 1.3 * q + .1) continue;
            const b = 1.2 + R() * 2.6 * sp + .3 * av * .1, lat = (R() - .5) * 1.1;
            spawn(0, x, gy + .08, z, -fx * b + cy * lat + wx * .2, .8 + R() * 1.3 * sp, -fz * b - sy * lat + wz * .2, .2 + R() * .12, .85 + R() * .5, 1.0 + R() * .9, (.14 + R() * .1) * inten * (.5 + .5 * sp), (R() * 3) | 0, col, gy, 1.7, .4);
          }
          if (k > .4 && av > 5 && R() < .75 * q) {                     // flying grit / clods
            const b = 2 + R() * 3.5, lat = (R() - .5) * 2.2, sz = .05 + R() * .05;
            spawn(1, x, gy + .1, z, -fx * b + cy * lat, 1.6 + R() * 2.6, -fz * b - sy * lat, sz, sz, .55 + R() * .4, .85, 3, GRIT, gy, .25, 0);
          }
        }
        E.grounded[li] = g;
      }
    }

    /* ---- hanging trail behind the hindquarters ---- */
    const kT = surf(W, s.x, s.z), iT = lerp(.28, 1, kT);
    if (av > 2.5 && !s.air) {
      E.ta += dt * clamp((av - 2.5) / (SPD * .8), 0, 1) * 20 * q * (.45 + .55 * kT);
      const col = colFor(kT);
      while (E.ta >= 1) {
        E.ta -= 1;
        const back = 1.0 + R() * .7, lat = (R() - .5) * .9, x = s.x - fx * back + cy * lat, z = s.z - fz * back - sy * lat, gy = W.height(x, z), b = .4 + R() * .9, sz = .65 + R() * .5;
        spawn(0, x, gy + .12, z, -fx * b + wx * .5, .22 + R() * .5, -fz * b + wz * .5, sz, sz * (3.6 + R() * 1.8), 3.2 + R() * 2.6, (.07 + R() * .06) * iT * (.5 + .5 * sp), (R() * 3) | 0, col, gy, .9, .22);
      }
    } else E.ta = 0;

    /* ---- braking skid ---- */
    const decel = (E.prevSpeed - v) / Math.max(dt, .001);
    if (decel > 3 && av > 2.5 && !s.air) {
      E.tb += dt * 38 * q * (.3 + .7 * kT);
      const col = colFor(kT);
      while (E.tb >= 1) {
        E.tb -= 1;
        const lat = (R() - .5) * 1.3, x = s.x - fx * (.5 + R() * .8) + cy * lat, z = s.z - fz * (.5 + R() * .8) - sy * lat, gy = W.height(x, z), sz = .45 + R() * .35;
        spawn(0, x, gy + .1, z, fx * av * (.25 + R() * .3) + wx * .3, .4 + R() * .8, fz * av * (.25 + R() * .3) + wz * .3, sz, sz * (3.4 + R() * 1.6), 1.8 + R() * 1.4, (.2 + R() * .12) * iT, (R() * 3) | 0, col, gy, 1.4, .35);
      }
    } else E.tb = 0;
    E.prevSpeed = v;

    /* ---- landing burst after a jump ---- */
    if (E.prevAir && !s.air && an.feet) {
      const col = colFor(kT);
      for (let li = 0; li < an.feet.length && li < 4; li++) {
        const f = an.feet[li]; if (!f) continue;
        const x = s.x + sy * f.world[2] + cy * f.world[0], z = s.z + cy * f.world[2] - sy * f.world[0], gy = W.height(x, z);
        for (let i = 0; i < 3; i++) {
          const a = R() * PI * 2, out = 1.2 + R() * 1.8, sz = .35 + R() * .25;
          spawn(0, x, gy + .06, z, Math.cos(a) * out + sy * v * .3, .6 + R() * 1, Math.sin(a) * out + cy * v * .3, sz, sz * (3.5 + R() * 2), 1.5 + R() * 1.2, (.26 + R() * .12) * iT, (R() * 3) | 0, col, gy, 1.8, .4);
        }
      }
    }
    E.prevAir = s.air; if (s.air) for (let i = 0; i < 4; i++) E.grounded[i] = false;

  }

  function step(dt, Rd) {
    const s = Rd.state, an = Rd.anim, W = Rd.World, scene = D.scene;
    dt = Math.min(dt, .05); T += dt;
    if (!Rd.mesh || !Rd.mesh.isEnabled()) { if (mesh.isEnabled()) { mesh.setEnabled(false); alive.fill(0); lastCount = 0; } return; }
    if (!mesh.isEnabled()) mesh.setEnabled(true);
    const sy = Math.sin(s.yaw), cy = Math.cos(s.yaw);
    const wx = .9 + .5 * Math.sin(T * .27), wz = .35 + .3 * Math.sin(T * .19 + 1.3);   // same breeze as emit()
    emit(dt, Rd, EM_PL);
    /* ---- simulate ---- */
    const cam = scene.activeCamera, cp = cam ? (cam.globalPosition || cam.position) : { x: s.x, y: s.y + 3, z: s.z - 7 };
    let rx = 1, ry = 0, rz = 0, ux = 0, uy = 1, uz = 0;
    if (cam) { const m = cam.getViewMatrix().m; rx = m[0]; ry = m[4]; rz = m[8]; ux = m[1]; uy = m[5]; uz = m[9]; }
    let cnt = 0;
    for (let i = 0; i < N; i++) {
      if (!alive[i]) continue;
      age[i] += dt; const t = age[i] / life[i]; if (t >= 1) { alive[i] = 0; continue; }
      if (typ[i] === 1) { vy[i] -= 9.8 * dt; }
      else {
        const d = Math.exp(-dt * drag[i]); vx[i] *= d; vy[i] *= d; vz[i] *= d; vy[i] += buoy[i] * dt * (1 - t);
        const wk = 1 - Math.exp(-dt * .7); vx[i] += (wx - vx[i]) * wk * .6; vz[i] += (wz - vz[i]) * wk * .6;
      }
      px[i] += vx[i] * dt; py[i] += vy[i] * dt; pz[i] += vz[i] * dt;
      if (py[i] < gyA[i] + .03) { py[i] = gyA[i] + .03; if (typ[i] === 1) { vy[i] *= -.25; vx[i] *= .5; vz[i] *= .5; } else vy[i] = Math.max(vy[i], 0); }
      rot[i] += rv[i] * dt;
      const dx = px[i] - cp.x, dy = py[i] - cp.y, dz = pz[i] - cp.z, d2 = Math.sqrt(dx * dx + dy * dy + dz * dz);
      dist[i] = d2; ord[cnt++] = i;
    }
    const arr = Array.prototype.slice.call(ord, 0, cnt).sort((a, b) => dist[b] - dist[a]);     // far → near for correct blending
    for (let n = 0; n < cnt; n++) {
      const i = arr[n], t = age[i] / life[i], e = 1 - (1 - t) * (1 - t);
      const size = typ[i] === 1 ? s0[i] : lerp(s0[i], s1[i], e), h = size * .5;
      let al = a0[i] * sstep(0, typ[i] === 1 ? .02 : .1, t) * (typ[i] === 1 ? 1 - t * .6 : Math.pow(1 - t, 1.5)) * sstep(1.3, 4.2, dist[i]);
      const hz = lerp(0, .55, typ[i] === 1 ? 0 : e), r0 = cr[i] + (HAZE[0] - cr[i]) * hz, g0 = cg[i] + (HAZE[1] - cg[i]) * hz, b0 = cb[i] + (HAZE[2] - cb[i]) * hz;
      const c = Math.cos(rot[i]), sn = Math.sin(rot[i]);
      const ax = (rx * c + ux * sn) * h, ay = (ry * c + uy * sn) * h, az = (rz * c + uz * sn) * h, bx = (-rx * sn + ux * c) * h, by = (-ry * sn + uy * c) * h, bz = (-rz * sn + uz * c) * h;
      const o = n * 12, x = px[i], y = py[i], z = pz[i];
      P[o] = x - ax - bx; P[o + 1] = y - ay - by; P[o + 2] = z - az - bz;
      P[o + 3] = x + ax - bx; P[o + 4] = y + ay - by; P[o + 5] = z + az - bz;
      P[o + 6] = x + ax + bx; P[o + 7] = y + ay + by; P[o + 8] = z + az + bz;
      P[o + 9] = x - ax + bx; P[o + 10] = y - ay + by; P[o + 11] = z - az + bz;
      const co = n * 16; for (let k = 0; k < 4; k++) { C[co + k * 4] = r0; C[co + k * 4 + 1] = g0; C[co + k * 4 + 2] = b0; C[co + k * 4 + 3] = al; }
      const u = (cell[i] % 2) * .5, vv = Math.floor(cell[i] / 2) * .5, uo = n * 8;
      UV[uo] = u; UV[uo + 1] = vv + .5; UV[uo + 2] = u + .5; UV[uo + 3] = vv + .5; UV[uo + 4] = u + .5; UV[uo + 5] = vv; UV[uo + 6] = u; UV[uo + 7] = vv;
    }
    for (let n = cnt; n < lastCount; n++) { P.fill(0, n * 12, n * 12 + 12); for (let k = 0; k < 4; k++) C[n * 16 + k * 4 + 3] = 0; }
    const B = BABYLON, top = Math.max(cnt, lastCount); lastCount = cnt;
    if (top > 0 || !D.sent) {
      D.sent = true;
      mesh.updateVerticesData(B.VertexBuffer.PositionKind, P, false, false);
      mesh.updateVerticesData(B.VertexBuffer.ColorKind, C, false, false);
      mesh.updateVerticesData(B.VertexBuffer.UVKind, UV, false, false);
    }
  }

  /* NPC horse (royal cart in Endless Run): spawns hoof dust into the same pool. The pool is simulated + drawn by the player's D.update each frame. */
  D.updateNpc = function (dt, Rd, slot) {                          // slot 2 = the second NPC horse (own emitter state, same shared particle pool)
    const EN = slot > 4 ? (EM_MORE[slot] || (EM_MORE[slot] = newEm())) : slot === 4 ? EM_NPC4 : slot === 3 ? EM_NPC3 : slot === 2 ? EM_NPC2 : EM_NPC;   // slot 3 = the oncoming-carriageway NPC horse
    if (!D.built || D.dead) return;
    try {
      dt = Math.min(dt, .05);
      if (!Rd.state || !Rd.anim || !Rd.active) { EN.prevSpeed = 0; EN.grounded.fill(true); return; }
      emit(dt, Rd, EN);
    } catch (e) { console.warn('NPC dust skipped', e); }
  };

  window.OYODust = D;
})();
