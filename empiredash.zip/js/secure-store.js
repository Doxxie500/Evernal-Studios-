/* EMPIRE DASH — secure-store.js
   Tamper-evident saves. Every value written through OYOStore carries a signature; a save whose signature does not match (someone edited
   localStorage by hand) is rejected and the game starts that save fresh instead of trusting it.
   Honest limit: this game has no server, so this stops casual editing from the browser's storage panel, not a determined programmer.
   Saves written before this file existed carry no signature: they are accepted ONCE (and signed) until LEGACY_UNTIL, then refused. */
(function () {
  'use strict';
  var SALT = 'oyo\u00b7ed\u00b77f3a91c2\u00b7kingdom';
  var LEGACY_UNTIL = Date.UTC(2026, 10, 28, 23, 0, 0);          // 29 Nov 2026 00:00 Nigerian time: one week after launch

  function h53(str, seed) {                                      // cyrb53: fast 53-bit string hash, no WebCrypto needed (works on http and in private mode)
    var h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed, ch;
    for (var i = 0; i < str.length; i++) {
      ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
  }
  function sign(key, json) { return h53(SALT + '|' + key + '|' + json, 17).toString(36) + h53(json + '|' + SALT + '|' + key, 91).toString(36); }

  var clk = { ok: false, s0: 0, p0: 0 };
  var S = window.OYOStore = {
    /* → { obj, state }   state: 'none' (nothing saved) | 'ok' (signature valid) | 'legacy' (old unsigned save) | 'bad' (edited / corrupt) */
    read: function (key) {
      var raw, p;
      try { raw = localStorage.getItem(key); } catch (e) { return { obj: null, state: 'none' }; }
      if (!raw) return { obj: null, state: 'none' };
      try { p = JSON.parse(raw); } catch (e) { return { obj: null, state: 'bad' }; }
      if (!p || typeof p !== 'object' || Array.isArray(p)) return { obj: null, state: 'bad' };
      var sig = p._sig; delete p._sig;
      if (sig === undefined) return { obj: p, state: 'legacy' };
      return sign(key, JSON.stringify(p)) === sig ? { obj: p, state: 'ok' } : { obj: null, state: 'bad' };
    },
    write: function (key, obj) {
      try {
        var c = {}; for (var k in obj) if (Object.prototype.hasOwnProperty.call(obj, k) && k !== '_sig') c[k] = obj[k];
        var j = JSON.stringify(c); c._sig = sign(key, j);
        localStorage.setItem(key, JSON.stringify(c)); return true;
      } catch (e) { return false; }                                // private mode / quota: the game keeps working, it just cannot save
    },
    legacyOk: function () { return S.now() < LEGACY_UNTIL; },
    /* SERVER CLOCK: now() is the server's time (from /api/time) so changing the phone's clock no longer opens the free launch window, daily bags, streaks or the Ose gate early.
       If the server cannot be reached (offline, or not on Vercel) it falls back to the phone's clock, exactly as before. */
    now: function () { return clk.ok ? clk.s0 + (performance.now() - clk.p0) : Date.now(); },
    sync: function () {
      var p = performance.now();
      return fetch('api/time', { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : Promise.reject(); }).then(function (j) {
        var p2 = performance.now();
        if (j && isFinite(j.now) && j.now > 1.7e12) { clk.s0 = j.now + (p2 - p) / 2; clk.p0 = p2; clk.ok = true; }
      }).catch(function () { /* offline / no server: keep the phone clock */ });
    },
    /* a random id for this device, used only so a paid cart link can be limited to a few devices */
    device: function () {
      try { var d = localStorage.getItem('jagun-dev'); if (d && /^[a-z0-9]{16,40}$/.test(d)) return d;
        var a = new Uint8Array(16); (window.crypto || {}).getRandomValues ? crypto.getRandomValues(a) : a.forEach(function (_, i) { a[i] = Math.floor(Math.random() * 256); });
        d = Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); localStorage.setItem('jagun-dev', d); return d;
      } catch (e) { return ''; }
    },
    num: function (v, lo, hi, def) { v = +v; return isFinite(v) ? Math.min(hi, Math.max(lo, v)) : def; }
  };
  try { S.sync(); setInterval(S.sync, 600000); document.addEventListener('visibilitychange', function () { if (!document.hidden) S.sync(); }); } catch (e) { /* no fetch: phone clock */ }
})();
