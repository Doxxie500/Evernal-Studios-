/* EMPIRE DASH — obstacles.js  (Stage 12f: road obstacles, Free Roam riding)
   Hazards of a 1650 Yoruba road appear on the Royal Road ahead of the rider: fallen branches, boulders, fallen logs, a broken wooden cart,
   and goats / cattle wandering across. Hit one with the horse or the cart and you lose a few cowries, the horse stumbles (slows) and you get a
   red flash, screen shake, flying debris and a thud. A good jump (Space) clears low things (branch, log, boulder); a wrecked cart or an animal
   must be steered around. The road gets rougher the further you ride: more hazards, more often, harder kinds, bigger penalty (levels 1–6).
   Penalty = cowries off the session balance (never below 0). Nothing is saved. All models are hand-built from primitives (no modern objects).
   Self-contained. To remove: delete this file, its <script> line in boot.js + sw.js, and the "obstacles.js" block in style.css. */
(function () {
  'use strict';
  const OYO = window.OYO, MS = OYO && OYO.mission, B = window.BABYLON; if (!MS || !B) return;
  const PI = Math.PI, clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const LEVEL_M = 350, MAX_LVL = 6, SPAWN_MIN = 90, SPAWN_RND = 90, KEEP_GAP = 16, NEAR_CLEAR = 28, DESPAWN = 290, STAGGER = .7;
  const snd = (f, a) => { try { window.OYOAudio && OYOAudio[f] && OYOAudio[f](a); } catch (e) { /* audio optional */ } };
  let RD = null, World = null, scene = null, onB = false, T = {}, mats = null, list = [], parts = [], dist = 0, lvl = 1, spawnT = 2, stag = 0, seed = 1650, ui = null, tT = 0;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };

  /* ---------- hand-built models (merged primitives, vertex-coloured; +z = long axis) ---------- */
  function mk(name, defs) {
    const out = [];
    defs.forEach(d => {
      let m;
      if (d.k === 'cyl') m = B.MeshBuilder.CreateCylinder(name, { diameter: d.d, height: d.h, tessellation: d.t || 8 }, scene);
      else if (d.k === 'box') m = B.MeshBuilder.CreateBox(name, { width: d.w, height: d.h, depth: d.l }, scene);
      else if (d.k === 'ico') m = B.MeshBuilder.CreateIcoSphere(name, { radius: 1, subdivisions: 2 }, scene);
      else m = B.MeshBuilder.CreateSphere(name, { diameter: 1, segments: 7 }, scene);
      if (d.s) m.scaling.set(d.s[0], d.s[1], d.s[2]); if (d.r) m.rotation.set(d.r[0], d.r[1], d.r[2]); m.position.set(d.p[0], d.p[1], d.p[2]);
      m.bakeCurrentTransformIntoVertices();
      const n = m.getTotalVertices(), a = new Float32Array(n * 4); for (let i = 0; i < n; i++) { a[i * 4] = d.c[0]; a[i * 4 + 1] = d.c[1]; a[i * 4 + 2] = d.c[2]; a[i * 4 + 3] = 1; }
      m.setVerticesData(B.VertexBuffer.ColorKind, a); out.push(m);
    });
    const m = B.Mesh.MergeMeshes(out, true, true); m.name = name; m.material = mats; m.isPickable = false; m.isVisible = false; return m;
  }
  const BARK = [.33, .22, .13], WOOD = [.45, .3, .17], DARK = [.26, .17, .1], CUT = [.72, .55, .35], LEAF = [.2, .36, .13], ROCK = [.5, .47, .42];
  function goat(col, k, horn) {
    const d = [
      { k: 'sph', s: [.5 * k, .42 * k, .95 * k], p: [0, .85 * k, 0], c: col },
      { k: 'cyl', d: .16 * k, h: .55 * k, r: [-.8, 0, 0], p: [0, 1.08 * k, .62 * k], c: col },
      { k: 'sph', s: [.22 * k, .22 * k, .34 * k], p: [0, 1.3 * k, .92 * k], c: col },
      { k: 'cyl', d: .06 * k, h: .35 * k * horn, r: [-.5, 0, .5], p: [.1 * k, 1.5 * k, .86 * k], c: [.2, .17, .13] },
      { k: 'cyl', d: .06 * k, h: .35 * k * horn, r: [-.5, 0, -.5], p: [-.1 * k, 1.5 * k, .86 * k], c: [.2, .17, .13] },
      { k: 'cyl', d: .07 * k, h: .3 * k, r: [.8, 0, 0], p: [0, .95 * k, -.85 * k], c: col }];
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(q => d.push({ k: 'cyl', d: .09 * k, h: .62 * k, p: [q[0] * .18 * k, .31 * k, q[1] * .4 * k], c: [col[0] * .8, col[1] * .8, col[2] * .8] }));
    return d;
  }
  function models() {
    mats = new B.StandardMaterial('obMat', scene); mats.diffuseColor = new B.Color3(1, 1, 1); mats.specularColor = new B.Color3(.05, .05, .05); mats.emissiveColor = new B.Color3(.12, .1, .08);
    T.branch = mk('obBranch', [
      { k: 'cyl', d: .24, h: 3.8, r: [PI / 2, 0, 0], p: [0, .22, 0], c: BARK },
      { k: 'cyl', d: .09, h: 1.4, r: [PI / 2, 0, .7], p: [.5, .4, .9], c: BARK }, { k: 'cyl', d: .09, h: 1.3, r: [PI / 2, 0, -.7], p: [-.5, .4, -.2], c: BARK },
      { k: 'cyl', d: .08, h: 1.1, r: [PI / 2, 0, .5], p: [.4, .35, -1], c: BARK },
      { k: 'sph', s: [1.2, .35, 1.1], p: [.95, .5, 1.45], c: LEAF }, { k: 'sph', s: [1.1, .35, 1], p: [-.9, .5, -.7], c: LEAF }, { k: 'sph', s: [1.3, .4, 1.1], p: [0, .45, 1.9], c: [.24, .4, .15] }]);
    T.rock = mk('obRock', [{ k: 'ico', s: [1.3, .85, 1.1], p: [0, .45, 0], c: ROCK }, { k: 'ico', s: [.6, .4, .5], p: [1.25, .2, .6], c: [.42, .4, .36] }, { k: 'ico', s: [.4, .3, .4], p: [-1.1, .15, -.7], c: [.55, .5, .44] }]);
    T.log = mk('obLog', [
      { k: 'cyl', d: .95, h: 4.2, t: 10, r: [PI / 2, 0, 0], p: [0, .47, 0], c: BARK },
      { k: 'cyl', d: .84, h: .05, t: 10, r: [PI / 2, 0, 0], p: [0, .47, 2.11], c: CUT }, { k: 'cyl', d: .84, h: .05, t: 10, r: [PI / 2, 0, 0], p: [0, .47, -2.11], c: CUT },
      { k: 'cyl', d: .22, h: .8, r: [0, 0, 1.0], p: [.5, .85, .5], c: BARK }]);
    T.wreck = mk('obWreck', [
      { k: 'box', w: 2.4, h: .16, l: 3.2, p: [0, .6, 0], r: [.05, 0, .24], c: WOOD },
      { k: 'box', w: .1, h: .5, l: 3.1, p: [-1.1, .95, 0], r: [.05, 0, .24], c: DARK }, { k: 'box', w: .1, h: .4, l: 2.2, p: [1.15, .35, -.3], r: [0, .12, -.5], c: DARK },
      { k: 'box', w: .1, h: 1.5, l: .1, p: [-1.55, .78, .4], c: DARK }, { k: 'box', w: .1, h: .1, l: 1.5, p: [-1.55, .78, .4], c: DARK },
      { k: 'cyl', d: 1.5, h: .1, t: 14, r: [0, 0, PI / 2], p: [-1.55, .78, .4], c: [.36, .24, .13] },
      { k: 'cyl', d: 1.4, h: .1, t: 14, r: [.05, 0, .06], p: [2.2, .14, .9], c: [.36, .24, .13] },
      { k: 'cyl', d: .14, h: 3.2, r: [PI / 2 - .1, .2, 0], p: [.4, .3, 2.7], c: DARK },
      { k: 'box', w: .12, h: .12, l: 1.4, p: [1.3, .1, -1.6], r: [0, .6, 0], c: WOOD }]);
    T.goatA = mk('obGoatA', goat([.72, .58, .38], 1, 1)); T.goatB = mk('obGoatB', goat([.22, .18, .15], 1, 1));
    T.cattle = mk('obCattle', goat([.52, .3, .2], 1.75, 2.2));
  }
  const TYPES = {   // hl: half-length of collision segment, r: radius, clear: jump height that clears it, say: message noun
    branch: { t: 'branch', hl: 1.7, r: .5, clear: .5, say: 'a fallen branch', nudge: 1 },
    rock: { t: 'rock', hl: .6, r: 1.1, clear: 1.1, say: 'a boulder', nudge: 0 },
    log: { t: 'log', hl: 1.9, r: .6, clear: .9, say: 'a fallen log', nudge: 1 },
    wreck: { t: 'wreck', hl: 1.2, r: 1.5, clear: 99, say: 'a broken cart', nudge: 0 },
    goat: { t: 'goatA', hl: .7, r: .55, clear: 99, say: 'a goat', live: 1 },
    cattle: { t: 'cattle', hl: 1.2, r: .85, clear: 99, say: 'a cow', live: 1 }
  };
  function pickType() {
    const w = [['branch', 5], ['rock', 5]]; if (lvl >= 2) w.push(['log', 3 + lvl]); if (lvl >= 3) w.push(['wreck', 1 + lvl * .6]); if (lvl >= 4) { w.push(['goat', 2 + lvl]); w.push(['cattle', lvl - 2]); }
    let tot = 0; w.forEach(a => tot += a[1]); let r = rnd() * tot; for (const a of w) { if ((r -= a[1]) <= 0) return a[0]; } return 'rock';
  }

  /* ---------- spawning along the Royal Road ahead of the rider ---------- */
  function badSpot(x, z) {
    const PA = window.OYOPalace && OYOPalace.site, o = RD.obs;
    if (PA && PA.a) { const dx = x - PA.x, dz = z - PA.z, sn = Math.sin(PA.yaw), cs = Math.cos(PA.yaw); if (Math.abs(dx * cs - dz * sn) < PA.a + 8 && Math.abs(dx * sn + dz * cs) < PA.b + 8) return true; }
    if (o && o.x) for (let k = 0; k < o.x.length; k++) { const q = o.r[k] + 2.5; if ((x - o.x[k]) ** 2 + (z - o.z[k]) ** 2 < q * q) return true; }
    for (const e of list) if ((x - e.x) ** 2 + (z - e.z) ** 2 < KEEP_GAP * KEEP_GAP) return true;
    return false;
  }
  function spawn() {
    const s = RD.state, r = World.byId.royal; if (!r) return;
    const D = SPAWN_MIN + rnd() * SPAWN_RND, fx = Math.sin(s.yaw), fz = Math.cos(s.yaw), tx = s.x + fx * D, tz = s.z + fz * D;
    let bi = -1, bd = 1e9; for (let i = 0; i < r.n; i++) { const d = (r.x[i] - tx) ** 2 + (r.z[i] - tz) ** 2; if (d < bd) { bd = d; bi = i; } }
    if (bi < 0 || bd > 45 * 45) return;
    const key = pickType(), def = TYPES[key], hw = World.widthAt(r, bi) * .5, nx = r.nx[bi], nz = r.nz[bi], tgx = r.tx[bi], tgz = r.tz[bi];
    let lat = (rnd() * 2 - 1) * hw * .7, ang = Math.atan2(tgx, tgz) + (rnd() < .5 ? 0 : PI) + (rnd() - .5) * .9, vx = 0, vz = 0;
    if (def.live) { const side = rnd() < .5 ? 1 : -1; lat = side * (hw + 2.5); const sp = (key === 'cattle' ? .9 : 1.4) + rnd() * .4; vx = -nx * side * sp; vz = -nz * side * sp; ang = Math.atan2(vx, vz); }
    const x = r.x[bi] + nx * lat, z = r.z[bi] + nz * lat;
    if (badSpot(x, z) || (x - s.x) ** 2 + (z - s.z) ** 2 < NEAR_CLEAR * NEAR_CLEAR) return;
    const tn = key === 'goat' ? (rnd() < .5 ? 'goatA' : 'goatB') : def.t, m = T[tn].createInstance('ob_' + key);
    m.isPickable = false; const y = World.height(x, z); m.position.set(x, y, z); m.rotation.y = ang;
    list.push({ key, def, m, x, z, y, ang, vx, vz, hit: false, wob: 0, ph: rnd() * 6, run: 0 });
  }
  function drop(i) { try { list[i].m.dispose(); } catch (e) { /* ignore */ } list.splice(i, 1); }

  /* ---------- feedback: flash, shake, toast, debris ---------- */
  function mkUI() {
    if (ui) return; const hud = document.getElementById('hud'); if (!hud) return;
    ui = document.createElement('div'); ui.innerHTML = '<div class="ob-flash"></div><div class="ob-toast hud-card" style="display:none"></div>'; hud.appendChild(ui);
    ui.flash = ui.querySelector('.ob-flash'); ui.toast = ui.querySelector('.ob-toast'); ui.cv = document.getElementById('renderCanvas');
    const dm = new B.StandardMaterial('obDeb', scene); dm.diffuseColor = new B.Color3(.4, .28, .16); dm.specularColor = B.Color3.Black(); dm.emissiveColor = new B.Color3(.15, .1, .06);
    for (let i = 0; i < 12; i++) { const p = B.MeshBuilder.CreateIcoSphere('obDebris' + i, { radius: .12, subdivisions: 1 }, scene); p.material = dm; p.isPickable = false; p.setEnabled(false); parts.push({ m: p, t: 9, vx: 0, vy: 0, vz: 0 }); }
  }
  function toast(txt, bad) { if (!ui) return; ui.toast.textContent = txt; ui.toast.classList.toggle('bad', !!bad); ui.toast.style.display = ''; tT = 2.6; }
  function burst(x, y, z) { let n = 0; for (const p of parts) { if (p.t < .7) continue; p.t = 0; p.vx = (rnd() - .5) * 7; p.vy = 3 + rnd() * 4; p.vz = (rnd() - .5) * 7; p.m.position.set(x, y + .5, z); p.m.setEnabled(true); if (++n >= 8) break; } }
  function fb() {
    if (!ui) return; ui.flash.classList.remove('go'); void ui.flash.offsetWidth; ui.flash.classList.add('go');
    if (ui.cv) { ui.cv.classList.remove('ob-shake'); void ui.cv.offsetWidth; ui.cv.classList.add('ob-shake'); }
  }

  /* ---------- hit handling ---------- */
  function segHit(e, px, pz, pr) {
    const sa = Math.sin(e.ang), ca = Math.cos(e.ang), dx = px - e.x, dz = pz - e.z, t = clamp(dx * sa + dz * ca, -e.def.hl, e.def.hl), ex = dx - t * sa, ez = dz - t * ca;
    return ex * ex + ez * ez < (e.def.r + pr) * (e.def.r + pr);
  }
  function onHit(e, s) {
    e.hit = true; stag = STAGGER; e.wob = .6;
    const h = OYO.hud, pen = 2 + lvl, loss = Math.min(h.score | 0, pen); h.score -= loss;
    s.speed *= .35; snd('impact', e.def.live ? 4 : e.def.t === 'branch' || e.def.t === 'log' ? 2 : e.def.t === 'wreck' ? 5 : 1); fb(); burst(e.x, e.y, e.z);
    toast('Ouch! You hit ' + e.def.say + (loss ? ' · −' + loss + ' 🐚' : '') + '!', true);
    if (e.def.nudge) { const sa = Math.cos(e.ang), ca = -Math.sin(e.ang); e.x += sa * .9; e.z += ca * .9; e.ang += .5; }   // shoved aside
    if (e.def.live) { e.run = 5; e.vx *= 3.4; e.vz *= 3.4; }                                                           // bolts away
  }
  OYO.obstacles = OYO.obstacles || {};
  OYO.obstacles.threat = function () {            // 0..1 for the music director: nearest hazard ahead on the road (read-only)
    const s = RD && RD.state; if (!s || !list.length) return 0; const fx = Math.sin(s.yaw), fz = Math.cos(s.yaw); let b = 0;
    for (const e of list) { if (e.hit) continue; const dx = e.x - s.x, dz = e.z - s.z, ah = dx * fx + dz * fz; if (ah < 0 || ah > 45 || Math.abs(dx * fz - dz * fx) > 7) continue; b = Math.max(b, 1 - ah / 45); }
    return b;
  };
  let cartRef = null; if (window.OYOCart) ['spawnHitched', 'spawnParked'].forEach(k => { const f = OYOCart[k]; if (typeof f === 'function') OYOCart[k] = function () { const c = f.apply(this, arguments); if (c) cartRef = c; return c; }; });

  /* ---------- per-frame ---------- */
  function tick() {
    const h = OYO.hud, s = RD && RD.state; if (!h || !s) return;
    const live = h.screen === 'free' && h.mode === 'ride' && RD.built && !(MS.paused);
    if (!(h.screen === 'free' && h.mode === 'ride' && RD.built)) { if (list.length) { for (let i = list.length - 1; i >= 0; i--) drop(i); } dist = 0; lvl = 1; spawnT = 2; if (ui && ui.toast.style.display !== 'none') ui.toast.style.display = 'none'; return; }
    if (!live) return;
    if (!mats) models(); mkUI(); if (!ui) return;
    const dt = Math.min(.05, scene.getEngine().getDeltaTime() / 1000), cs = cartRef && cartRef.hitched ? cartRef.state : null;
    dist += Math.abs(s.speed) * dt; const nl = Math.min(MAX_LVL, 1 + Math.floor(dist / LEVEL_M));
    if (nl > lvl) { lvl = nl; toast('The road grows rougher… (hazard level ' + lvl + ')', false); }
    if (tT > 0) { tT -= dt; if (tT <= 0) ui.toast.style.display = 'none'; }
    if (stag > 0) stag -= dt;
    spawnT -= dt; if (spawnT <= 0) { spawnT = Math.max(1.1, 3.6 - .45 * (lvl - 1)) * (.7 + rnd() * .6); if (list.length < 3 + lvl * 2) spawn(); }
    const fx = Math.sin(s.yaw), fz = Math.cos(s.yaw), jumpH = s.air ? s.jy : 0;
    for (let i = list.length - 1; i >= 0; i--) {
      const e = list[i];
      if (e.def.live) { e.x += e.vx * dt; e.z += e.vz * dt; e.y = World.height(e.x, e.z); if (e.run > 0) e.run -= dt; e.ang = Math.atan2(e.vx, e.vz); }
      if (e.wob > 0) e.wob -= dt;
      e.m.position.set(e.x, e.live ? e.y : (e.y = World.height(e.x, e.z)), e.z);
      e.m.rotation.y = e.ang; e.m.rotation.z = e.wob > 0 ? Math.sin(e.wob * 30) * .12 * e.wob : 0;
      if (e.def.live) e.m.position.y = e.y + Math.abs(Math.sin(performance.now() / 1000 * (e.run > 0 ? 14 : 6) + e.ph)) * .06;
      const dx = e.x - s.x, dz = e.z - s.z, d2 = dx * dx + dz * dz, ahead = dx * fx + dz * fz;
      if (d2 > DESPAWN * DESPAWN || (ahead < -70 && d2 > 70 * 70)) { drop(i); continue; }
      if (e.hit || stag > 0 || d2 > 400) continue;
      if (jumpH >= e.def.clear) continue;                                  // jumped clean over it
      if (segHit(e, s.x, s.z, .7) || (cs && segHit(e, cs.x, cs.z, 1.1))) onHit(e, s);
    }
    for (const p of parts) { if (p.t >= .7) continue; p.t += dt; if (p.t >= .7) { p.m.setEnabled(false); continue; } p.vy -= 16 * dt; const q = p.m.position; q.x += p.vx * dt; q.y += p.vy * dt; q.z += p.vz * dt; }
  }

  const prev = MS.init;
  MS.init = function (world, riding, scn) {
    const r = prev.apply(this, arguments); RD = riding; World = world; scene = scn;
    if (!onB) { onB = true; scene.onBeforeRenderObservable.add(tick); } return r;
  };
})();
