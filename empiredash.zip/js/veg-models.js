/* EMPIRE DASH — Stage 3 · veg-models.js
   Hand-built tree / plant geometry + hand-painted leaf, frond and bark textures.
   Every model is a few hundred triangles and is drawn with thin instances. */
(function () {
  'use strict';
  const B = BABYLON;
  const rng = seed => { let s = (seed * 7919 + 12345) % 2147483647; return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; };
  const norm = v => { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; };
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const mixc = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
  const mesher = () => ({ p: [], n: [], c: [], u: [], i: [] });
  const tris = m => m.i.length / 3;

  /* ---------- geometry helpers ---------- */
  function tube(m, pts, rad, sides, colFn, o) {
    o = o || {}; const base = m.p.length / 3, n = pts.length; let len = 0;
    for (let i = 0; i < n; i++) {
      const p = pts[i], q0 = pts[Math.max(0, i - 1)], q1 = pts[Math.min(n - 1, i + 1)], t = norm([q1[0] - q0[0], q1[1] - q0[1], q1[2] - q0[2]]);
      if (i) len += Math.hypot(p[0] - pts[i - 1][0], p[1] - pts[i - 1][1], p[2] - pts[i - 1][2]);
      const ref = Math.abs(t[1]) > .9 ? [1, 0, 0] : [0, 1, 0], a = norm(cross(t, ref)), b = cross(t, a), col = colFn(i / (n - 1));
      for (let s = 0; s <= sides; s++) {
        const th = s / sides * 6.2832, cs = Math.cos(th), sn = Math.sin(th); let r = rad[i];
        if (o.flute) r *= 1 + o.flute * Math.sin(th * o.k + i * .25);
        if (o.ring && i % 2) r *= 1 + o.ring;
        const dx = a[0] * cs + b[0] * sn, dy = a[1] * cs + b[1] * sn, dz = a[2] * cs + b[2] * sn, sh = .9 + .2 * ((s * 7 + i * 3) % 5) / 5;
        m.p.push(p[0] + dx * r, p[1] + dy * r, p[2] + dz * r); m.n.push(dx, dy, dz); m.c.push(col[0] * sh, col[1] * sh, col[2] * sh, 1); m.u.push(s / sides * (o.uR || 2), len * (o.uV || .35));
      }
    }
    for (let i = 0; i < n - 1; i++) for (let s = 0; s < sides; s++) { const a = base + i * (sides + 1) + s, b = a + 1, c = a + sides + 1, d = c + 1; m.i.push(a, c, b, b, c, d); }
  }
  // atlas cell k (4 x 2 cells of 256px) -> uv rect
  const cellUV = k => { const u0 = (k % 4) * .25, vt = 1 - Math.floor(k / 4) * .5; return [u0, vt - .5, u0 + .25, vt]; };
  function card(m, c, r, u, uv, nrm, col) {
    const o = m.p.length / 3;
    m.p.push(c[0] - r[0] - u[0], c[1] - r[1] - u[1], c[2] - r[2] - u[2], c[0] + r[0] - u[0], c[1] + r[1] - u[1], c[2] + r[2] - u[2], c[0] + r[0] + u[0], c[1] + r[1] + u[1], c[2] + r[2] + u[2], c[0] - r[0] + u[0], c[1] - r[1] + u[1], c[2] - r[2] + u[2]);
    for (let k = 0; k < 4; k++) { m.n.push(nrm[0], nrm[1], nrm[2]); m.c.push(col[0], col[1], col[2], 1); }
    m.u.push(uv[0], uv[1], uv[2], uv[1], uv[2], uv[3], uv[0], uv[3]); m.i.push(o, o + 1, o + 2, o, o + 2, o + 3);
  }
  // Leafy twig card: its base sits at `pos`, the twig grows along `dir` (outward), randomly twisted.
  function sprigCard(m, R, pos, dir, size, uv, lo, hi, droop) {
    const up = norm([dir[0], dir[1] + (droop || 0), dir[2]]); let side = cross(up, [0, 1, 0]); if (Math.hypot(side[0], side[1], side[2]) < .1) side = [1, 0, 0]; side = norm(side);
    let nrm = cross(side, up); if (nrm[0] * dir[0] + nrm[1] * dir[1] + nrm[2] * dir[2] < 0) nrm = [-nrm[0], -nrm[1], -nrm[2]];
    const roll = (R() - .5) * 1.9, cr = Math.cos(roll), sr = Math.sin(roll), sd = [side[0] * cr + nrm[0] * sr, side[1] * cr + nrm[1] * sr, side[2] * cr + nrm[2] * sr];
    const s = size * (.8 + R() * .4), c = [pos[0] + up[0] * s * .42, pos[1] + up[1] * s * .42, pos[2] + up[2] * s * .42], lit = Math.min(1, Math.max(0, (dir[1] + 1) / 2)), col = mixc(lo, hi, lit), k = .88 + R() * .24;
    card(m, c, [sd[0] * s * .5, sd[1] * s * .5, sd[2] * s * .5], [up[0] * s * .5, up[1] * s * .5, up[2] * s * .5], uv, norm([dir[0] * .7, dir[1] * .7 + .45, dir[2] * .7]), [col[0] * k, col[1] * k, col[2] * k]);
  }
  // palm frond: arching rachis, leaflets drooping to both sides (V-folded strip)
  function frond(m, R, top, yaw, el, L, droop, col, wd) {
    wd = wd || 1;
    const segs = 5, hd = [Math.cos(yaw), 0, Math.sin(yaw)], P = [], roll = (R() - .5) * .9, o = m.p.length / 3;
    for (let j = 0; j <= segs; j++) { const t = j / segs; P.push([top[0] + hd[0] * L * t * Math.cos(el), top[1] + L * t * Math.sin(el) - droop * L * t * t * 1.1, top[2] + hd[2] * L * t * Math.cos(el)]); }
    for (let j = 0; j <= segs; j++) {
      const t = j / segs, q0 = P[Math.max(0, j - 1)], q1 = P[Math.min(segs, j + 1)], tg = norm([q1[0] - q0[0], q1[1] - q0[1], q1[2] - q0[2]]);
      let sd = norm(cross(tg, [0, 1, 0])); const up = cross(sd, tg); sd = [sd[0] * Math.cos(roll) + up[0] * Math.sin(roll), sd[1] * Math.cos(roll) + up[1] * Math.sin(roll), sd[2] * Math.cos(roll) + up[2] * Math.sin(roll)];
      const hw = .95 * wd * (1 - .72 * Math.pow(t, 1.6)), nrm = norm(cross(tg, sd)), k = (.88 + .24 * t) * (.92 + R() * .16), p = P[j], ru = cross(sd, tg), lift = hw * .3 * (1 - t * .5);
      m.p.push(p[0] - sd[0] * hw, p[1] - sd[1] * hw, p[2] - sd[2] * hw, p[0] + ru[0] * lift, p[1] + ru[1] * lift, p[2] + ru[2] * lift, p[0] + sd[0] * hw, p[1] + sd[1] * hw, p[2] + sd[2] * hw);
      for (let q = 0; q < 3; q++) { m.n.push(nrm[0], Math.abs(nrm[1]) + .3, nrm[2]); m.c.push(col[0] * k, col[1] * k, col[2] * k, 1); }
      m.u.push(0, t, .5, t, 1, t);
    }
    for (let j = 0; j < segs; j++) { const a = o + j * 3, b = a + 3; m.i.push(a, a + 1, b + 1, a, b + 1, b, a + 1, a + 2, b + 2, a + 1, b + 2, b + 1); }
  }
  const branchPath = (R, from, dir, len, n, bend) => {
    const pts = [], d = norm(dir); for (let i = 0; i < n; i++) { const t = i / (n - 1); pts.push([from[0] + d[0] * len * t, from[1] + d[1] * len * t + bend * len * t * t, from[2] + d[2] * len * t]); } return pts;
  };
  const radLin = (n, a, b) => Array.from({ length: n }, (_, i) => a + (b - a) * i / (n - 1));

  /* ---------- tree models ---------- */
  function palm(seed) {
    // Royal palm: tall, smooth silver-grey ringed trunk, bright green crownshaft, big arching feather fronds
    const R = rng(seed), w = mesher(), l = mesher(), h = 15 + R() * 5, lx = (R() - .5) * 1.6, lz = (R() - .5) * 1.6, n = 26, pts = [], rad = [];
    for (let i = 0; i < n; i++) { const t = i / (n - 1); pts.push([lx * t * t, h * t, lz * t * t]); rad.push(.36 + .14 * Math.exp(-t * 9) + .07 * Math.sin(Math.min(1, t / .6) * Math.PI) - .06 * t); }
    tube(w, pts, rad, 8, t => mixc([1.12, 1.26, 1.42], [1.0, 1.14, 1.3], t), { ring: .04, uV: .5, uR: 1 });
    const t0 = pts[n - 1], sh = [[t0[0], t0[1] - .1, t0[2]], [t0[0] + lx * .01, t0[1] + .9, t0[2] + lz * .01], [t0[0] + lx * .02, t0[1] + 1.9, t0[2] + lz * .02]];
    tube(w, sh, [.31, .34, .28], 8, t => mixc([.62, 1.4, .38], [.78, 1.5, .5], t), { uV: .3, uR: 1 });
    const top = sh[2], nf = 15, tier = [[1.1, .25, .85, .3], [.55, .25, 1, .55], [.1, .25, 1, .9], [-.25, .2, .9, 1.2]];
    for (let k = 0; k < nf; k++) {
      const ti = k < 4 ? 0 : k < 9 ? 1 : k < 13 ? 2 : 3, T = tier[ti];
      frond(l, R, [top[0], top[1] + .1, top[2]], k / nf * 6.283 * 2.4 + R() * .6, T[0] + R() * T[1], (5.2 + R() * 1.2) * T[2], T[3], [.95, 1, .9], 1.3);
    }
    return { wood: w, leaf: l, kind: 'frond', r: 6, h: top[1] + 4.5 };
  }
  const LEAF_LO = [.68, .84, .6], LEAF_HI = [1.06, 1.08, .8];
  function baobab(seed) {
    // Giant bottle trunk, a few short thick limbs, then a huge dense dome of fine forking twigs (bare, dry-season look)
    const R = rng(seed), w = mesher(), H = 10 + R() * 2, n = 13, pts = [], prof = [3.7, 3.3, 3.1, 3.0, 2.95, 2.95, 3.0, 3.05, 3.1, 3.05, 2.85, 2.5, 2.15];
    for (let i = 0; i < n; i++) pts.push([Math.sin(i * .5) * .2, H * i / (n - 1), Math.cos(i * .4) * .2]);
    tube(w, pts, prof, 16, t => mixc([1.25, .95, .66], [1.1, .8, .56], t), { flute: .08, k: 9, uV: .12, uR: 3 });
    const top = pts[n - 1], C = [top[0], top[1] + 4.6, top[2]], Rc = 12.5, KIDS = [3, 3, 3, 2], SIDES = [7, 6, 5, 4, 3], rv = () => [R() - .5, R() - .5, R() - .5];
    function grow(from, dir, len, r0, depth) {
      const np = depth === 0 ? 5 : depth < 3 ? 4 : depth === 3 ? 3 : 2, d = norm(dir), P = [from], rd = [], step = len / (np - 1);
      let cur = d;
      for (let i = 1; i < np; i++) { const q = rv(); cur = norm([cur[0] + q[0] * .3, cur[1] + q[1] * .3 - .03, cur[2] + q[2] * .3]); const p = P[i - 1]; P.push([p[0] + cur[0] * step, p[1] + cur[1] * step, p[2] + cur[2] * step]); }
      for (let i = 0; i < np; i++) rd.push(r0 * (1 - .5 * i / (np - 1)));
      const cc = depth / 4; tube(w, P, rd, SIDES[depth], t => mixc(mixc([1.2, .9, .62], [1.0, .62, .38], cc), [.95, .62, .4], t * .4 + cc * .3), { uV: .3 });
      if (depth >= 4) return;
      for (let j = 0; j < KIDS[depth]; j++) {
        const idx = j === 0 ? np - 1 : 1 + Math.floor(R() * (np - 1)), p = P[idx], ox = p[0] - C[0], oy = p[1] - C[1], oz = p[2] - C[2], dist = Math.hypot(ox, oy * 1.5, oz) || 1, out = [ox / dist, oy / dist * .3, oz / dist], q = rv();
        let cd = [cur[0] * .5 + out[0] * .55 + q[0] * .9, cur[1] * .5 + out[1] * .55 + q[1] * .9 + .1, cur[2] * .5 + out[2] * .55 + q[2] * .9];
        const f = Math.min(1.3, Math.max(0, (dist / Rc - .62) * 3.2)); cd = [cd[0] - ox / dist * f, cd[1] - oy / dist * f * 1.4, cd[2] - oz / dist * f];
        grow(p, cd, len * (.72 + R() * .12), rd[idx] * .64, depth + 1);
      }
    }
    const nb = 6;
    for (let k = 0; k < nb; k++) { const a = k / nb * 6.283 + R() * .4; grow([top[0] + Math.cos(a) * .9, top[1] - 1.2, top[2] + Math.sin(a) * .9], [Math.cos(a) * .6, 1, Math.sin(a) * .6], 5 + R() * 1.4, 1.0, 0); }
    grow([top[0], top[1] - 1.2, top[2]], [0, 1, 0], 4.8, 1.05, 0);
    return { wood: w, kind: 'wood', r: 13, h: top[1] + 12.5 };
  }
  function acacia(seed, wide) {
    // Umbrella thorn: short gnarled leaning trunk forking into a few curved limbs under one wide, flat-topped, thin canopy
    const R = rng(seed), w = mesher(), l = mesher(), H = 3 + R() * .8, la = R() * 6.283, lean = .8 + R() * .9, pts = [], R0 = wide ? 6 : 4.9;
    for (let i = 0; i < 7; i++) { const t = i / 6; pts.push([Math.cos(la) * lean * t * t + Math.sin(t * 5 + seed) * .3 * t, H * t, Math.sin(la) * lean * t * t + Math.cos(t * 4 + seed) * .25 * t]); }
    tube(w, pts, [.66, .52, .46, .42, .38, .34, .3], 7, t => mixc([.62, .5, .42], [.5, .4, .34], t), { flute: .1, k: 3, uV: .4 });
    const top = pts[6], nl = 3, ends = [], LV = 2.1 + R() * .5;
    for (let k = 0; k < nl; k++) {
      const a = la + (k - 1) * 1.7 + (R() - .5) * .6, hx = Math.cos(a), hz = Math.sin(a), LH = R0 * (.5 + R() * .12), P = [], rd = [.3, .25, .19, .14, .1];
      for (let i = 0; i < 5; i++) { const t = i / 4, tw = Math.sin(t * 6 + k * 2 + seed) * .35 * t; P.push([top[0] + hx * LH * t - hz * tw, top[1] - .2 + LV * (2 * t - t * t), top[2] + hz * LH * t + hx * tw]); }
      tube(w, P, rd, 5, t => mixc([.5, .4, .32], [.4, .32, .27], t), { uV: .4 });
      const e = P[4]; ends.push(e);
      for (let s = 0; s < 2; s++) { const sa = a + (s ? .6 : -.6), Q = []; for (let i = 0; i < 4; i++) { const t = i / 3; Q.push([e[0] + Math.cos(sa) * R0 * .32 * t, e[1] + .35 * t - .3 * t * t, e[2] + Math.sin(sa) * R0 * .32 * t]); } tube(w, Q, [.1, .08, .06, .035], 4, () => [.4, .32, .27], { uV: .4 }); ends.push(Q[3]); }
    }
    let cx = 0, cy = 0, cz = 0; ends.forEach(e => { cx += e[0]; cy += e[1]; cz += e[2]; }); cx /= ends.length; cy = cy / ends.length + .35; cz /= ends.length;
    const uvs = cellUV(1), colr = () => mixc(LEAF_LO, LEAF_HI, .35 + R() * .65);
    // flat top layer: horizontal feathery cards, slightly domed
    for (let q = 0; q < 46; q++) {
      const a = R() * 6.283, d = R0 * Math.sqrt(R()) * .92, f = d / R0, y = cy + .75 * (1 - f * f) - .25 * f * f * f + (R() - .5) * .35, s = 1.5 + R() * .45, yw = R() * 6.283, k = .9 + R() * .2, c = colr();
      card(l, [cx + Math.cos(a) * d, y, cz + Math.sin(a) * d], [Math.cos(yw) * s, 0, Math.sin(yw) * s], [-Math.sin(yw) * s, 0, Math.cos(yw) * s], uvs, [0, 1, 0], [c[0] * k, c[1] * k, c[2] * k]);
    }
    // twigs fanning outward (give the canopy its ragged edge and side silhouette)
    for (let q = 0; q < 64; q++) {
      const a = q / 64 * 6.283 + R() * .5, f = q % 3 === 0 ? .35 + R() * .4 : .65 + R() * .35, d = R0 * f, y = cy + .5 * (1 - f * f) - .2 * f * f * f + (R() - .5) * .4;
      sprigCard(l, R, [cx + Math.cos(a) * d, y, cz + Math.sin(a) * d], norm([Math.cos(a) * .9, .12 + R() * .3 - (f > .85 ? .1 : 0), Math.sin(a) * .9]), 1.9 + R() * .7, uvs, LEAF_LO, LEAF_HI, 0);
    }
    // sparse underside layer (canopy stays see-through beneath)
    for (let q = 0; q < 12; q++) { const a = R() * 6.283, d = R0 * (.3 + R() * .6); sprigCard(l, R, [cx + Math.cos(a) * d, cy - .45 - R() * .3, cz + Math.sin(a) * d], norm([Math.cos(a) * .8, -.2, Math.sin(a) * .8]), 1.7, uvs, [.55, .7, .45], LEAF_LO, 0); }
    return { wood: w, leaf: l, kind: 'leaf', r: R0 * 1.25, h: cy + 1.2 };
  }
  function tropical(seed, tall) {
    const R = rng(seed), w = mesher(), l = mesher(), H = tall ? 9.5 + R() * 2.5 : 6.5 + R() * 2, n = 8, pts = [], rad = [];
    for (let i = 0; i < n; i++) { const t = i / (n - 1); pts.push([Math.sin(seed + t * 3) * .35 * t, H * t, Math.cos(seed + t * 2) * .3 * t]); rad.push(i === 0 ? 1.0 : i === 1 ? .62 : .42 - .1 * t); }
    tube(w, pts, rad, 8, t => mixc([.5, .38, .3], [.44, .34, .27], t), { flute: .06, k: 5, uV: .4 });
    for (let k = 0; k < 3; k++) { const a = k * 2.1 + R(); tube(w, [[Math.cos(a) * .3, 1.7, Math.sin(a) * .3], [Math.cos(a) * 1.2, .5, Math.sin(a) * 1.2], [Math.cos(a) * 2.0, 0, Math.sin(a) * 2.0]], [.2, .32, .45], 4, () => [.46, .36, .28]); }
    const top = pts[n - 1], cr = tall ? [4.2, 4.0, 4.2] : [5.0, 3.1, 5.0], cen = [top[0], top[1] + cr[1] * .5, top[2]], uvs = cellUV(0), nb = 8;
    for (let k = 0; k < nb; k++) {
      const a = k / nb * 6.283 + R() * .5, from = [top[0], H * (.62 + R() * .25), top[2]], bp = branchPath(R, from, [Math.cos(a), .75 + R() * .5, Math.sin(a)], 3 + R() * 2.4, 4, -.15);
      tube(w, bp, [.24, .18, .12, .07], 5, t => mixc([.46, .36, .28], [.38, .3, .24], t));
    }
    const rdir = () => { const a = R() * 6.283, e = Math.asin(R() * 1.45 - .5); return [Math.cos(e) * Math.cos(a), Math.sin(e), Math.cos(e) * Math.sin(a)]; };
    for (let k = 0; k < 104; k++) {
      const d = rdir(), f = k < 84 ? .55 + R() * .35 : .22 + R() * .3;
      sprigCard(l, R, [cen[0] + d[0] * cr[0] * f, cen[1] + d[1] * cr[1] * f, cen[2] + d[2] * cr[2] * f], d, 1.5 + R() * .8, uvs, LEAF_LO, LEAF_HI, d[1] < .1 ? -.45 : 0);
    }
    return { wood: w, leaf: l, kind: 'leaf', r: cr[0] * 1.15, h: top[1] + cr[1] * 1.5 };
  }
  // shrub: a dozen leafy twig cards fanned over a few woody stems
  function bush(seed, size, count, cell, stems) {
    const R = rng(seed), l = mesher(), w = stems ? mesher() : null, uvs = cellUV(cell);
    for (let k = 0; k < count; k++) {
      const yaw = R() * 6.283, e = .3 + R() * 1.05, d = [Math.cos(yaw) * Math.cos(e), Math.sin(e), Math.sin(yaw) * Math.cos(e)], rad = size * .4 * (.25 + R() * .75);
      sprigCard(l, R, [d[0] * rad, size * .12 + d[1] * rad * .8, d[2] * rad], d, size * .62, uvs, LEAF_LO, LEAF_HI, -.12);
    }
    if (w) for (let k = 0; k < 3; k++) { const a = k * 2.1 + R(); tube(w, [[0, 0, 0], [Math.cos(a) * .15, size * .35, Math.sin(a) * .15], [Math.cos(a) * .4, size * .7, Math.sin(a) * .4]], [.035, .028, .015], 4, () => [.5, .4, .32]); }
    return Object.assign({ leaf: l, kind: 'leaf', r: size, h: size }, w ? { wood: w } : {});
  }
  function flowerModel(seed) {
    const R = rng(seed), l = mesher(), uvs = cellUV(3);
    for (let k = 0; k < 4; k++) {
      const a = R() * 6.283, b = R() * 3.1416, lx = (R() - .5) * .25, lz = (R() - .5) * .25;
      card(l, [Math.cos(a) * .1 + lx, .36, Math.sin(a) * .1 + lz], [Math.cos(b) * .27, 0, Math.sin(b) * .27], [lx, .36, lz], uvs, [0, 1, 0], [.92 + R() * .12, .92 + R() * .12, .92 + R() * .12]);
    }
    return { leaf: l, kind: 'leaf', r: .5, h: .7 };
  }
  // dry savanna grass clump: real tapered, curved blades (3 triangles each)
  function grassClump(seed, blades) {
    const R = rng(seed), l = mesher();
    for (let k = 0; k < blades; k++) {
      const a = R() * 6.283, d = R() * .16, bx = Math.cos(a) * d, bz = Math.sin(a) * d, la = a + (R() - .5) * 1.2, h = .55 + R() * .5, wd = .035 + R() * .03, lean = (.12 + R() * .3) * h, g = R() < .2;
      const dx = Math.cos(la), dz = Math.sin(la), sx = -dz, sz = dx, o = l.p.length / 3, cb = g ? [.3, .32, .12] : [.34, .26, .12], cm = g ? [.55, .62, .22] : [.78, .62, .3], ct = g ? [.78, .8, .38] : [.98, .86, .55];
      l.p.push(bx - sx * wd, 0, bz - sz * wd, bx + sx * wd, 0, bz + sz * wd, bx + dx * lean * .4 - sx * wd * .8, h * .55, bz + dz * lean * .4 - sz * wd * .8, bx + dx * lean * .4 + sx * wd * .8, h * .55, bz + dz * lean * .4 + sz * wd * .8, bx + dx * lean * 1.5, h * .97, bz + dz * lean * 1.5);
      [cb, cb, cm, cm, ct].forEach(c => { const v = .9 + R() * .2; l.c.push(c[0] * v, c[1] * v, c[2] * v, 1); l.n.push(0, 1, 0); l.u.push(0, 0); });
      l.i.push(o, o + 1, o + 2, o + 1, o + 3, o + 2, o + 2, o + 3, o + 4);
    }
    return { leaf: l, kind: 'plain', r: .5, h: .9 };
  }
  function branchModel(seed, twigs) {
    const R = rng(seed), w = mesher(), len = 2.4 + R() * .8, pts = [];
    for (let i = 0; i < 6; i++) { const t = i / 5; pts.push([len * (t - .5), .06 + Math.sin(t * 3 + seed) * .06, Math.sin(t * 4 + seed) * .12]); }
    tube(w, pts, [.09, .085, .07, .055, .04, .025], 5, t => mixc([.42, .34, .28], [.3, .25, .21], t));
    for (let k = 0; k < twigs; k++) { const f = pts[1 + k], d = [(R() - .3) * .6, .35, (k % 2 ? 1 : -1) * (.6 + R() * .4)]; tube(w, branchPath(R, f, d, .8 + R() * .5, 3, -.2), [.04, .03, .015], 4, () => [.36, .3, .25]); }
    return { wood: w, kind: 'wood', r: 1.4, h: .4 };
  }
  function leafDecal() { const l = mesher(); l.p.push(0, 0, -.5, .22, 0, -.05, 0, 0, .5, -.22, 0, -.05); for (let k = 0; k < 4; k++) { l.n.push(0, 1, 0); l.c.push(1, 1, 1, 1); l.u.push(0, 0); } l.i.push(0, 1, 2, 0, 2, 3); return { leaf: l, kind: 'plain', r: .2, h: 0 }; }
  function blob() { const l = mesher(); l.p.push(-.5, 0, -.5, .5, 0, -.5, .5, 0, .5, -.5, 0, .5); l.u.push(0, 0, 1, 0, 1, 1, 0, 1); for (let k = 0; k < 4; k++) { l.n.push(0, 1, 0); l.c.push(1, 1, 1, 1); } l.i.push(0, 2, 1, 0, 3, 2); return { leaf: l, kind: 'blob', r: 1, h: 0 }; }
  function farTree(cell) { const l = mesher(), uvs = cellUV(cell); for (let k = 0; k < 2; k++) card(l, [0, .5, 0], [k ? 0 : .5, 0, k ? .5 : 0], [0, .5, 0], uvs, [0, 1, 0], [1, 1, 1]); return { leaf: l, kind: 'leaf', r: 1, h: 1 }; }

  /* ---------- hand-painted textures ---------- */
  const prng = rng(4242);
  function leaf(g, x, y, ang, len, wid, pal) {
    const ex = x + Math.cos(ang) * len, ey = y + Math.sin(ang) * len, nx = -Math.sin(ang), ny = Math.cos(ang), mx = (x + ex) / 2, my = (y + ey) / 2;
    const gr = g.createLinearGradient(x, y, ex, ey); gr.addColorStop(0, pal[0]); gr.addColorStop(.55, pal[1]); gr.addColorStop(1, pal[2]);
    g.fillStyle = gr; g.strokeStyle = 'rgba(14,36,14,.55)'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(mx + nx * wid * 1.3, my + ny * wid * 1.3, ex, ey); g.quadraticCurveTo(mx - nx * wid * 1.3, my - ny * wid * 1.3, x, y); g.fill(); g.stroke();
    g.strokeStyle = 'rgba(235,245,165,.4)'; g.beginPath(); g.moveTo(x, y); g.lineTo(x + (ex - x) * .88, y + (ey - y) * .88); g.stroke();
  }
  function inside(x, y, M) { return x > M && x < 256 - M && y > M && y < 256 - M; }
  function twig(g, o) {
    const R = prng, dx = Math.cos(o.ang), dy = Math.sin(o.ang), nx = -dy, ny = dx, P = t => [o.x + dx * o.len * t + nx * o.curve * o.len * t * t, o.y + dy * o.len * t + ny * o.curve * o.len * t * t];
    g.strokeStyle = o.stem || '#4a3a22'; g.lineWidth = o.sw || 3; g.beginPath(); for (let i = 0; i <= 10; i++) { const p = P(i / 10); i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); } g.stroke();
    const put = (p, a, len, wid) => { for (let k = 0; k < 6 && !inside(p[0] + Math.cos(a) * len, p[1] + Math.sin(a) * len, 10); k++) { len *= .82; wid *= .82; } leaf(g, p[0], p[1], a, len, wid, o.pals[(R() * o.pals.length) | 0]); };
    for (let i = 0; i < o.n; i++) { const t = (i + 1) / (o.n + 1) * .92 + .06, sc = (1 - .38 * t) * (.85 + R() * .3); put(P(t), o.ang + (i % 2 ? 1 : -1) * (.7 + R() * .45) + o.curve * .8 * t, o.ll * sc, o.lw * sc); }
    put(P(1), o.ang + o.curve * .8, o.ll * .7, o.lw * .8);
  }
  function paintCell(g, k, fn) { g.save(); g.translate((k % 4) * 256, Math.floor(k / 4) * 256); g.beginPath(); g.rect(0, 0, 256, 256); g.clip(); fn(g); g.restore(); }
  function paintAtlas(g) {
    const R = prng; g.lineCap = 'round'; g.lineJoin = 'round';
    const TROP = [['#1d4a24', '#3b7d32', '#8cc04a'], ['#255a2a', '#4a8f38', '#a6cf55'], ['#2d5f2a', '#5a9a3a', '#c3d86a'], ['#3a5a22', '#6f9a32', '#d3d56a']];
    paintCell(g, 0, g => { for (let k = 0; k < 5; k++) twig(g, { x: 128 + (k - 2) * 9, y: 248, ang: -1.5708 + (k - 2) * .3, len: 150 - Math.abs(k - 2) * 18, n: 6, ll: 58, lw: 19, curve: (k - 2) * .1, pals: TROP }); for (let k = 0; k < 2; k++) twig(g, { x: 128, y: 214, ang: -1.5708 + (k ? .85 : -.85), len: 70, n: 3, ll: 46, lw: 15, curve: k ? .1 : -.1, pals: TROP }); });
    paintCell(g, 1, g => {
      const pal = [['#2f6a22', '#4d8f2e', '#8fc040'], ['#3a7a2a', '#68a834', '#b0d04c']];
      for (let a = -1.2; a <= 1.21; a += .3) {
        const ang = -1.5708 + a, len = 175 - Math.abs(a) * 40, dx = Math.cos(ang), dy = Math.sin(ang); g.strokeStyle = '#5a4a28'; g.lineWidth = 1.8; g.beginPath(); g.moveTo(128, 248); g.lineTo(128 + dx * len, 248 + dy * len); g.stroke();
        for (let t = .16; t < 1; t += .045) { const px = 128 + dx * len * t, py = 248 + dy * len * t, ll = 22 * (1 - t * .5); for (const s of [-1, 1]) { const la = ang + s * 1.05; if (inside(px + Math.cos(la) * ll, py + Math.sin(la) * ll, 8)) leaf(g, px, py, la, ll, 4.4, pal[(R() * 2) | 0]); } }
      }
    });
    const SHR = [['#2c6b2c', '#4fa23c', '#9ad156'], ['#2a6030', '#5aaa3e', '#b4de5c'], ['#35722e', '#6cb140', '#d0e66a']];
    paintCell(g, 2, g => { for (let k = 0; k < 7; k++) twig(g, { x: 128 + (k - 3) * 7, y: 248, ang: -1.5708 + (k - 3) * .26, len: 125 - Math.abs(k - 3) * 10, n: 6, ll: 36, lw: 13, curve: (k - 3) * .07, pals: SHR }); });
    paintCell(g, 3, g => {
      for (let k = 0; k < 15; k++) {
        const bx = 128 + (k - 7) * 8, tx = bx + (R() - .5) * 56, ty = 56 + R() * 100, col = ['#ffd23f', '#fff4d6', '#ff9f43', '#e85d9a', '#9b6bd6'][(R() * 5) | 0];
        g.strokeStyle = '#4f8a2e'; g.lineWidth = 2.4; g.beginPath(); g.moveTo(bx, 248); g.quadraticCurveTo(bx, (248 + ty) / 2, tx, ty); g.stroke();
        leaf(g, (bx + tx) / 2, (248 + ty) / 2 + 14, -.6 - R() * .6, 22, 5, ['#2f6a2a', '#4a9a38', '#8ccc4e']);
        g.fillStyle = col; for (let p = 0; p < 6; p++) { const a = p / 6 * 6.283; g.beginPath(); g.ellipse(tx + Math.cos(a) * 8, ty + Math.sin(a) * 8, 7, 4.5, a, 0, 6.3); g.fill(); }
        g.fillStyle = '#8a5a14'; g.beginPath(); g.arc(tx, ty, 3.6, 0, 6.3); g.fill();
      }
    });
    paintCell(g, 4, g => {
      const pal = ['#d8b968', '#c29a4a', '#a98a3c', '#b8884a'];
      for (let k = 0; k < 10; k++) {
        const bx = 128 + (k - 5) * 11, tx = bx + (R() - .5) * 60, ty = 30 + R() * 100, mx = (bx + tx) / 2 + (R() - .5) * 20, my = (248 + ty) / 2;
        g.strokeStyle = pal[(R() * 4) | 0]; g.lineWidth = 2.6; g.beginPath(); g.moveTo(bx, 248); g.quadraticCurveTo(mx, my, tx, ty); g.stroke();
        for (let s = 0; s < 7; s++) { const a = Math.atan2(ty - my, tx - mx); g.fillStyle = s % 2 ? '#c9a447' : '#8a6a2c'; g.beginPath(); g.ellipse(tx + Math.cos(a) * s * 3.5, ty + Math.sin(a) * s * 3.5, 3.4, 6, a + 1.57, 0, 6.3); g.fill(); }
        leaf(g, bx, 244 - R() * 40, -1.5 + (R() - .5), 40, 4, ['#7a6a30', '#a89440', '#cdbb62']);
      }
    });
    paintCell(g, 5, g => {
      const pal = ['#6b6a2a', '#9a9438', '#d0c45a'];
      for (let k = 0; k < 4; k++) {
        const ang = -1.5708 + (k - 1.5) * .45, len = 140, ex = 128 + Math.cos(ang) * len, ey = 248 + Math.sin(ang) * len; g.strokeStyle = '#5b4a38'; g.lineWidth = 3; g.beginPath(); g.moveTo(128, 248); g.lineTo(ex, ey); g.stroke();
        for (const t of [.55, .8, 1]) { const px = 128 + Math.cos(ang) * len * t, py = 248 + Math.sin(ang) * len * t; for (let f = -2; f <= 2; f++) { const fa = ang + f * .45, fl = 38 - Math.abs(f) * 4; if (inside(px + Math.cos(fa) * fl, py + Math.sin(fa) * fl, 8)) leaf(g, px, py, fa, fl, 8, pal); } }
      }
    });
    paintCell(g, 6, g => {
      g.fillStyle = '#5a4232'; g.beginPath(); g.moveTo(120, 252); g.lineTo(124, 124); g.lineTo(104, 100); g.lineTo(112, 96); g.lineTo(130, 116); g.lineTo(150, 94); g.lineTo(158, 100); g.lineTo(134, 128); g.lineTo(138, 252); g.fill();
      for (let k = 0; k < 60; k++) { const x = 30 + R() * 196, y = 60 + R() * 46 - Math.abs(x - 128) * .12; g.fillStyle = ['#3d6224', '#4d7a2c', '#6d9a36', '#8cb040'][(y < 78 ? 2 : 0) + ((R() * 2) | 0)]; g.beginPath(); g.ellipse(x, y, 14 + R() * 12, 7 + R() * 6, 0, 0, 6.3); g.fill(); }
    });
    paintCell(g, 7, g => {
      g.fillStyle = '#4f3a2c'; g.fillRect(120, 140, 16, 108);
      for (let k = 0; k < 80; k++) { const a = R() * 6.283, d = Math.sqrt(R()), x = 128 + Math.cos(a) * 86 * d, y = 96 + Math.sin(a) * 66 * d; g.fillStyle = ['#2c5c2e', '#3a7a30', '#4f9438', '#6aa63a'][(y < 86 ? 1 : 0) + ((R() * 3) | 0) % 3]; g.beginPath(); g.arc(x, y, 12 + R() * 14, 0, 6.3); g.fill(); }
    });
  }
  function paintFrond(g) {
    g.lineCap = 'round'; g.strokeStyle = '#6a7a2a'; g.lineWidth = 3.4; g.beginPath(); g.moveTo(128, 510); g.lineTo(128, 6); g.stroke();
    for (let y = 500; y > 12; y -= 5) {
      const t = (500 - y) / 488, L = Math.max(7, 112 * (1 - t * t) * (.4 + .6 * Math.min(1, t * 5))), cr = Math.round(30 + 58 * t), cg = Math.round(96 + 58 * t), cb = Math.round(30 + 10 * t);
      for (const s of [-1, 1]) {
        const ex = 128 + s * L, ey = y - L * .5, cx = 128 + s * L * .55, cy = y - L * .05 + L * .12;
        g.strokeStyle = `rgb(${cr},${cg},${cb})`; g.lineWidth = 5.2 - t * 2.2; g.beginPath(); g.moveTo(128, y); g.quadraticCurveTo(cx, cy, ex, ey); g.stroke();
        g.strokeStyle = `rgba(214,230,110,${.25 + .25 * t})`; g.lineWidth = 1.4; g.beginPath(); g.moveTo(128, y - 1); g.quadraticCurveTo(cx, cy - 2, ex, ey - 1); g.stroke();
      }
    }
  }
  function paintBark(g) {
    const R = prng; g.fillStyle = '#a89480'; g.fillRect(0, 0, 256, 256); g.lineCap = 'round';
    for (let i = 0; i < 700; i++) {
      const x = R() * 256, y = R() * 256, l = 16 + R() * 60, col = R() < .5 ? 'rgba(60,45,35,.26)' : 'rgba(225,208,182,.24)', w = 1.4 + R() * 3.6;
      for (const dx of [0, x < 8 ? 256 : x > 248 ? -256 : 0]) for (const dy of [0, y < 70 ? 256 : y > 186 ? -256 : 0]) { g.strokeStyle = col; g.lineWidth = w; g.beginPath(); g.moveTo(x + dx, y + dy); g.lineTo(x + dx + (R() - .5) * 4, y + dy + l); g.stroke(); }
    }
  }
  function paintBlob(g) {
    for (const [x, y, r, a] of [[64, 64, 62, .5], [48, 70, 40, .22], [82, 58, 38, .22], [64, 84, 34, .2]]) { const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, `rgba(52,28,48,${a})`); gr.addColorStop(.6, `rgba(52,28,48,${a * .6})`); gr.addColorStop(1, 'rgba(52,28,48,0)'); g.fillStyle = gr; g.fillRect(0, 0, 128, 128); }
  }
  const dyn = (scene, name, w, h, fn) => { const t = new B.DynamicTexture(name, { width: w, height: h }, scene, true); fn(t.getContext()); t.hasAlpha = true; t.wrapU = t.wrapV = B.Texture.WRAP_ADDRESSMODE; t.anisotropicFilteringLevel = 2; t.update(); return t; };

  /* ---------- public: build base meshes + materials ---------- */
  function create(scene) {
    const emi = new B.Color3(.1, .06, .04), std = (name, o) => { const m = new B.StandardMaterial(name, scene); m.specularColor = B.Color3.Black(); m.emissiveColor = emi; m.backFaceCulling = false; Object.assign(m, o || {}); return m; };
    const atlas = dyn(scene, 'vegAtlas', 1024, 512, paintAtlas), frondT = dyn(scene, 'vegFrond', 256, 512, paintFrond), bark = dyn(scene, 'vegBark', 256, 256, paintBark), blobT = dyn(scene, 'vegBlob', 128, 128, paintBlob);
    bark.hasAlpha = false;
    const cut = t => ({ diffuseTexture: t, alphaCutOff: .42, transparencyMode: B.Material.MATERIAL_ALPHATEST, twoSidedLighting: true });
    const mats = {
      wood: std('vegWood', { diffuseTexture: bark }), leaf: std('vegLeaf', cut(atlas)), frond: std('vegFrondMat', cut(frondT)), plain: std('vegPlain', {}),
      blob: std('vegBlob', { diffuseTexture: blobT, useAlphaFromDiffuseTexture: true, transparencyMode: B.Material.MATERIAL_ALPHABLEND, disableLighting: true, disableDepthWrite: true, zOffset: -4, emissiveColor: B.Color3.Black() })
    };
    const mk = (name, m, mat) => { const me = new B.Mesh(name, scene), vd = new B.VertexData(); vd.positions = m.p; vd.normals = m.n; vd.colors = m.c; vd.uvs = m.u; vd.indices = m.i; vd.applyToMesh(me); me.material = mat; me.isPickable = false; me.setEnabled(false); return me; };
    const defs = makeDefs();
    const models = {};
    for (const k in defs) {
      const d = defs[k], parts = [];
      if (d.wood) parts.push(mk(k + '_wood', d.wood, mats.wood));
      if (d.leaf) parts.push(mk(k + '_leaf', d.leaf, d.kind === 'frond' ? mats.frond : d.kind === 'plain' ? mats.plain : d.kind === 'blob' ? mats.blob : mats.leaf));
      models[k] = { parts, r: d.r, h: d.h, tris: (d.wood ? tris(d.wood) : 0) + (d.leaf ? tris(d.leaf) : 0) };
    }
    return { models, mats };
  }
  function makeDefs() {
    return {
      palm1: palm(11), palm2: palm(23), baobab: baobab(5), acacia1: acacia(7, false), acacia2: acacia(19, true), tropical1: tropical(3, false), tropical2: tropical(17, true),
      bush: bush(2, 1.7, 18, 2, true), plant: bush(9, .8, 9, 2), dryBush: bush(14, 1.3, 14, 5, true), flower: flowerModel(4), grass: grassClump(8, 5),
      branch: branchModel(6, 2), leafDecal: leafDecal(), blob: blob(), far1: farTree(6), far2: farTree(7)
    };
  }
  const dims = () => { const d = makeDefs(), o = {}; for (const k in d) o[k] = { r: d[k].r, h: d[k].h, tris: (d[k].wood ? tris(d[k].wood) : 0) + (d[k].leaf ? tris(d[k].leaf) : 0) }; return o; };
  window.OYOVegModels = { create, dims, _defs: { palm, baobab, acacia, tropical, bush, grassClump, flowerModel, branchModel }, tris };
})();
