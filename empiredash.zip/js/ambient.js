/* EMPIRE DASH — Stage 17 · ambient.js
   Environmental audio for Oyo, c. 1650. Fully procedural WebAudio (no sound files), read-only with respect to the game:
   it only LOOKS at the player's position, mode, speed and the world's markets / forges / farms / trees, and plays into its own bus.
   Nothing in movement, riding, the horse or the cart is touched.

   What plays, and where
   · forest .......... birdsong (dove coo, trills, whistles, weaver chatter) + wind hissing through leaves      (tree density around the player)
   · open land ....... a soft wind bed that swells in gusts and rushes when the horse gallops
   · marketplace ..... crowd murmur loop + vendor calls, laughter, cowrie clinks, calabash taps                 (nearest market)
   · blacksmith ...... hammer-on-anvil rhythm, quench hiss, bellows — panned toward the forge                    (nearest forge)
   · farms/villages .. goats, cattle, hens, a rooster                                                           (farm / village / herder zones)
   · village voices .. gossip, mothers calling children, women singing, kids at play, greetings, hawkers (synthesised vowels, own quiet bus; always on in Endless Run)
   · village life .... yam pounding (pestle & mortar), sweeping, a far-off talking drum                         (towns, villages, palace)
   · on foot ......... footsteps — crunchy on dirt roads, soft on grass
   · riding .......... hoofbeats in walk / trot / gallop (free roam only; missions keep their own), breathing, snorts, bridle
   · cart ............ wheel rumble, wooden clacks, axle creaks (only while the cart is hitched and moving)

   Mobile care: a director lets at most TWO "place" sounds (market / forge / livestock / village / birds) play at once; they cross-fade
   as the player moves; all scheduling is one 100 ms timer (zones re-evaluated every 500 ms); loops stop completely when silent;
   one-shots are capped; Settings → Graphics "Fast" thins everything out; the whole system sleeps when switched off.
   Settings: Ambient sounds on/off + Ambient volume (stored in localStorage, independent of music). Also muted by "Sound effects: Off". */
(function () {
  'use strict';
  const OYO = window.OYO = window.OYO || {}, A = window.OYOAudio;
  if (!A) return;
  const R = Math.random, PI2 = Math.PI * 2;
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v, lerp = (a, b, t) => a + (b - a) * t;
  const sm01 = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
  const LEVEL = { wind: .05, trees: .06, murmur: .1, rumble: .1, hoof: .55, step: .2, spot: 1 };   // loudness trims — tune here

  /* ---------------- settings ---------------- */
  const KEY = 'jagun-ambient-v1';
  const AM = OYO.ambient = { on: true, vol: .7, running: false, L: {}, act: {} };
  try { const j = JSON.parse(localStorage.getItem(KEY) || 'null'); if (j) { AM.on = j.on !== false; AM.vol = clamp(+j.vol >= 0 ? +j.vol : .7, 0, 1); } } catch (e) { /* storage may be blocked */ }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify({ on: AM.on, vol: AM.vol })); } catch (e) { /* ignore */ } };
  const sync = () => { const h = OYO.hud; if (!h) return; if (h.amb !== AM.on) h.amb = AM.on; const v = Math.round(AM.vol * 100); if (h.avol !== v) h.avol = v; };
  AM.toggle = function () { AM.on = !AM.on; save(); sync(); applyBus(); if (!AM.on) stopAll(); try { A.click && A.click(); } catch (e) { /* ignore */ } };
  AM.setVol = function (v) { AM.vol = clamp((+v || 0) / 100, 0, 1); save(); sync(); applyBus(); };
  const eff = () => AM.on && A.on !== false;
  const inEndless = () => true;   // villager / crowd / market / village-life sounds are switched off everywhere (start menu, Endless Run and Free Roam)

  /* ---------------- state ---------------- */
  let ctx = null, bus = null, FB = null, NB = null, MUR = null, built = false, W = null, live = 0, fastT = null, slowT = null, lastPerf = 0;
  let markets = [], smiths = [], sites = [], herds = [], grid = null, treeN = 0;
  const Z = { x: 0, z: 0, yaw: 0, spd: 0, f: 0, road: false, ride: false, walk: false, rv: 0, cart: false, mission: false, q: 1, maxLive: 7 };
  const SRC = { market: null, smith: null, stock: null, village: null, birds: null };      // nearest source of each place-sound (x, z, d, kind)
  const L = AM.L, act = AM.act;
  ['market', 'smith', 'stock', 'village', 'birds'].forEach(k => { L[k] = 0; act[k] = 0; });
  const EM = {};   // one-shot emitters (next scheduled time + armed flag)
  ['market', 'smith', 'stock', 'village', 'birds', 'creak', 'clack', 'idle', 'folk'].forEach(k => EM[k] = { next: 0, armed: false, n: 0 });
  let gust = .5, gustT = 0;

  const track = d => { live++; setTimeout(() => { live = Math.max(0, live - 1); }, (d + .4) * 1000); };
  /* Endless Run has the Yoruba music (flute, gángan, bàtá…) as its main sound, so hoofbeats, cart, wind, birds, market and forge sit well underneath it.
     ENDLESS_TRIM scales the whole ambient bus only while a run is on; free roam keeps its full level. The Ambient volume slider still applies on top. */
  const ENDLESS_TRIM = .38;
  function applyBus() { if (!bus || !ctx) return; const E = OYO.endless, trim = E && E.on ? ENDLESS_TRIM : 1; bus.gain.setTargetAtTime(eff() ? AM.vol * .9 * trim : 0, ctx.currentTime, .5); if (FB) FB.gain.setTargetAtTime(eff() ? AM.vol * (E && E.on ? .8 : .6) : 0, ctx.currentTime, .5); }   // villager voices have their own bus, so the Endless trim does not bury them

  /* ---------------- synth primitives ---------------- */
  function route(pan, far) {        // → gain node; muffles with distance, pans toward the source
    const g = ctx.createGain(); let n = g;
    if (far > .08) { const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = lerp(9000, 1300, clamp(far, 0, 1)); g.connect(f); n = f; }
    if (ctx.createStereoPanner && Math.abs(pan) > .02) { const p = ctx.createStereoPanner(); p.pan.value = clamp(pan, -.85, .85); n.connect(p); p.connect(bus); } else n.connect(bus);
    return g;
  }
  function env(g, t, a, peak, d) { g.gain.setValueAtTime(.0001, t); g.gain.linearRampToValueAtTime(Math.max(.0003, peak), t + a); g.gain.exponentialRampToValueAtTime(.0001, t + a + d); }
  function osc(t, type, f0, f1, dur, peak, atk, dst) {
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + atk + dur);
    env(g, t, atk, peak, dur); o.connect(g); g.connect(dst); o.start(t); o.stop(t + atk + dur + .04);
  }
  function nz(t, dur, type, f, q, peak, dst, atk) {
    const s = ctx.createBufferSource(), fl = ctx.createBiquadFilter(), g = ctx.createGain(); atk = atk || .004;
    s.buffer = NB; fl.type = type; fl.frequency.value = f; fl.Q.value = q; env(g, t, atk, peak, dur);
    s.connect(fl); fl.connect(g); g.connect(dst); s.start(t, R() * 1.4); s.stop(t + atk + dur + .04);
  }
  function vox(t, pts, fm1, fm2, dur, peak, dst, type, vib) {   // voice-like: saw → two moving formants. pts = [[time, Hz], …]; fm = [Hz start, Hz end, Q]
    const o = ctx.createOscillator(), g = ctx.createGain(), a = ctx.createBiquadFilter(), b = ctx.createBiquadFilter(), ga = ctx.createGain(), gb = ctx.createGain();
    o.type = type || 'sawtooth'; o.frequency.setValueAtTime(pts[0][1], t); for (let i = 1; i < pts.length; i++) o.frequency.linearRampToValueAtTime(pts[i][1], t + pts[i][0]);
    [[a, fm1], [b, fm2]].forEach(([f, m]) => { f.type = 'bandpass'; f.frequency.setValueAtTime(m[0], t); f.frequency.linearRampToValueAtTime(m[1], t + dur); f.Q.value = m[2]; });
    ga.gain.value = 3; gb.gain.value = 2; o.connect(a); o.connect(b); a.connect(ga); b.connect(gb); ga.connect(g); gb.connect(g); env(g, t, .045, peak, dur); g.connect(dst);
    if (vib) { const l = ctx.createOscillator(), lg = ctx.createGain(); l.frequency.value = vib[0]; lg.gain.value = vib[1]; l.connect(lg); lg.connect(o.frequency); l.start(t); l.stop(t + dur + .1); }
    o.start(t); o.stop(t + dur + .1);
  }
  function panTo(s) {               // stereo pan toward a world position relative to where the player looks
    if (!s) return 0; const dx = s.x - Z.x, dz = s.z - Z.z, d = Math.hypot(dx, dz) || 1, c = Math.cos(Z.yaw), sn = Math.sin(Z.yaw);
    return clamp((dx * c - dz * sn) / d, -1, 1) * (d > 4 ? .85 : .25);
  }

  /* ---------------- loops (run only while audible) ---------------- */
  function Loop(kind) { this.kind = kind; this.src = null; this.g = null; this.f = null; this.off = 0; }
  Loop.prototype.start = function (freq) {
    const buf = this.kind === 'murmur' ? MUR : NB; if (!buf) return;
    const s = ctx.createBufferSource(), g = ctx.createGain(); s.buffer = buf; s.loop = true; g.gain.value = 0;
    if (this.kind === 'murmur') s.connect(g);
    else { const f = ctx.createBiquadFilter(); f.type = this.kind === 'rumble' ? 'lowpass' : 'bandpass'; f.frequency.value = freq || 500; f.Q.value = this.kind === 'trees' ? 1.1 : this.kind === 'rumble' ? .7 : .55; s.connect(f); f.connect(g); this.f = f; }
    g.connect(bus); s.start(0, R() * buf.duration * .9); this.src = s; this.g = g;
  };
  Loop.prototype.set = function (t, lvl, freq, tc) {
    tc = tc || .6;
    if (lvl > .004) {
      if (!this.src) this.start(freq); if (!this.src) return; this.off = 0;
      this.g.gain.setTargetAtTime(lvl, t, tc); if (freq && this.f) this.f.frequency.setTargetAtTime(freq, t, tc);
    } else if (this.src) {
      this.g.gain.setTargetAtTime(0, t, tc);
      if (!this.off) this.off = t + tc * 6; else if (t > this.off) this.stop();
    }
  };
  Loop.prototype.stop = function () { try { this.src && this.src.stop(); } catch (e) { /* already stopped */ } try { this.g && this.g.disconnect(); } catch (e) { /* ignore */ } this.src = this.g = this.f = null; this.off = 0; };
  const LP = { wind: new Loop('wind'), trees: new Loop('trees'), murmur: new Loop('murmur'), rumble: new Loop('rumble') };
  function stopAll() { Object.keys(LP).forEach(k => LP[k].stop()); }

  /* ---------------- sampled buffers (built once, lazily, in small slices) ---------------- */
  function makeNoise() { const sr = 22050, b = ctx.createBuffer(1, sr * 2, sr), d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = R() * 2 - 1; return b; }
  function makeMurmur() {           // a crowd: 7 band-limited "voices", each pulsing at syllable rate and phrasing slowly; periodic so the loop is seamless
    const sr = 22050, n = sr * 4, b = ctx.createBuffer(1, n, sr), d = b.getChannelData(0);
    for (let v = 0; v < 7; v++) {
      const f = 240 + R() * 520, aH = 1 - Math.exp(-PI2 * f * 1.7 / sr), aL = 1 - Math.exp(-PI2 * f * .55 / sr);
      const k1 = 14 + (R() * 8 | 0), p1 = R(), k2 = 1 + (R() * 3 | 0), p2 = R(); let h = 0, l = 0;
      for (let i = 0; i < n; i++) {
        const x = R() * 2 - 1; h += (x - h) * aH; l += (x - l) * aL; const t = i / n;
        const s = .5 + .5 * Math.sin(PI2 * (k1 * t + p1)), p = .5 + .5 * Math.sin(PI2 * (k2 * t + p2));
        d[i] += (h - l) * s * s * p * p * 1.6;
      }
    }
    let pk = 1e-6; for (let i = 0; i < n; i++) pk = Math.max(pk, Math.abs(d[i])); const fade = Math.floor(sr * .03);
    for (let i = 0; i < n; i++) { d[i] *= .8 / pk; if (i < fade) d[i] *= i / fade; else if (i > n - fade) d[i] *= (n - i) / fade; }
    return b;
  }

  /* ---------------- one-shot voices ---------------- */
  function birds(t, lv) {
    const s = SRC.birds, dst = route(R() * 1.4 - .7, .1 + R() * .5), r = R(); let dur = 1;
    if (r < .3) {                                           // collared dove: coo – COO – coo
      const f = 420 + R() * 120; [[0, .2, 1], [.27, .34, 1.08], [.66, .22, .96]].forEach(([dt, d, k]) => { osc(t + dt, 'sine', f * k, f * k * .94, d, .06 * lv, .05, dst); osc(t + dt, 'sine', f * k * 2, f * k * 1.9, d, .014 * lv, .05, dst); }); dur = 1;
    } else if (r < .62) {                                   // trill of quick chirps
      const n = 5 + (R() * 6 | 0), f = 2500 + R() * 1500; for (let i = 0; i < n; i++) osc(t + i * .056, 'sine', f * (1 + i * .012), f * 1.32, .045, .035 * lv, .008, dst); dur = n * .06 + .1;
    } else if (r < .88) {                                   // bulbul-like slurred whistles
      const n = 2 + (R() * 2 | 0); let f = 1800 + R() * 800; for (let i = 0; i < n; i++) { const f2 = f * (R() < .5 ? 1.35 : .78); osc(t + i * .21, 'sine', f, f2, .17, .045 * lv, .015, dst); f = f2; } dur = n * .22 + .1;
    } else {                                                // weaver-bird chatter
      const n = 8 + (R() * 7 | 0); for (let i = 0; i < n; i++) nz(t + i * .045 + R() * .015, .022, 'bandpass', 3800 + R() * 1200, 7, .03 * lv, dst, .002); dur = n * .05 + .1;
    }
    track(dur + .3); return (2.2 + R() * 5.5) / (.5 + lv);
  }
  function market(t, lv) {
    const s = SRC.market, far = s ? clamp(s.d / 80, 0, .8) : .3, dst = route(s ? panTo(s) * .6 + (R() - .5) * .5 : 0, far * .7), r = R();
    if (r < .42) {                                          // vendor call: "a-yo!" (two voices, male / female)
      const f = R() < .5 ? 150 + R() * 40 : 230 + R() * 50;
      vox(t, [[0, f], [.14, f * 1.3], [.42, f * 1.12], [.7, f * .82]], [700, 430, 4], [1250, 800, 5], .7, .2 * lv, dst, 'sawtooth', [5, f * .02]);
      if (R() < .45) vox(t + .85, [[0, f * 1.1], [.2, f * 1.35], [.55, f * .9]], [650, 480, 4], [1150, 850, 5], .55, .17 * lv, dst);
    } else if (r < .62) {                                   // a burst of laughter
      const f = 230 + R() * 80, n = 3 + (R() * 3 | 0); for (let i = 0; i < n; i++) { const tt = t + i * .13; vox(tt, [[0, f * (1.05 - i * .04)], [.09, f * (.9 - i * .04)]], [850, 750, 3], [1400, 1200, 4], .1, .16 * lv, dst); nz(tt, .08, 'bandpass', 2500, 1, .02 * lv, dst); }
    } else if (r < .84) {                                   // cowries / coins in a calabash
      const n = 5 + (R() * 5 | 0); for (let i = 0; i < n; i++) { const tt = t + i * (.03 + R() * .035); nz(tt, .05, 'bandpass', 5500 + R() * 2500, 5, .06 * lv, dst, .002); osc(tt, 'sine', 3800 + R() * 1800, 0, .04, .016 * lv, .002, dst); }
    } else {                                                // knuckles on a calabash / wooden stool
      const n = 1 + (R() * 3 | 0); for (let i = 0; i < n; i++) { const tt = t + i * .17; osc(tt, 'sine', 300 + R() * 90, 180, .11, .12 * lv, .003, dst); nz(tt, .04, 'bandpass', 900, 2, .05 * lv, dst); }
    }
    track(1.6); return (1.8 + R() * 3.4) / (.6 + lv);
  }
  function smith(t, lv) {
    const s = SRC.smith, d01 = s ? clamp(s.d / 55, 0, 1) : .3, dst = route(panTo(s), d01 * .85);
    const hit = (tt, k) => {            // hammer on iron: a bright inharmonic "ting" over a short body knock
      nz(tt, .02, 'bandpass', 3400, 1, .3 * lv * k, dst, .001); osc(tt, 'sine', 190, 115, .09, .3 * lv * k, .002, dst);
      const f = 1380 + R() * 140; [[1, .12], [2.76, .07], [5.4, .035]].forEach(([m, a]) => osc(tt, 'sine', f * m, f * m * .995, .3 + .1 / m, a * lv * k, .001, dst));
    };
    hit(t, 1); hit(t + .5 + R() * .03, .72); hit(t + .98 + R() * .04, 1);
    if (R() < .3) { nz(t + 1.3, .8, 'highpass', 4600, .7, .06 * lv, dst, .04); }                     // quenching in the trough
    if (R() < .22) { nz(t + 1.4, .9, 'lowpass', 520, .6, .1 * lv, dst, .4); }                         // bellows
    n3(EM.smith); track(2.2);
    return EM.smith.n % 4 === 0 ? 3.5 + R() * 3.5 : 1.3 + R() * .5;
  }
  function n3(e) { e.n = (e.n || 0) + 1; }
  function stock(t, lv) {
    const s = SRC.stock, far = s ? clamp(s.d / 70, 0, .9) : .4, dst = route(panTo(s), far * .8), kind = s ? s.kind : 'farm', r = R();
    if (kind === 'herd' && r < .55 || (r < .3 && kind !== 'herd')) {      // cattle: a long low moo
      const f = 100 + R() * 25; vox(t, [[0, f], [.35, f * 1.28], [1.3, f * .86]], [380, 330, 3], [800, 640, 3], 1.5, .34 * lv, dst, 'sawtooth', [5, 3]);
    } else if (r < .72) {                                   // goat: nasal "meh-eh-eh"
      const f = 380 + R() * 70, n = 1 + (R() * 2 | 0); for (let i = 0; i < n; i++) vox(t + i * .62, [[0, f], [.5, f * .82]], [900, 760, 4], [1750, 1500, 5], .55, .22 * lv, dst, 'sawtooth', [34, 38]);
    } else if (r < .93) {                                   // hens clucking
      const n = 3 + (R() * 3 | 0); for (let i = 0; i < n; i++) vox(t + i * .1, [[0, 620 + R() * 80], [.06, 440]], [1400, 1200, 5], [2400, 2100, 5], .07, .12 * lv, dst);
    } else {                                                // rooster crow
      vox(t, [[0, 520], [.12, 880], [.32, 760], [.55, 1020], [.85, 900], [1.25, 540]], [1000, 900, 4], [2300, 2000, 5], 1.3, .22 * lv, dst, 'sawtooth', [14, 20]);
    }
    track(2); return (2.8 + R() * 6) / (.5 + lv);
  }
  function village(t, lv) {
    const s = SRC.village, far = s ? clamp(s.d / 85, 0, .9) : .4, dst = route(panTo(s), .2 + far * .7), r = R();
    let dur = 4;
    if (r < .5) {                                           // pounding yam: pestle on wooden mortar, two pounders alternating
      const n = 6 + (R() * 6 | 0); for (let i = 0; i < n; i++) { const tt = t + i * .47 + R() * .015; osc(tt, 'sine', 150, 62, .15, .26 * lv, .003, dst); nz(tt, .06, 'bandpass', 420, 1.4, .22 * lv, dst); osc(tt, 'sine', 215, 205, .28, .05 * lv, .003, dst); if (i % 2) { const t2 = tt + .23; osc(t2, 'sine', 170, 70, .12, .14 * lv, .003, dst); nz(t2, .05, 'bandpass', 520, 1.4, .12 * lv, dst); } }
      dur = n * .47 + 1;
    } else if (r < .66) {                                   // sweeping with a broom of palm ribs
      for (let i = 0; i < 3 + (R() * 3 | 0); i++) nz(t + i * .55, .45, 'bandpass', 2300, .7, .09 * lv, dst, .12); dur = 3.5;
    } else if (r < .88) {                                   // a far-off talking drum (hourglass pitch bends)
      const pat = [[0, 1], [.22, 0], [.4, 1], [.7, 1], [.92, 0], [1.3, 0], [1.5, 1]]; pat.forEach(([dt, hi]) => osc(t + dt, 'sine', hi ? 190 : 130, hi ? 285 : 105, .2, .22 * lv, .004, dst)); dur = 2.2;
    } else {                                                // two neighbours chatting
      const f = 190 + R() * 80; vox(t, [[0, f], [.3, f * 1.25], [.6, f * .9]], [700, 500, 4], [1200, 900, 5], .65, .14 * lv, dst); vox(t + .8, [[0, f * 1.3], [.3, f * 1.5], [.5, f * 1.1]], [650, 500, 4], [1150, 900, 5], .5, .12 * lv, dst); dur = 2;
    }
    track(dur); return (3.5 + R() * 6) / (.5 + lv);
  }


  /* ---------------- village voices (Stage 52): gossip, mothers calling children, singing, kids at play, greetings, hawkers ----------------
     All synthesised: a sawtooth "larynx" through two moving formant filters (Yoruba vowels a e ẹ i o ọ u), tone-contoured syllables, vibrato on sung notes.
     They are a lively murmur in the background, not words: placed left/right, muffled with distance, on their own quiet bus. */
  const VW = { a: [800, 1250], e: [450, 1950], E: [620, 1750], i: [300, 2250], o: [460, 900], O: [640, 1050], u: [330, 820] };
  function routeF(pan, far) {
    const g = ctx.createGain(); let n = g;
    if (far > .05) { const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = lerp(7000, 1500, clamp(far, 0, 1)); g.connect(f); n = f; }
    if (ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = clamp(pan, -.9, .9); n.connect(p); p.connect(FB); } else n.connect(FB);
    return g;
  }
  function syl(t, f0, v, dur, pk, dst, f1) {                       // one spoken syllable with a pitch glide and a little consonant noise
    const w = VW[v] || VW.a; vox(t, [[0, f0], [dur, f1 || f0]], [w[0], w[0] * .95, 5], [w[1], w[1] * .95, 6], dur, pk, dst, 'sawtooth', [5.5, f0 * .01]); nz(t, .035, 'bandpass', 2600 + R() * 1500, 1.2, pk * .1, dst, .004);
  }
  function held(t, f0, f1, dur, pk, dst, v) {                      // a sustained sung note with vibrato
    const w = VW[v] || VW.a, o = ctx.createOscillator(), g = ctx.createGain(), fa = ctx.createBiquadFilter(), fb = ctx.createBiquadFilter(), ga = ctx.createGain(), gb = ctx.createGain(), l = ctx.createOscillator(), lg = ctx.createGain();
    o.type = 'sawtooth'; o.frequency.setValueAtTime(f0, t); o.frequency.linearRampToValueAtTime(f1 || f0, t + Math.min(.12, dur * .4));
    fa.type = fb.type = 'bandpass'; fa.frequency.value = w[0]; fb.frequency.value = w[1]; fa.Q.value = 6; fb.Q.value = 7; ga.gain.value = 3; gb.gain.value = 2;
    o.connect(fa); o.connect(fb); fa.connect(ga); fb.connect(gb); ga.connect(g); gb.connect(g);
    g.gain.setValueAtTime(.0001, t); g.gain.linearRampToValueAtTime(pk, t + .07); g.gain.setValueAtTime(pk, t + dur * .7); g.gain.exponentialRampToValueAtTime(.0001, t + dur + .12);
    l.frequency.value = 5 + R() * 1.2; lg.gain.value = (f1 || f0) * .013; l.connect(lg); lg.connect(o.frequency);
    g.connect(dst); o.start(t); l.start(t); o.stop(t + dur + .2); l.stop(t + dur + .2);
  }
  function speak(t, f0, n, pk, dst, tempo) {                       // an utterance of n syllables with Yoruba-like high / mid / low tones and a falling sentence line
    let x = t; const vs = 'aeEioOu', tones = [.88, 1, 1.1, 1.2];
    for (let i = 0; i < n; i++) { const d = (.1 + R() * .09) * tempo, tn = f0 * tones[R() * 4 | 0] * (1 - i / n * .16); syl(x, tn, vs[R() * 7 | 0], d, pk, dst, tn * (.93 + R() * .12)); x += d * (1.05 + R() * .3); if (R() < .1) x += .09; }
    return x;
  }
  function laugh(t, f, pk, dst) { const n = 3 + (R() * 3 | 0); for (let i = 0; i < n; i++) { const tt = t + i * .125; vox(tt, [[0, f * (1.05 - i * .04)], [.09, f * (.9 - i * .04)]], [850, 750, 3], [1400, 1200, 4], .1, pk, dst); nz(tt, .07, 'bandpass', 2500, 1, pk * .15, dst); } return t + n * .125 + .1; }
  const PENT = [0, 2, 4, 7, 9, 12, 14];
  function folk(t, lv) {
    const far = .2 + R() * .55, pan = (R() < .5 ? -1 : 1) * (.25 + R() * .6), dst = routeF(pan, far), r = R(), pk = .2 * lv; let dur = 3;
    if (r < .3) {                                                  // gossip: two neighbours trading sentences, now and then a laugh
      const m = 1 + (R() * 2 | 0), fa = R() < .5 ? 120 + R() * 30 : 205 + R() * 40, fb = fa < 170 ? 205 + R() * 40 : 125 + R() * 25; let x = t;
      for (let i = 0; i < 2 + (R() * 3 | 0); i++) { x = speak(x, i % 2 ? fb : fa, 4 + (R() * 6 | 0), pk, dst, 1) + .12 + R() * .3; if (R() < .3) x = laugh(x, i % 2 ? fb * 1.25 : fa * 1.25, pk * .8, dst); }
      dur = x - t + 1;
    } else if (r < .46) {                                          // a mother calling her child in for the evening, the child answering from further away
      const f = 235 + R() * 45; syl(t, f * .95, 'o', .17, pk * 1.2, dst, f * 1.08); syl(t + .2, f * 1.1, 'a', .2, pk * 1.2, dst, f * 1.25); held(t + .42, f * 1.25, f * 1.02, .75, pk * 1.1, dst, 'a');
      const kd = routeF(-pan * .7, clamp(far + .2, 0, .85)), kf = 400 + R() * 90; syl(t + 1.7, kf, 'a', .2, pk * .9, kd, kf * 1.05); syl(t + 1.92, kf * 1.1, 'i', .3, pk * .9, kd, kf * .92); dur = 3.4;
    } else if (r < .66) {                                          // women singing: a pentatonic phrase in two parts, answered by a second singer
      const base = 190 + R() * 50, nn = 5 + (R() * 3 | 0), vs = 'aoaEu'; let x = t, deg = 3, prev = base * Math.pow(2, PENT[deg] / 12);
      for (let ph = 0; ph < (Z.q >= 1 ? 2 : 1); ph++) {
        for (let i = 0; i < nn; i++) { deg = clamp(deg + (R() * 3 | 0) - 1 + (i > nn - 3 ? -1 : 0), 0, PENT.length - 1); const f = base * Math.pow(2, PENT[deg] / 12), d = [.28, .3, .45, .6][R() * 4 | 0] * (i === nn - 1 ? 1.8 : 1), v = vs[(i + ph) % vs.length];
          held(x, prev, f, d, pk * .9, dst, v); if (Z.q >= 1 && i % 2 === 0) held(x + .02, prev * .8, f * .8, d, pk * .55, dst, v); prev = f; x += d + .04; }
        x += .5; deg = 3 + (R() * 2 | 0);
      }
      dur = x - t + 1;
    } else if (r < .78) {                                          // children at play: quick high shrieks and giggles
      const n = 3 + (R() * 4 | 0), kf = 420 + R() * 120; let x = t; for (let i = 0; i < n; i++) { syl(x, kf * (1 + R() * .3), 'ie'[R() * 2 | 0], .09 + R() * .06, pk * .85, dst, kf * (1.1 + R() * .3)); x += .15 + R() * .25; if (R() < .3) x = laugh(x, kf * .9, pk * .6, dst); }
      dur = x - t + 1;
    } else if (r < .9) {                                           // a greeting across the road: "Ẹ káàbọ̀!"
      const f = 125 + R() * 25, tn = [1, 1.18, .88, .84], vv = ['E', 'a', 'a', 'O'], dd = [.13, .17, .18, .3]; let x = t; for (let i = 0; i < 4; i++) { syl(x, f * tn[i], vv[i], dd[i], pk * 1.1, dst, f * tn[i] * .97); x += dd[i] * 1.05; }
      if (R() < .6) { const rd = routeF(-pan * .8, clamp(far + .15, 0, .85)), g = 205 + R() * 35; x += .35; speak(x, g, 3 + (R() * 3 | 0), pk * .9, rd, 1); }
      dur = 3;
    } else {                                                       // a hawker's long drawn-out cry
      const f = 140 + R() * 30; held(t, f, f * 1.25, .5, pk * 1.2, dst, 'a'); held(t + .52, f * 1.25, f * .85, .8, pk * 1.2, dst, 'o'); if (R() < .5) speak(t + 1.6, f * 1.1, 3, pk, dst, 1); dur = 3;
    }
    track(dur); return 3.2 + R() * 5.5;
  }

  /* ---------------- movement voices ---------------- */
  function hoofPlay(t, role, kind, vol, pan, bright) {
    const bank = A.HOOF && A.HOOF[kind] && A.HOOF[kind][role];
    if (!bank || !bank.length) { osc(t, 'sine', 130, 60, .12, vol * .3, .002, bus); return; }
    const s = ctx.createBufferSource(), g = ctx.createGain(), f = ctx.createBiquadFilter();
    s.buffer = bank[(EM.idle.n++ + (R() * 3 | 0)) % bank.length]; s.playbackRate.value = .94 + R() * .12; f.type = 'lowpass'; f.frequency.value = bright; f.Q.value = .4; g.gain.value = vol * LEVEL.hoof * (.82 + R() * .3);
    s.connect(f); f.connect(g);
    if (ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = pan * .18; g.connect(p); p.connect(bus); } else g.connect(bus);
    s.start(t);
  }
  function breath(t, v) { nz(t, .17, 'bandpass', 520 + R() * 160, .9, .045 + v * .004, bus, .012); nz(t + .02, .12, 'highpass', 2600, .6, .012, bus, .01); }
  function jingle(t) { const f0 = 2900 + R() * 900; [1, 1.52, 2.31].forEach((m, i) => osc(t + i * .018 + R() * .01, 'sine', f0 * m, f0 * m * .995, .09 + R() * .05, .014 * (1 - i * .25), .002, bus)); }
  function step(t, k, road, run) {
    const sh = .9 + R() * .2, pan = (k % 2 ? .12 : -.12), g = ctx.createGain(); g.connect(ctx.createStereoPanner ? (function () { const p = ctx.createStereoPanner(); p.pan.value = pan; p.connect(bus); return p; })() : bus);
    const a = LEVEL.step * (run ? 1.25 : 1) * (.85 + R() * .3);
    if (road) { nz(t, .085, 'bandpass', 1300 * sh, .8, a, g, .003); nz(t, .03, 'highpass', 4200, .7, a * .5, g, .002); osc(t, 'sine', 95 * sh, 55, .07, a * .9, .003, g); }      // gritty packed earth
    else { nz(t, .12, 'lowpass', 750 * sh, .6, a * .8, g, .008); nz(t + .01, .09, 'bandpass', 2600, .6, a * .22, g, .01); osc(t, 'sine', 80 * sh, 50, .08, a * .6, .004, g); } // soft grass
    g.gain.value = 1;
  }
  function advance(st, now, f, evs, cb) {   // fires the footfalls of a repeating pattern that fall in the next look-ahead window, at their exact times
    const hz = now + .22; if (st.t < now) st.t = now; const dt = hz - st.t; if (dt <= 0) return;
    const prev = st.ph, nxt = prev + dt * f;
    for (let k = Math.floor(prev); k <= Math.floor(nxt); k++) for (let e = 0; e < evs.length; e++) { const pos = k + evs[e][0]; if (pos <= prev || pos > nxt) continue; cb(e, st.t + (pos - prev) / f, k); }
    st.ph = nxt > 60 ? nxt - 60 : nxt; st.t = hz;
  }
  const HS = { ph: 0, t: 0 }, FS = { ph: 0, t: 0 }, EVF = [[0]];
  const EVH = { walk: [[0, 'hind', 1, -.3], [.25, 'front', .85, -.3], [.5, 'hind', 1, .3], [.75, 'front', .85, .3]], trot: [[0, 'hind', 1, -.3], [.012, 'front', .8, .3], [.5, 'hind', 1, .3], [.512, 'front', .8, -.3]], gallop: [[0, 'hind', .95, -.25], [.13, 'hind', 1, .25], [.27, 'front', .9, -.3], [.40, 'front', 1, .3]] };

  /* ---------------- world knowledge (read once the world exists) ---------------- */
  function learn() {
    W = OYO.core.S.world; const V = window.OYOVillagers;
    try { markets = (V && V.markets || []).map(m => ({ x: m.x, z: m.z, R: m.R || 8, big: !!m.big })); } catch (e) { markets = []; }
    try { smiths = (V && V.people || []).filter(p => p.k === 'smith').map(p => ({ x: p.x, z: p.z })); } catch (e) { smiths = []; }
    try {
      const S = W.settlements; sites = [];
      (S && S.sites || []).forEach(s => { if (s.x != null && (s.type === 'farm' || s.type === 'village' || s.type === 'town')) sites.push({ x: s.x, z: s.z, R: s.type === 'farm' ? 30 : s.type === 'village' ? 46 : 62, type: s.type }); });
      if (S && S.palace && S.palace.x != null) sites.push({ x: S.palace.x, z: S.palace.z, R: 70, type: 'palace' });
    } catch (e) { sites = []; }
    herds = []; try { const r6 = W.byId.p6, r4 = W.byId.s4; if (r6) herds.push({ x: r6.x[r6.n - 1], z: r6.z[r6.n - 1], R: 60, type: 'herd' }); if (r4) { const i = Math.floor(r4.n * .55); herds.push({ x: r4.x[i], z: r4.z[i], R: 55, type: 'herd' }); } } catch (e) { /* optional */ }
    grid = new Map(); treeN = 0;
    (W.treePts || []).forEach(p => { const k = Math.floor(p[0] / 20) * 4099 + Math.floor(p[1] / 20); grid.set(k, (grid.get(k) || 0) + 1); treeN++; });
  }
  function forestAt(x, z) {
    if (grid && treeN > 20) { const ix = Math.floor(x / 20), iz = Math.floor(z / 20); let c = 0; for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) c += grid.get((ix + a) * 4099 + iz + b) || 0; return sm01((c - 4) / 12); }
    return W ? sm01((W.fbm(x / 140 + 7, z / 140 + 3, 2) - .52) * 5) * .7 : 0;
  }
  function nearest(list, x, z, reachOf) {   // → [weight 0..1, source]
    let bw = 0, bs = null; for (let i = 0; i < list.length; i++) { const s = list[i], d = Math.hypot(s.x - x, s.z - z), w = sm01(1 - d / reachOf(s)); if (w > bw) { bw = w; bs = { x: s.x, z: s.z, d, kind: s.type }; } } return [bw, bs];
  }

  /* ---------------- 500 ms: where is the player, what should be audible ---------------- */
  function slow() {
    sync(); if (!ready()) return;
    if (!built) build(); if (!built) return;
    applyBus(); if (!eff()) { stopAll(); return; }
    if (ctx.state !== 'running') return;
    const h = OYO.hud, S0 = OYO.core.S, P = OYO.core.P, t = ctx.currentTime, q = h.quality;
    Z.q = q === 'perf' ? .6 : q === 'high' ? 1.2 : 1; Z.maxLive = q === 'perf' ? 5 : q === 'high' ? 9 : 7;
    Z.x = P.x; Z.z = P.z; Z.yaw = P.yaw || 0;
    const RD = S0.riding; Z.ride = !!(h.mode === 'ride' && !h.tour && RD && RD.active && RD.state); Z.walk = h.mode === 'walk' && !h.tour;
    Z.mission = !!(OYO.mission && OYO.mission.playing);
    const C = S0.cart; Z.cart = !!(Z.ride && C && C.state && C.state.hitched && C.enabled !== false);
    Z.f = forestAt(Z.x, Z.z);
    if (Z.ride || Z.walk) { const qr = W.queryRoad(Z.x, Z.z); Z.road = !!(qr && qr.d - qr.hw < .8); }

    // place-sound candidates → director keeps the loudest TWO (with hysteresis so they do not flicker)
    const rm = nearest(markets, Z.x, Z.z, m => m.R + (m.big ? 52 : 38)), rs = nearest(smiths, Z.x, Z.z, () => 42);
    const rl = nearest(sites.filter(s => s.type !== 'town' && s.type !== 'palace').concat(herds), Z.x, Z.z, s => s.R * .9 + 12), rv = nearest(sites, Z.x, Z.z, s => s.R + 14);
    SRC.market = rm[1]; SRC.smith = rs[1]; SRC.stock = rl[1]; SRC.village = rv[1]; SRC.birds = null;
    const cand = [['market', rm[0] * 1.1], ['smith', rs[0] * 1.2], ['stock', rl[0] * .9], ['village', rv[0] * .85], ['birds', Z.f]];   // short-range, distinctive sources win ties
    const rank = c => c[1] * (act[c[0]] ? 1.25 : 1);
    cand.sort((a, b) => rank(b) - rank(a)); let n = 0; const tgt = {};
    cand.forEach(c => { if (n < 2 && c[1] > .06) { tgt[c[0]] = Math.min(1, c[1]); act[c[0]] = 1; n++; } else { tgt[c[0]] = 0; act[c[0]] = 0; } });
    const k = 1 - Math.exp(-.5 / 1.1); for (const key in L) L[key] += ((tgt[key] || 0) - L[key]) * k;

    // beds & loops
    const v = Z.ride ? Math.abs(RD.state.speed) : Z.spd, ws = clamp(v / 30, 0, 1), duck = 1 - .4 * clamp(v / 26, 0, 1);
    if (t > gustT) { gust = .25 + R() * .75; gustT = t + 2 + R() * 3.5; }
    LP.wind.set(t, (.03 + .04 * gust * (1 - Z.f * .5) + .13 * ws * ws) * LEVEL.wind * 2.2, 380 + 60 * gust + 800 * ws, 1);
    LP.trees.set(t, Z.q < .7 ? 0 : Z.f * (.25 + .75 * gust) * LEVEL.trees * 2, 1300 + 400 * gust, 1.1);
    LP.murmur.set(t, inEndless() ? 0 : L.market * duck * LEVEL.murmur * (SRC.market && SRC.market.d > 18 ? .8 : 1.1), 0, 1);
    LP.rumble.set(t, Z.cart && v > .5 ? clamp(v / 14, 0, 1) * LEVEL.rumble * (Z.road ? 1 : .6) : 0, 140 + v * 22, .4);
    Z.duck = duck;
    if (!Z.ride && !Z.walk) { HS.t = FS.t = 0; }
  }

  /* ---------------- 100 ms: schedule what is about to be heard ---------------- */
  const SPOT = { market, smith, stock, village, birds };
  function fast() {
    if (!built || !ctx || ctx.state !== 'running' || !eff()) return;
    const t = ctx.currentTime, now = performance.now(), dt = Math.min(.3, (now - lastPerf) / 1000 || .1); lastPerf = now;
    const P = OYO.core.P, S0 = OYO.core.S, M = OYO.mission;
    const inst = Math.hypot(P.x - Z.px, P.z - Z.pz) / Math.max(dt, .03); Z.px = P.x; Z.pz = P.z; if (inst < 150) Z.spd += (inst - Z.spd) * .5;
    if (M && M.paused) return;
    const LOOK = .25, duck = Z.duck || 1;
    for (const key in SPOT) {                                               // place sounds (sparse, randomised, density follows proximity)
      const e = EM[key], lv = L[key] * duck;
      if (lv < .06 || (inEndless() && (key === 'market' || key === 'village'))) { e.armed = false; continue; }
      if (!e.armed) { e.armed = true; e.next = t + .4 + R() * 1.8; }
      if (e.next < t) e.next = t + .02;
      if (e.next < t + LOOK && live < Z.maxLive) { const gap = SPOT[key](e.next, clamp(lv * 1.4, .2, 1) * LEVEL.spot); e.next += Math.max(.6, gap / Z.q); }
    }
    { const E = OYO.endless, endless = !!(E && E.on && !E.over), near = Math.max(L.village, L.market * .9), lvF = endless ? .85 : clamp(near * 1.3, 0, 1), e = EM.folk;     // village voices: always in Endless Run, near villages / markets in Free Roam
      if (lvF < .15 || endless || inEndless()) e.armed = false;
      else { if (!e.armed) { e.armed = true; e.next = t + .8 + R() * 2.5; } if (e.next < t) e.next = t + .02; if (e.next < t + LOOK && live < Z.maxLive) { const gap = folk(e.next, lvF); e.next += Math.max(2.4, gap / Z.q * (endless ? .8 : 1)); } } }
    if (Z.ride) ride(t, S0, dt);
    else if (Z.walk) {
      const v = Z.spd; if (v < .6) { FS.t = t + .22; return; }
      const f = v < 3 ? 1.2 + v * .3 : 1.9 + (v - 7) * .15, run = v > 9.5, road = Z.road;
      advance(FS, t, clamp(f, 1.2, 3.2), EVF, (e, when, k) => step(when, k, road, run));
    }
  }
  function ride(t, S0, dt) {
    const v = Math.abs(S0.riding.state.speed), gait = v < 2.9 ? 'walk' : v < 7 ? 'trot' : 'gallop', hz = t + .22;
    const own = !Z.mission;                                                       // missions already play their own hoofbeats (audio.js)
    if (v < .35) {                                                               // standing: slow breathing, snorts, an occasional soft nicker
      HS.t = hz; HS.ph = 0; const e = EM.idle;
      if (!e.armed) { e.armed = true; e.next = t + 2 + R() * 4; }
      if (t + .25 > e.next && live < Z.maxLive) {
        const r = R(); if (r < .6) breath(e.next, 4); else if (r < .85) { nz(e.next, .4, 'bandpass', 900, .8, .08, bus, .05); nz(e.next + .05, .3, 'lowpass', 420, .8, .05, bus, .05); }
        else vox(e.next, [[0, 250], [.25, 330], [.7, 300]], [600, 700, 4], [1300, 1500, 5], .75, .07, bus, 'sawtooth', [6, 8]);
        track(1); e.next += 3 + R() * 7;
      }
    } else if (own) {
      const f = gait === 'walk' ? .8 + v * .2 : gait === 'trot' ? 1.15 + (v - 2.9) * .13 : 2.0 + (v - 7) * .2, kind = Z.road ? 'dirt' : 'grass';
      const vol = gait === 'walk' ? .5 : gait === 'trot' ? .66 : .82, bright = gait === 'gallop' ? 7000 : gait === 'trot' ? 5600 : 4300, ev = EVH[gait];
      advance(HS, t, f, ev, (e, when) => {
        hoofPlay(when, ev[e][1], kind, vol * ev[e][2], ev[e][3], bright);
        if (gait === 'gallop' && e === 3) breath(when + .03, v); else if (gait === 'trot' && e === 0 && R() < .3) breath(when + .02, 1);
        if (gait !== 'walk' && R() < .25) jingle(when + .01);
      });
    } else HS.t = hz;
    if (Z.cart && v > 1.5) {                                                     // cart: wooden clacks over ruts + axle creaks
      const ec = EM.clack, ek = EM.creak;
      if (!ec.armed) { ec.armed = true; ec.next = t + .1; }
      while (ec.next < t + .25 && live < Z.maxLive + 4) {
        if (R() > .3) { const g = ctx.createGain(); g.gain.value = 1; g.connect(bus); const a = (Z.road ? .08 : .05) * (.6 + R() * .6); osc(ec.next, 'sine', 170 + R() * 50, 105, .06, a, .002, g); nz(ec.next, .045, 'bandpass', 650 + R() * 250, 2, a * .8, g, .002); }
        ec.next += 1 / clamp(1.5 + v * .5, 1.5, 9) * (.75 + R() * .5);
      }
      if (!ek.armed) { ek.armed = true; ek.next = t + 1 + R() * 2; }
      if (ek.next < t + .25 && live < Z.maxLive) { const f = 300 + R() * 140, d = .3 + R() * .35; vox(ek.next, [[0, f], [d, f * (R() < .5 ? 1.18 : .86)]], [1000, 1250, 9], [2000, 2200, 7], d, .05 + Math.min(.04, v * .002), bus, 'sawtooth', [9, 8]); track(1); ek.next += 1.2 + R() * 3; }
    } else { EM.clack.armed = false; EM.creak.armed = false; }
  }

  /* ---------------- start-up ---------------- */
  function ready() { return !!(A.ctx && A.ready && OYO.core && OYO.core.S && OYO.core.S.world && OYO.core.P && OYO.hud && !OYO.hud.loading); }
  function build() {
    try {
      ctx = A.ctx; bus = ctx.createGain(); bus.gain.value = 0; bus.connect(ctx.destination); FB = ctx.createGain(); FB.gain.value = 0; FB.connect(ctx.destination); NB = makeNoise(); learn();
      setTimeout(() => { try { MUR = makeMurmur(); } catch (e) { console.warn('Crowd loop skipped', e); } }, 60);
      try { A.muteLegacy && A.muteLegacy(); } catch (e) { /* keep the old wind if this fails */ }        // the old global wind + birds are replaced by this layer
      Z.px = OYO.core.P.x; Z.pz = OYO.core.P.z; lastPerf = performance.now(); built = true; AM.running = true; applyBus();
      fastT = setInterval(() => { try { fast(); } catch (e) { /* never break the game */ } }, 100);
    } catch (e) { console.warn('Ambient audio unavailable', e); built = false; }
  }
  slowT = setInterval(() => { try { slow(); } catch (e) { console.warn('ambient', e); } }, 500);
  AM.status = () => ({ on: AM.on, vol: AM.vol, running: AM.running, place: Object.assign({}, L), active: Object.assign({}, act), forest: Z.f, ride: Z.ride, walk: Z.walk, cart: Z.cart, road: Z.road, live, markets: markets.length, smiths: smiths.length, sites: sites.length, trees: treeN });
})();
