/* EMPIRE DASH — Stage 2 · terrain.js
   Savanna landscape: rolling land, kopjes, erosion gullies, road-graded terrain,
   painted splat-shader, distant mountains, boulders and dry-grass tufts. */
(function () {
  'use strict';
  const B = BABYLON;
  const HALF = 450, CS = 4, N = 225, V = N + 1, X0 = -HALF, FAR = 1600, FCS = 50, CELL = 24;

  /* ---------- noise ---------- */
  function hash(x, y) { const h = Math.sin(x * 127.1 + y * 311.7) * 43758.5453; return h - Math.floor(h); }
  function vnoise(x, y) {
    const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
    const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
    const a = hash(xi, yi), b = hash(xi + 1, yi), c = hash(xi, yi + 1), d = hash(xi + 1, yi + 1);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }
  function fbm(x, y, o) { let s = 0, a = .5, f = 1; for (let i = 0; i < o; i++) { s += a * vnoise(x * f, y * f); f *= 2; a *= .5; } return s; }
  const sm = (a, b, x) => { x = Math.min(1, Math.max(0, (x - a) / (b - a))); return x * x * (3 - 2 * x); };
  let sd = 90210; const rnd = () => { sd = (sd * 16807) % 2147483647; return (sd - 1) / 2147483646; };

  /* ---------- landform ---------- */
  const kop = [];
  function kopH(x, z) {
    let h = 0;
    for (let k = 0; k < kop.length; k++) {
      const p = kop[k], dx = x - p.x, dz = z - p.z, lim = p.R * 1.3; if (dx * dx + dz * dz > lim * lim) continue;
      const d = Math.sqrt(dx * dx + dz * dz);
      h += p.A * (1 - sm(p.R * .28, p.R * 1.25, d)) * (.84 + .32 * vnoise(x / 6 + p.s, z / 6));
    }
    return h;
  }
  function kopT(x, z) {
    let t = 0;
    for (let k = 0; k < kop.length; k++) {
      const p = kop[k], dx = x - p.x, dz = z - p.z, lim = p.R * 1.2; if (dx * dx + dz * dz > lim * lim) continue;
      const v = 1 - sm(p.R * .3, p.R * 1.1, Math.sqrt(dx * dx + dz * dz)); if (v > t) t = v;
    }
    return t;
  }
  const gully = (x, z) => Math.pow(1 - Math.abs(2 * vnoise(x / 62 + 7, z / 62 + 2) - 1), 7) + Math.pow(1 - Math.abs(2 * vnoise(x / 110 + 31, z / 110 + 8) - 1), 9);

  function baseHeight(x, z) {
    const flat = sm(.40, .62, fbm(x / 260 + 40, z / 260 + 17, 2));
    let h = (fbm(x / 380 + 3, z / 380 + 9, 3) - .45) * 30;
    h += ((fbm(x / 130 + 11, z / 130 + 5, 3) - .45) * 13 + (vnoise(x / 38, z / 38) - .5) * 2.4 + (vnoise(x / 13, z / 13) - .5) * .55) * (.38 + .62 * flat);
    const r = 1 - Math.abs(2 * vnoise(x / 62 + 7, z / 62 + 2) - 1), r2 = 1 - Math.abs(2 * vnoise(x / 110 + 31, z / 110 + 8) - 1);
    h -= (Math.pow(r, 7) * 1.5 + Math.pow(r2, 9) * 2.6) * (.35 + .65 * (1 - flat));
    h += kopH(x, z);
    const e = Math.max(Math.abs(x), Math.abs(z)), ramp = sm(385, 650, e);
    h += ramp * ramp * (48 + 36 * fbm(x / 170 + 60, z / 170 + 20, 2));
    const ridge = 1 - Math.abs(2 * fbm(x / 260 + 90, z / 260 + 40, 3) - 1);
    h += sm(560, 1350, e) * Math.pow(ridge, 2.2) * 190;
    return h;
  }

  /* ---------- road integration ---------- */
  let W = null, roads = [], grid = new Map(), stamp, bd, bi, touched, curStamp = 0, lastEdge = 1e9;
  const gk = (ix, iz) => (ix + 64) * 256 + (iz + 64);

  function edgeBrute(x, z) {
    let best = 1e9;
    for (const r of roads) for (let i = 0; i < r.n; i += 2) { const d = Math.hypot(x - r.x[i], z - r.z[i]) - r.w * .5; if (d < best) best = d; }
    return best;
  }
  function roadEdge(x, z) {
    const cx = Math.floor(x / CELL), cz = Math.floor(z / CELL); let best = 1e9;
    for (let ix = cx - 1; ix <= cx + 1; ix++) for (let iz = cz - 1; iz <= cz + 1; iz++) {
      const a = grid.get(gk(ix, iz)); if (!a) continue;
      for (let q = 0; q < a.length; q += 2) { const r = roads[a[q]], i = a[q + 1], d = Math.hypot(x - r.x[i], z - r.z[i]) - r.w * .5; if (d < best) best = d; }
    }
    if (W && W.siteEdge) { const s = W.siteEdge(x, z); if (s < best) best = s; }
    return best;
  }
  const bedAt = (r, t) => { const f = t * (r.n - 1), i = Math.min(r.n - 2, Math.floor(f)), k = f - i; return r.bed[i] + (r.bed[i + 1] - r.bed[i]) * k; };

  function prepare(World) {
    W = World; roads = World.roads; grid = new Map();
    roads.forEach((r, ri) => { for (let i = 0; i < r.n; i++) { const k = gk(Math.floor(r.x[i] / CELL), Math.floor(r.z[i] / CELL)); let a = grid.get(k); if (!a) grid.set(k, a = []); a.push(ri, i); } });
    stamp = new Int32Array(roads.length); bd = new Float32Array(roads.length); bi = new Int32Array(roads.length); touched = new Int32Array(roads.length);

    // kopjes (rounded granite hills) — kept well clear of every road
    kop.length = 0;
    for (let t = 0; t < 500 && kop.length < 12; t++) {
      const x = (rnd() * 2 - 1) * 370, z = (rnd() * 2 - 1) * 370, R = 14 + rnd() * 22;
      if (edgeBrute(x, z) < R * 1.3 + 30) continue;
      if (kop.some(k => Math.hypot(k.x - x, k.z - z) < k.R + R + 70)) continue;
      kop.push({ x, z, R, A: 7 + rnd() * 13 + R * .25, s: rnd() * 50 });
    }
    for (let t = 0; t < 600 && kop.length < 28; t++) {      // distant domes, outside the play area
      const x = (rnd() * 2 - 1) * 1400, z = (rnd() * 2 - 1) * 1400, R = 70 + rnd() * 130;
      if (Math.max(Math.abs(x), Math.abs(z)) < 450 + R * 1.3 + 20) continue;
      kop.push({ x, z, R, A: 40 + rnd() * 80, s: rnd() * 50 });
    }

    // graded road beds: smoothed profile of the land along each road
    roads.forEach(r => {
      const n = r.n; let a = new Float32Array(n);
      for (let i = 0; i < n; i++) a[i] = baseHeight(r.x[i], r.z[i]);
      for (let pass = 0; pass < 3; pass++) {
        const b = new Float32Array(n);
        for (let i = 0; i < n; i++) { let s = 0, c = 0; for (let j = -10; j <= 10; j++) { const q = i + j; if (q >= 0 && q < n) { s += a[q]; c++; } } b[i] = s / c; }
        a = b;
      }
      r.bed = a;
      if (r.pa) { const diff = bedAt(W.byId[r.pa.on], r.pa.t) - r.bed[0]; for (let i = 0; i < n; i++) r.bed[i] += diff * (1 - sm(0, 45, r.s[i])); }
      if (r.pb) { const diff = bedAt(W.byId[r.pb.on], r.pb.t) - r.bed[n - 1]; for (let i = 0; i < n; i++) r.bed[i] += diff * (1 - sm(0, 45, r.len - r.s[i])); }
    });
  }

  function carved(x, z) {
    const base = baseHeight(x, z); lastEdge = 1e9;
    const cx = Math.floor(x / CELL), cz = Math.floor(z / CELL); let nt = 0; curStamp++;
    for (let ix = cx - 1; ix <= cx + 1; ix++) for (let iz = cz - 1; iz <= cz + 1; iz++) {
      const a = grid.get(gk(ix, iz)); if (!a) continue;
      for (let q = 0; q < a.length; q += 2) {
        const ri = a[q], i = a[q + 1], r = roads[ri], dx = x - r.x[i], dz = z - r.z[i], d2 = dx * dx + dz * dz;
        if (stamp[ri] !== curStamp) { stamp[ri] = curStamp; bd[ri] = d2; bi[ri] = i; touched[nt++] = ri; }
        else if (d2 < bd[ri]) { bd[ri] = d2; bi[ri] = i; }
      }
    }
    let sw = 0, sdh = 0;
    for (let t = 0; t < nt; t++) {
      const ri = touched[t], r = roads[ri], i = bi[ri]; let dist = Math.sqrt(bd[ri]), bed = r.bed[i];
      for (let s = -1; s <= 0; s++) {
        const a = i + s, b = a + 1; if (a < 0 || b >= r.n) continue;
        const ax = r.x[a], az = r.z[a], ex = r.x[b] - ax, ez = r.z[b] - az, l2 = ex * ex + ez * ez || 1;
        let tt = ((x - ax) * ex + (z - az) * ez) / l2; tt = tt < 0 ? 0 : tt > 1 ? 1 : tt;
        const px = ax + ex * tt - x, pz = az + ez * tt - z, dd = Math.sqrt(px * px + pz * pz);
        if (dd < dist) { dist = dd; bed = r.bed[a] + (r.bed[b] - r.bed[a]) * tt; }
      }
      const hw = W.widthAt(r, i) * .5, flat = hw * 1.9, S = 5 + hw * 1.4, e = dist - hw;
      if (e < lastEdge) lastEdge = e;
      const w = 1 - sm(flat, flat + S, dist); if (w > 0) { sw += w; sdh += w * (bed - base); }
    }
    return base + sdh / Math.max(1, sw);
  }

  /* ---------- height grid (this exact grid is what gets rendered) ---------- */
  let H = null, E = null;
  function meshH(x, z) {
    let fx = (x - X0) / CS, fz = (z - X0) / CS; const m = N - 1e-4;
    fx = fx < 0 ? 0 : fx > m ? m : fx; fz = fz < 0 ? 0 : fz > m ? m : fz;
    const i = fx | 0, j = fz | 0, u = fx - i, v = fz - j, o = j * V + i, ha = H[o], hb = H[o + 1], hc = H[o + V], hd = H[o + V + 1];
    return u >= v ? ha + (hb - ha) * u + (hd - hb) * v : ha + (hd - hc) * u + (hc - ha) * v;
  }
  function normalAt(x, z, o) {
    const e = 2, hx = (meshH(x + e, z) - meshH(x - e, z)) / (2 * e), hz = (meshH(x, z + e) - meshH(x, z - e)) / (2 * e), l = Math.hypot(hx, 1, hz);
    o = o || {}; o.x = -hx / l; o.y = 1 / l; o.z = -hz / l; return o;
  }
  function computeHeights() {
    H = new Float32Array(V * V); E = new Float32Array(V * V);
    for (let j = 0; j < V; j++) for (let i = 0; i < V; i++) { H[j * V + i] = carved(X0 + i * CS, X0 + j * CS); E[j * V + i] = lastEdge; }
    W.setHeightFn(meshH);
  }

  /* ---------- surface painting weights ---------- */
  const P = new Float32Array(7);   // soil, grass, rock, clay, tint rgb
  function paintAt(x, z, h, ny, edge) {
    const slope = 1 - ny, patch = fbm(x / 48 + 31, z / 48 + 4, 3), moist = sm(4, -9, h);
    let g = sm(.40, .60, patch + .16 * moist) * (1 - sm(.10, .28, slope));
    const gu = gully(x, z);
    let d = sm(.2, .8, gu) * .9 + sm(.66, .84, fbm(x / 75 + 120, z / 75 + 7, 2)) * .45;
    let r = sm(.14, .32, slope) + sm(.74, .82, vnoise(x / 34 + 80, z / 34 + 13)) * (1 - sm(.08, .18, slope)) * .85 + kopT(x, z) * .9;
    const gf = sm(1.5, 16, edge);
    g *= gf; r *= .15 + .85 * sm(2, 16, edge); d *= .4 + .6 * sm(0, 10, edge);
    const s = .28 + .5 * (1 - g) + (1 - gf) * .9, sum = s + g + r + d;
    P[0] = s / sum; P[1] = g / sum; P[2] = r / sum; P[3] = d / sum;
    const t = fbm(x / 120 + 14, z / 120 + 60, 2), rr = .93 + .14 * vnoise(x / 9, z / 9);
    P[4] = (.86 + .22 * t) * rr; P[5] = (.96 - .01 * t) * rr; P[6] = (.74 + .01 * t) * rr;
  }

  /* ---------- painted textures ---------- */
  const tileDraw = (g, S, x, y, m, fn) => {
    const xs = [0], ys = [0]; if (x < m) xs.push(S); else if (x > S - m) xs.push(-S); if (y < m) ys.push(S); else if (y > S - m) ys.push(-S);
    for (const dx of xs) for (const dy of ys) { g.save(); g.translate(dx, dy); fn(); g.restore(); }
  };
  function makeTex(scene, name, paint) {
    const S = 512, t = new B.DynamicTexture(name, { width: S, height: S }, scene, true), g = t.getContext(); g.lineCap = 'round'; paint(g, S);
    t.wrapU = t.wrapV = B.Texture.WRAP_ADDRESSMODE; t.anisotropicFilteringLevel = 4; t.update(); return t;
  }
  const stroke = (g, S, x, y, a, l, w, col, m) => tileDraw(g, S, x, y, m || 40, () => { g.strokeStyle = col; g.lineWidth = w; g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke(); });
  const dab = (g, S, x, y, rx, ry, col) => tileDraw(g, S, x, y, 20, () => { g.fillStyle = col; g.beginPath(); g.ellipse(x, y, rx, ry, 0, 0, 6.3); g.fill(); });

  function paintSoil(g, S) {
    g.fillStyle = '#9b5535'; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 1000; i++) {
      const c = rnd() < .45 ? `rgba(${170 + rnd() * 50 | 0},${95 + rnd() * 40 | 0},${58 + rnd() * 30 | 0},.2)` : `rgba(${90 + rnd() * 30 | 0},${44 + rnd() * 20 | 0},${28 + rnd() * 14 | 0},.18)`;
      stroke(g, S, rnd() * S, rnd() * S, rnd() * 3.14, 8 + rnd() * 30, 2 + rnd() * 7, c);
    }
    for (let i = 0; i < 22; i++) {                 // erosion ripples
      let x = rnd() * S, y = rnd() * S; const a = rnd() * 3.14;
      for (let k = 0; k < 6; k++) { const nx = x + Math.cos(a + Math.sin(k) * .4) * 14, ny = y + Math.sin(a + Math.sin(k) * .4) * 14; stroke(g, S, x, y, Math.atan2(ny - y, nx - x), 15, 1.6, 'rgba(235,170,120,.16)', 60); x = nx; y = ny; }
    }
    for (let i = 0; i < 140; i++) { const x = rnd() * S, y = rnd() * S, r = 1 + rnd() * 3; dab(g, S, x + 1, y + 1, r, r * .8, 'rgba(70,32,18,.35)'); dab(g, S, x, y, r, r * .8, rnd() < .5 ? '#c89870' : '#b4784f'); }
    for (let i = 0; i < 12; i++) { let x = rnd() * S, y = rnd() * S; for (let k = 0; k < 6; k++) { const a = rnd() * 6.28; stroke(g, S, x, y, a, 10 + rnd() * 16, 1.2, 'rgba(60,28,16,.3)', 40); x += Math.cos(a) * 12; y += Math.sin(a) * 12; } }
  }
  function paintGrass(g, S) {
    g.fillStyle = '#c4a057'; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 70; i++) dab(g, S, rnd() * S, rnd() * S, 12 + rnd() * 30, 8 + rnd() * 20, 'rgba(124,74,44,.16)');
    const pal = ['rgba(232,207,134,.55)', 'rgba(185,137,63,.5)', 'rgba(243,226,172,.5)', 'rgba(154,138,69,.45)', 'rgba(160,90,50,.35)', 'rgba(120,88,40,.4)'];
    for (let i = 0; i < 2800; i++) stroke(g, S, rnd() * S, rnd() * S, -Math.PI / 2 + (rnd() - .5) * 1.0, 9 + rnd() * 18, 1 + rnd() * 1.6, pal[(rnd() * pal.length) | 0], 30);
  }
  function paintRock(g, S) {
    g.fillStyle = '#8b7260'; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 150; i++) {
      const x = rnd() * S, y = rnd() * S, r = 25 + rnd() * 60, n = 5 + (rnd() * 3 | 0), l = rnd() < .5, a0 = rnd() * 6.28;
      const col = l ? `rgba(${200 + rnd() * 40 | 0},${170 + rnd() * 30 | 0},${140 + rnd() * 30 | 0},.2)` : `rgba(${60 + rnd() * 30 | 0},${44 + rnd() * 20 | 0},${36 + rnd() * 16 | 0},.22)`;
      tileDraw(g, S, x, y, r, () => { g.fillStyle = col; g.beginPath(); for (let k = 0; k < n; k++) { const a = a0 + k / n * 6.28, rr = r * (.6 + hash(i, k) * .5); k ? g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr) : g.moveTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } g.closePath(); g.fill(); });
    }
    for (let i = 0; i < 40; i++) stroke(g, S, rnd() * S, rnd() * S, rnd() * 6.28, 20 + rnd() * 50, 1.4, 'rgba(40,28,22,.35)', 60);
    for (let i = 0; i < 500; i++) stroke(g, S, rnd() * S, rnd() * S, rnd() * 6.28, 4 + rnd() * 10, 2, rnd() < .5 ? 'rgba(220,190,160,.2)' : 'rgba(50,36,30,.2)');
  }
  function paintClay(g, S) {
    g.fillStyle = '#d9b284'; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 90; i++) dab(g, S, rnd() * S, rnd() * S, 14 + rnd() * 30, 10 + rnd() * 22, rnd() < .5 ? 'rgba(244,220,180,.25)' : 'rgba(180,128,86,.16)');
    for (let i = 0; i < 30; i++) { let x = rnd() * S, y = rnd() * S; for (let k = 0; k < 5; k++) { const a = rnd() * 6.28; stroke(g, S, x, y, a, 14 + rnd() * 22, 1.2, 'rgba(90,52,32,.35)', 50); x += Math.cos(a) * 16; y += Math.sin(a) * 16; } }
    for (let i = 0; i < 700; i++) dab(g, S, rnd() * S, rnd() * S, 1 + rnd() * 1.4, 1 + rnd() * 1.2, rnd() < .5 ? 'rgba(255,240,210,.5)' : 'rgba(110,70,46,.35)');
  }

  /* ---------- terrain shader (cel-banded light, flat Yoruba palette, haze + fog) ---------- */
  B.Effect.ShadersStore.oyoLandVertexShader = `precision highp float;
attribute vec3 position;attribute vec3 normal;attribute vec4 color;attribute vec3 tint;
uniform mat4 worldViewProjection;uniform mat4 worldView;
varying vec3 vW;varying vec3 vN;varying vec4 vC;varying vec3 vT;varying float vD;
void main(){vW=position;vN=normal;vC=color;vT=tint;vD=length((worldView*vec4(position,1.)).xyz);gl_Position=worldViewProjection*vec4(position,1.);}`;
  B.Effect.ShadersStore.oyoLandFragmentShader = `precision highp float;
varying vec3 vW;varying vec3 vN;varying vec4 vC;varying vec3 vT;varying float vD;
uniform vec3 toSun;uniform vec3 sunCol;uniform vec3 skyCol;uniform vec3 gndCol;uniform vec3 fogCol;uniform vec3 hazeCol;uniform float fogD;uniform float tile;
void main(){
  /* Yoruba palette, flat colour (no texture reads): camwood soil, leaf-green grass, indigo rock, ivory clay */
  vec4 w=vC*vC;w/=(w.x+w.y+w.z+w.w+.0001);
  vec3 alb=vec3(.70,.38,.24)*w.x+vec3(.40,.64,.30)*w.y+vec3(.32,.38,.66)*w.z+vec3(.92,.78,.52)*w.w;
  alb*=vT*(.93+.14*sin(vW.x*.021)*sin(vW.z*.017));
  vec3 N=normalize(vN);float ndl=dot(N,toSun);
  float band=.5*smoothstep(-.02,.08,ndl)+.5*smoothstep(.30,.42,ndl);
  float lit=mix(band,clamp(ndl,0.,1.),.3);
  vec3 hemi=mix(gndCol,skyCol,N.y*.5+.5);
  vec3 col=alb*(hemi+sunCol*lit);
  col=mix(col,col*vec3(.80,.74,1.),(1.-lit)*.45);
  col=mix(col,hazeCol,smoothstep(300.,1500.,vD)*.55);
  float f=1.-exp(-fogD*fogD*vD*vD);
  gl_FragColor=vec4(mix(col,fogCol,f),1.);
}`;

  /* ---------- meshes ---------- */
  function buildMeshes(scene, World) {
    const mat = new B.ShaderMaterial('landMat', scene, { vertex: 'oyoLand', fragment: 'oyoLand' }, {
      attributes: ['position', 'normal', 'color', 'tint'], uniforms: ['worldViewProjection', 'worldView', 'toSun', 'sunCol', 'skyCol', 'gndCol', 'fogCol', 'hazeCol', 'fogD', 'tile'], samplers: []
    });
    mat.setVector3('toSun', World.sunDir); mat.setVector3('sunCol', new B.Vector3(.85, .73, .53)); mat.setVector3('skyCol', new B.Vector3(.55, .57, .65));
    mat.setVector3('gndCol', new B.Vector3(.40, .30, .27)); mat.setVector3('fogCol', new B.Vector3(scene.fogColor.r, scene.fogColor.g, scene.fogColor.b));
    mat.setVector3('hazeCol', new B.Vector3(.93, .84, .64)); mat.setFloat('fogD', scene.fogDensity); mat.setFloat('tile', 7);
    mat.backFaceCulling = false;

    // ---- main play-area terrain (rendered from the very same height grid used for gameplay)
    const SK = 4 * N, tot = V * V + SK;
    const pos = new Float32Array(tot * 3), nor = new Float32Array(tot * 3), col = new Float32Array(tot * 4), tnt = new Float32Array(tot * 3);
    for (let j = 0; j < V; j++) for (let i = 0; i < V; i++) {
      const o = j * V + i, x = X0 + i * CS, z = X0 + j * CS, h = H[o];
      const hx = (H[j * V + Math.min(V - 1, i + 1)] - H[j * V + Math.max(0, i - 1)]) / ((Math.min(V - 1, i + 1) - Math.max(0, i - 1)) * CS);
      const hz = (H[Math.min(V - 1, j + 1) * V + i] - H[Math.max(0, j - 1) * V + i]) / ((Math.min(V - 1, j + 1) - Math.max(0, j - 1)) * CS), l = Math.hypot(hx, 1, hz);
      pos[o * 3] = x; pos[o * 3 + 1] = h; pos[o * 3 + 2] = z; nor[o * 3] = -hx / l; nor[o * 3 + 1] = 1 / l; nor[o * 3 + 2] = -hz / l;
      paintAt(x, z, h, 1 / l, E[o]);
      col[o * 4] = P[0]; col[o * 4 + 1] = P[1]; col[o * 4 + 2] = P[2]; col[o * 4 + 3] = P[3]; tnt[o * 3] = P[4]; tnt[o * 3 + 1] = P[5]; tnt[o * 3 + 2] = P[6];
    }
    const idx = new Uint16Array(N * N * 6 + SK * 6); let n = 0;
    for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) { const a = j * V + i, b = a + 1, c = a + V, d = c + 1; idx[n++] = a; idx[n++] = b; idx[n++] = d; idx[n++] = a; idx[n++] = d; idx[n++] = c; }
    const loop = []; for (let i = 0; i <= N; i++) loop.push(i); for (let j = 1; j <= N; j++) loop.push(j * V + N); for (let i = N - 1; i >= 0; i--) loop.push(N * V + i); for (let j = N - 1; j >= 1; j--) loop.push(j * V);
    loop.forEach((s, k) => {
      const t = V * V + k; pos[t * 3] = pos[s * 3]; pos[t * 3 + 1] = pos[s * 3 + 1] - 30; pos[t * 3 + 2] = pos[s * 3 + 2];
      nor.copyWithin(t * 3, s * 3, s * 3 + 3); col.copyWithin(t * 4, s * 4, s * 4 + 4); tnt.copyWithin(t * 3, s * 3, s * 3 + 3);
    });
    for (let k = 0; k < loop.length; k++) { const a = loop[k], b = loop[(k + 1) % loop.length], a2 = V * V + k, b2 = V * V + (k + 1) % loop.length; idx[n++] = a; idx[n++] = b; idx[n++] = a2; idx[n++] = b; idx[n++] = b2; idx[n++] = a2; }
    const ground = new B.Mesh('terrain', scene), vd = new B.VertexData();
    vd.positions = pos; vd.normals = nor; vd.colors = col; vd.indices = idx; vd.applyToMesh(ground);
    ground.setVerticesData('tint', tnt, false, 3);
    ground.material = mat; ground.isPickable = false; ground.freezeWorldMatrix(); ground.refreshBoundingInfo();

    // ---- distant landscape: coarse ring of savanna plains, domes and mountain ranges
    const FV = FAR * 2 / FCS + 1, fp = [], fn = [], fc = [], ft = [], fi = [], inside = (v) => Math.abs(v) <= HALF + 1e-6;
    for (let j = 0; j < FV; j++) for (let i = 0; i < FV; i++) {
      const x = -FAR + i * FCS, z = -FAR + j * FCS, h = baseHeight(x, z), e = 25;
      const hx = (baseHeight(x + e, z) - baseHeight(x - e, z)) / (2 * e), hz = (baseHeight(x, z + e) - baseHeight(x, z - e)) / (2 * e), l = Math.hypot(hx, 1, hz);
      fp.push(x, h, z); fn.push(-hx / l, 1 / l, -hz / l); paintAt(x, z, h, 1 / l, 1e9);
      fc.push(P[0], P[1], P[2], P[3]); ft.push(P[4], P[5], P[6]);
    }
    for (let j = 0; j < FV - 1; j++) for (let i = 0; i < FV - 1; i++) {
      const x0 = -FAR + i * FCS, z0 = -FAR + j * FCS; if (inside(x0) && inside(x0 + FCS) && inside(z0) && inside(z0 + FCS)) continue;
      const a = j * FV + i, b = a + 1, c = a + FV, d = c + 1; fi.push(a, b, d, a, d, c);
    }
    const far = new B.Mesh('farLand', scene), fv = new B.VertexData();
    fv.positions = fp; fv.normals = fn; fv.colors = fc; fv.indices = fi; fv.applyToMesh(far);
    far.setVerticesData('tint', ft, false, 3); far.material = mat; far.isPickable = false; far.freezeWorldMatrix(); far.refreshBoundingInfo();
    return { ground, far, mat };
  }

  /* ---------- boulders & dry-grass tufts ---------- */
  function scatter(scene, World, sg) {
    const q = new B.Quaternion(), sc = new B.Vector3(), tr = new B.Vector3(), mtx = new B.Matrix();
    const mkChunks = () => new Map();
    const put = (map, x, z, y, scl, yaw, tilt, color) => {
      const key = Math.floor((x + HALF) / 150) * 10 + Math.floor((z + HALF) / 150); let c = map.get(key); if (!c) map.set(key, c = { m: [], c: [] });
      B.Quaternion.RotationYawPitchRollToRef(yaw, tilt * (rnd() - .5), tilt * (rnd() - .5), q); sc.copyFromFloats(scl[0], scl[1], scl[2]); tr.copyFromFloats(x, y, z);
      B.Matrix.ComposeToRef(sc, q, tr, mtx); for (let k = 0; k < 16; k++) c.m.push(mtx.m[k]); c.c.push(color[0], color[1], color[2], 1);
    };
    const flush = (map, base, name, shadow) => {
      map.forEach((c, key) => {
        const m = base.clone(name + key); m.thinInstanceSetBuffer('matrix', new Float32Array(c.m), 16, true); m.thinInstanceSetBuffer('color', new Float32Array(c.c), 4, true);
        m.thinInstanceRefreshBoundingInfo(true); m.isPickable = false; if (shadow) { m.receiveShadows = true; sg.getShadowMap().renderList.push(m); }
      });
      base.dispose();
    };

    // boulders: rocky patches + rings around kopjes
    const rocks = mkChunks(), pal = [[.42, .48, .76], [.32, .38, .66], [.90, .82, .64], [.64, .38, .28], [.76, .64, .42]];
    const boulder = (x, z, size) => {
      if (roadEdge(x, z) < 5 + size) return; const p = pal[(rnd() * pal.length) | 0], l = .85 + rnd() * .25;
      put(rocks, x, z, meshH(x, z) + size * .22, [size * (.9 + rnd() * .5), size * (.55 + rnd() * .4), size * (.9 + rnd() * .5)], rnd() * 6.28, .7, [p[0] * l, p[1] * l, p[2] * l]);
    };
    for (let t = 0, got = 0; t < 400 && got < 16; t++) {
      const cx = (rnd() * 2 - 1) * 380, cz = (rnd() * 2 - 1) * 380, R = 8 + rnd() * 14; if (edgeBrute(cx, cz) < R + 20) continue; got++;
      const cnt = 16 + (rnd() * 26 | 0);
      for (let k = 0; k < cnt; k++) { const a = rnd() * 6.28, d = Math.sqrt(rnd()) * R; boulder(cx + Math.cos(a) * d, cz + Math.sin(a) * d, .4 + Math.pow(rnd(), 2.2) * 2.4); }
    }
    kop.forEach(p => { if (Math.max(Math.abs(p.x), Math.abs(p.z)) > HALF - 20) return; const cnt = 8 + (rnd() * 8 | 0); for (let k = 0; k < cnt; k++) { const a = rnd() * 6.28, d = p.R * (.9 + rnd() * .6); boulder(p.x + Math.cos(a) * d, p.z + Math.sin(a) * d, 1 + rnd() * 2.4); } });
    const rb = B.MeshBuilder.CreatePolyhedron('boulderBase', { type: 2, size: .5 }, scene); rb.convertToFlatShadedMesh();
    const rm = new B.StandardMaterial('boulderMat', scene); rm.specularColor = B.Color3.Black(); rm.emissiveColor = new B.Color3(.08, .05, .035); rb.material = rm;
    flush(rocks, rb, 'boulders_', true);

    // dry-grass tufts (3 blades each, painted straw colours)
    const gp = [], gc = [], gi = [], gn = [];
    for (let b = 0; b < 4; b++) {
      const a = b * 1.57 + .35, c = Math.cos(a), s = Math.sin(a), bw = .07, hg = .4 + b * .07, lean = .2 + b * .04, o = gp.length / 3;
      gp.push(-s * bw, 0, c * bw, s * bw, 0, -c * bw, c * lean * hg, hg, s * lean * hg);
      gc.push(.5, .36, .18, 1, .5, .36, .18, 1, 1, .9, .62, 1); gn.push(0, 1, 0, 0, 1, 0, 0, 1, 0); gi.push(o, o + 1, o + 2);
    }
    const tb = new B.Mesh('tuftBase', scene), tv = new B.VertexData(); tv.positions = gp; tv.colors = gc; tv.normals = gn; tv.indices = gi; tv.applyToMesh(tb);
    const tm = new B.StandardMaterial('tuftMat', scene); tm.backFaceCulling = false; tm.specularColor = B.Color3.Black(); tm.emissiveColor = new B.Color3(.1, .06, .04); tb.material = tm;
    const tufts = mkChunks(), tp = [[1, .9, .6], [.95, .78, .42], [1, .95, .75], [.8, .78, .45], [.85, .6, .36]], nv = { x: 0, y: 1, z: 0 };
    for (let x = -HALF + 4; x < HALF - 4; x += 6.5) for (let z = -HALF + 4; z < HALF - 4; z += 6.5) {
      const px = x + (rnd() - .5) * 5, pz = z + (rnd() - .5) * 5, edge = roadEdge(px, pz); if (edge < 2.5) continue;
      const h = meshH(px, pz); normalAt(px, pz, nv); paintAt(px, pz, h, nv.y, edge);
      const dens = (P[1] - .3) * 1.5 + P[0] * .12; if (dens <= 0 || rnd() > dens) continue;
      for (let k = 0; k < 2; k++) {
        const tx = px + (rnd() - .5) * 2.6, tz = pz + (rnd() - .5) * 2.6; if (roadEdge(tx, tz) < 2) continue;
        const p = tp[(rnd() * tp.length) | 0], l = .85 + rnd() * .25, s = .7 + rnd() * 1.0;
        put(tufts, tx, tz, meshH(tx, tz) - .02, [s * (.9 + rnd() * .4), s, s * (.9 + rnd() * .4)], rnd() * 6.28, .25, [p[0] * l, p[1] * l, p[2] * l]);
      }
    }
    flush(tufts, tb, 'tufts_', false);
  }

  /* ---------- minimap relief ---------- */
  function paintMap(g, size) {
    const R = 150, c = document.createElement('canvas'); c.width = c.height = R; const cg = c.getContext('2d'), img = cg.createImageData(R, R), nv = { x: 0, y: 1, z: 0 };
    for (let py = 0; py < R; py++) for (let px = 0; px < R; px++) {
      const x = -HALF + (px + .5) / R * 2 * HALF, z = HALF - (py + .5) / R * 2 * HALF, h = meshH(x, z); normalAt(x, z, nv);
      paintAt(x, z, h, nv.y, 20);
      const sh = Math.min(1.25, Math.max(.55, .78 + (nv.x * .5 - nv.z * .5) * 2.2)), e = Math.max(Math.abs(x), Math.abs(z)), v = 1 - sm(385, 450, e) * .45, o = (py * R + px) * 4;
      img.data[o] = (P[0] * 150 + P[1] * 200 + P[2] * 140 + P[3] * 220) * sh * v;
      img.data[o + 1] = (P[0] * 84 + P[1] * 160 + P[2] * 116 + P[3] * 178) * sh * v;
      img.data[o + 2] = (P[0] * 52 + P[1] * 92 + P[2] * 100 + P[3] * 130) * sh * v; img.data[o + 3] = 255;
    }
    cg.putImageData(img, 0, 0); g.imageSmoothingEnabled = true; g.drawImage(c, 0, 0, size, size);
  }

  window.OYOTerrain = { prepare, computeHeights, buildMeshes, scatter, paintMap, baseHeight, meshH, normalAt, _t: { carved, kop, paintAt, P } };
})();
