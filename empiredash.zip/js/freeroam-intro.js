/* Free Roam opening: Evernal Studios logo → "Present" → game title + Yoruba facts + loading bar → Free Roam intro (landscape required) → play. */
(function () {
  'use strict';
  var FACTS = [
    'Oyo-Ile, also called Old Oyo, was the capital of the Oyo Empire, which grew into one of the largest states in West Africa.',
    'The king of Oyo is called the Aláàfin, meaning “owner of the palace”.',
    'The Yoruba talking drum, the dùndún, can imitate the rise and fall of the tonal Yoruba language, so a drum can “speak”.',
    'The Ọyọ́ Mẹ́sì, a council of seven chiefs led by the Bàṣọ̀run, advised the Aláàfin and acted as a check on his power.',
    'Oyo built its strength on cavalry. Its horsemen gave the savanna kingdom a great military advantage.'
  ];
  var css = '#fri{position:fixed;inset:0;z-index:99999;background:#000;color:#fff;font-family:system-ui,sans-serif;display:none;overflow:hidden}#fri.on{display:block}' +
    '.fs{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;opacity:0;pointer-events:none;transition:opacity .9s ease;padding:16px;box-sizing:border-box}.fs.on{opacity:1;pointer-events:auto}' +
    '.fl{width:min(86vw,620px);opacity:0;transform:scale(.82);filter:blur(10px) brightness(.6)}.fs.on .fl{animation:flIn 2.2s .2s cubic-bezier(.2,.8,.2,1) forwards}' +
    '@keyframes flIn{60%{opacity:1;filter:blur(0) brightness(1.25)}100%{opacity:1;transform:scale(1);filter:blur(0) brightness(1)}}' +
    '.fsh{position:absolute;top:0;bottom:0;width:30%;left:-40%;background:linear-gradient(100deg,transparent,rgba(255,215,120,.35),transparent);transform:skewX(-18deg);mix-blend-mode:screen}.fs.on .fsh{animation:flSh 1.4s 1.5s ease-out forwards}@keyframes flSh{to{left:120%}}' +
    '.flw{position:relative;overflow:hidden}.fpr{font-size:clamp(1.4rem,5vw,2.2rem);letter-spacing:.5em;text-indent:.5em;font-weight:300;color:#f0b43a;opacity:0;transform:translateY(8px)}.fs.on .fpr{animation:fpIn 1.6s .2s ease forwards}@keyframes fpIn{to{opacity:1;transform:none}}' +
    '.ftl{width:min(70vw,420px);max-height:34vh;object-fit:contain;filter:drop-shadow(0 4px 14px #000)}.ffact{max-width:min(88vw,560px);min-height:4.2em;margin:14px 0 10px;font-size:clamp(.85rem,2.6vw,1.05rem);line-height:1.45;color:#ffe9b8;transition:opacity .5s}.fk{font-size:.68rem;letter-spacing:.2em;color:#f0b43a;font-weight:800}' +
    '.fbar{width:min(80vw,420px);height:8px;border-radius:9px;background:rgba(255,255,255,.15);overflow:hidden}.fbar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#c88a1c,#ffd27a);transition:width .25s linear}.fpc{font-size:.78rem;color:#b3a7f2;margin-top:6px}' +
    '.fbg{position:absolute;inset:0;background:center/cover no-repeat;opacity:.35}.fin{position:relative;max-width:min(90vw,520px);background:rgba(10,8,30,.82);border:1px solid #f0b43a;border-radius:14px;padding:16px}.fin h2{margin:0 0 8px;color:#f0b43a;font-size:1.2rem}.fin p{font-size:.88rem;line-height:1.45;margin:0 0 10px;text-align:left}' +
    '.fgo{padding:12px 26px;border:0;border-radius:10px;background:#f0a030;color:#2a1608;font-weight:800;font-size:1rem}.fgo[disabled]{background:#555;color:#aaa}.frot{color:#ffd27a;font-size:.9rem;margin:8px 0}.frot span{display:inline-block;font-size:1.6rem;animation:frr 1.6s ease-in-out infinite}@keyframes frr{50%{transform:rotate(90deg)}}';
  var root, scr = {}, timers = [], fi = 0, ft = 0;
  function later(f, ms) { timers.push(setTimeout(f, ms)); }
  function build() {
    if (root) return; var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
    root = document.createElement('div'); root.id = 'fri';
    root.innerHTML = '<div class="fs" data-s="logo"><div class="flw"><img class="fl" src="assets/art/evernal-logo.jpg" alt="Evernal Studios"><div class="fsh"></div></div></div>' +
      '<div class="fs" data-s="present"><div class="fpr">PRESENT</div></div>' +
      '<div class="fs" data-s="load"><div class="fbg" style="background-image:url(assets/art/scene-land.jpg)"></div><img class="ftl" src="assets/art/logo.png" alt="Empire Dash"><div class="fk" style="margin-top:12px">DID YOU KNOW?</div><div class="ffact" id="friFact"></div><div class="fbar"><i id="friBar"></i></div><div class="fpc" id="friPc">0%</div></div>' +
      '<div class="fs" data-s="intro"><div class="fbg" style="background-image:url(assets/art/free-roam.jpg)"></div><div class="fin"><h2>FREE ROAM</h2><p>Ride the Yoruba Kingdom at your own pace. Visit villages, markets and royal sites, pick up passengers on the road and drop them at their stops to earn cowries. Steer with the stick or A/D, jump with Space, and watch your horse’s stamina.</p><div class="frot" id="friRot"><span>📱</span> Turn your phone sideways (landscape) to play</div><button class="fgo" id="friGo" disabled>Play</button></div></div>';
    document.body.appendChild(root);
    ['logo', 'present', 'load', 'intro'].forEach(function (k) { scr[k] = root.querySelector('[data-s=' + k + ']'); });
    root.querySelector('#friGo').onclick = go;
    window.addEventListener('resize', land); window.addEventListener('orientationchange', function () { setTimeout(land, 200); });
  }
  function show(k) { for (var s in scr) scr[s].classList.toggle('on', s === k); }
  function isLand() { return innerWidth > innerHeight; }
  function land() { if (!root || !root.classList.contains('on')) return; var ok = isLand(), b = root.querySelector('#friGo'); b.disabled = !ok; root.querySelector('#friRot').style.display = ok ? 'none' : ''; }
  function fact() { var e = document.getElementById('friFact'); e.style.opacity = 0; later(function () { e.textContent = FACTS[order[fi++ % order.length]]; e.style.opacity = 1; }, 350); }
  var order = [];
  function play() {
    build(); timers.forEach(clearTimeout); timers = []; order = FACTS.map(function (_, i) { return i; }).sort(function () { return Math.random() - .5; }); fi = 0;
    root.classList.add('on'); try { document.documentElement.requestFullscreen && !document.fullscreenElement && document.documentElement.requestFullscreen().catch(function () {}); } catch (e) { /* ok */ }
    show('logo'); later(function () { show('present'); }, 3600); later(function () { show('load'); load(); }, 6200);
  }
  function load() {
    var bar = document.getElementById('friBar'), pc = document.getElementById('friPc'), t0 = Date.now(), DUR = 9000; fact();
    (function tick() { var p = Math.min(1, (Date.now() - t0) / DUR); bar.style.width = (p * 100) + '%'; pc.textContent = Math.floor(p * 100) + '%'; if (Math.floor((Date.now() - t0) / 3000) > ft) { ft = Math.floor((Date.now() - t0) / 3000); fact(); }
      if (p < 1) timers.push(setTimeout(tick, 120)); else { ft = 0; later(function () { show('intro'); land(); }, 500); } })();
  }
  function go() {
    if (!isLand()) { land(); return; }
    try { screen.orientation && screen.orientation.lock && screen.orientation.lock('landscape').catch(function () {}); } catch (e) { /* ok */ }
    root.style.transition = 'opacity .6s'; root.style.opacity = 0; later(function () { root.classList.remove('on'); root.style.opacity = 1; try { OYO.mission.free(); } catch (e) { console.warn('Free Roam start', e); } }, 650);
  }
  window.OYOFreeIntro = { play: play };
})();
