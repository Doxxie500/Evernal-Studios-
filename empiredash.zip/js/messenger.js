/* EMPIRE DASH — Stage 7 · messenger.js
   The royal messenger of the Aláàfin: young Oyo man in agbada, fila, waist sash, sandals, pouch and royal insignia.
   Built directly in horse model space (seated on the saddle), skinned to its own 13-bone rig; hands are IK-attached to the reins. */
(function (root) {
  'use strict';
  const R = root.OYORig || require('./rig.js');
  const H = root.OYOHorse || require('./horse.js');
  const { MB, nv, loft, ellipsoid, strip, tube, box, mixc, shade, smooth, lerp, clamp, norm, sub, add, mul, cross, dot, len, PI, TAU } = R;

  /* ---------------- palette ---------------- */
  const SKIN = [.40, .25, .165], SKIN_D = [.30, .18, .12], INDIGO = [.15, .21, .52], INDIGO_L = [.22, .30, .66], CREAM = [.94, .89, .77], GOLD = [.97, .77, .30], RED = [.76, .17, .13],
    WINE = [.43, .12, .20], LEATHER = [.36, .20, .10], LEATHER_L = [.52, .31, .15], BLACK = [.07, .05, .045], WHITE = [.96, .94, .90], BRASS = [.92, .68, .24], TEAL = [.14, .45, .48];

  /* ---------------- bones ---------------- */
  const BN = ['HIPS', 'CHEST', 'HEAD', 'UARM_L', 'FARM_L', 'UARM_R', 'FARM_R', 'THIGH_L', 'SHIN_L', 'FOOT_L', 'THIGH_R', 'SHIN_R', 'FOOT_R'];
  const B = {}; BN.forEach((n, i) => B[n] = i);
  const NB = BN.length;

  /* ---------------- rest layout (horse model space) ---------------- */
  const HIP = [.10, 1.555, -.07], ANK = [.325, .865, -.03], WAIST = [0, 1.66, -.07], NECKB = [0, 2.12, -.06];
  const SH = [.205, 2.04, -.03], HANDS = [.105, 1.80, .40], LU = .295, LF = .285;
  const KL = .435, KS = .455;     // thigh, shin
  const mirrorV = (p, s) => [p[0] * s, p[1], p[2]];

  /* 3-D two-bone IK: returns the middle joint */
  function ik3(S, T, l1, l2, pole) {
    const d = sub(T, S); let D = len(d); const dir = norm(d);
    D = clamp(D, Math.abs(l1 - l2) + 1e-3, l1 + l2 - 1e-3);
    const a = (l1 * l1 - l2 * l2 + D * D) / (2 * D), h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
    let p = sub(pole, mul(dir, dot(pole, dir))); p = norm(p);
    return add(add(S, mul(dir, a)), mul(p, h));
  }
  /* rest-pose joints */
  const rest = {};
  for (const s of [-1, 1]) {
    const k = s < 0 ? 'L' : 'R', hip = mirrorV(HIP, s), ank = mirrorV(ANK, s), sh = mirrorV(SH, s), hand = mirrorV(HANDS, s);
    rest['hip' + k] = hip; rest['ank' + k] = ank; rest['sh' + k] = sh; rest['hand' + k] = hand;
    rest['knee' + k] = ik3(hip, ank, KL, KS, [s * .45, .25, 1]);
    rest['elb' + k] = ik3(sh, hand, LU, LF, [s * .8, -.7, -.35]);
    rest['polA' + k] = norm(sub(rest['elb' + k], add(sh, mul(sub(hand, sh), dot(sub(rest['elb' + k], sh), norm(sub(hand, sh)))))));
  }

  function build() {
    const m = MB(), W1 = b => [b, b, 0], anchors = {};
    const hipsW = [B.HIPS, B.HIPS, 0];
    const torsoW = y => y < 1.52 ? [B.HIPS, B.HIPS, 0] : y < 1.80 ? [B.HIPS, B.CHEST, smooth(1.52, 1.80, y)] : [B.CHEST, B.CHEST, 0];

    /* ===== legs: sokoto trousers + sandals ===== */
    for (const s of [-1, 1]) {
      const k = s < 0 ? 'L' : 'R', hip = rest['hip' + k], kn = rest['knee' + k], an = rest['ank' + k];
      const bT = B['THIGH_' + k], bS = B['SHIN_' + k], bF = B['FOOT_' + k];
      const tdir = norm(sub(kn, hip)), sdir = norm(sub(an, kn));
      const P = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
      // thigh
      const ts = [{ p: add(hip, mul(tdir, -.06)), rx: .09, ry: .09, w: [B.HIPS, bT, .5] }, { p: P(hip, kn, .35), rx: .088, ry: .088, w: [bT, bT, 0] }, { p: P(hip, kn, .75), rx: .075, ry: .076, w: [bT, bT, 0] }, { p: kn, rx: .066, ry: .068, w: [bT, bS, .5] }];
      loft(m, ts, { N: 8, color: () => CREAM, weight: f => f.sec.w });
      // shin: loose cream sokoto gathering to a cuff
      const ss = [{ p: kn, rx: .066, ry: .068, w: [bT, bS, .5] }, { p: P(kn, an, .35), rx: .07, ry: .07, w: [bS, bS, 0] }, { p: P(kn, an, .8), rx: .06, ry: .06, w: [bS, bS, 0] }, { p: add(an, [0, .03, 0]), rx: .05, ry: .05, w: [bS, bF, .4] }];
      loft(m, ss, { N: 8, color: f => f.s === 3 ? mixc(CREAM, GOLD, .5) : CREAM, weight: f => f.sec.w, flex: f => [4, f.s * .06, s] });
      // foot + sandal (heel at back, toes forward, sole slightly below)
      const heel = [an[0], an[1] - .06, an[2] - .075], toe = [an[0], an[1] - .08, an[2] + .17];
      loft(m, [{ p: add(heel, [0, .045, .0]), rx: .036, ry: .042 }, { p: [an[0], an[1] - .035, an[2] + .01], rx: .042, ry: .042 }, { p: [an[0], an[1] - .06, an[2] + .10], rx: .046, ry: .032 }, { p: toe, rx: .04, ry: .022 }], { N: 8, cap1: .02, cap0: .02, color: f => SKIN, weight: () => W1(bF) });
      // (path is along z so section v = +y)
      box(m, [an[0], an[1] - .105, an[2] + .045], [.098, .014, .30], { col: LEATHER, w: W1(bF) });
      for (const dz of [.03, .12]) tube(m, [[an[0] - .045, an[1] - .1, an[2] + dz], [an[0], an[1] - .045, an[2] + dz + .01], [an[0] + .045, an[1] - .1, an[2] + dz]], .007, { seg: 4, col: LEATHER_L, weight: () => W1(bF) });
      tube(m, [[an[0] - .042, an[1] - .09, an[2] - .07], [an[0], an[1] - .03, an[2] - .09], [an[0] + .042, an[1] - .09, an[2] - .07]], .007, { seg: 4, col: LEATHER_L, weight: () => W1(bF) });
      ellipsoid(m, [an[0], an[1] - .06, an[2] + .01], [.012, .014, .014], { col: GOLD, w: W1(bF), seg: 5, rings: 3 });
    }

    /* ===== pelvis + agbada skirt (drapes over saddle and thighs) ===== */
    {
      const sk = [
        { p: [0, 1.62, -.07], rx: .17, ry: .125, dv: -.0, w: [B.HIPS, B.CHEST, .5], fa: 0 },
        { p: [0, 1.53, -.07], rx: .25, ry: .19, dv: -.02, w: hipsW, fa: 0 },
        { p: [0, 1.43, -.07], rx: .33, ry: .27, dv: -.05, w: hipsW, fa: .15 },
        { p: [0, 1.32, -.07], rx: .38, ry: .31, dv: -.06, w: hipsW, fa: .5 },
        { p: [0, 1.225, -.07], rx: .405, ry: .34, dv: -.07, w: hipsW, fa: 1 }
      ];
      loft(m, sk, {
        N: 20, e: 2.2,
        color: f => {   // indigo with gold hem band and embroidered rear panel
          const back = clamp(f.sn, 0, 1);           // v axis = -z, so +sn is the BACK
          let c = mixc(INDIGO, INDIGO_L, .25 * (1 + Math.sin(f.k * 3)) * .5);
          if (f.s === 4) c = GOLD; else if (f.s === 3 && f.k % 2 === 0) c = mixc(c, GOLD, .12);
          if (f.s >= 1 && back > .6 && Math.abs(f.cs) < .4) c = mixc(c, GOLD, .22 + .1 * (f.s % 2));
          return c;
        },
        weight: f => f.sec.w, flex: f => [4, f.sec.fa * .8, f.k * .7]
      });
      // front opening of the robe: cream underlayer visible between the knees
      loft(m, [{ p: [0, 1.58, .03], rx: .07, ry: .02 }, { p: [0, 1.45, .12], rx: .1, ry: .02 }, { p: [0, 1.32, .2], rx: .12, ry: .02 }], { N: 6, color: () => CREAM, weight: () => hipsW });
    }

    /* ===== torso: agbada body with cream under-buba V-neck ===== */
    {
      const ts = [{ p: [0, 1.60, -.07], rx: .165, ry: .12 }, { p: [0, 1.72, -.07], rx: .17, ry: .12 }, { p: [0, 1.86, -.065], rx: .20, ry: .125 }, { p: [0, 2.0, -.06], rx: .215, ry: .12 }, { p: [0, 2.09, -.06], rx: .12, ry: .09 }];
      loft(m, ts, {
        N: 16, e: 2.2, cap1: .02,
        color: f => {
          const front = clamp(-f.sn, 0, 1), y = f.y;
          let c = mixc(INDIGO, INDIGO_L, .2 * (1 + Math.sin(f.k * 2.3)) * .5);
          if (front > .45 && Math.abs(f.x) < .075 + (2.1 - y) * -.05 + .07 * (y < 2.0 ? 1 : 0) && y > 1.78) c = CREAM;           // V of the buba
          if (front > .3 && Math.abs(Math.abs(f.x) - (.085 + (2.09 - y) * .1)) < .014 && y > 1.78) c = GOLD;                     // gold neck trim
          if (f.sn > .5 && y > 1.74 && y < 2.03 && Math.abs(f.x) < .13 && (Math.abs(f.x) < .02 || Math.abs((y - 1.89) * .6) + Math.abs(f.x) < .1)) c = mixc(c, GOLD, .35);   // embroidered back diamond
          return c;
        },
        weight: f => torsoW(f.y)
      });
      // neck + head
      loft(m, [{ p: [0, 2.08, -.06], rx: .052, ry: .055, w: [B.CHEST, B.HEAD, .3] }, { p: [0, 2.15, -.05], rx: .05, ry: .052, w: W1(B.HEAD) }, { p: [0, 2.2, -.04], rx: .05, ry: .054, w: W1(B.HEAD) }], { N: 8, color: f => SKIN, weight: f => f.sec.w });
      // head
      const hc = [0, 2.285, -.03];
      ellipsoid(m, hc, [.082, .112, .1], { col: SKIN, w: W1(B.HEAD), seg: 12, rings: 8 });
      ellipsoid(m, [0, hc[1] - .075, hc[2] + .03], [.062, .05, .07], { col: SKIN, w: W1(B.HEAD), seg: 10, rings: 5 });                          // jaw / chin
      ellipsoid(m, [0, hc[1] - .012, hc[2] + .098], [.016, .033, .028], { col: shade(SKIN, 1.04), w: W1(B.HEAD), seg: 7, rings: 4, pitch: -.3 });      // nose
      for (const s of [-1, 1]) {
        ellipsoid(m, [s * .036, hc[1] + .018, hc[2] + .085], [.011, .008, .008], { col: WHITE, w: W1(B.HEAD), seg: 6, rings: 3 });
        ellipsoid(m, [s * .036, hc[1] + .018, hc[2] + .091], [.006, .006, .004], { col: BLACK, w: W1(B.HEAD), seg: 5, rings: 3 });
        ellipsoid(m, [s * .038, hc[1] + .036, hc[2] + .084], [.017, .005, .007], { col: BLACK, w: W1(B.HEAD), seg: 6, rings: 3 });                      // brows
        ellipsoid(m, [s * .083, hc[1] - .005, hc[2] - .005], [.012, .026, .018], { col: SKIN_D, w: W1(B.HEAD), seg: 6, rings: 4 });                      // ears
        ellipsoid(m, [s * .02, hc[1] - .058, hc[2] + .086], [.017, .006, .01], { col: shade(SKIN, .7), w: W1(B.HEAD), seg: 6, rings: 3 });               // mouth
      }
      // short hair at nape and temples
      ellipsoid(m, [0, hc[1] + .005, hc[2] - .03], [.086, .108, .085], { col: BLACK, w: W1(B.HEAD), seg: 10, rings: 6 });
      // fila cap: wine-red soft cap with gold band, side flop (dog-ear) and brooch
      loft(m, [{ p: [0, 2.318, -.03], rx: .098, ry: .108, dv: .0 }, { p: [0, 2.365, -.03], rx: .102, ry: .112 }, { p: [0, 2.42, -.035], rx: .09, ry: .1 }, { p: [0, 2.465, -.045], rx: .06, ry: .07 }],
        { N: 14, cap1: .02, cap0: .0, color: f => f.s === 0 ? GOLD : mixc(WINE, [.55, .16, .24], f.s * .12), weight: () => W1(B.HEAD) });
      loft(m, [{ p: [.09, 2.37, -.03], rx: .022, ry: .06 }, { p: [.12, 2.30, -.03], rx: .02, ry: .07 }, { p: [.13, 2.23, -.03], rx: .012, ry: .05 }], { N: 8, cap1: .01, color: f => f.s === 2 ? GOLD : WINE, weight: f => W1(B.HEAD), flex: f => [4, f.s * .12, 1.3] });
      ellipsoid(m, [0, 2.352, .082], [.02, .02, .008], { col: GOLD, w: W1(B.HEAD), seg: 8, rings: 4 });
    }

    /* ===== waist sash, sash tails, pouch & strap, insignia ===== */
    {
      const ring = [], N = 18; for (let k = 0; k <= N; k++) { const th = TAU * k / N; ring.push([Math.cos(th) * .185, 1.665, -.07 + Math.sin(th) * .135]); }
      tube(m, ring, .028, { seg: 6, col: RED, weight: () => [B.HIPS, B.CHEST, .5], color: (i, t) => i % 2 ? RED : shade(RED, .85) });
      const ring2 = ring.map(p => [p[0], p[1] + .045, p[2]]); tube(m, ring2, .012, { seg: 4, col: GOLD, weight: () => [B.HIPS, B.CHEST, .5] });
      for (const [dx, a] of [[.205, 0], [.19, .35]]) {
        strip(m, [[dx, 1.66, -.04 + a * .05], [dx + .03, 1.52, -.03 + a * .05], [dx + .05, 1.40, -.02 + a * .05]], [.07, .085, .075], [0, 0, 1], { color: (i, t) => i === 2 ? GOLD : RED, weight: () => hipsW, flex: (i, t) => [5, t * .8, a * 7] });
      }
      // sash knot
      ellipsoid(m, [.205, 1.67, -.04], [.04, .035, .035], { col: shade(RED, .9), w: [B.HIPS, B.CHEST, .5], seg: 8, rings: 5 });
      // pouch strap across body (left shoulder → right hip)
      const sp = [[-.14, 2.04, -.04], [-.1, 1.93, .06], [.0, 1.82, .075], [.12, 1.70, .06], [.235, 1.585, -.02]];
      tube(m, sp, .014, { seg: 5, col: LEATHER_L, weight: (i, t) => t < .35 ? [B.CHEST, B.CHEST, 0] : [B.CHEST, B.HIPS, smooth(.35, 1, t)] });
      const pc = [.255, 1.5, .0];
      box(m, pc, [.045, .14, .11], { col: LEATHER, w: hipsW });
      ellipsoid(m, [pc[0] + .026, pc[1] + .02, pc[2]], [.014, .075, .06], { col: LEATHER_L, w: hipsW, seg: 8, rings: 5 });                   // flap
      ellipsoid(m, [pc[0] + .036, pc[1] - .005, pc[2]], [.007, .03, .03], { col: BRASS, w: hipsW, seg: 8, rings: 4 });                           // royal disc on pouch
      ellipsoid(m, [pc[0] + .04, pc[1] - .005, pc[2]], [.004, .014, .014], { col: RED, w: hipsW, seg: 6, rings: 3 });
      tube(m, [[pc[0] + .02, pc[1] - .065, pc[2]], [pc[0] + .03, pc[1] - .12, pc[2] + .01], [pc[0] + .03, pc[1] - .17, pc[2] + .012]], .007, { seg: 4, col: RED, weight: () => hipsW, flex: (i, t) => [3, t * .4, 2] });
      // royal insignia: gold sun-disc on a cord at the chest + gold arm-bands
      const cord = [[-.07, 2.08, .04], [-.06, 2.0, .09], [0, 1.94, .11], [.06, 2.0, .09], [.07, 2.08, .04]];
      tube(m, cord, .006, { seg: 4, col: GOLD, weight: () => W1(B.CHEST) });
      const dc = [0, 1.91, .125];
      ellipsoid(m, dc, [.036, .036, .009], { col: GOLD, w: W1(B.CHEST), seg: 12, rings: 4, pitch: 0 });
      ellipsoid(m, [0, dc[1], dc[2] + .008], [.02, .02, .006], { col: RED, w: W1(B.CHEST), seg: 10, rings: 3 });
      for (let k = 0; k < 8; k++) {      // eight rays
        const a = TAU * k / 8;
        ellipsoid(m, [Math.cos(a) * .046, dc[1] + Math.sin(a) * .046, dc[2]], [.007, .007, .006], { col: GOLD, w: W1(B.CHEST), seg: 5, rings: 3 });
      }
    }

    /* ===== arms: wide agbada sleeves, forearm hidden to the cuff, fists on the reins ===== */
    for (const s of [-1, 1]) {
      const k = s < 0 ? 'L' : 'R', sh = rest['sh' + k], el = rest['elb' + k], hd = rest['hand' + k], bU = B['UARM_' + k], bF = B['FARM_' + k];
      const P = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
      const ss = [
        { p: add(sh, [-s * .02, .02, -.01]), rx: .085, ry: .085, w: [B.CHEST, bU, .4], fa: 0 }, { p: P(sh, el, .45), rx: .082, ry: .085, w: [bU, bU, 0], fa: .05 }, { p: el, rx: .098, ry: .1, w: [bU, bF, .5], fa: .15 },
        { p: P(el, hd, .45), rx: .125, ry: .125, w: [bF, bF, 0], fa: .4 }, { p: P(el, hd, .78), rx: .155, ry: .15, w: [bF, bF, 0], fa: .8 }, { p: P(el, hd, 1.0), rx: .175, ry: .17, w: [bF, bF, 0], fa: 1 }
      ];
      loft(m, ss, {
        N: 12, e: 2.1, color: f => f.s === 5 ? GOLD : f.s === 4 && f.k % 3 === 0 ? mixc(INDIGO, GOLD, .25) : mixc(INDIGO, INDIGO_L, .2 * (1 + Math.sin(f.k * 2 + f.s)) * .5),
        weight: f => f.sec.w, flex: f => [4, f.sec.fa * .9, f.k * .6 + s]
      });
      // inner cream cuff lining + hand
      const hp = add(hd, [0, -.005, .01]);
      ellipsoid(m, hp, [.04, .04, .055], { col: SKIN, w: W1(bF), seg: 8, rings: 5, pitch: -.2 });
      ellipsoid(m, [hp[0] - s * .028, hp[1] + .012, hp[2] + .015], [.014, .022, .03], { col: SKIN, w: W1(bF), seg: 6, rings: 4 });
      ellipsoid(m, [hp[0], hp[1] - .028, hp[2] + .03], [.03, .014, .028], { col: shade(SKIN, .92), w: W1(bF), seg: 6, rings: 3 });
      // arm-band
      ellipsoid(m, add(P(sh, el, .5), [0, 0, 0]), [.09, .016, .09], { col: GOLD, w: W1(bU), seg: 10, rings: 3, pitch: .0 });
    }
    return { mesh: m, anchors: { handL: rest.handL, handR: rest.handR } };
  }

  const api = { build, BN, B, NB, rest, HIP, ANK, SH, HANDS, KL, KS, LU, LF, ik3, palette: { SKIN, INDIGO, CREAM, GOLD, RED, WINE } };
  root.OYOMessenger = Object.assign(root.OYOMessenger || {}, api);
  if (typeof module !== 'undefined' && module.exports) module.exports = root.OYOMessenger;
})(typeof window !== 'undefined' ? window : globalThis);
