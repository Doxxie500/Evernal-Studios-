/* EMPIRE DASH — cowry-icon.js
   One cowry icon everywhere in the menus and HUD. The shell is a single <symbol id="cwr-sym"> in index.html; this file swaps every 🐚 character
   that appears in page text (Alpine x-text, toasts, speech bubbles, HUD chips…) for that icon, now and whenever the text changes.
   The 3D cowries lying on the road are untouched (they are Babylon meshes, not page text). */
(function () {
  'use strict';
  var E = '\uD83D\uDC1A', NS = 'http://www.w3.org/2000/svg', XL = 'http://www.w3.org/1999/xlink';
  var SKIP = { SCRIPT: 1, STYLE: 1, TEXTAREA: 1, INPUT: 1, TITLE: 1, SVG: 1, CANVAS: 1 };
  function icon() {
    var s = document.createElementNS(NS, 'svg'), u = document.createElementNS(NS, 'use');
    s.setAttribute('class', 'cwr'); s.setAttribute('aria-hidden', 'true');
    u.setAttribute('href', '#cwr-sym'); u.setAttributeNS(XL, 'xlink:href', '#cwr-sym'); s.appendChild(u); return s;
  }
  function fix(n) {
    var p = n.parentNode; if (!p || n.nodeValue.indexOf(E) < 0 || SKIP[String(p.nodeName).toUpperCase()] || p.isContentEditable) return;
    var parts = n.nodeValue.split(E), f = document.createDocumentFragment();
    for (var i = 0; i < parts.length; i++) { if (i) f.appendChild(icon()); if (parts[i]) f.appendChild(document.createTextNode(parts[i])); }
    p.replaceChild(f, n);
  }
  function scan(root) {
    if (!root) return;
    if (root.nodeType === 3) { fix(root); return; }
    if (root.nodeType !== 1 || SKIP[String(root.nodeName).toUpperCase()]) return;
    var w = document.createTreeWalker(root, 4, null, false), list = [], n;
    while ((n = w.nextNode())) if (n.nodeValue.indexOf(E) >= 0) list.push(n);
    for (var i = 0; i < list.length; i++) fix(list[i]);
  }
  function start() {
    scan(document.body);
    new MutationObserver(function (ms) {
      for (var i = 0; i < ms.length; i++) {
        var m = ms[i];
        if (m.type === 'characterData') fix(m.target);
        else for (var j = 0; j < m.addedNodes.length; j++) scan(m.addedNodes[j]);
      }
    }).observe(document.body, { childList: true, characterData: true, subtree: true });
  }
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
})();
