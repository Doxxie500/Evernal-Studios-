/* EMPIRE DASH — Stage 7 · rig.js
   Pure-JS toolkit shared by horse.js / messenger.js / riding.js (no Babylon dependency, so it can be unit-tested):
   - 3x4 rigid/affine matrices (row-major, 12 floats)
   - skinned mesh builder: lofts, ellipsoids, hair/cloth strips, tubes, boxes
   - CPU linear-blend skinning with two influences per vertex.                                            */
(function (root) {
  'use strict';
  const PI = Math.PI, TAU = PI * 2;
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  const lerp = (a, b, t) => a + (b - a) * t;
  const sgn = v => v < 0 ? -1 : 1;
  const smooth = (a, b, x) => { x = clamp((x - a) / (b - a), 0, 1); return x * x * (3 - 2 * x); };
  const shade = (c, t) => [c[0] * t, c[1] * t, c[2] * t];
  const mixc = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

  /* ---------------- vectors ---------------- */
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
  const mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const len = a => Math.hypot(a[0], a[1], a[2]);
  const norm = a => { const l = len(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };

  /* ---------------- 3x4 matrices: [r00 r01 r02 tx, r10 r11 r12 ty, r20 r21 r22 tz] ---------------- */
  const mIdent = () => [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0];
  function mMul(A, B) {   // A * B
    const o = new Array(12);
    for (let r = 0; r < 3; r++) {
      const a0 = A[r * 4], a1 = A[r * 4 + 1], a2 = A[r * 4 + 2];
      o[r * 4] = a0 * B[0] + a1 * B[4] + a2 * B[8];
      o[r * 4 + 1] = a0 * B[1] + a1 * B[5] + a2 * B[9];
      o[r * 4 + 2] = a0 * B[2] + a1 * B[6] + a2 * B[10];
      o[r * 4 + 3] = a0 * B[3] + a1 * B[7] + a2 * B[11] + A[r * 4 + 3];
    }
    return o;
  }
  const mApply = (M, p) => [M[0] * p[0] + M[1] * p[1] + M[2] * p[2] + M[3], M[4] * p[0] + M[5] * p[1] + M[6] * p[2] + M[7], M[8] * p[0] + M[9] * p[1] + M[10] * p[2] + M[11]];
  const mApplyDir = (M, p) => [M[0] * p[0] + M[1] * p[1] + M[2] * p[2], M[4] * p[0] + M[5] * p[1] + M[6] * p[2], M[8] * p[0] + M[9] * p[1] + M[10] * p[2]];
  function mInvRigid(M) {  // inverse of rotation+translation
    const o = [M[0], M[4], M[8], 0, M[1], M[5], M[9], 0, M[2], M[6], M[10], 0];
    const t = [M[3], M[7], M[11]];
    o[3] = -(o[0] * t[0] + o[1] * t[1] + o[2] * t[2]); o[7] = -(o[4] * t[0] + o[5] * t[1] + o[6] * t[2]); o[11] = -(o[8] * t[0] + o[9] * t[1] + o[10] * t[2]);
    return o;
  }
  /* rotation matrices.  rotX(a): positive a lifts +z toward +y (nose-up) and swings a hanging foot FORWARD (+z).  */
  const rotX = a => { const c = Math.cos(a), s = Math.sin(a); return [1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0]; };
  const rotY = a => { const c = Math.cos(a), s = Math.sin(a); return [c, 0, s, 0, 0, 1, 0, 0, -s, 0, c, 0]; };   // +a turns +z toward +x (heading)
  const rotZ = a => { const c = Math.cos(a), s = Math.sin(a); return [c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, 0]; };
  const trans = (x, y, z) => [1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z];
  /* rotate about a pivot (rest coordinates), then translate:  v' = R (v - pivot) + pivot + t   with R = Rz·Rx·Ry */
  function boneM(pivot, rx, ry, rz, tx, ty, tz) {
    let R = mIdent();
    if (rz) R = mMul(R, rotZ(rz)); if (rx) R = mMul(R, rotX(rx)); if (ry) R = mMul(R, rotY(ry));
    const px = pivot[0], py = pivot[1], pz = pivot[2];
    R[3] = px - (R[0] * px + R[1] * py + R[2] * pz) + (tx || 0);
    R[7] = py - (R[4] * px + R[5] * py + R[6] * pz) + (ty || 0);
    R[11] = pz - (R[8] * px + R[9] * py + R[10] * pz) + (tz || 0);
    return R;
  }
  /* pitch about X placed at J (current) for rest joint Jr:  v' = J + Rx(a)(v - Jr) */
  function pitchAt(Jr, J, a) {
    const R = rotX(a);
    R[3] = J[0] - (R[0] * Jr[0] + R[1] * Jr[1] + R[2] * Jr[2]);
    R[7] = J[1] - (R[4] * Jr[0] + R[5] * Jr[1] + R[6] * Jr[2]);
    R[11] = J[2] - (R[8] * Jr[0] + R[9] * Jr[1] + R[10] * Jr[2]);
    return R;
  }
  /* general frame rotation: maps rest direction dr (and secondary pr) to dc (and pc); result as 3x4 pivoting rest point Pr to current point P */
  function frameM(Pr, P, dr, pr, dc, pc) {
    const f = (d, p) => { const a = norm(d); let b = sub(p, mul(a, dot(p, a))); b = norm(b); const c = cross(a, b); return [a, b, c]; };
    const Fr = f(dr, pr), Fc = f(dc, pc);
    // R = Fc * Fr^T  (columns are axes)
    const R = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) R[i * 4 + j] = Fc[0][i] * Fr[0][j] + Fc[1][i] * Fr[1][j] + Fc[2][i] * Fr[2][j];
    R[3] = P[0] - (R[0] * Pr[0] + R[1] * Pr[1] + R[2] * Pr[2]);
    R[7] = P[1] - (R[4] * Pr[0] + R[5] * Pr[1] + R[6] * Pr[2]);
    R[11] = P[2] - (R[8] * Pr[0] + R[9] * Pr[1] + R[10] * Pr[2]);
    return R;
  }

  /* ---------------- 2-D (y,z) circle intersection helper for sagittal limb IK ---------------- */
  /* points are [y, z].  side = +1 → intersection with larger z (anterior), -1 → smaller z */
  function circ(c1, r1, c2, r2, side) {
    const dy = c2[0] - c1[0], dz = c2[1] - c1[1]; let d = Math.hypot(dy, dz);
    if (d < 1e-6) return [c1[0] - r1, c1[1]];
    const dd = clamp(d, Math.abs(r1 - r2) + 1e-4, r1 + r2 - 1e-4);
    const a = (r1 * r1 - r2 * r2 + dd * dd) / (2 * dd), h = Math.sqrt(Math.max(0, r1 * r1 - a * a));
    const ey = dy / d, ez = dz / d, my = c1[0] + ey * a, mz = c1[1] + ez * a;
    let ny = -ez, nz = ey; if (nz < 0) { ny = -ny; nz = -nz; }      // normal pointing anterior
    return [my + ny * h * side, mz + nz * h * side];
  }

  /* ======================= MESH BUILDER ======================= */
  function MB() { return { p: [], n: [], c: [], a: [], b: [], w: [], fk: [], fa: [], fp: [], i: [] }; }
  const nv = m => m.p.length / 3;
  function vert(m, x, y, z, col, wt, fl) {
    m.p.push(x, y, z); m.n.push(0, 1, 0); m.c.push(col[0], col[1], col[2]);
    wt = wt || [0, 0, 0]; m.a.push(wt[0]); m.b.push(wt[1] == null ? wt[0] : wt[1]); m.w.push(wt[2] || 0);
    fl = fl || [0, 0, 0]; m.fk.push(fl[0]); m.fa.push(fl[1]); m.fp.push(fl[2]);
    return m.p.length / 3 - 1;
  }
  /* recompute smooth normals for vertices in [v0, v1) using triangles that live entirely in the range, orient with hint(vIndex)->[x,y,z] outward dir */
  function normals(m, v0, i0, hint) {
    const v1 = nv(m), acc = new Array((v1 - v0) * 3).fill(0);
    for (let t = i0; t < m.i.length; t += 3) {
      const A = m.i[t], B = m.i[t + 1], C = m.i[t + 2];
      const ax = m.p[A * 3], ay = m.p[A * 3 + 1], az = m.p[A * 3 + 2];
      const ux = m.p[B * 3] - ax, uy = m.p[B * 3 + 1] - ay, uz = m.p[B * 3 + 2] - az, vx = m.p[C * 3] - ax, vy = m.p[C * 3 + 1] - ay, vz = m.p[C * 3 + 2] - az;
      const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      for (const q of [A, B, C]) { acc[(q - v0) * 3] += nx; acc[(q - v0) * 3 + 1] += ny; acc[(q - v0) * 3 + 2] += nz; }
    }
    for (let k = v0; k < v1; k++) {
      let x = acc[(k - v0) * 3], y = acc[(k - v0) * 3 + 1], z = acc[(k - v0) * 3 + 2]; const l = Math.hypot(x, y, z) || 1; x /= l; y /= l; z /= l;
      if (hint) { const h = hint(k); if (h && x * h[0] + y * h[1] + z * h[2] < 0) { x = -x; y = -y; z = -z; } }
      m.n[k * 3] = x; m.n[k * 3 + 1] = y; m.n[k * 3 + 2] = z;
    }
  }

  /* ---------- loft: ellipse rings along a sagittal path ----------
     secs: [{p:[x,y,z], rx, ry, e?, dv?, col?, w?:[a,b,wb], fl?:[kind,amp,phase]}]
     o: { N ring count, color(info), weight(info), flex(info), cap0, cap1 (tip length or true), e default exponent, hint }          */
  function loft(m, secs, o) {
    o = o || {}; const N = o.N || 12, v0 = nv(m), i0 = m.i.length, centers = [];
    const U = [1, 0, 0];
    for (let s = 0; s < secs.length; s++) {
      const S = secs[s], a = secs[Math.max(0, s - 1)].p, b = secs[Math.min(secs.length - 1, s + 1)].p;
      let t = norm(sub(b, a)); const V = norm(cross(t, U)), e = S.e || o.e || 2, ex = 2 / e;
      const c = S.dv ? add(S.p, mul(V, S.dv)) : S.p; centers.push(c);
      for (let k = 0; k < N; k++) {
        const th = TAU * k / N, ct = Math.cos(th), st = Math.sin(th), cs = sgn(ct) * Math.pow(Math.abs(ct), ex), sn = sgn(st) * Math.pow(Math.abs(st), ex);
        const px = c[0] + U[0] * S.rx * cs + V[0] * S.ry * sn, py = c[1] + V[1] * S.ry * sn, pz = c[2] + V[2] * S.ry * sn;
        const info = { s, k, t: s / (secs.length - 1), th, x: px, y: py, z: pz, sec: S, cs, sn, N };
        const col = o.color ? o.color(info) : (S.col || [.5, .5, .5]);
        const wt = o.weight ? o.weight(info) : (S.w || [0, 0, 0]);
        const fl = o.flex ? o.flex(info) : (S.fl || null);
        vert(m, px, py, pz, col, wt, fl);
      }
    }
    for (let s = 0; s < secs.length - 1; s++) for (let k = 0; k < N; k++) {
      const k1 = (k + 1) % N, a0 = v0 + s * N + k, a1 = v0 + s * N + k1, b0 = a0 + N, b1 = a1 + N;
      m.i.push(a0, b0, a1, a1, b0, b1);
    }
    const poles = [];
    const pole = (s, dir, L) => {
      const S = secs[s], c = centers[s];
      const a = secs[Math.max(0, s - 1)].p, b = secs[Math.min(secs.length - 1, s + 1)].p, t = norm(sub(b, a));
      const pp = add(c, mul(t, dir * L)), base = v0 + s * N;
      const col = o.color ? o.color({ s, k: -1, t: s / (secs.length - 1), x: pp[0], y: pp[1], z: pp[2], sec: S, pole: true, sn: dir > 0 ? 0 : 0, cs: 0, th: 0, N }) : (S.col || [.5, .5, .5]);
      const wt = o.weight ? o.weight({ s, k: -1, t: s / (secs.length - 1), x: pp[0], y: pp[1], z: pp[2], sec: S, pole: true }) : (S.w || [0, 0, 0]);
      const pi = vert(m, pp[0], pp[1], pp[2], col, wt, S.fl || null);
      for (let k = 0; k < N; k++) m.i.push(pi, base + k, base + (k + 1) % N);
      poles.push({ idx: pi, c, dir: mul(t, dir) });
    };
    if (o.cap0) pole(0, -1, o.cap0 === true ? Math.min(secs[0].rx, secs[0].ry) * .7 : o.cap0);
    if (o.cap1) pole(secs.length - 1, 1, o.cap1 === true ? Math.min(secs[secs.length - 1].rx, secs[secs.length - 1].ry) * .7 : o.cap1);
    normals(m, v0, i0, k => {
      if (k >= v0 + secs.length * N) { for (const P of poles) if (P.idx === k) return P.dir; return null; }
      const s = Math.floor((k - v0) / N), c = centers[s]; return [m.p[k * 3] - c[0], m.p[k * 3 + 1] - c[1], m.p[k * 3 + 2] - c[2]];
    });
    return { v0, v1: nv(m) };
  }

  /* ---------- ellipsoid (analytic normals).  yaw/pitch/roll orient it. ---------- */
  function ellipsoid(m, c, r, o) {
    o = o || {}; const seg = o.seg || 9, rings = o.rings || 6, col = o.col || [.5, .5, .5], base = nv(m);
    let R = mIdent(); if (o.roll) R = mMul(R, rotZ(o.roll)); if (o.pitch) R = mMul(R, rotX(o.pitch)); if (o.yaw) R = mMul(R, rotY(o.yaw));
    for (let rg = 0; rg <= rings; rg++) {
      const ph = -PI / 2 + PI * rg / rings, cp = Math.cos(ph), sp = Math.sin(ph), tone = o.tone ? lerp(o.tone[0], o.tone[1], rg / rings) : 1;
      for (let s = 0; s < seg; s++) {
        const th = TAU * s / seg, ex = cp * Math.cos(th), ey = sp, ez = cp * Math.sin(th);
        let nx = ex / r[0], ny = ey / r[1], nz = ez / r[2]; const nl = Math.hypot(nx, ny, nz) || 1;
        const lp = mApplyDir(R, [ex * r[0], ey * r[1], ez * r[2]]), ln = mApplyDir(R, [nx / nl, ny / nl, nz / nl]);
        const i = vert(m, c[0] + lp[0], c[1] + lp[1], c[2] + lp[2], shade(col, tone), o.w, o.fl);
        m.n[i * 3] = ln[0]; m.n[i * 3 + 1] = ln[1]; m.n[i * 3 + 2] = ln[2];
      }
    }
    for (let rg = 0; rg < rings; rg++) for (let s = 0; s < seg; s++) {
      const s1 = (s + 1) % seg, a0 = base + rg * seg + s, a1 = base + rg * seg + s1, b0 = a0 + seg, b1 = a1 + seg; m.i.push(a0, b0, a1, a1, b0, b1);
    }
    return { v0: base, v1: nv(m) };
  }

  /* ---------- strip: ribbon along a polyline (hair, fringe, cloth).  pts[], widths[], dir = unit width direction (or fn(i)) ---------- */
  function strip(m, pts, widths, wdir, o) {
    o = o || {}; const v0 = nv(m), i0 = m.i.length, n = pts.length;
    for (let i = 0; i < n; i++) {
      const w = widths[i] * .5, d = typeof wdir === 'function' ? wdir(i) : wdir, t = i / (n - 1);
      const col = o.color ? o.color(i, t) : (o.col || [.2, .2, .2]);
      const wt = o.weight ? o.weight(i, t) : (o.w || [0, 0, 0]);
      const fl = o.flex ? o.flex(i, t) : (o.fl || null);
      vert(m, pts[i][0] - d[0] * w, pts[i][1] - d[1] * w, pts[i][2] - d[2] * w, col, wt, fl);
      vert(m, pts[i][0] + d[0] * w, pts[i][1] + d[1] * w, pts[i][2] + d[2] * w, col, wt, fl);
    }
    for (let i = 0; i < n - 1; i++) { const a = v0 + i * 2; m.i.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    normals(m, v0, i0, o.hint || null);
    return { v0, v1: nv(m) };
  }

  /* ---------- tube along a polyline with per-point radius (straps, reins, ropes) ---------- */
  function tube(m, pts, radii, o) {
    o = o || {}; const seg = o.seg || 5, v0 = nv(m), i0 = m.i.length, n = pts.length;
    let prevU = null;
    const centers = [];
    for (let i = 0; i < n; i++) {
      const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)], t = norm(sub(b, a));
      let u = prevU ? sub(prevU, mul(t, dot(prevU, t))) : cross(t, Math.abs(t[1]) < .9 ? [0, 1, 0] : [1, 0, 0]);
      u = norm(u); prevU = u; const v = cross(t, u), r = radii[i] != null ? radii[i] : radii, tt = i / (n - 1);
      const rr = Array.isArray(radii) ? radii[i] : radii;
      centers.push(pts[i]);
      for (let k = 0; k < seg; k++) {
        const th = TAU * k / seg, c = Math.cos(th), s = Math.sin(th);
        const col = o.color ? o.color(i, tt) : (o.col || [.3, .2, .1]);
        vert(m, pts[i][0] + (u[0] * c + v[0] * s) * rr, pts[i][1] + (u[1] * c + v[1] * s) * rr, pts[i][2] + (u[2] * c + v[2] * s) * rr, col, o.weight ? o.weight(i, tt) : (o.w || [0, 0, 0]), o.flex ? o.flex(i, tt) : (o.fl || null));
      }
    }
    for (let s = 0; s < n - 1; s++) for (let k = 0; k < seg; k++) { const k1 = (k + 1) % seg, a0 = v0 + s * seg + k, a1 = v0 + s * seg + k1, b0 = a0 + seg, b1 = a1 + seg; m.i.push(a0, b0, a1, a1, b0, b1); }
    normals(m, v0, i0, k => { const s = Math.floor((k - v0) / seg), c = centers[s]; return [m.p[k * 3] - c[0], m.p[k * 3 + 1] - c[1], m.p[k * 3 + 2] - c[2]]; });
    return { v0, v1: nv(m), seg, n };
  }

  /* ---------- box with per-face shading ---------- */
  function box(m, c, sz, o) {
    o = o || {}; const col = o.col || [.5, .5, .5], hx = sz[0] / 2, hy = sz[1] / 2, hz = sz[2] / 2;
    let R = mIdent(); if (o.roll) R = mMul(R, rotZ(o.roll)); if (o.pitch) R = mMul(R, rotX(o.pitch)); if (o.yaw) R = mMul(R, rotY(o.yaw));
    const F = [[[1, 0, 0], [0, hy, 0], [0, 0, hz], hx, .92], [[-1, 0, 0], [0, hy, 0], [0, 0, hz], hx, .88], [[0, 1, 0], [hx, 0, 0], [0, 0, hz], hy, 1.05], [[0, -1, 0], [hx, 0, 0], [0, 0, hz], hy, .72], [[0, 0, 1], [hx, 0, 0], [0, hy, 0], hz, .96], [[0, 0, -1], [hx, 0, 0], [0, hy, 0], hz, .84]];
    const base = nv(m);
    for (const [n, u, v, h, t] of F) {
      const cc = [n[0] * h, n[1] * h, n[2] * h], b = nv(m), nn = mApplyDir(R, n);
      for (const [su, sv] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
        const q = mApplyDir(R, [cc[0] + u[0] * su + v[0] * sv, cc[1] + u[1] * su + v[1] * sv, cc[2] + u[2] * su + v[2] * sv]);
        const i = vert(m, c[0] + q[0], c[1] + q[1], c[2] + q[2], shade(col, t), o.w, o.fl); m.n[i * 3] = nn[0]; m.n[i * 3 + 1] = nn[1]; m.n[i * 3 + 2] = nn[2];
      }
      m.i.push(b, b + 1, b + 2, b, b + 2, b + 3);
    }
    return { v0: base, v1: nv(m) };
  }

  /* re-weight / recolour / move an already-built vertex range */
  function setWeights(m, r, wt) { for (let k = r.v0; k < r.v1; k++) { m.a[k] = wt[0]; m.b[k] = wt[1] == null ? wt[0] : wt[1]; m.w[k] = wt[2] || 0; } }
  function mirrorX(m, r, wtMap) {   // duplicate range mirrored across x=0; wtMap(boneIndex) → mirrored bone index
    const base = nv(m), idx0 = m.i.length;
    for (let k = r.v0; k < r.v1; k++) {
      const j = vert(m, -m.p[k * 3], m.p[k * 3 + 1], m.p[k * 3 + 2], [m.c[k * 3], m.c[k * 3 + 1], m.c[k * 3 + 2]], [wtMap ? wtMap(m.a[k]) : m.a[k], wtMap ? wtMap(m.b[k]) : m.b[k], m.w[k]], [m.fk[k], m.fa[k], m.fp[k]]);
      m.n[j * 3] = -m.n[k * 3]; m.n[j * 3 + 1] = m.n[k * 3 + 1]; m.n[j * 3 + 2] = m.n[k * 3 + 2];
    }
    // copy triangles that live fully in the range, with flipped winding (mirror)
    const tris = [];
    for (let t = 0; t < idx0; t += 3) {
      const A = m.i[t], B = m.i[t + 1], C = m.i[t + 2];
      if (A >= r.v0 && A < r.v1 && B >= r.v0 && B < r.v1 && C >= r.v0 && C < r.v1) tris.push(A, C, B);
    }
    for (const q of tris) m.i.push(q - r.v0 + base);
    return { v0: base, v1: nv(m) };
  }
  function xformRange(m, r, M) {
    for (let k = r.v0; k < r.v1; k++) {
      const p = mApply(M, [m.p[k * 3], m.p[k * 3 + 1], m.p[k * 3 + 2]]), n = mApplyDir(M, [m.n[k * 3], m.n[k * 3 + 1], m.n[k * 3 + 2]]);
      m.p[k * 3] = p[0]; m.p[k * 3 + 1] = p[1]; m.p[k * 3 + 2] = p[2]; m.n[k * 3] = n[0]; m.n[k * 3 + 1] = n[1]; m.n[k * 3 + 2] = n[2];
    }
  }
  /* append all of mesh b to mesh a with a bone-index offset */
  function append(a, b, boneOff) {
    const base = nv(a);
    for (let k = 0; k < nv(b); k++) {
      a.p.push(b.p[k * 3], b.p[k * 3 + 1], b.p[k * 3 + 2]); a.n.push(b.n[k * 3], b.n[k * 3 + 1], b.n[k * 3 + 2]); a.c.push(b.c[k * 3], b.c[k * 3 + 1], b.c[k * 3 + 2]);
      a.a.push(b.a[k] + boneOff); a.b.push(b.b[k] + boneOff); a.w.push(b.w[k]); a.fk.push(b.fk[k]); a.fa.push(b.fa[k]); a.fp.push(b.fp[k]);
    }
    for (const q of b.i) a.i.push(q + base);
    return base;
  }

  /* ---------------- skinning: out arrays are Float32Array(3*nv) ---------------- */
  function skin(m, bones, outP, outN, count, start) {
    const n = count || nv(m), P = m.p, N = m.n, A = m.a, Bb = m.b, W = m.w;
    for (let k = start || 0; k < n; k++) {
      const x = P[k * 3], y = P[k * 3 + 1], z = P[k * 3 + 2], nx = N[k * 3], ny = N[k * 3 + 1], nz = N[k * 3 + 2];
      const a = A[k] * 12, b = Bb[k] * 12, w = W[k];
      let px = bones[a] * x + bones[a + 1] * y + bones[a + 2] * z + bones[a + 3], py = bones[a + 4] * x + bones[a + 5] * y + bones[a + 6] * z + bones[a + 7], pz = bones[a + 8] * x + bones[a + 9] * y + bones[a + 10] * z + bones[a + 11];
      let qx = bones[a] * nx + bones[a + 1] * ny + bones[a + 2] * nz, qy = bones[a + 4] * nx + bones[a + 5] * ny + bones[a + 6] * nz, qz = bones[a + 8] * nx + bones[a + 9] * ny + bones[a + 10] * nz;
      if (w > 0.001) {
        const rx = bones[b] * x + bones[b + 1] * y + bones[b + 2] * z + bones[b + 3], ry = bones[b + 4] * x + bones[b + 5] * y + bones[b + 6] * z + bones[b + 7], rz = bones[b + 8] * x + bones[b + 9] * y + bones[b + 10] * z + bones[b + 11];
        const sx = bones[b] * nx + bones[b + 1] * ny + bones[b + 2] * nz, sy = bones[b + 4] * nx + bones[b + 5] * ny + bones[b + 6] * nz, sz = bones[b + 8] * nx + bones[b + 9] * ny + bones[b + 10] * nz;
        px += (rx - px) * w; py += (ry - py) * w; pz += (rz - pz) * w; qx += (sx - qx) * w; qy += (sy - qy) * w; qz += (sz - qz) * w;
      }
      outP[k * 3] = px; outP[k * 3 + 1] = py; outP[k * 3 + 2] = pz;
      const l = Math.hypot(qx, qy, qz) || 1; outN[k * 3] = qx / l; outN[k * 3 + 1] = qy / l; outN[k * 3 + 2] = qz / l;
    }
  }

  const api = { PI, TAU, clamp, lerp, sgn, smooth, shade, mixc, sub, add, mul, dot, cross, len, norm,
    mIdent, mMul, mApply, mApplyDir, mInvRigid, rotX, rotY, rotZ, trans, boneM, pitchAt, frameM, circ,
    MB, nv, vert, normals, loft, ellipsoid, strip, tube, box, setWeights, mirrorX, xformRange, append, skin };
  root.OYORig = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
