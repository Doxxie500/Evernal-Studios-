/* EMPIRE DASH — Stage 8 · audio.js
   Fully procedural WebAudio (no files): modelled hoof samples with real gait footfall patterns, neigh, mission fanfare, success / failure jingles,
   impact thud, timer tick, wind + bird ambience. Starts on the first tap (browser autoplay rules). */
(function () {
  'use strict';
  const A = window.OYOAudio = { ctx: null, master: null, mus: null, vol: .7, on: true, mvol: .5, mon: true, ready: false, nb: null };
  const R = Math.random;
  let birdT = null, legacyAmb = true;

  A.init = function () {
    if (A.ctx) { if (A.ctx.state === 'suspended') A.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    try {
      let c; try { c = A.ctx = new AC({ latencyHint: 'playback' }); } catch (e) { c = A.ctx = new AC(); }   // 'playback' = big, safe buffers: no crackle when the game is busy
      A.master = c.createGain(); A.master.gain.value = A.on ? A.vol : 0; A.master.connect(c.destination);
      const nb = A.nb = c.createBuffer(1, c.sampleRate, c.sampleRate), d = nb.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = R() * 2 - 1;
      A.mus = c.createGain(); A.mus.gain.value = A.mon ? A.mvol * .6 : 0; A.mus.connect(c.destination);
      ambience(); setTimeout(() => { if (!(window.OYO && OYO.music && OYO.music.running)) { try { music(); } catch (e) { console.warn('Music unavailable', e); } } }, 9000);   /* old live loop only as a fallback if the pre-rendered music cannot start */
       try { buildHoofs(); } catch (e) { console.warn('Hoof samples unavailable', e); } A.ready = true;
    } catch (e) { console.warn('Audio unavailable', e); }
  };
  A.setVolume = function (v) { A.vol = Math.max(0, Math.min(1, v)); if (A.master) A.master.gain.value = A.on ? A.vol : 0; };
  A.setOn = function (b) { A.on = !!b; if (A.master) A.master.gain.value = A.on ? A.vol : 0; };
  /* Stage 9: music has its own bus, volume and switch (sound effects + ambience stay on `master`) */
  A.setMusicVolume = function (v) { A.mvol = Math.max(0, Math.min(1, v)); if (A.mus) A.mus.gain.value = A.mon ? A.mvol * .6 : 0; };
  A.setMusicOn = function (b) { A.mon = !!b; if (A.mus) A.mus.gain.value = A.mon ? A.mvol * .6 : 0; };
  A.suspend = function () { if (A.ctx && A.ctx.state === 'running') A.ctx.suspend(); };
  A.resume = function () { if (A.ctx && A.ctx.state === 'suspended') A.ctx.resume(); };

  function env(g, t, a, peak, d) { g.gain.cancelScheduledValues(t); g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(Math.max(.0002, peak), t + a); g.gain.exponentialRampToValueAtTime(.0001, t + a + d); }
  let live = 0; const busy = () => live > 60, track = d => { live++; setTimeout(() => { live = Math.max(0, live - 1); }, (d + .3) * 1000); };
  function noise(t, dur, type, freq, q, peak) {
    if (busy()) return; track(dur);
    const c = A.ctx, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = A.nb; f.type = type; f.frequency.value = freq; f.Q.value = q; env(g, t, .004, peak, dur);
    s.connect(f); f.connect(g); g.connect(A.master); s.start(t, R() * .6); s.stop(t + dur + .05);
  }
  function tone(t, f0, f1, dur, type, peak, atk) {
    if (busy()) return; track(dur);
    const c = A.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t); if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    env(g, t, atk || .006, peak, dur); o.connect(g); g.connect(A.master); o.start(t); o.stop(t + dur + .05);
  }
  const ok = () => A.ctx && A.ready && A.on;

  /* ---- hoofbeats (Stage 11h): modelled, not beeped ----
     A real hoof strike is a sharp "crack" transient, a damped knock of the hoof wall / packed soil (a few resonances that die in
     ~50 ms), a low ground thump, and a bit of scuffed soil. Each strike is synthesised once, at start-up, into a small bank of
     slightly different sample buffers (dirt road + soft grass; front hooves lighter, hind hooves deeper) and then played back with
     the real footfall pattern of each gait — walk: four even beats; trot: two diagonal pairs; gallop: the four-beat bound with a
     suspension gap — plus breath and bridle jingle at speed. */
  const HOOF = { dirt: { front: [], hind: [] }, grass: { front: [], hind: [] } };
  // footfall positions inside one stride (0..1) with a per-hoof role; walk = LH, LF, RH, RF; trot = diagonal pairs; gallop = hind, hind, front, front + suspension
  const EV = {
    walk:   [[0, 'hind', 1, -.3], [.25, 'front', .85, -.3], [.5, 'hind', 1, .3], [.75, 'front', .85, .3]],
    trot:   [[0, 'hind', 1, -.3], [.012, 'front', .8, .3], [.5, 'hind', 1, .3], [.512, 'front', .8, -.3]],
    gallop: [[0, 'hind', .95, -.25], [.13, 'hind', 1, .25], [.27, 'front', .9, -.3], [.40, 'front', 1, .3]]
  };
  A.HOOF = HOOF; A.EV = EV;   // Stage 17: shared with ambient.js (free-roam hoofbeats)
  function makeHoof(kind, role, seed) {
    const c = A.ctx, sr = c.sampleRate, len = Math.floor(sr * .3), b = c.createBuffer(1, len, sr), d = b.getChannelData(0);
    let sd = seed * 9301 + 49297; const rnd = () => { sd = (sd * 9301 + 49297) % 233280; return sd / 233280; };
    const hard = kind === 'dirt' ? 1 : .5, hind = role === 'hind' ? 1 : 0, J = () => .9 + rnd() * .2;
    // damped resonances of hoof wall + packed earth (Hz, gain, decay seconds); hind hooves are heavier → lower and longer
    const sh = hind ? .82 : 1.12;
    const modes = [[150 * sh * J(), 1, .075], [265 * sh * J(), .75, .055], [410 * sh * J(), .5 * hard, .04], [690 * sh * J(), .32 * hard, .028], [1150 * J(), .16 * hard, .016]];
    const ph = modes.map(() => rnd() * 6.28);
    const thumpF = (hind ? 62 : 74) * J(), crackA = (.8 + .5 * hard) * (hind ? .85 : 1), t2 = .008 + rnd() * .006;   // second contact (toe then heel)
    let lp = 0, lp2 = 0, peak = 1e-6;
    for (let i = 0; i < len; i++) {
      const t = i / sr; let v = 0;
      for (let m = 0; m < modes.length; m++) { const M = modes[m]; v += M[1] * Math.exp(-t / M[2]) * Math.sin(6.2832 * M[0] * t + ph[m]) * (t < .001 ? t / .001 : 1); }
      v *= .55;
      v += .9 * Math.exp(-t / .1) * Math.sin(6.2832 * (thumpF + 30 * Math.exp(-t / .03)) * t);                                    // ground thump
      const n = rnd() * 2 - 1; lp += (n - lp) * (.25 + .5 * hard); lp2 += (lp - lp2) * .5;                                       // crack: brief filtered noise
      v += crackA * 1.6 * Math.exp(-t / (.005 + .003 * hard)) * lp2;
      if (t > t2) v += .5 * crackA * Math.exp(-(t - t2) / .006) * lp2;
      v += (kind === 'grass' ? .5 : .18) * Math.exp(-Math.max(0, t - .012) / (kind === 'grass' ? .07 : .045)) * (rnd() * 2 - 1) * (t > .008 ? 1 : 0) * (kind === 'grass' ? .5 : .35); // scuffed soil / grass
      v *= (1 - Math.exp(-t / .0007));                                                                                           // click-free onset
      d[i] = v; if (Math.abs(v) > peak) peak = Math.abs(v);
    }
    const g = .9 / peak, fade = Math.floor(sr * .03);
    for (let i = 0; i < len; i++) { d[i] *= g; if (i > len - fade) d[i] *= (len - i) / fade; }
    return b;
  }
  function buildHoofs() {
    ['dirt', 'grass'].forEach((k, ki) => ['front', 'hind'].forEach((r, ri) => { for (let n = 0; n < 5; n++) HOOF[k][r].push(makeHoof(k, r, 1 + ki * 40 + ri * 17 + n * 5)); }));
  }
  let ph = 0, lastGait = '', hoofN = 0;
  function hoof(role, kind, vol, pan, bright, when) {
    const c = A.ctx, bank = HOOF[kind][role]; if (!bank || !bank.length) return;
    const s = c.createBufferSource(), g = c.createGain(), f = c.createBiquadFilter();
    s.buffer = bank[(hoofN++ + Math.floor(R() * 3)) % bank.length]; s.playbackRate.value = .94 + R() * .12;
    f.type = 'lowpass'; f.frequency.value = bright; f.Q.value = .4;
    g.gain.value = vol * (.82 + R() * .3); s.connect(f); f.connect(g);
    if (c.createStereoPanner) { const p = c.createStereoPanner(); p.pan.value = pan * .18; g.connect(p); p.connect(A.master); } else g.connect(A.master);
    s.start(when);
  }
  function breath(t, vol) {      // exhale through the nostrils, once per stride at a gallop
    noise(t, .16, 'bandpass', 520 + R() * 160, .9, vol); noise(t + .02, .12, 'highpass', 2600, .6, vol * .22);
  }
  function jingle(t, vol) {      // bridle rings and bit: a few tiny inharmonic pings
    const f0 = 2900 + R() * 900; [1, 1.52, 2.31].forEach((m, i) => tone(t + i * .018 + R() * .01, f0 * m, f0 * m * .995, .09 + R() * .05, 'sine', vol * (1 - i * .25)));
  }
  A.steps = function (dt, speed) {
    if (!ok() || A.ctx.state !== 'running' || !HOOF.dirt.hind.length) return;
    const v = Math.abs(speed); if (v < .35) { ph = 0; return; }
    const gait = v < 2.9 ? 'walk' : v < 7 ? 'trot' : 'gallop';
    // strides per second (real horses: walk ≈ 1, trot ≈ 1.5, gallop ≈ 2.2–2.6)
    const f = gait === 'walk' ? .8 + v * .2 : gait === 'trot' ? 1.15 + (v - 2.9) * .13 : 2.0 + (v - 7) * .2;
    const vol = gait === 'walk' ? .5 : gait === 'trot' ? .66 : .82, kind = (window.OYO && OYO.hud && OYO.hud.rough) ? 'grass' : 'dirt';
    const bright = gait === 'gallop' ? 7000 : gait === 'trot' ? 5600 : 4300;           // quicker gaits sound sharper and closer
    if (gait !== lastGait) { lastGait = gait; if (ph > 1) ph = ph % 1; }
    const prev = ph; ph += dt * f; const now = A.ctx.currentTime, ev = EV[gait];
    for (let k = Math.floor(prev); k <= Math.floor(ph); k++) {
      for (let e = 0; e < ev.length; e++) {
        const pos = k + ev[e][0]; if (pos <= prev || pos > ph) continue;
        const when = now + .004;
        hoof(ev[e][1], kind, vol * ev[e][2], ev[e][3], bright, when);
        if (gait === 'gallop' && e === 3) breath(when + .03, .05 + (v - 7) * .01);
        else if (gait === 'trot' && e === 0 && R() < .35) breath(when + .02, .02);
        if (gait !== 'walk' && R() < (gait === 'gallop' ? .45 : .3)) { jingle(when + .01, gait === 'gallop' ? .018 : .012); }
      }
    }
  };

  A.neigh = function (power) {
    if (!ok()) return; power = power || 1;
    const c = A.ctx, t = c.currentTime + .01, o = c.createOscillator(), o2 = c.createOscillator(), lfo = c.createOscillator(), lg = c.createGain(), f = c.createBiquadFilter(), g = c.createGain();
    o.type = 'sawtooth'; o2.type = 'square';
    [[520, 0], [980, .17], [880, .42], [640, .7], [400, 1.0]].forEach(([fr, dt], i) => { o.frequency[i ? 'exponentialRampToValueAtTime' : 'setValueAtTime'](fr, t + dt); o2.frequency[i ? 'exponentialRampToValueAtTime' : 'setValueAtTime'](fr / 2, t + dt); });
    lfo.frequency.value = 27; lg.gain.value = 22; lfo.connect(lg); lg.connect(o.frequency);
    f.type = 'bandpass'; f.frequency.value = 1250; f.Q.value = 2.6;
    const g2 = c.createGain(); g2.gain.value = .35; o2.connect(g2); g2.connect(f); o.connect(f); f.connect(g);
    env(g, t, .07, .3 * power, 1.05); g.connect(A.master);
    [o, o2, lfo].forEach(x => { x.start(t); x.stop(t + 1.2); });
  };
  A.start = function () {   // royal horn + talking-drum
    if (!ok()) return; const t = A.ctx.currentTime + .02;
    [[392, 0], [523, .16], [659, .32], [784, .5]].forEach(([f, d]) => tone(t + d, f, f * 1.01, .38, 'triangle', .17));
    for (let i = 0; i < 3; i++) { tone(t + i * .16, 150, 95, .16, 'sine', .35); }
    setTimeout(() => A.neigh(.8), 650);
  };
  A.festival = function () {   // talking-drum phrase, shaker and a bright bell chord: a town festival greets the rider
    if (!ok()) return; const t = A.ctx.currentTime + .03;
    [0, .18, .36, .48, .72, .9, 1.08, 1.2].forEach((d, i) => { const f = [180, 270, 200, 340][i % 4]; tone(t + d, f, f * .68, .17, 'sine', .3); if (i % 2 === 0) tone(t + d, 95, 62, .2, 'sine', .34); });
    for (let i = 0; i < 12; i++) noise(t + i * .12, .06, 'highpass', 6200, .8, .028);
    [784, 988, 1175].forEach((f, i) => tone(t + 1.35 + i * .05, f, f, .55, 'sine', .11));
  };
  A.leg = function () { if (!ok()) return; const t = A.ctx.currentTime + .02; [659, 880].forEach((f, i) => tone(t + i * .12, f, f, .3, 'sine', .16)); };
  A.success = function () {
    if (!ok()) return; const t = A.ctx.currentTime + .02;
    [523, 659, 784, 1047, 1319].forEach((f, i) => { tone(t + i * .1, f, f, .55, 'sine', .15); tone(t + i * .1, f * 2.01, f * 2.01, .35, 'sine', .04); });
    setTimeout(() => A.neigh(.9), 600);
  };
  A.fail = function () {
    if (!ok()) return; const t = A.ctx.currentTime + .02;
    [330, 262, 196, 131].forEach((f, i) => tone(t + i * .24, f, f * .97, .5, 'sawtooth', .1));
  };
  A.cowrie = function (n) {   // bright little bell; climbs a pentatonic-ish scale while cowries are picked up in a run
    if (!ok()) return; const t = A.ctx.currentTime + .005, f = 1046 * Math.pow(2, [0, 2, 4, 7, 9, 12, 14][Math.max(0, Math.min(6, n || 0))] / 12);
    tone(t, f, f, .22, 'sine', .13); tone(t, f * 2.76, f * 2.76, .12, 'sine', .035); tone(t + .05, f * 1.5, f * 1.5, .16, 'sine', .06); noise(t, .05, 'highpass', 5200, .8, .05);
  };
  A.power = function (type) {   // magnet: shimmering rising chime · speed bolt: quick rising sweep with a bright zap
    if (!ok()) return; const t = A.ctx.currentTime + .01;
    if (type === 'mag') { [523, 659, 784, 1047, 1319].forEach((f, i) => tone(t + i * .07, f, f * 1.01, .32, 'sine', .13)); noise(t, .35, 'bandpass', 3200, 1.2, .05); }
    else { tone(t, 280, 1100, .26, 'sawtooth', .07); tone(t + .08, 560, 1680, .22, 'square', .05); [784, 1175, 1568].forEach((f, i) => tone(t + .1 + i * .06, f, f, .2, 'sine', .12)); noise(t, .12, 'highpass', 4800, .9, .06); }
  };
  A.bell = function () {   // brass cart bell, struck twice ("ting-ting"): bright strike + inharmonic hand-bell partials that ring out
    if (!ok()) return; const t = A.ctx.currentTime + .005;
    [[0, 1046, 1], [.16, 1109, .8]].forEach(([dt, f, g]) => {
      tone(t + dt, f, f, .85, 'sine', .17 * g, .002); tone(t + dt, f * 2.32, f * 2.32, .5, 'sine', .08 * g, .002);
      tone(t + dt, f * 3.9, f * 3.9, .3, 'sine', .045 * g, .002); tone(t + dt, f * .5, f * .5, .6, 'sine', .05 * g, .004);
      noise(t + dt, .04, 'highpass', 4200, .8, .07 * g);
    });
  };
  A.tick = function () { if (ok()) tone(A.ctx.currentTime + .005, 1050, 1050, .06, 'square', .06); };
  A.click = function () { if (ok()) tone(A.ctx.currentTime + .005, 620, 780, .07, 'triangle', .1); };

  /* ---- music (Stage 9): a slow, looping procedural theme — warm drone, pentatonic kalimba-style plucks and a soft talking-drum pulse.
     Scheduled a few seconds ahead from ctx.currentTime, so a suspended context (pause / app in background) simply stops it. ---- */
  let musT = null, nextM = 0, step = 0;
  const PENT = [0, 2, 4, 7, 9], ROOT = 146.83;                                  // D pentatonic
  const MEL = [4, 2, 3, 1, 2, 0, 1, -1, 4, 3, 2, 3, 1, 0, 2, -1];             // scale degrees (-1 = rest), one per beat
  function mtone(t, f, dur, type, peak, atk) {
    const c = A.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.value = f; env(g, t, atk || .01, peak, dur); o.connect(g); g.connect(A.legacyMus || A.mus); o.start(t); o.stop(t + dur + .06);
  }
  function music() {
    A.legacyMus = A.ctx.createGain(); A.legacyMus.connect(A.mus);
    nextM = A.ctx.currentTime + .4; step = 0; const BEAT = .62;
    const tick = () => {
      if (!A.ctx) return;
      while (nextM < A.ctx.currentTime + 1.6) {
        const k = step % MEL.length, t = nextM;
        if (k === 0) { mtone(t, ROOT / 2, BEAT * 8, 'sine', .22, .6); mtone(t, ROOT * .75, BEAT * 8, 'sine', .09, 1.0); }          // drone + fifth
        if (k === 8) { mtone(t, ROOT * .667, BEAT * 8, 'sine', .2, .6); mtone(t, ROOT, BEAT * 8, 'sine', .07, 1.0); }
        const d = MEL[k]; if (d >= 0) { const f = ROOT * 2 * Math.pow(2, (PENT[d % 5] + 12 * Math.floor(d / 5)) / 12); mtone(t, f, 1.1, 'triangle', .13, .006); mtone(t, f * 2.01, .4, 'sine', .03, .004); }
        if (k % 4 === 0) { mtone(t, 110, .22, 'sine', .3, .004); }                                                                 // drum
        else if (k % 4 === 2) { mtone(t + BEAT * .02, 170, .12, 'sine', .14, .004); }
        step++; nextM += BEAT;
      }
    };
    tick(); musT = setInterval(tick, 400);
  }

  /* Stage 30: the Yoruba music engine (yoruba-music.js) replaces the old kalimba loop. It calls this once it is running, so two music tracks can never overlap. */
  A.stopLegacyMusic = function () {
    if (!A.ctx || !A.legacyMus) return; const t = A.ctx.currentTime;
    try { A.legacyMus.gain.cancelScheduledValues(t); A.legacyMus.gain.setTargetAtTime(0, t, .35); } catch (e) { /* ignore */ }
    if (musT) { clearInterval(musT); musT = null; }
  };
  /* collisions (kind: 1 stone / earth · 2 wood · 3 pothole · 4 animal · 5 wrecked cart). Every impact also tells the music director. */
  A.thunder = function () {                                              // Ṣàngó's strike, timed to the lightning: leader crackle, then the CRACK of the return stroke, a re-strike snap, and a long rolling boom
    if (!ok()) return; const t = A.ctx.currentTime + .005, c = t + .14;
    for (let i = 0; i < 10; i++) noise(t + i * .011 + R() * .008, .02, 'highpass', 4500 + R() * 2800, .8, .05 + i * .012);     // stepped-leader sizzle
    noise(c, .05, 'highpass', 4200, .6, .7); noise(c, .14, 'bandpass', 2300, .9, .5); noise(c + .012, .09, 'bandpass', 900, 1.1, .4);   // the crack
    tone(c, 150, 28, 1.4, 'sine', .62); noise(c + .03, 1.7, 'lowpass', 430, .8, .56);                                               // boom + body of the thunder
    noise(c + .115, .05, 'highpass', 3600, .6, .32); noise(c + .24, .04, 'highpass', 3200, .6, .2);                                  // re-strike snaps
    [.28, .55, .9, 1.35, 1.9].forEach((d, i) => noise(c + d, .55 + d * .3, 'lowpass', 150 + R() * 190, .8, .3 * (1 - i * .15)));     // rolling echoes off the land
  };
  A.thud = function (kind) {
    if (!ok()) return; const t = A.ctx.currentTime + .005; kind = kind || 1;
    try { A.impactAt = A.ctx.currentTime; A.onImpact && A.onImpact(kind); } catch (e) { /* ignore */ }
    tone(t, 110, 38, .22, 'sine', .5); noise(t, .16, 'lowpass', 420, .7, .5);                                 // body of the impact (as before)
    if (kind === 1) { noise(t, .07, 'bandpass', 1800, 1.2, .22); tone(t + .01, 620, 300, .08, 'triangle', .08); }                      // stone: sharp crack + chip
    else if (kind === 2) { noise(t, .05, 'bandpass', 900, 2.5, .4); noise(t + .045, .06, 'bandpass', 1500, 3, .3); tone(t, 210, 130, .1, 'square', .06); for (let i = 0; i < 3; i++) noise(t + .09 + i * .05 + R() * .03, .03, 'highpass', 3200, .8, .12); }   // wood: crack, snap, splinters
    else if (kind === 3) { tone(t, 150, 60, .3, 'sine', .35); noise(t + .03, .2, 'bandpass', 260, 1.4, .3); [0, .09, .17].forEach(d => noise(t + .1 + d, .04, 'bandpass', 700 + R() * 400, 3, .12)); }   // pothole: jolt + cart rattle
    else if (kind === 4) { const f = 330 + R() * 90; tone(t + .02, f, f * .78, .32, 'sawtooth', .07); tone(t + .02, f * 2, f * 1.5, .22, 'square', .025); }                      // startled animal bleat
    else if (kind === 5) { noise(t, .12, 'bandpass', 1100, 1.5, .4); [0, .07, .15, .26].forEach(d => noise(t + d, .05, 'bandpass', 500 + R() * 600, 2.5, .22)); tone(t + .03, 95, 45, .35, 'sine', .4); }   // wrecked cart: heavy crunch
  };

  /* ---- Stage 31: realistic collision sounds (A.impact) ----
     The old thud was one sine drop + one lowpass noise burst with a thin coat on top, so every hit sounded the same. Real impacts are
     built from layers: a sharp contact transient, the struck material ringing at its own (damped, slightly inharmonic) resonances,
     a low body thump, and debris / rattle afterwards. Every call is randomly detuned so two hits in a row never sound identical.
     kind: 1 stone / earth · 2 wood (log, branch) · 4 animal · 5 wrecked cart · 6 cart-on-cart (wood + iron rim + rattle) · 7 horse rider */
  function ring(t, f, dec, peak) {                                      // one damped resonance (a struck object "tonk")
    if (busy()) return; track(dec);
    const c = A.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = 'sine'; o.frequency.value = f; env(g, t, .002, peak, dec); o.connect(g); g.connect(A.master); o.start(t); o.stop(t + dec + .05);
  }
  function sweep(t, dur, type, f0, f1, q, peak) {                       // noise whose filter slides: a crack that darkens, a whump that sinks
    if (busy()) return; track(dur);
    const c = A.ctx, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = A.nb; f.type = type; f.Q.value = q; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t + dur);
    env(g, t, .003, peak, dur); s.connect(f); f.connect(g); g.connect(A.master); s.start(t, R() * .5); s.stop(t + dur + .05);
  }
  function voice(t, f0, f1, dur, peak, formants, trem) {                // throat / mouth sound: saw source through vowel-like formants
    if (busy()) return; track(dur);
    const c = A.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = 'sawtooth'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur); env(g, t, .014, peak, dur);
    formants.forEach(fm => { const b = c.createBiquadFilter(), m = c.createGain(); b.type = 'bandpass'; b.frequency.value = fm[0]; b.Q.value = fm[1]; m.gain.value = fm[2]; o.connect(b); b.connect(m); m.connect(g); });
    if (trem) { const l = c.createOscillator(), lg = c.createGain(); l.frequency.value = trem; lg.gain.value = peak * .45; l.connect(lg); lg.connect(g.gain); l.start(t); l.stop(t + dur + .05); }
    g.connect(A.master); o.start(t); o.stop(t + dur + .05);
  }
  A.impact = function (kind) {
    if (!ok()) return; const t = A.ctx.currentTime + .005; kind = kind || 1;
    try { A.impactAt = A.ctx.currentTime; A.onImpact && A.onImpact(kind); } catch (e) { /* ignore */ }
    const v = .92 + R() * .16;                                          // per-hit variation
    // shared low body: a short thump that sinks, plus the air / ground "whump" around it (kept tighter and drier than the old thud)
    tone(t, 92 * v, 34, .2, 'sine', kind === 4 || kind === 7 ? .36 : .5, .003);
    sweep(t, .2, 'lowpass', 900, 110, .8, kind === 4 || kind === 7 ? .3 : .42);
    if (kind === 1) {                                                   // STONE / EARTH: hard "tck" contact, ringing rock, pebbles skittering away
      sweep(t, .03, 'highpass', 2600, 6000, .7, .38);
      ring(t, 760 * v, .11, .13); ring(t + .002, 1190 * v, .07, .1); ring(t + .002, 1830 * v, .05, .07);
      noise(t + .01, .07, 'bandpass', 1900 * v, 1.4, .2);
      for (let i = 0; i < 4; i++) noise(t + .07 + i * (.045 + R() * .03), .02, 'bandpass', 2400 + R() * 2200, 3.5, .07 - i * .012);
    } else if (kind === 2) {                                            // WOOD: sharp crack, hollow knock, splinters, a groan of strained fibre
      sweep(t, .045, 'bandpass', 2300, 900, 3.2, .46); sweep(t + .04, .05, 'bandpass', 3000, 1400, 4, .3);
      ring(t, 185 * v, .18, .2); ring(t, 338 * v, .13, .14); ring(t, 515 * v, .09, .1);
      for (let i = 0; i < 4; i++) noise(t + .08 + i * (.04 + R() * .035), .03, 'highpass', 3200 + R() * 1500, .8, .1);
      tone(t + .05, 170 * v, 105, .2, 'sawtooth', .022, .02);
    } else if (kind === 4) {                                            // ANIMAL: soft fleshy thump, startled "mbaa" with the fast flutter of a bleat
      sweep(t, .09, 'lowpass', 600, 180, .7, .3);
      const f = 400 * v + R() * 60;
      voice(t + .03, f, f * .72, .34, .1, [[720, 6, 1], [1250, 8, .7], [2700, 10, .25]], 26);
      noise(t + .02, .09, 'bandpass', 600, 1.2, .08);                    // scuffle in the dust
    } else if (kind === 5) {                                            // WRECKED CART: heavy timber crunch, loose planks, a dull iron clank
      sweep(t, .06, 'bandpass', 1800, 600, 2, .46); sweep(t + .05, .06, 'bandpass', 2400, 900, 2.5, .34);
      ring(t, 150 * v, .26, .22); ring(t, 270 * v, .18, .15);
      ring(t + .02, 430 * v, .22, .1); ring(t + .02, 1120 * v, .16, .06);   // iron band
      [.08, .15, .24, .33].forEach((d, i) => sweep(t + d + R() * .02, .07, 'bandpass', 1400 - i * 150 + R() * 400, 500, 2.8, .2 - i * .03));
    } else if (kind === 6) {                                            // CART ON CART: wood-on-wood bang, iron wheel rim clank, goods rattling, axle groan
      sweep(t, .05, 'bandpass', 2000, 800, 3, .42);
      ring(t, 210 * v, .2, .2); ring(t, 395 * v, .14, .13);
      ring(t + .01, 640 * v, .26, .09); ring(t + .01, 1630 * v, .2, .06); ring(t + .01, 2480 * v, .12, .035);   // iron rim: bright, inharmonic, long ring
      [.1, .17, .22, .3, .37].forEach(d => sweep(t + d + R() * .02, .05, 'bandpass', 900 + R() * 1400, 400, 3, .1));
      tone(t + .06, 140 * v, 95, .26, 'sawtooth', .02, .03);
    } else if (kind === 7) {                                            // HORSE RIDER: dull body / leather thump, rider's breath knocked out, tack jingling, hooves scuffing
      sweep(t, .1, 'lowpass', 700, 150, .7, .34);
      voice(t + .02, 190 * v, 120, .16, .1, [[520, 5, 1], [1050, 7, .6]], 0);   // "hhuh"
      noise(t + .02, .12, 'bandpass', 650, 1, .09);
      [3150, 4020, 5100].forEach((f, i) => ring(t + .04 + i * .045 + R() * .02, f * v, .09, .03));
      for (let i = 0; i < 3; i++) noise(t + .1 + i * .06, .045, 'lowpass', 700, .8, .08);
    } else {                                                            // anything else: fall back to the generic thud
      A.thud(kind);
    }
  };

  function ambience() {
    const c = A.ctx, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain(), lfo = c.createOscillator(), lg = c.createGain();
    s.buffer = A.nb; s.loop = true; f.type = 'bandpass'; f.frequency.value = 520; f.Q.value = .5; g.gain.value = .07;
    lfo.frequency.value = .13; lg.gain.value = .035; lfo.connect(lg); lg.connect(g.gain);
    s.connect(f); f.connect(g); g.connect(A.master); s.start(); lfo.start();
    const bird = () => {
      if (legacyAmb && A.ctx && A.ctx.state === 'running' && A.on) {
        const t = A.ctx.currentTime + .01, base = 2200 + R() * 1400, n = 2 + Math.floor(R() * 3);
        for (let i = 0; i < n; i++) tone(t + i * .11, base, base * (1.15 + R() * .3), .08, 'sine', .035, .01);
      }
      birdT = setTimeout(bird, 1800 + R() * 4500);
    };
    birdT = setTimeout(bird, 1500);
    A.muteLegacy = function () { legacyAmb = false; try { g.gain.setTargetAtTime(0, c.currentTime, .3); lfo.stop(c.currentTime + 2); s.stop(c.currentTime + 2); } catch (e) { /* ambient.js now provides wind + birds */ } };   // Stage 17
  }
})();
