/* EMPIRE DASH — stamina.js  (Stage 12g: horse stamina in Free Roam riding)
   Free Roam now has the same stamina the missions use, built on the existing pieces instead of new ones:
   - speed comes from the horse's own state (riding.js state.speed); the throttle limit goes through riding.js's existing `inp.cap`
   - same numbers as missions.js: gallop (>7 m/s) drains STAM_DRAIN /s, trot (4.3–7) recovers STAM_TROT /s, walk / stand recovers STAM_WALK /s
   - the stamina bar is the existing minimap-side bar (.mm-stam) fed by the existing hud.stam / hud.exh values; index.html just shows it in Free Roam riding too
   - below LOW the top speed eases down; when it hits 0 the horse is "exhausted" (capped at EXH_CAP of top speed) until it recovers past REVIVE
   - stamina is clamped to 0..100 every frame, so it can never go negative
   Subtle exhaustion feedback: red bar (existing), a soft pulsing dark-red screen-edge vignette, a short message and one tired neigh.
   Missions keep their own stamina untouched (this does nothing while a mission is playing). Nothing is saved.
   Self-contained. To remove: delete this file, its <script> line in boot.js + sw.js, the "stamina.js" block in style.css, and restore the
   .mm-stam x-show in index.html to  screen === 'play' || screen === 'pause'. */
(function () {
  'use strict';
  return;   // horse stamina has been removed from the game: this module is switched off (the horse never tires)
  const OYO = window.OYO, MS = OYO && OYO.mission; if (!MS || typeof MS.pre !== 'function') return;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const DRAIN = 1.5, TROT = 10, WALK = 20, REVIVE = 20, TIRING = 22, LOW = 35, EXH_CAP = .6;   // same values as missions.js
  const snd = (f, a) => { try { window.OYOAudio && OYOAudio[f] && OYOAudio[f](a); } catch (e) { /* audio optional */ } };
  let stam = 100, exhausted = false, tired = false, el = null, msgT = 0, was = false;

  function ui() {
    if (el) return; const hud = document.getElementById('hud'); if (!hud) return;
    el = document.createElement('div'); el.innerHTML = '<div class="st-vig"></div><div class="st-msg hud-card" style="display:none"></div>'; hud.appendChild(el);
    el.vig = el.querySelector('.st-vig'); el.msg = el.querySelector('.st-msg');
  }
  function say(t) { if (!el) return; el.msg.textContent = t; el.msg.style.display = ''; msgT = 3.2; }

  const orig = MS.pre;
  MS.pre = function (dt, inp, st) {
    const r = orig.apply(this, arguments), h = OYO.hud;
    if (MS.playing || !h || h.screen !== 'free' || h.mode !== 'ride') {                  // not free-roam riding: stay out of the way
      if (was) { was = false; if (el) { el.vig.classList.remove('on'); el.msg.style.display = 'none'; } }
      return r;
    }
    ui(); if (!el) return r; was = true;
    const v = Math.abs(st.speed);
    if (v > 7) stam -= DRAIN * dt; else if (v > 4.3) stam += TROT * dt; else stam += WALK * dt;
    stam = clamp(stam, 0, 100);                                                          // never below zero
    if (exhausted && stam >= REVIVE) exhausted = false;
    if (!exhausted && stam <= 0) { exhausted = true; snd('neigh', .6); say('Your horse is exhausted — slow down to recover!'); }
    if (stam > TIRING + 12) tired = false; else if (!tired && !exhausted && stam <= TIRING && v > 7) { tired = true; say('Your horse is tiring — ease off to let it recover.'); }
    // top-speed limit through riding.js's existing throttle cap: full above LOW, easing down to EXH_CAP at 0
    const cap = exhausted ? EXH_CAP : stam < LOW ? EXH_CAP + (1 - EXH_CAP) * (stam / LOW) : 1;
    if (cap < 1) inp.cap = inp.cap == null ? cap : Math.min(inp.cap, cap);
    h.stam = Math.round(stam); h.exh = exhausted; h.rough = false;                       // feeds the existing stamina bar
    el.vig.classList.toggle('on', exhausted);
    if (msgT > 0) { msgT -= dt; if (msgT <= 0) el.msg.style.display = 'none'; }
    return r;
  };
})();
