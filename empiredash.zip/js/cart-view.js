/* EMPIRE DASH — cart-view.js
   Live 3D preview inside the Carts menu. Click any cart card to look at it; carts that are still locked are shown the same way
   but greyed out (CSS grayscale on the canvas) with a padlock over them. Uses its own small Babylon engine, created when the
   menu opens and disposed when it closes, so it costs nothing while playing. */
(function () {
  'use strict';
  const B = window.BABYLON, OYO = window.OYO;
  if (!B || !window.OYOCart) return;
  let eng = null, scene = null, cam = null, cart = null, canvas = null, cur = null, hp = null;

  /* A real horse harnessed to a preview cart (its own mesh + skeleton, so the game's riding horse is never touched). The cart's own hitch()
     couples shafts, collar and tugs to this horse; opts: still (standing), speed (m/s, forced wheel speed), circle (walks a loop). */
  function attachHorse(sc, World, cart, o) {
    o = o || {};
    try {
      const R = window.OYORig, H = window.OYOHorse, A = window.OYORideAnim, SS = B.Effect.ShadersStore;
      if (!R || !H || !A || !cart || !cart.hitch || !SS.oyoRiderVertexShader) return null;
      const D = OYOCart.dims, Z0 = D.HORSE_Z + (D.KPZ - D.RZ) / 2;
      const hg = H.build({ regalia: o.regalia != null ? o.regalia : (window.OYOHorseRegalia ? window.OYOHorseRegalia() : '') }), mesh = R.MB(); R.append(mesh, hg.mesh, 0);
      const nv = R.nv(mesh), anim = new A.Animator(); anim.bitRest = { L: hg.anchors.bitL, R: hg.anchors.bitR }; anim.update(1 / 60, 0, 0);
      const P = new Float32Array(nv * 3), N = new Float32Array(nv * 3), col = new Float32Array(nv * 4), uv = new Float32Array(nv * 2);
      for (let k = 0; k < nv; k++) {
        col[k * 4] = mesh.c[k * 3]; col[k * 4 + 1] = mesh.c[k * 3 + 1]; col[k * 4 + 2] = mesh.c[k * 3 + 2]; col[k * 4 + 3] = 1;
        uv[k * 2] = mesh.p[k * 3] * 1.7 + mesh.p[k * 3 + 2] * .9; uv[k * 2 + 1] = mesh.p[k * 3 + 1] * 2.6;
      }
      R.skin(mesh, anim.bones, P, N, nv);
      const rm = new B.Mesh('pvHorse', sc), vd = new B.VertexData();
      vd.positions = P; vd.normals = N; vd.colors = col; vd.uvs = uv; vd.indices = mesh.i.length > 65000 ? new Uint32Array(mesh.i) : new Uint16Array(mesh.i);
      vd.applyToMesh(rm, true); rm.isPickable = false; rm.alwaysSelectAsActiveMesh = true; rm.doNotSyncBoundingInfo = true;
      const tex = new B.DynamicTexture('pvBrush', { width: 64, height: 64 }, sc, true), g = tex.getContext();
      g.fillStyle = '#f4ecde'; g.fillRect(0, 0, 64, 64); g.lineCap = 'round';
      for (let i = 0; i < 90; i++) { const x = (i * 37.7) % 64, y = (i * 53.3) % 64, a = i * 1.9, l = 3 + (i % 7); g.strokeStyle = i % 2 ? 'rgba(255,252,240,.32)' : 'rgba(110,86,60,.16)'; g.lineWidth = 1.5 + (i % 3); g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke(); }
      tex.wrapU = tex.wrapV = B.Texture.WRAP_ADDRESSMODE; tex.update();
      const fogOn = sc.fogMode && sc.fogMode !== B.Scene.FOGMODE_NONE;
      const mat = new B.ShaderMaterial('pvHorseMat', sc, { vertex: 'oyoRider', fragment: 'oyoRider' }, { attributes: ['position', 'normal', 'color', 'uv'], uniforms: ['world', 'viewProjection', 'camPos', 'toSun', 'sunCol', 'skyCol', 'gndCol', 'fogCol', 'hazeCol', 'fogD'], samplers: ['tex'] });
      mat.setTexture('tex', tex); mat.setVector3('toSun', World.sunDir); mat.setVector3('sunCol', new B.Vector3(.85, .73, .53)); mat.setVector3('skyCol', new B.Vector3(.58, .54, .47));
      mat.setVector3('gndCol', new B.Vector3(.42, .27, .2)); mat.setVector3('fogCol', new B.Vector3(sc.fogColor.r, sc.fogColor.g, sc.fogColor.b)); mat.setVector3('hazeCol', new B.Vector3(.93, .84, .64));
      mat.setFloat('fogD', fogOn ? sc.fogDensity : 0); mat.setVector3('camPos', new B.Vector3(0, 0, 0)); mat.backFaceCulling = false; rm.material = mat;
      const hs = { x: 0, y: 0, z: Z0, yaw: 0 }, wb = new Float32Array(A.NB * 12), rd = { built: true, active: true, state: hs, wb };
      cart.hitch(rd);
      if (o.speed != null) { const orig = cart.update; cart.update = function (dt, v, st) { return orig.call(cart, dt, o.speed, st); }; }
      const RC = 15, V = o.still ? 0 : (o.speed != null ? o.speed : 2.6); let t = 0, ang = 0;
      const obs = sc.onBeforeRenderObservable.add(() => {
        const dt = Math.min(.05, Math.max(.001, sc.getEngine().getDeltaTime() / 1000)); t += dt;
        if (o.circle) { ang += V / RC * dt; hs.x = RC * (1 - Math.cos(ang)); hs.z = Z0 + RC * Math.sin(ang); hs.yaw = ang; } else { hs.x = 0; hs.z = Z0; hs.yaw = o.speed != null ? Math.sin(t * .7) * .07 : 0; }
        anim.update(dt, V, 0);
        const Mw = R.rotY(hs.yaw); Mw[3] = hs.x; Mw[7] = hs.y; Mw[11] = hs.z;
        const B0 = anim.bones;
        for (let b = 0; b < A.NB; b++) { const q = b * 12; for (let r = 0; r < 3; r++) { const a0 = Mw[r * 4], a1 = Mw[r * 4 + 1], a2 = Mw[r * 4 + 2];
          wb[q + r * 4] = a0 * B0[q] + a1 * B0[q + 4] + a2 * B0[q + 8]; wb[q + r * 4 + 1] = a0 * B0[q + 1] + a1 * B0[q + 5] + a2 * B0[q + 9]; wb[q + r * 4 + 2] = a0 * B0[q + 2] + a1 * B0[q + 6] + a2 * B0[q + 10]; wb[q + r * 4 + 3] = a0 * B0[q + 3] + a1 * B0[q + 7] + a2 * B0[q + 11] + Mw[r * 4 + 3]; } }
        R.skin(mesh, wb, P, N, nv);
        try { anim.applyFlex(mesh, P, 0, nv, [Mw[0], Mw[4], Mw[8]], [Mw[1], Mw[5], Mw[9]], [Mw[2], Mw[6], Mw[10]]); } catch (e) { /* flex is cosmetic */ }
        rm.updateVerticesData(B.VertexBuffer.PositionKind, P, false, false); rm.updateVerticesData(B.VertexBuffer.NormalKind, N, false, false);
        if (sc.activeCamera) mat.setVector3('camPos', sc.activeCamera.position);
      }, -1, true);
      return {
        horse: hs, Z0,
        mid() { const c = cart.state; return [(hs.x + c.x) / 2, (hs.z + c.z) / 2]; },
        dispose() { try { sc.onBeforeRenderObservable.remove(obs); } catch (e) { /* ignore */ } try { rm.dispose(); mat.dispose(); tex.dispose(); } catch (e) { /* ignore */ } }
      };
    } catch (e) { console.warn('Preview horse unavailable', e); return null; }
  }

  function dispose() {
    try { eng && eng.stopRenderLoop(); } catch (e) { /* ignore */ }
    try { scene && scene.dispose(); } catch (e) { /* ignore */ }
    try { eng && eng.dispose(); } catch (e) { /* ignore */ }
    eng = scene = cam = cart = canvas = cur = hp = null;
  }
  function make(c) {
    eng = new B.Engine(c, true, { antialias: true }, true);
    eng.setHardwareScalingLevel(1 / Math.min(window.devicePixelRatio || 1, 2));
    scene = new B.Scene(eng);
    const bg = new B.Color3(.80, .72, .62);
    scene.clearColor = new B.Color4(bg.r, bg.g, bg.b, 1); scene.fogMode = B.Scene.FOGMODE_EXP2; scene.fogColor = bg; scene.fogDensity = .0015;
    cam = new B.ArcRotateCamera('cvCam', -2.5, 1.2, 10.5, new B.Vector3(0, 1.35, 0), scene); cam.minZ = .1; cam.fov = .7;
    const g = B.MeshBuilder.CreateGround('cvG', { width: 120, height: 120 }, scene), gm = new B.StandardMaterial('cvGm', scene);
    gm.disableLighting = true; gm.emissiveColor = new B.Color3(.55, .44, .30); gm.diffuseColor = B.Color3.Black(); gm.specularColor = B.Color3.Black(); g.material = gm;
    scene.onBeforeRenderObservable.add(() => {
      const dt = Math.min(.05, eng.getDeltaTime() / 1000);
      if (cart && !hp) cart.update(dt, 1.2, 0);
      if (hp) { const m = hp.mid(); cam.target.set(m[0], 1.3, m[1]); cam.radius = 16.5; }
      cam.alpha += dt * .4;
    });
    eng.runRenderLoop(() => scene.render());
  }
  const key = (id, x) => id + '|' + (x ? x.paint + '|' + x.name + '|' + (x.regalia == null ? '' : x.regalia) : '');
  function show(id, x) {
    if (hp) { hp.dispose(); hp = null; }
    if (cart) { try { cart.dispose(); } catch (e) { /* ignore */ } cart = null; }
    const World = { sunDir: new B.Vector3(.55, .55, -.5).normalize(), height: () => 0 };
    try { cart = OYOCart.build(scene, World, Object.assign({ x: 0, z: 0, yaw: 0, variant: id }, x ? { paint: x.paint, board: x.name } : {})); cur = key(id, x); hp = attachHorse(scene, World, cart, { circle: true, regalia: x ? x.regalia : null }); if (!hp) cam.radius = 10.5; } catch (e) { console.warn('Cart preview failed', e); }
  }
  window.OYOCartView = {
    open(c, id, x) {
      if (!c) return;
      try {
        if (canvas !== c) { dispose(); canvas = c; make(c); }
        eng.resize(); setTimeout(() => { try { eng && eng.resize(); } catch (e) { /* ignore */ } }, 150);
        if (key(id, x) !== cur) show(id || 'starter', x);
      } catch (e) { console.warn('Cart preview unavailable', e); }
    },
    close() { if (eng) dispose(); }
  };

  /* Stage 31: still pictures of the REAL carts for the start menu. Each cart is built with the game's own OYOCart.build, drawn once on a small
     transparent canvas (its own short-lived Babylon engine, the same way the Carts menu does it) and turned into a PNG. Nothing is kept running. */
  const SN = { w: 360, h: 200, busy: false, tries: 0 };
  window.OYOUI && Object.assign(window.OYOUI.state, { cartImgStarter: '', cartImgRoyal: '', cartImgIndigo: '', cartImgEbony: '', cartImgGold: '' });
  function snapshotOne(id, paint) {
    return new Promise(resolve => {
      let e = null, sc = null, ct = null, done = false, ph = null;
      const finish = url => { if (done) return; done = true; try { ph && ph.dispose(); } catch (x) { /* ignore */ } try { ct && ct.dispose(); } catch (x) { /* ignore */ } try { sc && sc.dispose(); } catch (x) { /* ignore */ } try { e && e.dispose(); } catch (x) { /* ignore */ } resolve(url || ''); };
      try {
        const cv = document.createElement('canvas'); cv.width = SN.w; cv.height = SN.h;
        e = new B.Engine(cv, true, { antialias: true, preserveDrawingBuffer: true, alpha: true }, false); e.setHardwareScalingLevel(1);
        sc = new B.Scene(e); sc.clearColor = new B.Color4(0, 0, 0, 0);
        const cm = new B.ArcRotateCamera('snapCam', 2.3, 1.27, 9.4, new B.Vector3(0, 1.3, 0), sc); cm.minZ = .1; cm.fov = .7;
        const World = { sunDir: new B.Vector3(.55, .55, -.5).normalize(), height: () => 0 };
        ct = OYOCart.build(sc, World, { x: 0, z: 0, yaw: 0, variant: id, paint: paint || '', board: '' }); try { ct.update(.016, 0, 0); } catch (x) { /* pose is optional */ }
        ph = attachHorse(sc, World, ct, { still: true }); if (ph) { cm.radius = 15.8; cm.target = new B.Vector3(0, 1.3, 1.7); }
        const timer = setTimeout(() => finish(''), 5000);
        sc.executeWhenReady(() => { try { sc.render(); sc.render(); clearTimeout(timer); finish(cv.toDataURL('image/png')); } catch (x) { clearTimeout(timer); finish(''); } });
      } catch (x) { console.warn('Cart snapshot failed', id, x); finish(''); }
    });
  }
  async function snapshots() {
    const h = OYO.hud; if (SN.busy || !h) return; SN.busy = true; SN.tries++;
    try { for (const [id, key, pt] of [['starter', 'cartImgStarter', ''], ['royal', 'cartImgRoyal', ''], ['royal', 'cartImgIndigo', 'indigo'], ['royal', 'cartImgEbony', 'ebony'], ['royal', 'cartImgGold', 'gold']]) { if (h[key]) continue; const u = await snapshotOne(id, pt); if (u && u.length > 400) h[key] = u; } }
    catch (x) { console.warn('Cart snapshots', x); }
    SN.busy = false;
  }
  window.OYOCartView.snapshots = snapshots;
  const snapT = setInterval(() => {                                    // wait for the title screen, give the intro a moment, then do it once
    const h = OYO.hud; if (!h) return; if (h.cartImgStarter && h.cartImgRoyal && h.cartImgIndigo && h.cartImgEbony && h.cartImgGold || SN.tries >= 3) { clearInterval(snapT); return; }
    if (!h.loading && h.screen === 'title' && !SN.busy) { if (!SN.wait) SN.wait = Date.now(); else if (Date.now() - SN.wait > 900) snapshots(); }
  }, 600);

  /* Ọjà preview: the chosen paint on the cart while it ROLLS along an Oyo road. The cart stays put; the road, and acacia trees
     stream past it at the same speed the wheels turn (no slip), so it reads as a cart in motion. Its own short-lived engine, disposed on close. */
  let rEng = null, rScene = null, rCart = null, rCanvas = null, rKey = '', rHp = null;
  const RSPEED = 7, ZMIN = -34;
  function stopRide() {
    try { rEng && rEng.stopRenderLoop(); } catch (e) { /* ignore */ }
    try { rScene && rScene.dispose(); } catch (e) { /* ignore */ }
    try { rEng && rEng.dispose(); } catch (e) { /* ignore */ }
    rEng = rScene = rCart = rCanvas = rHp = null; rKey = '';
  }
  function flat(sc, name, r, g, b) {
    const m = new B.StandardMaterial(name, sc);
    m.disableLighting = true; m.emissiveColor = new B.Color3(r, g, b); m.diffuseColor = B.Color3.Black(); m.specularColor = B.Color3.Black(); return m;
  }
  function makeRoad(sc) {
    const items = [];
    const hide = m => { m.position.y = -500; return m; };                              // masters live far underground; only their instances are seen
    const grass = B.MeshBuilder.CreateGround('rvGrass', { width: 320, height: 320 }, sc); grass.material = flat(sc, 'rvGrassM', .56, .55, .30);
    // the game's own Royal Road: 11 m wide, same painted dirt texture (ruts, stones, hoof prints), same warm verge, NO kerbs and NO painted lines
    const RW = 11, TILE = RW * .95, LEN = 320, W = window.OYOWorld;
    const verge = B.MeshBuilder.CreateGround('rvVerge', { width: RW * 1.9, height: LEN }, sc); verge.position.y = .01; verge.material = flat(sc, 'rvVergeM', .80 * .92, .55 * .92, .38 * .92);
    const road = B.MeshBuilder.CreateGround('rvRoad', { width: RW, height: LEN }, sc); road.position.y = .02;
    const rm = new B.StandardMaterial('rvRoadM', sc); rm.disableLighting = true; rm.diffuseColor = B.Color3.Black(); rm.specularColor = B.Color3.Black();
    let tex = null; try { tex = W && W.paintRoad ? W.paintRoad(sc, 'royal') : null; } catch (e) { tex = null; }
    if (tex) { tex.vScale = LEN / TILE; rm.emissiveTexture = tex; rm.emissiveColor = new B.Color3(.95, .93, .90); } else rm.emissiveColor = new B.Color3(.71, .42, .25);
    road.material = rm;
    // acacia trees (umbrella canopy) on both verges; positions are fixed so every visit looks the same
    const trunk = hide(B.MeshBuilder.CreateCylinder('rvTr', { height: 2.6, diameterTop: .22, diameterBottom: .36, tessellation: 6 }, sc)), crown = hide(B.MeshBuilder.CreateCylinder('rvCr', { height: .9, diameterTop: 5.4, diameterBottom: 3.2, tessellation: 7 }, sc));
    trunk.material = flat(sc, 'rvTrM', .30, .19, .10); crown.material = flat(sc, 'rvCrM', .30, .40, .17);
    const TN = 12, TS = 13, rnd = i => { const v = Math.sin(i * 91.7 + 3.1) * 43758.5; return v - Math.floor(v); };
    for (const side of [-1, 1]) for (let i = 0; i < TN; i++) {
      const root = new B.TransformNode('rvT' + side + '_' + i, sc), a = trunk.createInstance('rvTa' + side + i), b = crown.createInstance('rvTb' + side + i);
      a.parent = root; a.position.y = 1.3; b.parent = root; b.position.y = 2.9; const sc2 = .8 + rnd(i + side * 7) * .6; root.scaling.setAll(sc2);
      const z = ZMIN + i * TS + rnd(i + 40) * 6; root.position.set(side * (12.5 + rnd(i + 11) * 9), 0, z); items.push({ m: root, z, span: TN * TS });
    }
    // low far hills for depth (do not move)
    for (const [x, z, w] of [[-60, 120, 90], [30, 135, 110], [95, 100, 70]]) { const h = B.MeshBuilder.CreateSphere('rvHill', { diameter: w, segments: 6 }, sc); h.scaling.y = .22; h.position.set(x, 0, z); h.material = flat(sc, 'rvHillM' + x, .62, .58, .40); }
    let off = 0;
    return { update(dt, v) { if (tex) { off += v * dt / TILE; tex.vOffset = off % 1; } for (const it of items) { it.z -= v * dt; if (it.z < ZMIN) it.z += it.span; it.m.position.z = it.z; } } };
  }
  function makeRide(c) {
    rEng = new B.Engine(c, true, { antialias: true }, true);
    rEng.setHardwareScalingLevel(1 / Math.min(window.devicePixelRatio || 1, 2));
    rScene = new B.Scene(rEng);
    const haze = new B.Color3(.95, .80, .55);                                          // late-afternoon harmattan haze
    rScene.clearColor = new B.Color4(haze.r, haze.g, haze.b, 1); rScene.fogMode = B.Scene.FOGMODE_EXP2; rScene.fogColor = haze; rScene.fogDensity = .011;
    const cm = new B.ArcRotateCamera('rvCam', 1.0, 1.26, 11, new B.Vector3(0, 1.3, 1.3), rScene);
    cm.minZ = .1; cm.fovMode = B.Camera.FOVMODE_HORIZONTAL_FIXED; cm.fov = .95;
    cm.lowerRadiusLimit = cm.upperRadiusLimit = 11; cm.lowerBetaLimit = 1.1; cm.upperBetaLimit = 1.42; cm.lowerAlphaLimit = .3; cm.upperAlphaLimit = 2.2; cm.panningSensibility = 0;
    try { cm.attachControl(c, true); cm.inputs.removeByType('ArcRotateCameraMouseWheelInput'); } catch (e) { /* drag-to-look is optional */ }
    const road = makeRoad(rScene); let t = 0;
    rScene.onBeforeRenderObservable.add(() => {
      const dt = Math.min(.05, rEng.getDeltaTime() / 1000); t += dt;
      road.update(dt, RSPEED);
      if (rCart && !rHp) rCart.update(dt, RSPEED, Math.sin(t * .7) * .12);                     // wheels turn at road speed; a gentle weave
    });
    rEng.runRenderLoop(() => rScene.render());
  }
  window.OYOCartView.ride = function (c, x) {
    if (!c || !x) return;
    try {
      if (rCanvas !== c) { stopRide(); rCanvas = c; makeRide(c); }
      rEng.resize(); setTimeout(() => { try { rEng && rEng.resize(); } catch (e) { /* ignore */ } }, 150);
      const k = key('royal', x); if (k === rKey) return;
      if (rHp) { rHp.dispose(); rHp = null; }
      if (rCart) { try { rCart.dispose(); } catch (e) { /* ignore */ } rCart = null; }
      const World = { sunDir: new B.Vector3(.55, .55, -.5).normalize(), height: () => 0 };
      rCart = OYOCart.build(rScene, World, { x: 0, z: 0, yaw: 0, variant: 'royal', paint: x.paint || '', board: x.name || '' }); rKey = k;
      rHp = attachHorse(rScene, World, rCart, { speed: RSPEED }); if (rHp) { const cm = rScene.activeCamera; cm.lowerRadiusLimit = cm.upperRadiusLimit = cm.radius = 15; cm.target = new B.Vector3(0, 1.3, 1.7); }
    } catch (e) { console.warn('Cart road preview unavailable', e); }
  };
  window.OYOCartView.stopRide = stopRide;
  window.addEventListener('resize', () => { try { eng && eng.resize(); rEng && rEng.resize(); } catch (e) { /* ignore */ } });
})();
