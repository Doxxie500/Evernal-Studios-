/* EMPIRE DASH — Stage 6 · villagers.js
   Yoruba villagers (14 stylised archetypes, GPU-animated) + open-air marketplaces.
   - Characters: one merged mesh per archetype, thin-instanced, skeleton animated in the vertex shader
     (walk / idle / talk / head-load carry / trade / hoe / run). ~14 draw calls for the whole population.
   - Markets: one merged static mesh each (stalls, thatch, goods, fabrics) + soft ground decals.
   - Nothing from earlier stages is modified: markets reserve ground via hidden compounds (like the palace). */
(function () {
  'use strict';
  const TAU = Math.PI * 2, PI = Math.PI;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  let sd = 6061;
  const rd = () => { sd = (sd * 16807) % 2147483647; return (sd - 1) / 2147483646; };
  const rr = (a, b) => a + (b - a) * rd(), pick = a => a[(rd() * a.length) | 0];
  const angD = (a, b) => Math.atan2(Math.sin(b - a), Math.cos(b - a));

  /* ---------------- palette (rich natural dyes) ---------------- */
  const SKIN = [[.47, .30, .20], [.40, .25, .17], [.52, .34, .23]];
  const INDIGO = [.17, .24, .58], CAM = [.74, .27, .17], OCHRE = [.88, .64, .20], CREAM = [.94, .89, .78], GREEN = [.22, .46, .30],
    PURPLE = [.42, .24, .52], GOLD = [.98, .80, .30], WHITE = [.96, .94, .90], STRAW = [.86, .70, .36], WOOD = [.46, .31, .19],
    WOOD2 = [.60, .42, .26], BASKET = [.74, .52, .27], CLAY = [.76, .40, .22], DARK = [.10, .07, .06], EARTH = [.62, .46, .28],
    TEAL = [.15, .45, .50], RUST = [.62, .30, .16];

  /* ---------------- geometry buffers + primitives ---------------- */
  const Buf = () => ({ p: [], n: [], c: [], b: [], i: [] });
  const nv = B => B.p.length / 3;
  const shade = (c, t) => [c[0] * t, c[1] * t, c[2] * t];
  function vtx(B, x, y, z, nx, ny, nz, col, a, bone) { B.p.push(x, y, z); B.n.push(nx, ny, nz); B.c.push(col[0], col[1], col[2], a); B.b.push(bone); return B.p.length / 3 - 1; }
  function ringIdx(B, base, rings, seg, closed) {
    for (let r = 0; r < rings; r++) for (let s = 0; s < seg; s++) {
      const s1 = closed ? (s + 1) % seg : s + 1; if (!closed && s1 >= seg) continue;
      const a0 = base + r * seg + s, a1 = base + r * seg + s1, b0 = a0 + seg, b1 = a1 + seg; B.i.push(a0, b0, a1, a1, b0, b1);
    }
  }
  function ell(B, cx, cy, cz, rx, ry, rz, col, a, bone, seg, rings, yaw) {
    seg = seg || 8; rings = rings || 5; yaw = yaw || 0; const cs = Math.cos(yaw), sn = Math.sin(yaw), base = nv(B);
    for (let r = 0; r <= rings; r++) {
      const ph = -PI / 2 + PI * r / rings, cp = Math.cos(ph), sp = Math.sin(ph), t = .86 + .14 * (r / rings);
      for (let s = 0; s < seg; s++) {
        const th = TAU * s / seg, ex = cp * Math.cos(th), ey = sp, ez = cp * Math.sin(th);
        let nx = ex / rx, ny = ey / ry, nz = ez / rz; const nl = Math.hypot(nx, ny, nz) || 1; nx /= nl; ny /= nl; nz /= nl;
        const lx = ex * rx, lz = ez * rz;
        vtx(B, cx + lx * cs + lz * sn, cy + ey * ry, cz - lx * sn + lz * cs, nx * cs + nz * sn, ny, -nx * sn + nz * cs, shade(col, t), a, bone);
      }
    }
    ringIdx(B, base, rings, seg, true);
  }
  function limb(B, p0, p1, r0, r1, col, a, bone, seg, noCap) {
    seg = seg || 6; const ax = p1[0] - p0[0], ay = p1[1] - p0[1], az = p1[2] - p0[2], L = Math.hypot(ax, ay, az) || 1, d = [ax / L, ay / L, az / L];
    const h = Math.abs(d[1]) < .9 ? [0, 1, 0] : [1, 0, 0];
    let u = [d[1] * h[2] - d[2] * h[1], d[2] * h[0] - d[0] * h[2], d[0] * h[1] - d[1] * h[0]]; const ul = Math.hypot(u[0], u[1], u[2]) || 1; u = [u[0] / ul, u[1] / ul, u[2] / ul];
    const v = [d[1] * u[2] - d[2] * u[1], d[2] * u[0] - d[0] * u[2], d[0] * u[1] - d[1] * u[0]], base = nv(B), k = r0 - r1;
    for (let e = 0; e < 2; e++) {
      const P = e ? p1 : p0, r = e ? r1 : r0, t = e ? 1 : .88;
      for (let s = 0; s < seg; s++) {
        const th = TAU * s / seg, c = Math.cos(th), si = Math.sin(th), rx = u[0] * c + v[0] * si, ry = u[1] * c + v[1] * si, rz = u[2] * c + v[2] * si;
        let nx = rx * L + d[0] * k, ny = ry * L + d[1] * k, nz = rz * L + d[2] * k; const nl = Math.hypot(nx, ny, nz) || 1;
        vtx(B, P[0] + rx * r, P[1] + ry * r, P[2] + rz * r, nx / nl, ny / nl, nz / nl, shade(col, t), a, bone);
      }
    }
    ringIdx(B, base, 1, seg, true);
    if (!noCap) for (let e = 0; e < 2; e++) {
      const P = e ? p1 : p0, sg = e ? 1 : -1, c0 = vtx(B, P[0], P[1], P[2], d[0] * sg, d[1] * sg, d[2] * sg, col, a, bone), r = e ? r1 : r0, f0 = nv(B);
      for (let s = 0; s < seg; s++) { const th = TAU * s / seg, c = Math.cos(th), si = Math.sin(th); vtx(B, P[0] + (u[0] * c + v[0] * si) * r, P[1] + (u[1] * c + v[1] * si) * r, P[2] + (u[2] * c + v[2] * si) * r, d[0] * sg, d[1] * sg, d[2] * sg, col, a, bone); }
      for (let s = 0; s < seg; s++) B.i.push(c0, f0 + s, f0 + (s + 1) % seg);
    }
  }
  /* prof: [[r, y, tone?], ...] bottom → top; normals follow the profile */
  function lathe(B, prof, seg, cx, cy, cz, sx, sz, col, a, bone, rot) {
    seg = seg || 8; rot = rot || 0; const base = nv(B), n = prof.length;
    for (let k = 0; k < n; k++) {
      const q = prof[k], pr = prof[Math.max(0, k - 1)], nx_ = prof[Math.min(n - 1, k + 1)];
      let nr = nx_[1] - pr[1], ny = -(nx_[0] - pr[0]); const nl = Math.hypot(nr, ny) || 1; nr /= nl; ny /= nl;
      for (let s = 0; s < seg; s++) {
        const th = rot + TAU * s / seg, c = Math.cos(th), si = Math.sin(th); let X = nr * c / sx, Z = nr * si / sz; const l = Math.hypot(X, ny, Z) || 1;
        vtx(B, cx + q[0] * c * sx, cy + q[1], cz + q[0] * si * sz, X / l, ny / l, Z / l, shade(col, q[2] || 1), a, bone);
      }
    }
    ringIdx(B, base, n - 1, seg, true);
  }
  function box(B, cx, cy, cz, sx, sy, sz, col, a, bone, yaw) {
    yaw = yaw || 0; const cs = Math.cos(yaw), sn = Math.sin(yaw), hx = sx / 2, hy = sy / 2, hz = sz / 2;
    const F = [[[1, 0, 0], [0, hy, 0], [0, 0, hz], hx, .92], [[-1, 0, 0], [0, hy, 0], [0, 0, hz], hx, .88], [[0, 1, 0], [hx, 0, 0], [0, 0, hz], hy, 1.04], [[0, -1, 0], [hx, 0, 0], [0, 0, hz], hy, .75], [[0, 0, 1], [hx, 0, 0], [0, hy, 0], hz, .96], [[0, 0, -1], [hx, 0, 0], [0, hy, 0], hz, .86]];
    for (const [n, u, v, h, t] of F) {
      const c = [n[0] * h, n[1] * h, n[2] * h], base = nv(B);
      for (const [su, sv] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
        const x = c[0] + u[0] * su + v[0] * sv, y = c[1] + u[1] * su + v[1] * sv, z = c[2] + u[2] * su + v[2] * sv;
        vtx(B, cx + x * cs + z * sn, cy + y, cz - x * sn + z * cs, n[0] * cs + n[2] * sn, n[1], -n[0] * sn + n[2] * cs, shade(col, t), a, bone);
      }
      B.i.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
  }
  function quad(B, p0, p1, p2, p3, col, a, bone) {
    const ux = p1[0] - p0[0], uy = p1[1] - p0[1], uz = p1[2] - p0[2], vx = p3[0] - p0[0], vy = p3[1] - p0[1], vz = p3[2] - p0[2];
    let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx; const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
    const base = nv(B); [p0, p1, p2, p3].forEach(p => vtx(B, p[0], p[1], p[2], nx, ny, nz, col, a, bone)); B.i.push(base, base + 1, base + 2, base, base + 2, base + 3);
  }
  function xf(B, v0, ox, oy, oz, yaw) {
    const cs = Math.cos(yaw), sn = Math.sin(yaw);
    for (let k = v0; k < nv(B); k++) {
      const x = B.p[3 * k], z = B.p[3 * k + 2], nx = B.n[3 * k], nz = B.n[3 * k + 2];
      B.p[3 * k] = ox + x * cs + z * sn; B.p[3 * k + 2] = oz - x * sn + z * cs; B.p[3 * k + 1] += oy;
      B.n[3 * k] = nx * cs + nz * sn; B.n[3 * k + 2] = -nx * sn + nz * cs;
    }
  }

  /* ======================= CHARACTERS ======================= */
  /* Rig (object space, +z forward): hips y .92 · knees .50 · shoulders y 1.42 x±.20 · elbows y 1.13 · neck y 1.50.
     bones: 0 body · 1 head · 2/3 upper arm L/R · 4/5 forearm L/R · 6/7 thigh · 8/9 shin · 10 head-load · 11 wrapper skirt
     vertex alpha: 0 = skin (tinted per person), 1 = cloth */
  function person(o) {
    const B = Buf(), sk = o.skin || SKIN[0], kid = !!o.kid, hs = kid ? 1.32 : 1, hz = o.stoop || 0, hy = o.stoop ? -.03 : 0;
    const hp = (dx, dy, dz) => [dx * hs, 1.65 + hy + dy * hs, hz + dz * hs];
    const rAt = (pr, y) => { if (y <= pr[0][1]) return pr[0][0]; for (let k = 1; k < pr.length; k++) if (y <= pr[k][1]) { const a = pr[k - 1], b = pr[k]; return a[0] + (b[0] - a[0]) * (y - a[1]) / ((b[1] - a[1]) || 1); } return pr[pr.length - 1][0]; };
    let PR = null, PZ = .8;                                                       // current garment profile (for woven bands that hug it)
    const strip = (y0, y1, col, bone, pr, sz) => { pr = pr || PR; lathe(B, [[rAt(pr, y0) + .007, y0], [rAt(pr, y1) + .007, y1]], 10, 0, 0, 0, 1, sz || PZ, col, 1, bone || 0); };
    const bandsOf = (list, col, bone, pr, sz) => list.forEach(b => strip(b[0], b[1], b[2] || col, bone, pr, sz));
    const lp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
    const top = o.top, tc = o.cloth, tr = o.trim || GOLD, t2 = o.trim2 || (tc ? shade(tc, .72) : tr), sz0 = o.sokoto;
    // legs & footwear
    for (const s of [-1, 1]) {
      const bt = s < 0 ? 6 : 7, bs = s < 0 ? 8 : 9, lc = o.pants || sk, la = o.pants ? 1 : 0;
      limb(B, [s * .09, .93, 0], [s * .09, .5, 0], sz0 ? .115 : .088, sz0 ? .098 : .062, lc, la, bt, 6);
      limb(B, [s * .09, .5, 0], [s * .09, .09, 0], sz0 ? .098 : .062, sz0 ? .052 : .044, o.pantsLong ? lc : sk, o.pantsLong ? la : 0, bs, 6);
      ell(B, s * .09, .045, .06, .052, .042, .12, o.shoe || sk, o.shoe ? 1 : 0, bs, 6, 3);
      if (o.sandal) { box(B, s * .09, .012, .065, .1, .024, .27, o.sandal, 1, bs); box(B, s * .09, .082, .05, .108, .02, .05, o.sandal, 1, bs); }
      if (o.legwrap) limb(B, [s * .09, .3, 0], [s * .09, .11, 0], .064, .052, o.legwrap, 1, bs, 6, true);
      if (o.anklets) limb(B, [s * .09, .15, 0], [s * .09, .11, 0], .056, .056, o.anklets, 1, bs, 6, true);
    }
    // torso + garments
    if (top === 'agbada') {
      PR = [[0, .24], [.46, .26], [.42, .5], [.37, .85], [.31, 1.15], [.30, 1.36], [.13, 1.46], [0, 1.47]]; PZ = .8;
      lathe(B, PR, 10, 0, 0, 0, 1, .8, tc, 1, 0);
      bandsOf([[.27, .34, tr], [.38, .40, t2], [.43, .45, tr]], tr, 0);                 // embroidered hem
      if (o.under) { box(B, 0, .68, .335, .13, .6, .02, o.under, 1, 0); }                  // inner buba / sokoto glimpsed at the front opening
      box(B, 0, 1.13, .27, .2, .36, .03, tr, 1, 0); box(B, 0, 1.13, .275, .1, .28, .03, shade(tc, .8), 1, 0);
      if (o.rich) { box(B, 0, 1.13, .29, .15, .06, .02, o.collar ? o.collar[0] : tr, 1, 0); box(B, 0, .95, .29, .02, .2, .02, tr, 1, 0); }
      strip(1.40, 1.455, tr, 0);
    } else if (top === 'dansiki') {                                                  // knee-length aso-oke tunic over baggy sokoto
      PR = [[0, .5], [.215, .52], [.205, .75], [.175, 1.05], [.17, 1.3], [.175, 1.4], [.09, 1.465], [0, 1.47]]; PZ = .78;
      lathe(B, PR, 10, 0, 0, 0, 1, PZ, tc, 1, 0);
      bandsOf(o.bands || [[.52, .58, tr], [.62, .64, t2]], tr, 0);
      box(B, 0, 1.2, .134, .075, .42, .02, tr, 1, 0); strip(1.4, 1.455, tr, 0);
      if (o.waist) strip(.86, .95, o.waist, 0);
      if (o.chestPanel) box(B, 0, 1.0, .152, .22, .2, .02, o.chestPanel, 1, 0);
    } else if (top === 'buba') {
      PR = [[0, .86], [.17, .88], [.15, 1.0], [.145, 1.15], [.16, 1.3], [.17, 1.4], [.09, 1.465], [0, 1.47]]; PZ = .75;
      lathe(B, PR, 10, 0, 0, 0, 1, .75, tc, 1, 0);
      const IRO = [[0, .1], [.25, .12], [.255, .35], [.22, .6], [.185, .85], [.17, .96], [0, .97]];
      lathe(B, IRO, 10, 0, 0, 0, 1, .85, o.iro, 1, 11);
      box(B, 0, .52, .2, .3, .74, .02, o.iro2 || shade(o.iro, 1.3), 1, 11);
      bandsOf([[.15, .2, o.band || tr], [.40, .43, o.band2 || tr], [.66, .7, o.band || tr]], tr, 11, IRO, .85);   // woven aso-oke bands on the iro
      lathe(B, [[.185, .93], [.205, .93], [.205, 1.01], [.185, 1.01]], 10, 0, 0, 0, 1, .85, o.oja || tr, 1, 0);
      if (o.oja) { ell(B, .07, .97, .175, .05, .07, .035, o.oja, 1, 0, 6, 3); box(B, .09, .8, .17, .05, .3, .015, shade(o.oja, .85), 1, 11); box(B, .04, .82, .17, .045, .26, .015, shade(o.oja, 1.1), 1, 11); }
      if (o.cuffs) for (const s of [-1, 1]) limb(B, [s * .24, 1.0, 0], [s * .252, .91, 0], .1, .11, o.cuffs, 1, s < 0 ? 4 : 5, 7, true);
    } else if (top === 'tunic') {
      PR = [[0, .86], [.15, .88], [.15, 1.1], [.16, 1.3], [.17, 1.4], [.09, 1.465], [0, 1.47]]; PZ = .75;
      lathe(B, PR, 10, 0, 0, 0, 1, .75, tc, 1, 0);
      if (o.wrap) { lathe(B, [[0, .52], [.215, .53], [.2, .75], [.16, .95], [0, .96]], 9, 0, 0, 0, 1, .8, o.wrap, 1, 0); strip(.54, .6, o.wrapBand || tr, 0, [[0, .52], [.215, .53], [.2, .75]], .8); }
      if (o.waist) strip(.9, .98, o.waist, 0, PR, .75);
    } else {  // bare chest + wrapper (men)
      PR = [[0, .86], [.15, .88], [.15, 1.1], [.16, 1.3], [.17, 1.4], [.09, 1.465], [0, 1.47]]; PZ = .75;
      lathe(B, PR, 10, 0, 0, 0, 1, .75, sk, 0, 0);
      if (o.wrap) {
        const WP = [[0, .5], [.225, .51], [.215, .7], [.185, .88], [.16, .96], [0, .97]];
        lathe(B, WP, 9, 0, 0, 0, 1, .86, o.wrap, 1, o.skirtBone ? 11 : 0);
        bandsOf(o.wbands || [[.52, .58, tr], [.66, .69, shade(o.wrap, .7)]], tr, o.skirtBone ? 11 : 0, WP, .86);
        if (o.belt) { lathe(B, [[.185, .93], [.2, .93], [.2, 1.0], [.185, 1.0]], 9, 0, 0, 0, 1, .86, o.belt, 1, 0); box(B, 0, .965, .17, .06, .06, .02, GOLD, 1, 0); }
      }
      if (o.apron) { box(B, 0, .8, .148, .24, .5, .02, o.apron, 1, 0); box(B, 0, 1.12, .125, .1, .22, .02, o.apron, 1, 0); }
      if (o.sash) limb(B, [-.15, 1.38, .02], [-.06, 1.2, .13], .028, .028, o.sash, 1, 0, 5, true), limb(B, [-.06, 1.2, .13], [.06, 1.08, .13], .028, .028, o.sash, 1, 0, 5, true), limb(B, [.06, 1.08, .13], [.14, .98, .07], .028, .028, o.sash, 1, 0, 5);
      if (o.baldric) for (const m of [-1, 1]) {                                                 // crossed leather straps with brass studs
        const a = [-m * .15, 1.38, .03], b = [-m * .06, 1.22, .13], c = [m * .07, 1.1, .13], d = [m * .14, .98, .07];
        limb(B, a, b, .024, .024, o.baldric, 1, 0, 5, true); limb(B, b, c, .024, .024, o.baldric, 1, 0, 5, true); limb(B, c, d, .024, .024, o.baldric, 1, 0, 5);
      }
      if (o.baldric) { ell(B, 0, 1.16, .145, .032, .032, .02, GOLD, 1, 0, 6, 3); }
    }
    if (o.shawl) {                                                                   // ipele: cloth draped over one shoulder
      const m = o.shawlSide || 1, c = o.shawl;
      ell(B, m * .175, 1.425, 0, .085, .05, .1, c, 1, 0, 7, 3);
      limb(B, [m * .15, 1.4, .1], [-m * .02, 1.22, .15], .03, .03, c, 1, 0, 6, true); limb(B, [-m * .02, 1.22, .15], [-m * .12, .98, .13], .03, .028, c, 1, 0, 6);
      limb(B, [m * .15, 1.4, -.09], [-m * .08, 1.15, -.13], .028, .03, shade(c, .9), 1, 0, 6);
      box(B, -m * .13, .93, .14, .12, .05, .03, shade(c, 1.15), 1, 0);
    }
    if (o.collar) {                                                                  // layered bead necklaces (coral / agate / gold)
      const cl = o.collar, at = (y) => Math.min(.3, rAt(PR, y));
      [[1.395, 1.45], [1.335, 1.385], [1.275, 1.325]].forEach((b, k) => { if (k < cl.length) strip(b[0], b[1], cl[k], 0); });
      ell(B, 0, 1.21, top === 'agbada' ? .3 : PZ * (rAt(PR, 1.21) + .01), .028, .04, .02, cl[cl.length - 1], 1, 0, 6, 3);
    }
    // arms
    for (const s of [-1, 1]) {
      const bu = s < 0 ? 2 : 3, bf = s < 0 ? 4 : 5, sh = [s * .2, 1.42, 0], el = [s * .235, 1.13, 0], wr = [s * .255, .86, 0];
      if (top === 'agbada') { limb(B, sh, el, .10, .125, tc, 1, bu, 6); limb(B, el, wr, .13, .21, tc, 1, bf, 7); box(B, s * .255, .875, 0, .03, .03, .3, tr, 1, bf, 0); }
      else if (top === 'buba') { limb(B, sh, el, .074, .084, tc, 1, bu, 6); limb(B, el, wr, .088, .10, tc, 1, bf, 6); }
      else if (top === 'dansiki') { const md = lp(el, wr, .5); limb(B, sh, el, .085, .1, tc, 1, bu, 6); limb(B, el, md, .1, .125, tc, 1, bf, 6); limb(B, md, wr, .045, .038, sk, 0, bf, 6); }
      else { limb(B, sh, el, .056, .05, sk, 0, bu, 6); limb(B, el, wr, .05, .038, sk, 0, bf, 6); }
      ell(B, s * .256, .80, .01, .04, .06, .032, sk, 0, bf, 6, 4);
      if (o.armlet) { const a = lp(sh, el, .3), b = lp(sh, el, .46); limb(B, a, b, .07, .07, o.armlet, 1, bu, 7, true); }
      if (o.wrists) limb(B, [s * .256, .845, 0], [s * .256, .8, 0], .052, .052, o.wrists, 1, bf, 7, true);
    }
    // head
    limb(B, [0, 1.42, 0], [0, 1.56 + hy, hz * .6], .052, .046, sk, 0, 1, 7, true);
    const hc = hp(0, 0, 0);
    ell(B, hc[0], hc[1], hc[2], .105 * hs, .13 * hs, .115 * hs, sk, 0, 1, 9, 6);
    for (const s of [-1, 1]) {
      const e = hp(s * .04, .02, .1); ell(B, e[0], e[1], e[2], .013 * hs, .011 * hs, .01 * hs, DARK, 1, 1, 5, 3);
      const r = hp(s * .108, 0, 0); ell(B, r[0], r[1], r[2], .012 * hs, .03 * hs, .022 * hs, sk, 0, 1, 5, 3);
    }
    let q = hp(0, -.015, .112); ell(B, q[0], q[1], q[2], .017 * hs, .022 * hs, .02 * hs, sk, 0, 1, 5, 3);
    q = hp(0, -.06, .102); box(B, q[0], q[1], q[2], .036 * hs, .008, .01, [.26, .11, .1], 1, 1);
    const hh = o.head;
    if (hh === 'hair' || hh === 'fila' || hh === 'hat') { q = hp(0, .035, -.012); ell(B, q[0], q[1], q[2], .108 * hs, .112 * hs, .118 * hs, DARK, 1, 1, 9, 5); }
    if (hh === 'fila') {                                                              // fila abetí-àjà: soft cap, one flap folded to the side
      q = hp(0, .055, 0); lathe(B, [[.112 * hs, 0], [.121 * hs, 0], [.121 * hs, .06 * hs], [.112 * hs, .06 * hs]], 10, q[0], q[1], q[2], 1, 1, o.capband || o.cap, 1, 1);
      q = hp(.035, .125, -.01); ell(B, q[0], q[1], q[2], .13 * hs, .08 * hs, .122 * hs, o.cap, 1, 1, 9, 5, .3);
      q = hp(.1, .1, -.005); ell(B, q[0], q[1], q[2], .07 * hs, .09 * hs, .1 * hs, shade(o.cap, .9), 1, 1, 7, 4, .3);
      if (o.capStud) { q = hp(0, .085, .124); ell(B, q[0], q[1], q[2], .016 * hs, .016 * hs, .012 * hs, o.capStud, 1, 1, 5, 3); }
      if (o.feather) { q = hp(-.06, .17, -.03); limb(B, q, [q[0] - .03, q[1] + .27, q[2] - .09], .02, .004, o.feather, 1, 1, 5, true); }
    } else if (hh === 'gele') {                                                       // gèlè: folded & crowned head-tie
      const big = o.geleBig ? 1.22 : 1;
      q = hp(0, .075, -.01); ell(B, q[0], q[1], q[2], .135 * hs * big, .075 * hs, .13 * hs * big, o.gele, 1, 1, 10, 5);
      q = hp(.075, .15, -.02); ell(B, q[0], q[1], q[2], .12 * hs * big, .09 * hs * big, .105 * hs * big, shade(o.gele, 1.12), 1, 1, 9, 5, .5);
      q = hp(-.05, .17, -.035); ell(B, q[0], q[1], q[2], .1 * hs * big, .08 * hs * big, .1 * hs * big, shade(o.gele, .9), 1, 1, 8, 4, -.4);
      q = hp(.11, .085, .06); ell(B, q[0], q[1], q[2], .055 * hs, .07 * hs, .05 * hs, shade(o.gele, 1.2), 1, 1, 6, 4);
      if (o.geleBig) { q = hp(-.06, .27, .0); ell(B, q[0], q[1], q[2], .09 * hs, .07 * hs, .09 * hs, shade(o.gele, 1.08), 1, 1, 7, 4, .8); q = hp(0, .08, .125); ell(B, q[0], q[1], q[2], .02 * hs, .02 * hs, .015 * hs, GOLD, 1, 1, 5, 3); }
    } else if (hh === 'tie') {
      q = hp(0, .07, -.01); ell(B, q[0], q[1], q[2], .125 * hs, .07 * hs, .12 * hs, o.gele, 1, 1, 9, 4);
      q = hp(.0, .13, -.06); ell(B, q[0], q[1], q[2], .07 * hs, .06 * hs, .06 * hs, shade(o.gele, 1.15), 1, 1, 6, 4);
    } else if (hh === 'hat') {
      q = hp(0, 0, 0);
      lathe(B, [[0, 1.60], [.30, 1.665], [.36, 1.685], [.35, 1.70], [.15, 1.76], [.10, 1.85], [0, 1.87]], 12, 0, hy, hz, 1, 1, STRAW, 1, 1);
    }
    if (o.beard) { q = hp(0, -.095, .055); ell(B, q[0], q[1], q[2], .065 * hs, .085 * hs, .06 * hs, [.92, .9, .86], 1, 1, 7, 4); }
    // head loads (bone 10) & carried props
    if (o.load) {
      const L = o.load;
      if (L === 'bundle') { ell(B, 0, 1.93, 0, .3, .18, .25, o.loadCol || CREAM, 1, 10, 9, 5); ell(B, 0, 1.78, 0, .17, .04, .17, EARTH, 1, 10, 8, 3); limb(B, [-.3, 1.9, 0], [.3, 1.9, 0], .012, .012, DARK, 1, 10, 4); }
      else {
        ell(B, 0, 1.775, 0, .15, .035, .15, EARTH, 1, 10, 8, 3);
        lathe(B, [[0, 1.78], [.16, 1.78], [.24, 1.9], [.29, 2.0], [.28, 2.03], [0, 2.03]], 10, 0, 0, 0, 1, 1, o.loadCol || BASKET, 1, 10);
        const cols = L === 'yams' ? [[.55, .38, .22], [.6, .42, .24]] : L === 'fruit' ? [[.95, .58, .1], [.88, .2, .14], [.95, .85, .2]] : [[.3, .55, .22], [.9, .3, .15], [.95, .75, .25]];
        for (let k = 0; k < 6; k++) { const a = TAU * k / 6, r = k === 5 ? 0 : .13; if (L === 'yams') ell(B, Math.cos(a) * r, 2.1, Math.sin(a) * r, .05, .05, .2, pick(cols), 1, 10, 6, 3, a); else ell(B, Math.cos(a) * r, 2.07, Math.sin(a) * r, .09, .07, .09, pick(cols), 1, 10, 6, 4); }
      }
    }
    if (o.pouch) { const m = o.pouchSide || -1; ell(B, m * .2, .93, .1, .06, .07, .045, o.pouch, 1, 0, 6, 3); limb(B, [m * .18, 1.34, .04], [m * .2, .98, .1], .012, .012, shade(o.pouch, .8), 1, 0, 4, true); }   // trader's cowrie purse
    if (o.backBasket) {
      lathe(B, [[.15, 0], [.2, .22], [.25, .5], [.26, .55], [.23, .55], [.0, .5]], 10, 0, .72, -.3, 1, 1, BASKET, 1, 0);
      for (let k = 0; k < 4; k++) ell(B, rr(-.1, .1), 1.3 + rd() * .03, -.3 + rr(-.1, .1), .09, .07, .09, pick([[.3, .55, .22], [.55, .38, .22], [.95, .58, .1]]), 1, 0, 6, 3);
      for (const s of [-1, 1]) limb(B, [s * .14, 1.4, -.08], [s * .16, 1.0, -.3], .017, .017, [.3, .2, .12], 1, 0, 5);
    }
    if (o.hoe) { limb(B, [.262, .5, .16], [.3, 1.3, -.1], .022, .02, WOOD2, 1, 5, 5); box(B, .262, .47, .18, .18, .12, .025, [.55, .55, .58], 1, 5); }
    if (o.cutlass) { box(B, -.262, .66, .12, .03, .5, .07, [.62, .64, .68], 1, 4); box(B, -.262, .94, .06, .035, .1, .04, WOOD, 1, 4); }
    if (o.shield) { ell(B, -.33, .98, .08, .03, .27, .19, o.shield, 1, 4, 8, 4); ell(B, -.36, .98, .08, .02, .06, .06, GOLD, 1, 4, 6, 3); box(B, -.345, .98, .08, .012, .46, .03, shade(o.shield, .6), 1, 4); }
    if (o.smith) {   // blacksmith's work-place travels with him (he never walks): hammer, tongs, stump + anvil, clay hearth with embers, quench trough
      limb(B, [.262, .76, .04], [.262, .8, .4], .02, .02, WOOD2, 1, 5, 5); box(B, .262, .8, .43, .13, .075, .07, IRON, 1, 5);
      limb(B, [-.262, .8, .04], [-.262, .72, .46], .014, .014, IRON, 1, 4, 5); box(B, -.262, .72, .5, .05, .03, .1, IRON, 1, 4);
      limb(B, [0, 0, .66], [0, .5, .66], .17, .15, WOOD, 1, 0, 7); box(B, 0, .56, .66, .15, .1, .32, IRON, 1, 0); limb(B, [0, .57, .82], [0, .57, 1.0], .05, .012, IRON, 1, 0, 5);
      lathe(B, [[0, 0], [.46, 0], [.4, .2], [.27, .32], [.2, .3], [0, .3]], 9, -.95, 0, .35, 1, 1, CLAY, 1, 0);
      ell(B, -.95, .31, .35, .2, .06, .2, EMBER, 1, 0, 7, 3); ell(B, -.9, .33, .3, .1, .05, .09, [.2, .08, .06], 1, 0, 6, 3);
      box(B, .95, .2, .5, .55, .26, .3, WOOD, 1, 0); box(B, .95, .34, .5, .47, .02, .22, [.18, .26, .32], 1, 0);
      for (let k = 0; k < 4; k++) ell(B, -.4 + k * .28, .04, .95, .09, .05, .07, [.3, .3, .32], 1, 0, 5, 3);
    }
    if (o.staff) limb(B, [.262, 0, .06], [.262, 1.4, .06], .024, .02, WOOD2, 1, 5, 5);
    if (o.spear) { limb(B, [.28, .0, .1], [.28, 2.15, .1], .02, .016, WOOD2, 1, 5, 5); ell(B, .28, 2.24, .1, .035, .12, .014, [.72, .74, .78], 1, 5, 6, 4); limb(B, [.28, 2.08, .1], [.28, 2.14, .1], .03, .03, o.tassel || CAM, 1, 5, 6, true); }
    return B;
  }

  /* Stage 15 — historically inspired Oyo c.1650 dress: aso-oke strip-woven cloth (banded), wrappers (iro, ìpèlé), buba / dansiki + sokoto,
     agbada for the wealthy, fila & gèlè head-wear, coral/agate beads for chiefs, leather sandals. Colours: indigo (etu), camwood red, sanyan tan,
     alaari crimson, undyed cotton. Bone layout & vertex-alpha convention are unchanged, so every animation / pose works exactly as before. */
  const ETU = [.12, .17, .42], ALAARI = [.62, .12, .19], SANYAN = [.6, .48, .33], CORAL = [.88, .24, .18], AGATE = [.76, .42, .2], BRASS = [.86, .64, .22],
    LEATHER = [.36, .21, .12], LEATHER2 = [.5, .3, .16], HIDE = [.88, .8, .62], BLUEB = [.2, .4, .78], UNDYED = [.9, .84, .7], CRIM = [.66, .12, .15];
  const IRON = [.26, .26, .29], EMBER = [.98, .5, .12];
  const ARCH = [
    // 1 · male villagers — plain strip-woven dansiki over sokoto, fila, leather sandals
    { id: 'agA', o: { top: 'dansiki', cloth: [.2, .28, .56], trim: CREAM, trim2: CAM, head: 'fila', cap: [.72, .3, .2], pants: UNDYED, pantsLong: 1, sokoto: 1, sandal: LEATHER, skin: SKIN[0] }, mv: 1 },
    { id: 'agB', o: { top: 'dansiki', cloth: [.66, .3, .18], trim: OCHRE, trim2: CREAM, head: 'fila', cap: UNDYED, pants: [.2, .25, .48], pantsLong: 1, sokoto: 1, sandal: LEATHER2, skin: SKIN[1] }, mv: 1 },
    { id: 'agC', o: { top: 'dansiki', cloth: UNDYED, trim: INDIGO, trim2: CAM, head: 'fila', cap: [.2, .26, .5], pants: [.2, .26, .5], pantsLong: 1, sokoto: 1, sandal: LEATHER, skin: SKIN[2] }, mv: 1 },
    { id: 'farmA', o: { top: 'tunic', cloth: EARTH, waist: [.74, .58, .32], head: 'hat', pants: [.5, .38, .26], sokoto: 1, backBasket: 1, hoe: 1, skin: SKIN[1] }, mv: 1 },
    { id: 'farmB', o: { top: 'bare', wrap: [.5, .36, .22], trim: [.72, .5, .26], head: 'hair', load: 'yams', cutlass: 1, sash: CAM, skin: SKIN[2] }, mv: 3 },
    // 3 · market traders — brighter banded cloth, shoulder cloth (ìpèlé), cowrie purse
    { id: 'trdM', o: { top: 'dansiki', cloth: GREEN, trim: OCHRE, trim2: CAM, head: 'fila', cap: OCHRE, pants: UNDYED, pantsLong: 1, sokoto: 1, shawl: OCHRE, pouch: LEATHER2, sandal: LEATHER, load: 'bundle', loadCol: CREAM, skin: SKIN[0] }, mv: 3 },
    { id: 'elder', o: { top: 'agbada', cloth: [.88, .86, .8], trim: [.5, .55, .8], trim2: [.7, .72, .85], head: 'fila', cap: WHITE, pants: UNDYED, pantsLong: 1, sokoto: 1, sandal: LEATHER2, beard: 1, staff: 1, stoop: .07, skin: SKIN[1] }, mv: 0 },
    // 4 · royal palace guards — banded indigo wrapper, crossed leather baldrics, brass arm-rings, feathered fila, hide shield & spear
    { id: 'guard', o: { top: 'bare', wrap: ETU, wbands: [[.52, .57, CRIM], [.6, .62, CREAM], [.7, .74, CRIM]], skirtBone: 1, belt: LEATHER, baldric: LEATHER, armlet: BRASS, wrists: BRASS, legwrap: LEATHER, sandal: LEATHER2, head: 'fila', cap: CRIM, capband: BRASS, feather: WHITE, tassel: CRIM, shield: HIDE, spear: 1, skin: SKIN[1] }, mv: 0 },
    // 2 · female villagers — buba + banded iro wrapper, gèlè, single bead strand, bare feet
    { id: 'wA', o: { top: 'buba', cloth: CREAM, iro: CAM, iro2: OCHRE, trim: OCHRE, band2: CREAM, head: 'gele', gele: INDIGO, collar: [CORAL], skin: SKIN[0] }, mv: 1 },
    { id: 'wB', o: { top: 'buba', cloth: OCHRE, iro: INDIGO, iro2: CREAM, trim: CREAM, band2: CAM, head: 'gele', gele: CREAM, collar: [[.95, .85, .4]], skin: SKIN[2] }, mv: 1 },
    { id: 'wC', o: { top: 'buba', cloth: GREEN, iro: PURPLE, iro2: GOLD, trim: GOLD, band2: CREAM, head: 'gele', gele: CAM, collar: [BLUEB], skin: SKIN[1] }, mv: 1 },
    { id: 'trdW', o: { top: 'buba', cloth: WHITE, iro: TEAL, iro2: OCHRE, trim: OCHRE, band2: CAM, oja: CAM, pouch: OCHRE, pouchSide: 1, head: 'tie', gele: CAM, load: 'fruit', skin: SKIN[1] }, mv: 3 },
    { id: 'boy', o: { top: 'bare', wrap: [.7, .6, .4], trim: [.52, .42, .26], wbands: [[.52, .56, [.52, .42, .26]]], head: 'hair', pants: [.7, .6, .4], kid: 1, skin: SKIN[2] }, mv: 6 },
    { id: 'girl', o: { top: 'buba', cloth: CAM, iro: INDIGO, iro2: CREAM, trim: GOLD, head: 'tie', gele: OCHRE, kid: 1, skin: SKIN[0] }, mv: 6 },
    // 6 · wealthy chiefs & nobles — agbada in alaari / etu / sanyan aso-oke, coral-agate bead collars, beaded caps & wrists, red leather sandals
    { id: 'chfA', o: { top: 'agbada', cloth: ALAARI, trim: GOLD, trim2: CREAM, under: UNDYED, rich: 1, collar: [CORAL, AGATE, CORAL], wrists: CORAL, head: 'fila', cap: [.5, .09, .15], capband: CORAL, capStud: GOLD, pants: UNDYED, pantsLong: 1, sokoto: 1, sandal: [.56, .16, .12], anklets: CORAL, skin: SKIN[0] }, mv: 1 },
    { id: 'chfB', o: { top: 'agbada', cloth: ETU, trim: [.95, .85, .45], trim2: WHITE, under: UNDYED, rich: 1, collar: [BLUEB, CORAL, BLUEB], wrists: BLUEB, head: 'fila', cap: UNDYED, capband: CORAL, capStud: GOLD, pants: UNDYED, pantsLong: 1, sokoto: 1, sandal: LEATHER, anklets: BLUEB, skin: SKIN[2] }, mv: 1 },
    { id: 'chfC', o: { top: 'agbada', cloth: SANYAN, trim: [.22, .32, .68], trim2: GOLD, under: CREAM, rich: 1, collar: [AGATE, GOLD, AGATE], wrists: GOLD, head: 'fila', cap: ETU, capband: GOLD, capStud: CORAL, pants: CREAM, pantsLong: 1, sokoto: 1, sandal: [.56, .16, .12], beard: 1, skin: SKIN[1] }, mv: 1 },
    { id: 'wChf', o: { top: 'buba', cloth: [.6, .15, .34], trim: GOLD, cuffs: GOLD, iro: ETU, iro2: GOLD, band: GOLD, band2: CORAL, oja: GOLD, shawl: [.84, .72, .46], shawlSide: -1, head: 'gele', gele: BRASS, geleBig: 1, collar: [CORAL, AGATE, CORAL], wrists: CORAL, skin: SKIN[2] }, mv: 1 },
    // 5 · palace attendants — matching undyed-white livery with crimson trim
    { id: 'attM', o: { top: 'dansiki', cloth: [.94, .91, .83], trim: CRIM, trim2: CRIM, bands: [[.52, .58, CRIM]], waist: CRIM, head: 'fila', cap: CRIM, pants: [.94, .91, .83], pantsLong: 1, sokoto: 1, sandal: LEATHER, skin: SKIN[0] }, mv: 1 },
    { id: 'wAtt', o: { top: 'buba', cloth: WHITE, iro: CRIM, iro2: CREAM, trim: CREAM, band2: CREAM, oja: ETU, head: 'tie', gele: WHITE, skin: SKIN[1] }, mv: 1 },
    // 3 · stall vendors (market) — bold cloth, ìpèlé over the shoulder, cowrie purse
    { id: 'vndM', o: { top: 'dansiki', cloth: [.86, .6, .2], trim: INDIGO, trim2: CAM, head: 'fila', cap: CAM, pants: UNDYED, pantsLong: 1, sokoto: 1, shawl: [.17, .24, .58], shawlSide: -1, pouch: LEATHER2, sandal: LEATHER2, skin: SKIN[1] }, mv: 1 },
    { id: 'wVnd', o: { top: 'buba', cloth: [.9, .78, .3], iro: GREEN, iro2: CREAM, trim: CAM, band2: OCHRE, oja: CAM, shawl: [.17, .24, .58], head: 'tie', gele: [.78, .2, .14], pouch: LEATHER2, pouchSide: -1, skin: SKIN[0] }, mv: 1 },
    // 5 · blacksmith — sooty wrapper, leather apron, head-cloth; forge, anvil & trough baked into the mesh (stationary)
    { id: 'smith', o: { top: 'bare', wrap: [.22, .18, .16], wbands: [[.52, .56, [.5, .3, .16]]], apron: LEATHER, belt: LEATHER2, head: 'tie', gele: [.62, .2, .14], armlet: BRASS, smith: 1, skin: SKIN[1] }, mv: 0 }
  ];
  const IX = {}; ARCH.forEach((a, i) => { IX[a.id] = i; });
  const WOMEN = ['wA', 'wB', 'wC', 'trdW'], MEN = ['agA', 'agB', 'agC', 'farmA', 'farmB', 'trdM'];

  /* ======================= MARKET PIECES (stall-local frame, +z faces the market centre) ======================= */
  function potM(B, x, y, z, s, col) {
    lathe(B, [[0, 0, .8], [.12, 0, .85], [.21, .12, 1], [.24, .27, 1.05], [.18, .39, 1], [.12, .43, .95], [.14, .47, .9], [.1, .47, .5], [0, .43, .4]], 9, x, y, z, s, s, col, 1, 0);
    lathe(B, [[0, .46], [.1, .46]], 7, x, y, z, s, s, DARK, 1, 0);
  }
  function basketM(B, x, y, z, s, fill, fcol) {
    lathe(B, [[0, 0, .8], [.14, 0, .85], [.2, .12, 1], [.25, .2, 1.05], [.26, .23, 1.1], [.23, .23, .9], [0, .21, .8]], 9, x, y, z, s, s, BASKET, 1, 0);
    if (fill) for (let k = 0; k < fill; k++) { const a = TAU * k / fill + rd(), r = k ? .11 * s : 0; ell(B, x + Math.cos(a) * r, y + .25 * s, z + Math.sin(a) * r, .075 * s, .06 * s, .075 * s, Array.isArray(fcol[0]) ? pick(fcol) : fcol, 1, 0, 6, 3); }
  }
  function clothHang(B, x, yt, yb, z, w, c1, c2, bands) {
    const bw = w / bands;
    for (let k = 0; k < bands; k++) {
      const x0 = x - w / 2 + k * bw, c = k % 2 ? c2 : c1, z0 = z + Math.sin(k * 1.7) * .03, z1 = z + Math.sin((k + 1) * 1.7) * .03;
      quad(B, [x0, yt, z0], [x0 + bw, yt, z1], [x0 + bw, yb, z1 + .02], [x0, yb, z0 + .02], c, 1, 0);
    }
  }
  function stall(B, type, awning) {
    const v0 = nv(B);
    for (const sx of [-1, 1]) { limb(B, [sx * 1.55, -.15, -1.15], [sx * 1.55, 2.78, -1.15], .055, .05, WOOD, 1, 0, 6); limb(B, [sx * 1.55, -.15, 1.0], [sx * 1.55, 2.3, 1.0], .055, .05, WOOD, 1, 0, 6); }
    box(B, 0, 2.3, 1.0, 3.25, .07, .08, WOOD2, 1, 0); box(B, 0, 2.78, -1.15, 3.25, .07, .08, WOOD2, 1, 0);
    if (!awning) {
      lathe(B, [[0, 3.16, 1.05], [.55, 2.95, 1], [1, 2.55, .95], [1.1, 2.32, .75], [1.15, 2.22, .6]], 4, 0, 0, -.08, 2.7, 2.15, STRAW, 1, 0, PI / 4);
      lathe(B, [[1.05, 2.5, .8], [1.14, 2.3, .7]], 4, 0, 0, -.08, 2.7, 2.15, [.7, .55, .28], 1, 0, PI / 4);
    } else {
      const cs = [[INDIGO, CREAM], [CAM, OCHRE], [GREEN, CREAM], [PURPLE, GOLD]][(rd() * 4) | 0], n = 6, w = 3.8 / n;
      for (let k = 0; k < n; k++) { const x0 = -1.9 + k * w; quad(B, [x0, 2.9, -1.35], [x0 + w, 2.9, -1.35], [x0 + w, 2.2, 1.5], [x0, 2.2, 1.5], cs[k % 2], 1, 0); }
    }
    // counter
    box(B, 0, .43, .55, 3.0, .86, .9, WOOD, 1, 0); box(B, 0, .89, .55, 3.14, .06, 1.04, WOOD2, 1, 0);
    clothHang(B, 0, .84, .1, 1.015, 2.9, pick([INDIGO, CAM, GREEN, PURPLE]), CREAM, 7);
    const T = .92;
    if (type === 'yam') {
      for (let l = 0; l < 3; l++) for (let i = 0; i < 5 - l; i++) ell(B, -1.2 + i * .6 + l * .3 + rr(-.05, .05), T + .075 + l * .13, .45 + rr(-.1, .2), .075, .075, .3, [.5 + rd() * .15, .35 + rd() * .06, .2], 1, 0, 6, 4, rr(-.25, .25) + PI / 2);
      for (const sx of [-1, 1]) { basketM(B, sx * 1.95, 0, .8, 1.2, 0); for (let k = 0; k < 4; k++) ell(B, sx * 1.95 + rr(-.1, .1), .45, .8 + rr(-.1, .1), .06, .26, .06, [.55, .38, .22], 1, 0, 6, 4); }
    } else if (type === 'fruit') {
      const bf = [[.95, .58, .1], [.88, .2, .14], [.9, .8, .2]];
      [-.95, 0, .95].forEach((x, i) => { basketM(B, x, T, .55, 1.15, 7, [bf[i], shade(bf[i], 1.1)]); });
      ell(B, -1.35, T + .16, .3, .1, .16, .1, [.93, .7, .15], 1, 0, 7, 4); lathe(B, [[.07, T + .28], [.05, T + .4], [0, T + .45]], 6, -1.35, 0, .3, 1, 1, GREEN, 1, 0);
      ell(B, 1.35, T + .14, .3, .18, .14, .14, [.2, .5, .25], 1, 0, 8, 5);
      for (let k = 0; k < 4; k++) ell(B, -.75 + k * .5, 1.95, 1.0, .05, .22, .05, [.95, .82, .2], 1, 0, 5, 3);
      basketM(B, 1.95, 0, .8, 1.2, 8, [[.95, .58, .1], [.9, .8, .2]]);
    } else if (type === 'veg') {
      [-.9, 0, .9].forEach((x, i) => { ell(B, x, T + .1, .55, .36, .13, .26, i === 1 ? [.35, .6, .25] : [.25, .5, .2], 1, 0, 8, 4); ell(B, x, T + .18, .5, .22, .08, .16, [.45, .7, .3], 1, 0, 7, 3); });
      for (let k = 0; k < 9; k++) ell(B, -1.35 + (k % 3) * .12 + (k > 4 ? 2.6 : 0), T + .05, .25 + Math.floor(k / 3) * .09, .05, .035, .05, k % 2 ? [.88, .22, .14] : [.95, .75, .2], 1, 0, 5, 3);
      for (let k = 0; k < 5; k++) ell(B, -1 + k * .5, 1.95, 1.0, .07, .26, .05, [.28, .52, .22], 1, 0, 5, 3);
      for (const sx of [-1, 1]) { ell(B, sx * 1.95, .2, .8, .27, .2, .24, sx > 0 ? [.55, .3, .4] : [.82, .72, .5], 1, 0, 8, 4); }
    } else if (type === 'cloth') {
      [[-.9, INDIGO, CREAM, CAM], [0, CAM, OCHRE, GREEN], [.9, PURPLE, GOLD, WHITE]].forEach(([x, a, b, c]) => { box(B, x, T + .05, .55, .62, .08, .5, a, 1, 0); box(B, x, T + .13, .55, .58, .08, .46, b, 1, 0); box(B, x + .02, T + .21, .55, .54, .08, .44, c, 1, 0, .1); });
      clothHang(B, -.8, 2.22, 1.25, .9, 1.4, INDIGO, CREAM, 8); clothHang(B, .8, 2.22, 1.3, .9, 1.4, CAM, OCHRE, 6);
      clothHang(B, 0, 2.7, .5, -1.05, 2.8, [.2, .28, .62], [.9, .88, .8], 14);
    } else if (type === 'pots') {
      [[-1, .5], [0, .55], [1, .5]].forEach(([x, z], i) => potM(B, x, T, z, .6 + i * .05, shade(CLAY, .9 + i * .1)));
      for (const sx of [-1, 1]) { potM(B, sx * 1.95, 0, .7, 1.5, CLAY); potM(B, sx * 1.95 + sx * .3, 0, 1.25, 1.1, shade(CLAY, 1.1)); potM(B, sx * 1.95 - sx * .1, .62, .7, .8, shade(CLAY, .85)); }
      for (let k = 0; k < 3; k++) potM(B, -.7 + k * .7, 0, 1.55 + (k % 2) * .3, 1.2 - k * .15, shade(CLAY, .85 + k * .12));
    } else {  // grain & beans
      [-.9, 0, .9].forEach((x, i) => { basketM(B, x, T, .55, 1.2, 0); ell(B, x, T + .21, .55, .24, .1, .24, [[.92, .86, .65], [.55, .3, .2], [.85, .72, .35]][i], 1, 0, 8, 4); });
      for (const sx of [-1, 1]) { ell(B, sx * 1.95, .25, .7, .3, .25, .22, CREAM, 1, 0, 8, 5); ell(B, sx * 1.95 + sx * .2, .22, 1.2, .26, .2, .2, [.8, .7, .5], 1, 0, 8, 5); }
    }
    // clutter behind
    for (const sx of [-1, 1]) { if (rd() < .6) basketM(B, sx * 1.2, 0, -1.7, 1.3, 0); else potM(B, sx * 1.2, 0, -1.7, 1.2, CLAY); }
    return v0;
  }
  function pavilion(B) {
    const R = 2.5;
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) limb(B, [sx * R, -.15, sz * R], [sx * R, 2.9, sz * R], .09, .075, WOOD, 1, 0, 7);
    for (const s of [-1, 1]) { box(B, s * R, 2.85, 0, .1, .1, R * 2 + .3, WOOD2, 1, 0); box(B, 0, 2.85, s * R, R * 2 + .3, .1, .1, WOOD2, 1, 0); }
    lathe(B, [[0, 4.3, 1.05], [1.2, 3.75, 1], [2.9, 3.15, .95], [3.7, 2.7, .75], [3.85, 2.55, .6]], 10, 0, 0, 0, 1, 1, STRAW, 1, 0, PI / 10);
    lathe(B, [[3.45, 2.95, .8], [3.8, 2.6, .65]], 10, 0, 0, 0, 1, 1, [.62, .5, .26], 1, 0, PI / 10);
    box(B, 0, .03, 0, 4.4, .06, 4.4, [.72, .58, .34], 1, 0);
    [[-1.3, -1.2, INDIGO], [1.2, -1.3, CAM], [-.2, 1.3, OCHRE]].forEach(([x, z, c]) => { box(B, x, .075, z, 1.5, .03, 1.1, c, 1, 0, rr(-.5, .5)); });
    basketM(B, -1.2, .06, -1.0, 1.3, 6, [[.95, .58, .1], [.88, .2, .14]]); potM(B, 1.3, .06, -1.1, 1.2, CLAY); potM(B, .9, .06, -.6, .8, shade(CLAY, 1.1));
    basketM(B, 1.0, .06, 1.3, 1.2, 0); ell(B, 1.0, .3, 1.3, .24, .1, .24, [.9, .84, .62], 1, 0, 8, 3);
    clothHang(B, -2.5, 2.7, 1.5, -.9, 1.2, CAM, OCHRE, 6); clothHang(B, 2.5, 2.7, 1.55, .9, 1.2, INDIGO, CREAM, 8);
  }
  function softDisc(D, H, cx, cz, rx, rz, yaw, col, alpha, seg, rings, yo) {
    const cs = Math.cos(yaw), sn = Math.sin(yaw), base = D.p.length / 3;
    for (let r = 0; r <= rings; r++) for (let s = 0; s < (r ? seg : 1); s++) {
      const t = r / rings, th = TAU * s / seg, lx = Math.cos(th) * rx * t, lz = Math.sin(th) * rz * t, x = cx + lx * cs + lz * sn, z = cz - lx * sn + lz * cs;
      D.p.push(x, H(x, z) + yo, z); D.c.push(col[0], col[1], col[2], alpha * Math.pow(1 - t, .85) * (r === rings ? 0 : 1));
    }
    for (let r = 1; r <= rings; r++) for (let s = 0; s < seg; s++) {
      const s1 = (s + 1) % seg, a0 = r === 1 ? base : base + 1 + (r - 2) * seg + s, a1 = r === 1 ? base : base + 1 + (r - 2) * seg + s1, b0 = base + 1 + (r - 1) * seg + s, b1 = base + 1 + (r - 1) * seg + s1;
      if (r === 1) D.i.push(base, b0, b1); else D.i.push(a0, b0, a1, a1, b0, b1);
    }
  }

  /* ======================= SHADERS ======================= */
  const FV = `precision highp float;
attribute vec3 position;attribute vec3 normal;attribute vec4 color;
#ifdef INSTANCES
attribute float bone;attribute vec4 inst;attribute vec4 world0;attribute vec4 world1;attribute vec4 world2;attribute vec4 world3;
#else
uniform mat4 world;
#endif
uniform mat4 viewProjection;uniform float time;uniform vec3 camPos;
varying vec3 vN;varying vec3 vC;varying vec2 vUV;varying float vD;varying vec3 vV;
#ifdef INSTANCES
void rX(inout vec3 p,inout vec3 n,vec3 c,float a){float s=sin(a),k=cos(a);vec3 d=p-c;p=c+vec3(d.x,d.y*k-d.z*s,d.y*s+d.z*k);n=vec3(n.x,n.y*k-n.z*s,n.y*s+n.z*k);}
void rY(inout vec3 p,inout vec3 n,vec3 c,float a){float s=sin(a),k=cos(a);vec3 d=p-c;p=c+vec3(d.x*k+d.z*s,d.y,-d.x*s+d.z*k);n=vec3(n.x*k+n.z*s,n.y,-n.x*s+n.z*k);}
void rZ(inout vec3 p,inout vec3 n,vec3 c,float a){float s=sin(a),k=cos(a);vec3 d=p-c;p=c+vec3(d.x*k-d.y*s,d.x*s+d.y*k,d.z);n=vec3(n.x*k-n.y*s,n.x*s+n.y*k,n.z);}
float sm(float a,float b,float x){float t=clamp((x-a)/(b-a),0.,1.);return t*t*(3.-2.*t);}
// foot target for one leg: planted (sliding back at body speed) for fraction ds of the cycle, then swinging forward on a lifted arc
// whose ends carry the same backward velocity as the planted foot, so there is no snap at lift-off or touch-down
void foot(float u,float S,float ds,float lift,float hop,out float fz,out float fy){
  if(u<ds){fz=S*(1.-2.*u/ds);fy=0.;}
  else{float s=(u-ds)/(1.-ds),m=-1.5*S*(1.-ds)/ds,s2=s*s,s3=s2*s;
    fz=(2.*s3-3.*s2+1.)*-S+m*(s3-2.*s2+s)+(-2.*s3+3.*s2)*S+m*(s3-s2);fy=lift*sin(3.14159265*s)+hop*(1.-s);}
}
float smin(float a,float b,float k){float h=clamp(.5+.5*(b-a)/k,0.,1.);return mix(b,a,h)-k*h*(1.-h);}
// two-bone leg IK (thigh .42, shin .5, hip at height h): angles for the thigh (hip) and knee, knee bends backwards
void ik(float h,float fy,float fz,out float th,out float kp){
  float A=.42,Bn=.5,tx=-fz,ty=max(h-fy,.2);
  float d=clamp(sqrt(tx*tx+ty*ty),.1,.918);
  th=atan(tx,ty)-acos(clamp((A*A+d*d-Bn*Bn)/(2.*A*d),-1.,1.));
  kp=3.14159265-acos(clamp((A*A+Bn*Bn-d*d)/(2.*A*Bn),-1.,1.));
}
#endif
void main(){
  vec3 p=position;vec3 n=normal;
#ifdef INSTANCES
  vec3 SHL=vec3(-.2,1.42,0.),SHR=vec3(.2,1.42,0.),ELL=vec3(-.235,1.13,0.),ELR=vec3(.235,1.13,0.),HPL=vec3(-.09,.92,0.),HPR=vec3(.09,.92,0.),KNL=vec3(-.09,.5,0.),KNR=vec3(.09,.5,0.),NK=vec3(0.,1.5,0.),HPC=vec3(0.,.92,0.);
  float st=inst.y,T=time*inst.z+inst.x;
  float aSL=-.05,aSR=-.05,aEL=-.15,aER=-.15,zL=.04,zR=.04,aHL=0.,aHR=0.,aKL=0.,aKR=0.,zHL=0.,zHR=0.,lean=0.,hyaw=0.,hpit=0.,bob=0.,sway=0.,skirt=0.;
  float br=sin(T*1.6);
  lean=.012*br;bob=.004*br;sway=.012*sin(T*.7);hyaw=.5*sin(T*.37)*sin(T*.23+1.);aSL+=.03*br;aSR+=.03*sin(T*1.6+1.);
  if(abs(st-1.5)<.01){
    // 1.5 = seated pillion (roam-fare.js): thighs forward, legs splayed so they hang outside the horse's flanks
    aHL=aHR=-.5;aKL=aKR=.7;zHL=-.95;zHR=.95;aSL=aSR=-.45;aEL=aER=-.55;zL=zR=.08;lean=.0;bob=0.;sway=0.;skirt=0.;
  } else if(abs(st-6.25)<.01){
    // 6.25 = seated on a bench (cart.js passenger): thighs level, shins hanging, hands resting in the lap, calm breathing and an occasional glance around
    aHL=aHR=-1.45;aKL=aKR=1.35;zHL=-.04;zHR=.04;aSL=aSR=-.42;aEL=aER=-.75;zL=zR=.05;skirt=-1.15;
    lean=.012*br+.006*sin(T*.5);bob=0.;sway=.006*sin(T*.7);hyaw=.55*sin(T*.37)*sin(T*.23+1.);hpit=.05*sin(T*.9);
  } else if(abs(st-4.75)<.01){
    // 4.75 = blacksmith at the anvil: the right arm lifts the hammer slowly and strikes on a sharp beat, the left hand steadies the work with tongs, the torso rocks into each blow
    float hv=fract(T*.62),hu=sm(0.,.72,hv)*(1.-sm(.72,.8,hv));
    aSR=-.9-1.45*hu;aER=-.35-.85*hu;zR=.12;aSL=-.95+.04*sin(T*1.7);aEL=-.75;zL=.1;
    lean=.1+.1*hu;hpit=-.14-.08*hu;hyaw=.18*sin(T*.5);bob=-.025*hu;sway=.008*sin(T*.9);
  } else if(st>.5&&st<1.5){
    float W=sin(T*4.6),C=cos(T*4.6);
    aHL=.5*W;aHR=-.5*W;aKL=.85*max(0.,-C);aKR=.85*max(0.,C);
    aSL=-.45*W;aSR=.45*W;aEL=-.3;aER=-.3;bob=.03*(1.-abs(W));sway=.018*W;lean=.05;hyaw=.12*sin(T*2.3);skirt=.12*W;
  } else if(st>1.5&&st<2.5){
    aSR=-.95-.45*sin(T*3.2);aER=-.7+.55*sin(T*3.2+1.);zR=.12;
    aSL=-.3+.15*sin(T*2.1+2.);aEL=-.95+.2*sin(T*2.6);zL=.1;
    hyaw=.4*sin(T*1.1);hpit=.1*sin(T*2.4);lean=.04+.02*sin(T*1.1);sway=.025*sin(T*.8);
  } else if(st>2.5&&st<3.5){
    float W=sin(T*4.6),C=cos(T*4.6);
    aHL=.5*W;aHR=-.5*W;aKL=.85*max(0.,-C);aKR=.85*max(0.,C);
    aSR=-2.75;aER=-.25;zR=.14;aSL=-.3*W-.1;aEL=-.3;zL=.05;
    bob=.03*(1.-abs(W));sway=.014*W;lean=.02;hyaw=.06*sin(T*2.3);skirt=.1*W;
  } else if(st>3.5&&st<4.5){
    aSR=-1.0+.35*sin(T*2.4);aER=-.5+.4*sin(T*2.4+.5);zR=.1;
    aSL=-.7+.3*sin(T*1.7+2.);aEL=-.95;zL=.12;
    hyaw=.5*sin(T*.9);hpit=.08*sin(T*1.8);lean=.07+.03*sin(T*2.4);sway=.015*sin(T*.9);
  } else if(st>4.5&&st<5.5){
    float c=sin(T*2.2);
    lean=.55+.1*c;aSR=-1.3-.7*c;aSL=-1.2-.7*c;aER=-.5-.3*c;aEL=-.5;hpit=-.35;hyaw=.1*sin(T*.7);
    aHL=.18;aHR=.18;aKL=.35;aKR=.35;bob=-.05;
  } else if(st>6.5){
    // 7/8 = locomotion. inst.x is the gait phase (radians, driven on the CPU from real ground speed), inst.z the speed in model units.
    // Feet are placed by two-bone IK on a planted-stance / swinging-foot cycle, so they never skate at any speed; walk blends smoothly into run.
    float G=inst.x,vm=inst.z;
    float k=sm(1.7,3.0,vm),ds=mix(.62,.36,k);
    float fc=max(max(mix(.78+.25*vm,.95+.15*vm,k),vm*ds),.4);
    float S=max(vm*ds/(2.*fc),.01),zr=S/(2.*ds);
    float uL=fract(G/6.2831853),uR=fract(uL+.5);
    float qq=fract(2.*uL+.5-ds),xx=abs(1.-2.*qq),zs=clamp(zr*(1.-2.*qq),-S,S),zn=zs/S;
    float Ls=mix(.92-.015*(1.-zn*zn),.9-.11*(1.-zn*zn),k);
    float tf=clamp((xx-2.*ds)/max(1.-2.*ds,.01),0.,1.),hop=.07*k*(1.-(1.-tf)*(1.-tf));
    float hd0=sqrt(max(Ls*Ls-zs*zs,.25))+hop;
    float lift=mix(.07,.24,k),fzL,fyL,fzR,fyR;
    foot(uL,S,ds,lift,hop,fzL,fyL);foot(uR,S,ds,lift,hop,fzR,fyR);
    float hh=smin(hd0,smin(fyL+sqrt(max(.819-fzL*fzL,.01)),fyR+sqrt(max(.819-fzR*fzR,.01)),.02),.02);   // never ask a leg to reach further than it can
    ik(hh,fyL,fzL,aHL,aKL);ik(hh,fyR,fzR,aHR,aKR);
    float Aa=mix(.5,.95,k);
    lean=mix(.04,.17,k);bob=hh-.92;sway=-mix(.02,.012,k)*cos(G-3.14159265*ds);hpit=-.7*lean;hyaw=.1*sin(G);
    skirt=.08*(1.-k)*sin(G);zL=mix(.04,.1,k);zR=zL;
    if(st>7.5){aSR=-2.75;aER=-.25;zR=.14;aSL=.6*Aa*fzL/S-.1;aEL=-.3;zL=.05;}
    else{aSL=Aa*fzL/S;aSR=Aa*fzR/S;aEL=mix(-.25,-1.25,k);aER=aEL;}
  } else if(st>5.5){
    float W=sin(T*8.5),C=cos(T*8.5);
    aHL=.85*W;aHR=-.85*W;aKL=1.1*max(0.,-C);aKR=1.1*max(0.,C);
    aSL=-.9*W;aSR=.9*W;aEL=-1.2;aER=-1.2;zL=.25;zR=.25;bob=.07*abs(C);sway=.03*W;lean=.14;hyaw=.2*sin(T*2.);
  }
  float b=bone;
  if(b<.5){}
  else if(b<1.5){rY(p,n,NK,hyaw);rX(p,n,NK,hpit);}
  else if(b<3.5){if(b<2.5){rX(p,n,SHL,aSL);rZ(p,n,SHL,-zL);}else{rX(p,n,SHR,aSR);rZ(p,n,SHR,zR);}}
  else if(b<5.5){if(b<4.5){rX(p,n,ELL,aEL);rX(p,n,SHL,aSL);rZ(p,n,SHL,-zL);}else{rX(p,n,ELR,aER);rX(p,n,SHR,aSR);rZ(p,n,SHR,zR);}}
  else if(b<7.5){if(b<6.5){rZ(p,n,HPL,zHL);rX(p,n,HPL,aHL);}else{rZ(p,n,HPR,zHR);rX(p,n,HPR,aHR);}}
  else if(b<9.5){if(b<8.5){rX(p,n,KNL,aKL);rZ(p,n,HPL,zHL);rX(p,n,HPL,aHL);}else{rX(p,n,KNR,aKR);rZ(p,n,HPR,zHR);rX(p,n,HPR,aHR);}}
  else if(b>10.5){rX(p,n,HPC,skirt);}
  if(b<5.5||b>9.5)rX(p,n,HPC,lean);
  p.y+=bob;p.x+=sway;
  float h=inst.w;
  vec3 skm=mix(vec3(.78,.76,.78),vec3(1.28,1.18,1.12),fract(h*7.13));
  vec3 clm=vec3(.9+.2*fract(h*3.7),.9+.2*fract(h*5.3),.9+.2*fract(h*2.9));
  vC=color.rgb*mix(skm,clm,color.a);
  mat4 W4=mat4(world0,world1,world2,world3);
  vec4 wp=W4*vec4(p,1.);
  vN=mat3(W4[0].xyz,W4[1].xyz,W4[2].xyz)*n;
#else
  vC=color.rgb;
  vec4 wp=world*vec4(p,1.);
  vN=mat3(world[0].xyz,world[1].xyz,world[2].xyz)*n;
#endif
  vUV=position.xy*1.5+position.zy*.7;
  vD=length(wp.xyz-camPos);vV=camPos-wp.xyz;
  gl_Position=viewProjection*wp;
}`;
  const FF = `precision highp float;varying vec3 vN;varying vec3 vC;varying vec2 vUV;varying float vD;varying vec3 vV;
uniform sampler2D tex;uniform vec3 toSun;uniform vec3 sunCol;uniform vec3 skyCol;uniform vec3 gndCol;uniform vec3 fogCol;uniform vec3 hazeCol;uniform float fogD;
void main(){
  vec3 alb=texture2D(tex,vUV).rgb*vC;
  vec3 N=normalize(vN);if(!gl_FrontFacing)N=-N;
  float ndl=dot(N,toSun);
  float band=.5*smoothstep(-.02,.1,ndl)+.5*smoothstep(.30,.45,ndl);
  float lit=mix(band,clamp(ndl,0.,1.),.25);
  vec3 hemi=mix(gndCol,skyCol,N.y*.5+.5);
  vec3 col=alb*(hemi+sunCol*lit);
  col=mix(col,col*vec3(.80,.74,1.),(1.-lit)*.45);
  float rim=pow(1.-clamp(dot(N,normalize(vV)),0.,1.),3.)*smoothstep(-.3,.5,ndl)*.22;
  col+=sunCol*alb*rim*1.2;
  col=mix(col,hazeCol,smoothstep(300.,1500.,vD)*.55);
  float f=1.-exp(-fogD*fogD*vD*vD);
  gl_FragColor=vec4(mix(col,fogCol,f),1.);
}`;

  function paintBrush(scene) {
    const B = BABYLON, S = 256, t = new B.DynamicTexture('folkBrush', { width: S, height: S }, scene, true), g = t.getContext();
    g.fillStyle = '#f1e9da'; g.fillRect(0, 0, S, S); g.lineCap = 'round';
    for (let i = 0; i < 700; i++) {
      const x = Math.random() * S, y = Math.random() * S, a = Math.random() * PI, l = 6 + Math.random() * 22, light = Math.random() < .5;
      g.strokeStyle = light ? 'rgba(255,252,240,.35)' : 'rgba(120,96,70,.18)'; g.lineWidth = 1.5 + Math.random() * 4;
      for (const dx of [-S, 0, S]) for (const dy of [-S, 0, S]) { g.beginPath(); g.moveTo(x + dx, y + dy); g.lineTo(x + dx + Math.cos(a) * l, y + dy + Math.sin(a) * l); g.stroke(); }
    }
    t.wrapU = t.wrapV = B.Texture.WRAP_ADDRESSMODE; t.anisotropicFilteringLevel = 2; t.update(); return t;
  }

  /* ======================= PLANNING (before trees/rocks scatter: reserves ground) ======================= */
  let World = null, H = null, markets = [], people = [];
  function plan(W) {
    World = W; H = W.height; markets = [];
    const S = W.settlements; if (!S || !S.sites) return markets;
    const comps = S.compounds, kops = ((window.OYOTerrain && OYOTerrain._t && OYOTerrain._t.kop) || []).filter(k => Math.max(Math.abs(k.x), Math.abs(k.z)) < 500);
    const edgeR = (x, z) => { const q = W.queryRoad(x, z); return q ? q.d - q.hw : 99; };
    const sEdge = (x, z) => W.siteEdge ? W.siteEdge(x, z) : 99;
    const villages = S.sites.filter(s => s.type === 'village').filter((s, i) => i % 4 === 1);
    const sites = S.sites.filter(s => s.type === 'town').concat(villages);
    const okAt = (x, z, R) => {
      if (Math.abs(x) > 380 || Math.abs(z) > 380) return -1;
      for (const k of kops) if (Math.hypot(k.x - x, k.z - z) < k.R * 1.3 + R + 4) return -1;
      for (const m of markets) if (Math.hypot(m.x - x, m.z - z) < m.R + R + 10) return -1;
      if (edgeR(x, z) < R * .5 || sEdge(x, z) < R * .5) return -1;
      let lo = H(x, z), hi = lo;
      for (let k = 0; k < 8; k++) { const a = TAU * k / 8, h = H(x + Math.cos(a) * R * .85, z + Math.sin(a) * R * .85); lo = Math.min(lo, h); hi = Math.max(hi, h); }
      if (hi - lo > 1.7) return -1;
      for (let k = 0; k < 16; k++) { const a = TAU * k / 16, px = x + Math.cos(a) * (R + 1), pz = z + Math.sin(a) * (R + 1); if (edgeR(px, pz) < 3.4 || sEdge(px, pz) < 2.4) return -1; }
      return hi - lo;
    };
    sites.forEach(site => {
      const big = site.type === 'town';
      for (const R of big ? [13, 11.5, 9.5] : [9.5, 8.5, 7.5]) {
        let best = null;
        for (let d = 0; d <= 70; d += d < 8 ? 8 : 9) for (let a = 0; a < (d ? 12 : 1); a++) {
          const an = a / 12 * TAU + d * .37, x = site.x + Math.cos(an) * d, z = site.z + Math.sin(an) * d, f = okAt(x, z, R); if (f < 0) continue;
          const sc = d + f * 8 + Math.abs(edgeR(x, z) - (R + 8)) * .35; if (!best || sc < best.sc) best = { x, z, sc };
        }
        if (!best) continue;
        const q = W.queryRoad(best.x, best.z), ea = q ? Math.atan2(q.road.x[q.i] - best.x, q.road.z[q.i] - best.z) : 0;
        const m = { x: best.x, z: best.z, R, big: R >= 10.5, ea, site, stalls: [] }; markets.push(m);
        comps.push({ x: m.x, z: m.z, yaw: 0, kind: 'round', a: R + 3.5, b: R + 3.5, rc: (R + 3.5) * .8, hidden: true });
        break;
      }
    });
    return markets;
  }

  /* ======================= BUILD ======================= */
  const archTris = {};
  const PROP = { farmA: 1, elder: 1, guard: 1 };
  const kindOf = (id, st) => id === 'boy' || id === 'girl' ? 'kid' : id === 'elder' ? 'elder' : id === 'guard' ? 'guard' : id === 'smith' ? 'smith' : id === 'farmA' || id === 'farmB' ? 'farmer' : st === 4 ? 'vendor' : /^w|^trdW/.test(id) ? 'woman' : 'man';
  const link = (a, b, type) => { if (a && b) { a.pr = b; b.pr = a; a.lead = true; a.pt = b.pt = type; } };
  function addP(id, x, z, yaw, st, extra) {
    if (PROP[id] && (st === 2 || st === 4)) st = 0;   // staff / spear / hoe carriers stand still instead of gesturing
    const p = Object.assign({ a: IX[id], k: kindOf(id, st), x, z, yaw, st, ph: rd() * 60, sp: .88 + rd() * .26, h: rd(), sc: id === 'boy' || id === 'girl' ? .62 + rd() * .06 : .95 + rd() * .1, y: H(x, z), w: null, vc: 0, vm: 0, gp: 0 }, extra || {});
    p.gp = p.ph; people.push(p); return p;
  }
  const walker = (wp, v, stM, stP, o) => Object.assign({ wp, i: 0, dir: 1, pause: 0, v, stM, stP, loop: false, kid: false }, o || {});

  function popMarket(m, stallPos) {
    const rw = m.big ? (3.9 + (m.R - 3.8)) / 2 : (m.R - 3.8) * .55;
    stallPos.forEach(s => {
      const cs = Math.cos(s.yaw), sn = Math.sin(s.yaw), L = (lx, lz) => [s.x + lx * cs + lz * sn, s.z - lx * sn + lz * cs];
      const tp = L(rr(-.6, .6), -.5), id = rd() < .68 ? pick(['wA', 'wB', 'wC', 'trdW']) : pick(['agC', 'agA', 'agB']);
      const vd = addP(/^w|^trdW/.test(id) ? 'wVnd' : 'vndM', tp[0], tp[1], s.yaw, 4);   // stall-keepers wear trader dress
      if (rd() < .72) { const cp = L(rr(-1, 1), 1.95), id2 = pick(['agA', 'chfA', 'agC', 'wA', 'wChf', 'wC', 'elder', 'boy', 'girl']); const cu = addP(id2, cp[0], cp[1], s.yaw + PI + rr(-.4, .4), rd() < .55 ? 2 : 0); link(vd, cu, 'trade'); }
    });
    if (m.big) { addP('wC', m.x - 1.2, m.z + 1.0, 2.2, 4); addP('elder', m.x + 1.4, m.z + .2, -1.4, 0); }
    const nW = m.big ? 4 : 2, dir = rd() < .5 ? 1 : -1, off = rd() * TAU;
    for (let k = 0; k < nW; k++) {
      const pts = []; for (let j = 0; j < 12; j++) { const a = off + dir * TAU * j / 12; pts.push([m.x + Math.sin(a) * rw, m.z + Math.cos(a) * rw]); }
      const id = pick(['trdW', 'trdM', 'farmB', 'trdW']), a0 = Math.floor(k * 12 / nW), p0 = pts[a0];
      const p = addP(id, p0[0], p0[1], 0, 3, {}); p.w = walker(pts, rr(.95, 1.15), 3, 2, { loop: true, i: (a0 + 1) % 12 });
    }
    for (let k = 0; k < (m.big ? 2 : 1); k++) {
      const pts = []; for (let j = 0; j < 5; j++) { const a = rd() * TAU, r = rw + rr(-.8, .8); pts.push([m.x + Math.sin(a) * r, m.z + Math.cos(a) * r]); }
      const p = addP(k ? 'girl' : 'boy', pts[0][0], pts[0][1], 0, 6); p.w = walker(pts, 2.1, 6, 6, { kid: true, i: 1 });
    }
  }

  function popCompounds(S) {
    for (const c of S.compounds) {
      if (c.hidden || !c.L) continue;
      const cs = Math.cos(c.yaw), sn = Math.sin(c.yaw), W2 = (lx, lz) => [c.x + lx * cs + lz * sn, c.z - lx * sn + lz * cs];
      const free = (lx, lz) => {
        if (c.kind === 'round') { if ((lx / (c.a - 2)) ** 2 + (lz / (c.b - 2)) ** 2 > 1) return false; }
        else if (Math.abs(lx) > c.a - 1.9 || Math.abs(lz) > c.b - 1.9) return false;
        for (const q of c.L) if (Math.hypot(q.x - lx, q.z - lz) < q.r + 1.1) return false;
        return true;
      };
      const spots = []; for (let t = 0; t < 60 && spots.length < 8; t++) { const lx = rr(-c.a, c.a), lz = rr(-c.b, c.b * .8); if (free(lx, lz)) spots.push([lx, lz]); }
      if (spots.length < 2) continue;
      const farm = c.site && c.site.type === 'farm', r = rd(), A = spots[0];
      if (farm) {
        const w = W2(A[0], A[1]); addP('farmA', w[0], w[1], rd() * TAU, 5).cmp = c;
        if (rd() < .5) { const w2 = W2(spots[1][0], spots[1][1]); addP(pick(WOMEN.slice(0, 3)), w2[0], w2[1], rd() * TAU, 0); }
      } else if (r < .42) {
        const an = rd() * TAU, bl = [A[0] + Math.sin(an) * 1.2, A[1] + Math.cos(an) * 1.2];
        if (free(bl[0], bl[1])) {
          const wa = W2(A[0], A[1]), wb = W2(bl[0], bl[1]), ya = Math.atan2(wb[0] - wa[0], wb[1] - wa[1]);
          const pa = addP(pick(rd() < .5 ? WOMEN.slice(0, 3) : ['agA', 'agB', 'agC', 'elder']), wa[0], wa[1], ya, 2), pb = addP(pick(WOMEN.slice(0, 3).concat(['agB', 'agC'])), wb[0], wb[1], ya + PI, rd() < .6 ? 2 : 0); link(pa, pb, 'chat');
        }
      } else if (r < .8) {
        const k = rd(), w = W2(A[0], A[1]);
        if (k < .35) {
          const B2 = spots.slice(1).find(s => Math.hypot(s[0] - A[0], s[1] - A[1]) > 3);
          if (B2) { const w2 = W2(B2[0], B2[1]), p = addP(pick(['trdW', 'trdW', 'farmB']), w[0], w[1], 0, 3); p.w = walker([w, w2], 1.0, 3, 0, {}); }
        } else if (k < .6) addP(pick(WOMEN.slice(0, 3)), w[0], w[1], rd() * TAU, 0);
        else if (k < .8) addP(pick(['agA', 'agB', 'agC', 'farmA']), w[0], w[1], rd() * TAU, rd() < .5 ? 2 : 0);
        else addP('elder', w[0], w[1], rd() * TAU, 0);
      }
      if (rd() < .45) {
        const ks = spots.slice(1).map(s => W2(s[0], s[1])); if (ks.length >= 3) {
          const nk = rd() < .3 ? 2 : 1;
          for (let q = 0; q < nk; q++) { const p = addP(rd() < .5 ? 'boy' : 'girl', ks[q][0], ks[q][1], 0, 6); p.w = walker(ks, 2.0, 6, 6, { kid: true, i: (q + 1) % ks.length }); }
        }
      }
    }
  }

  function popPalace() {
    const P = window.OYOPalace && OYOPalace.site; if (!P || !P.G || !P.built) return;
    const fx = Math.sin(P.yaw), fz = Math.cos(P.yaw), lx = Math.cos(P.yaw), lz = -Math.sin(P.yaw), G = P.G;
    const at = (f, l) => [G[0] + fx * f + lx * l, G[1] + fz * f + lz * l];
    const ok = (p) => { const q = World.queryRoad(p[0], p[1]); return !q || q.d - q.hw > 2.4; };
    const put = (id, f, l, yaw, st) => { const p = at(f, l); if (ok(p)) return addP(id, p[0], p[1], yaw, st); return null; };
    put('guard', 6.2, -5.2, P.yaw, 0); put('guard', 6.2, 5.2, P.yaw, 0);
    const a = at(11, -8.5), b = at(11.2, -7.2); if (ok(a) && ok(b)) { link(addP('chfA', a[0], a[1], Math.atan2(b[0] - a[0], b[1] - a[1]), 2), addP('chfC', b[0], b[1], Math.atan2(a[0] - b[0], a[1] - b[1]), 2), 'chat'); }
    link(put('wChf', 14, 8.5, P.yaw + 2.6, 2), put('wAtt', 13.2, 7.4, P.yaw - .6, 0), 'chat');
    const w0 = at(7, -9.5), w1 = at(20, -9.5); if (ok(w0) && ok(w1)) { const p = addP('wAtt', w0[0], w0[1], P.yaw, 3); p.w = walker([w0, w1], 1.0, 3, 0, {}); }
    const e0 = at(8, 10), e1 = at(17, 10.5); if (ok(e0) && ok(e1)) { const p = addP('attM', e0[0], e0[1], P.yaw, 1); p.w = walker([e0, e1], 1.1, 1, 2, {}); }
    try { window.OYOPalaceCrew && OYOPalaceCrew({ P, at, put, addP, walker, link, ok }); } catch (e) { console.warn('Palace crew skipped:', e); }   // Stage 14: oyo-royal.js adds royal guards & attendants
  }

  /* ---- Stage 16: daily-life pass (runs last, on its own random stream, so every earlier placement stays exactly as it was) ----
     blacksmiths at forges · farmers working between spots on their farm · yam-porters on the farms · basket-women on compound paths ·
     idle neighbours paired into conversations. Everything stays inside compounds (never on a road), and walkers use the shared obstacle push-out. */
  function popCrafts(S) {
    const keep = sd; sd = 16057 + markets.length * 31;
    try {
      const roadOK = (x, z) => { const q = World.queryRoad(x, z); return !q || q.d - q.hw > 2.8; };
      const geo = c => {
        const cs = Math.cos(c.yaw), sn = Math.sin(c.yaw), W2 = (lx, lz) => [c.x + lx * cs + lz * sn, c.z - lx * sn + lz * cs], L2 = (x, z) => { const dx = x - c.x, dz = z - c.z; return [dx * cs - dz * sn, dx * sn + dz * cs]; };
        const free = (lx, lz, m) => {
          m = m || 1.1;
          if (c.kind === 'round') { if ((lx / (c.a - 2)) ** 2 + (lz / (c.b - 2)) ** 2 > 1) return false; } else if (Math.abs(lx) > c.a - 1.9 || Math.abs(lz) > c.b - 1.9) return false;
          for (const q of c.L) if (Math.hypot(q.x - lx, q.z - lz) < q.r + m) return false;
          const w = W2(lx, lz); return roadOK(w[0], w[1]);
        };
        const seg = (a, b, m) => { for (let t = 0; t <= 6; t++) { const u = t / 6; if (!free(a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, m)) return false; } return true; };
        return { W2, L2, free, seg };
      };
      const live = S.compounds.filter(c => !c.hidden && c.L), village = live.filter(c => !(c.site && c.site.type === 'farm')), farms = live.filter(c => c.site && c.site.type === 'farm');
      const pair = (c, g, lo, hi) => {           // two free points joined by a clear straight path
        for (let t = 0; t < 30; t++) {
          const a = [rr(-c.a, c.a), rr(-c.b, c.b)], an = rd() * TAU, d = rr(lo, hi), b = [a[0] + Math.sin(an) * d, a[1] + Math.cos(an) * d];
          if (g.free(a[0], a[1], 1.2) && g.free(b[0], b[1], 1.2) && g.seg(a, b, .9)) return [g.W2(a[0], a[1]), g.W2(b[0], b[1])];
        } return null;
      };
      // 1 · blacksmiths (a forge needs open ground: smith, anvil in front, hearth to his left, trough to his right)
      const cells = {}; let nSmith = 0;
      for (const c of village) {
        if (nSmith >= 5 || rd() > .4) continue; const cell = Math.round(c.x / 90) + ',' + Math.round(c.z / 90); if (cells[cell]) continue;
        const g = geo(c);
        for (let t = 0; t < 40; t++) {
          const lx = rr(-c.a, c.a), lz = rr(-c.b, c.b), ya = rd() * TAU, f = [Math.sin(ya), Math.cos(ya)], r = [Math.cos(ya), -Math.sin(ya)], w = g.W2(lx, lz);
          const pts = [[0, 0], [f[0] * 1.2, f[1] * 1.2], [f[0] * 2.2, f[1] * 2.2], [-r[0] * 1.2, -r[1] * 1.2], [r[0] * 1.3, r[1] * 1.3]], cu = [r[0] * 2.4, r[1] * 2.4];
          if (!pts.every(o => { const l = g.L2(w[0] + o[0], w[1] + o[1]); return g.free(l[0], l[1], .9); })) continue;
          const sm = addP('smith', w[0], w[1], ya, 4.75); sm.rs = true; cells[cell] = 1; nSmith++;
          const cl = g.L2(w[0] + cu[0], w[1] + cu[1]);
          if (rd() < .6 && g.free(cl[0], cl[1], .9)) link(sm, addP(rd() < .5 ? 'agB' : 'elder', w[0] + cu[0], w[1] + cu[1], ya - PI / 2 - .3, 0), 'smith');
          break;
        }
      }
      // 2 · farmers tend their plots: walk between work spots, stop and hoe at each
      people.slice().forEach(p => {
        if (p.a !== IX.farmA || !p.cmp || p.w || p.rl) return;
        const c = p.cmp, g = geo(c), pts = [[p.x, p.z]];
        for (let t = 0; t < 16 && pts.length < 4; t++) {
          const x = p.x + rr(-4.5, 4.5), z = p.z + rr(-4.5, 4.5), l = g.L2(x, z), last = pts[pts.length - 1];
          if (!g.free(l[0], l[1], 1.0) || Math.hypot(x - last[0], z - last[1]) < 2.2 || !g.seg(g.L2(last[0], last[1]), l, .8)) continue; pts.push([x, z]);
        }
        if (pts.length >= 3) { p.w = walker(pts, .62, 1, 5, {}); p.rs = true; }
      });
      // 3 · a farm hand carries yams across the farm; 4 · women with baskets walk the paths inside villages
      for (const c of farms) { if (rd() > .55) continue; const g = geo(c), pr = pair(c, g, 4.5, 9); if (pr) { const p = addP('farmB', pr[0][0], pr[0][1], 0, 3); p.w = walker(pr, .8, 3, 0, {}); p.rs = true; } }
      for (const c of village) { if (rd() > .3) continue; const g = geo(c), pr = pair(c, g, 4, 8); if (pr) { const p = addP('trdW', pr[0][0], pr[0][1], 0, 3); p.w = walker(pr, .85, 3, 0, {}); p.rs = true; } }
      // 5 · idle neighbours standing near one another turn to face each other and talk
      let np = 0; const idle = p => p.st === 0 && !p.w && !p.rl && !p.pr && !p.cr && p.k !== 'guard' && p.k !== 'kid' && p.k !== 'smith' && p.k !== 'vendor';
      const pool = people.filter(idle);
      for (const a of pool) {
        if (np >= 8 || !idle(a)) continue;
        let best = null, bd = 6.5; for (const b of pool) { if (b === a || !idle(b)) continue; const d = Math.hypot(a.x - b.x, a.z - b.z); if (d > 1.6 && d < bd) { bd = d; best = b; } }
        if (!best) continue;
        a.yaw = Math.atan2(best.x - a.x, best.z - a.z); best.yaw = a.yaw + PI;
        if (!PROP[ARCH[a.a].id]) a.st = 2; if (!PROP[ARCH[best.a].id] && rd() < .6) best.st = 2;
        link(a, best, 'chat'); np++;
      }
    } finally { sd = keep; }
  }

  function buildMarkets(scene, mats, stats) {
    const B = BABYLON, sun = World.sunDir, shx = -sun.x / sun.y, shz = -sun.z / sun.y, meshes = [], dAll = { p: [], c: [], i: [] };
    const types = ['yam', 'fruit', 'veg', 'cloth', 'pots', 'grain'];
    markets.forEach((m, mi) => {
      const G = Buf(), stallPos = [], Rs = m.R - 2.5, n = Math.max(5, Math.floor(TAU * Rs / 5.4)), a0 = rd() * TAU;
      let ti = (rd() * types.length) | 0;
      for (let k = 0; k < n; k++) {
        const al = a0 + TAU * k / n;
        if (Math.abs(angD(al, m.ea)) < .46 || Math.abs(angD(al, m.ea + PI)) < .46) continue;
        const sx = m.x + Math.sin(al) * Rs, sz = m.z + Math.cos(al) * Rs, yaw = al + PI, cs = Math.cos(yaw), sn = Math.sin(yaw);
        let gy = 1e9; for (const [lx, lz] of [[-1.6, -1.2], [1.6, -1.2], [-1.6, 1.1], [1.6, 1.1]]) gy = Math.min(gy, H(sx + lx * cs + lz * sn, sz - lx * sn + lz * cs));
        const type = types[ti++ % types.length], v0 = stall(G, type, type === 'cloth' || rd() < .22);
        xf(G, v0, sx, gy - .02, sz, yaw);
        softDisc(dAll, H, sx + shx * 1.6, sz + shz * 1.6, 2.7, 2.2, yaw, [.16, .09, .18], .42, 10, 2, .08);
        stallPos.push({ x: sx, z: sz, yaw }); stats.stalls++;
      }
      if (m.big) { const v0 = nv(G); pavilion(G); const gy = H(m.x, m.z); xf(G, v0, m.x, gy, m.z, m.ea + .4); softDisc(dAll, H, m.x + shx * 2, m.z + shz * 2, 4.4, 4.4, 0, [.16, .09, .18], .4, 14, 2, .08); }
      else {
        const gy = H(m.x, m.z); let v0 = nv(G);
        potM(G, -.6, 0, 0, 1.4, CLAY); potM(G, .2, 0, .5, 1.1, shade(CLAY, 1.1)); basketM(G, .7, 0, -.4, 1.4, 6, [[.95, .58, .1], [.9, .8, .2]]); ell(G, -.3, .2, -.7, .3, .22, .24, CREAM, 1, 0, 8, 5);
        xf(G, v0, m.x, gy, m.z, 0);
      }
      softDisc(dAll, H, m.x, m.z, m.R + 1.5, m.R + 1.5, 0, [.78, .56, .38], .8, 28, 5, .05);
      const mesh = new B.Mesh('market_' + mi, scene), vd = new B.VertexData(); vd.positions = G.p; vd.normals = G.n; vd.colors = G.c; vd.indices = G.i; vd.applyToMesh(mesh);
      mesh.material = mats.stat; mesh.isPickable = false; mesh.freezeWorldMatrix(); meshes.push(mesh); stats.tris += G.i.length / 3;
      m.stalls = stallPos; popMarket(m, stallPos);
    });
    const dm = new B.Mesh('market_ground', scene), dv = new B.VertexData(); dv.positions = dAll.p; dv.colors = dAll.c; dv.indices = dAll.i;
    const nrm = []; B.VertexData.ComputeNormals(dAll.p, dAll.i, nrm); dv.normals = nrm; dv.applyToMesh(dm);
    const gm = new B.StandardMaterial('marketGroundMat', scene); gm.specularColor = B.Color3.Black(); gm.disableLighting = true; gm.emissiveColor = new B.Color3(1, 1, 1); gm.backFaceCulling = false; gm.disableDepthWrite = true; gm.zOffset = -3;
    dm.material = gm; dm.hasVertexAlpha = true; dm.alphaIndex = 6; dm.isPickable = false; dm.freezeWorldMatrix();
    return meshes;
  }


  /* ======================= ROAD LIFE (Stage 11) =======================
     People going about their day along the roads: travellers (alone or in pairs), hawkers calling their wares, runners and
     children racing, villagers crossing the road (they wait for the rider), roadside gossips, traders, weeders and playing kids.
     Moving ones follow a road by arc-length `s` + a lateral offset `lat`; they step aside when the rider comes up behind. */
  const RP = { x: 0, z: 0, nx: 0, nz: 0, tx: 0, tz: 0, hw: 1.6 };
  function roadAt(r, s) {
    let lo = 0, hi = r.n - 1; s = clamp(s, 0, r.len);
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (r.s[m] < s) lo = m; else hi = m; }
    const t = clamp((s - r.s[lo]) / Math.max(.001, r.s[hi] - r.s[lo]), 0, 1), u = 1 - t;
    RP.x = r.x[lo] * u + r.x[hi] * t; RP.z = r.z[lo] * u + r.z[hi] * t;
    let a = r.nx[lo] * u + r.nx[hi] * t, b = r.nz[lo] * u + r.nz[hi] * t, l = Math.hypot(a, b) || 1; RP.nx = a / l; RP.nz = b / l;
    a = r.tx[lo] * u + r.tx[hi] * t; b = r.tz[lo] * u + r.tz[hi] * t; l = Math.hypot(a, b) || 1; RP.tx = a / l; RP.tz = b / l;
    RP.hw = r.fixedHW != null ? r.fixedHW : World.widthAt(r, lo) * .5;
  }
  /* ---- obstacle awareness: rocks, termite mounds and fallen branches (registered by missions.js after the world is built) ---- */
  const OCELL = 12, OS = []; let OBS = null;
  const okey = (ix, iz) => (ix + 500) * 2000 + (iz + 500);
  function gatherObs(x, z) {
    OS.length = 0; if (!OBS) return OS;
    const ix = Math.floor(x / OCELL), iz = Math.floor(z / OCELL);
    for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) { const l = OBS.get(okey(ix + a, iz + b)); if (l) for (let i = 0; i < l.length; i++) OS.push(l[i]); }
    return OS;
  }
  function pushOut(p, margin) {                                   // hard guarantee: nobody stands inside a rock
    if (!OBS) return; gatherObs(p.x, p.z);
    for (let it = 0; it < 3; it++) {                                // a few sweeps, so a chain of branch segments cannot squeeze anyone back in
      let moved = false;
      for (let i = 0; i < OS.length; i++) {
        const o = OS[i], dx = p.x - o.x, dz = p.z - o.z, d = Math.hypot(dx, dz), m = o.r + margin;
        if (d < m) { const k = d > .001 ? m / d : 0; if (k) { p.x = o.x + dx * k; p.z = o.z + dz * k; } else p.x = o.x + m; moved = true; }
      }
      if (!moved) break;
    }
  }
  function setObstacles(o) {
    OBS = new Map();
    for (let k = 0; k < o.x.length; k++) {
      if (!(o.k[k] >= 1)) continue;                              // 1: rocks / mounds, 2: fallen-branch segments (buildings are already avoided at placement)
      const e = { x: o.x[k], z: o.z[k], r: o.r[k] }, key = okey(Math.floor(e.x / OCELL), Math.floor(e.z / OCELL));
      (OBS.get(key) || OBS.set(key, []).get(key)).push(e);
    }
    for (const p of people) {
      if (!p.rs) continue;
      if (p.rl && p.rl.kind === 'cross') {                       // slide the crossing point along the road until the line is clear
        const L = p.rl;
        for (let it = 0; it < 4; it++) {
          roadAt(L.r, L.s); gatherObs(RP.x, RP.z); let moved = false;
          for (let i = 0; i < OS.length; i++) {
            const q = OS[i], dx = q.x - RP.x, dz = q.z - RP.z, along = dx * RP.tx + dz * RP.tz, lat = dx * RP.nx + dz * RP.nz;
            if (Math.abs(lat) < RP.hw + 1.9 + q.r + .5 && Math.abs(along) < q.r + 1.2) { L.s = clamp(L.s + (along >= 0 ? -1 : 1) * (q.r + 1.4 - Math.abs(along)), 26, L.r.len - 26); moved = true; break; }
          }
          if (!moved) break;
        }
      } else if (!p.rl) { pushOut(p, .8); if (p.w && p.w.wp) p.w.wp.forEach(w => { const t = { x: w[0], z: w[1] }; pushOut(t, .9); w[0] = t.x; w[1] = t.z; }); }
    }
  }
  function popRoads() {
    const W = World, PA = window.OYOPalace && OYOPalace.site, sEdge = (x, z) => W.siteEdge ? W.siteEdge(x, z) : 99;
    const inPalace = (x, z) => {
      if (!PA || !PA.a) return false;
      const dx = x - PA.x, dz = z - PA.z, sn = Math.sin(PA.yaw), cs = Math.cos(PA.yaw);
      return Math.abs(dx * cs - dz * sn) < PA.a + 8 && Math.abs(dx * sn + dz * cs) < PA.b + 8;
    };
    const nearJunction = (r, x, z) => { const q = W.queryRoad(x, z); return !!q && q.road !== r && q.d - q.hw < 4; };
    const side = () => rd() < .5 ? -1 : 1, carries = id => id === 'trdW' || id === 'trdM' || id === 'farmB';
    const WALKERS = ['trdW', 'trdM', 'farmB', 'wA', 'wB', 'wC', 'agA', 'agB', 'agC', 'farmA', 'elder'];
    const mk = (id, r, L) => {
      roadAt(r, L.s);
      const base = L.lane * (RP.hw * L.k + L.add) + (L.off || 0), yaw = Math.atan2(RP.tx * L.dir, RP.tz * L.dir);
      const p = addP(id, RP.x + RP.nx * base, RP.z + RP.nz * base, yaw, L.stM);
      p.rl = Object.assign({ r, pause: 0, lat: base, gt: rr(0, 12), stP: 0, run: false, endPause: 0, hawk: false, nextCall: rr(4, 12), add: 0 }, L);
      return p;
    };
    const edgeOK = (r, s, lat) => { roadAt(r, s); const x = RP.x + RP.nx * lat, z = RP.z + RP.nz * lat; return !inPalace(x, z) && sEdge(x, z) > 5 && !nearJunction(r, x, z) ? [x, z, RP.tx, RP.tz, RP.nx, RP.nz] : null; };
    const event = (r, s, roll) => {
      roadAt(r, s); if (inPalace(RP.x, RP.z) || nearJunction(r, RP.x, RP.z)) return;
      const hw = RP.hw, range = rr(70, 130), a0 = clamp(s - range / 2, 26, r.len - 56), a1 = clamp(a0 + range, a0 + 30, r.len - 26);
      const base = o => Object.assign({ s: rr(a0, a1), s0: a0, s1: a1, dir: rd() < .5 ? -1 : 1, lane: side(), k: .55, add: 0, v: 1.3, endPause: 3.5 }, o);
      if (roll < .26) {                                              // lone traveller, often with a load on the head
        const id = pick(WALKERS), p = mk(id, r, base({ stM: carries(id) ? 3 : 1, stP: 0 })); if (id !== 'elder') p.k = 'traveller';
        if (id === 'elder') p.rl.v = .8;
      } else if (roll < .34) {                                       // two travellers walking and talking together
        const b = base({ stM: 1, stP: 0, k: .35, v: 1.2 }), ia = pick(WOMEN.slice(0, 3)), ib = pick(['wA', 'wB', 'wC', 'agA', 'agB', 'agC']);
        const pa = mk(ia, r, Object.assign({}, b, { off: .5 })), pb = mk(ib, r, Object.assign({}, b, { off: -.5, s: b.s - b.dir }));
        pb.sp = pa.sp; pb.sc = pa.sc; pa.k = pb.k = 'traveller'; link(pa, pb, 'road');
      } else if (roll < .52) {                                       // hawker: walks the verge, stops now and then to cry his wares
        const id = pick(['trdW', 'trdM', 'farmB', 'trdW']), p = mk(id, r, base({ stM: 3, stP: 4, k: 1, add: 1.0, v: 1.0, hawk: true, endPause: 4 })); p.k = 'hawker';
      } else if (roll < .62) {                                       // runner: a child racing along, or a young man on an errand
        const id = rd() < .7 ? pick(['boy', 'girl', 'boy']) : 'agB', rg = rr(110, 190), b0 = clamp(s - rg / 2, 26, r.len - 56), b1 = clamp(b0 + rg, b0 + 30, r.len - 26);
        const p = mk(id, r, base({ s0: b0, s1: b1, s: rr(b0, b1), stM: 6, stP: 0, k: .25, v: 3.6, run: true, endPause: 1.5 })); if (id === 'agB') p.k = 'runner';
      } else if (roll < .78) {                                       // villager crossing the road (waits for the rider)
        const sd = side(), a = edgeOK(r, s, sd * (hw + 1.9)), b = edgeOK(r, s, -sd * (hw + 1.9)); if (!a || !b) return;
        const id = pick(['trdW', 'wA', 'wB', 'wC', 'farmB', 'agA', 'agC', 'boy', 'girl']);
        const p = addP(id, a[0], a[1], Math.atan2(-sd * a[4], -sd * a[5]), 0);
        p.rl = { r, kind: 'cross', s, side: sd, state: 'rest', t: rr(0, 6), v: 1.25, stM: carries(id) ? 3 : 1, stP: 0, gt: rr(0, 10), lat: sd * (hw + 1.9), rushed: false };
      } else if (roll < .86) {                                       // roadside gossips, or a hawker with a customer
        const sd = side(), a = edgeOK(r, s, sd * (hw + 2.6)), b = edgeOK(r, s + 1.3, sd * (hw + 2.6)); if (!a || !b) return;
        const ya = Math.atan2(b[0] - a[0], b[1] - a[1]);
        if (rd() < .35) { const pa = addP(pick(['trdW', 'trdM']), a[0], a[1], ya, 4), pb = addP(pick(WOMEN.slice(0, 3)), b[0], b[1], ya + PI, 2); pa.k = 'hawker'; link(pa, pb, 'trade'); }
        else { const pa = addP(pick(rd() < .5 ? WOMEN.slice(0, 3) : ['agA', 'agB', 'agC', 'elder']), a[0], a[1], ya, 2), pb = addP(pick(WOMEN.slice(0, 3).concat(['agB', 'agC'])), b[0], b[1], ya + PI, rd() < .6 ? 2 : 0); link(pa, pb, 'road'); }
      } else if (roll < .92) {                                       // farmer weeding the verge
        const sd = side(), a = edgeOK(r, s, sd * (hw + 3.4)); if (!a) return; addP('farmA', a[0], a[1], rd() * TAU, 5);
      } else {                                                       // children playing chase beside the road
        const sd = side(), c = edgeOK(r, s, sd * (hw + 4.8)); if (!c) return;
        const pts = []; for (let k = 0; k < 4; k++) { const x = c[0] + rr(-3.4, 3.4), z = c[1] + rr(-3.4, 3.4); if (sEdge(x, z) > 5) pts.push([x, z]); }
        if (pts.length < 3) return;
        for (let q = 0; q < 2; q++) { const p = addP(rd() < .5 ? 'boy' : 'girl', pts[q][0], pts[q][1], 0, 6); p.w = walker(pts, 2.0, 6, 6, { kid: true, i: (q + 1) % pts.length }); }
      }
    };
    W.roads.forEach(r => {
      if (r.len < 90) return;
      const per = r.cls === 'royal' ? 58 : r.cls === 'secondary' ? 76 : 100; let s = 34 + rr(0, 26);
      while (s < r.len - 34) { const roll = rd(), n0 = people.length; try { event(r, s, roll); } catch (e) { console.warn('Road life skipped one:', e); } for (let i = n0; i < people.length; i++) people[i].rs = true; s += per * rr(.7, 1.4); }
    });
  }
  /* ---- locomotion shared by every walking / running NPC (Stage 11c) ----
     Ground speed ramps up and down (no instant starts or stops), people turn to face where they are going before they set off, and the
     gait phase is advanced from the real ground speed, so legs and ground move together. The vertex shader (state 7 / 8) turns that
     phase + speed into planted-foot IK strides that blend smoothly from a walk into a full run. */
  const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  function gaitHz(vm) {                                             // cycles per second for a speed in model units; must match the shader
    const k = smooth(1.7, 3.0, vm), ds = .62 + (.36 - .62) * k, w = .78 + .25 * vm, r = .95 + .15 * vm;
    return Math.max(w + (r - w) * k, vm * ds, .4);
  }
  function locoMove(p, want, dt, carry, stP) {
    const v = p.vc, a = want > v ? (want > 2.2 ? 3.4 : 1.8) : (v > 2.2 ? 4.5 : 2.6);
    p.vc = v + clamp(want - v, -a * dt, a * dt);
    p.vm = p.vc / p.sc;
    if (p.vc > .12) { p.gp += TAU * gaitHz(p.vm) * dt; p.st = carry ? 8 : 7; } else p.st = stP === 6 ? 0 : stP;
  }
  function turnTo(p, hd, dt, rate) {                                // eased, rate-limited turn; returns the heading error before turning
    const e = angD(p.yaw, hd); p.yaw += clamp(e * Math.min(1, dt * 7), -rate * dt, rate * dt); return e;
  }
  const alignOf = e => clamp(1.25 - Math.abs(e), 0, 1);             // walk only once roughly facing the way you are going

  function roadStep(p, dt, now, rp, T) {
    const L = p.rl, r = L.r, kidSz = p.sc < .8;
    if (L.kind === 'cross') {
      roadAt(r, L.s); const hw = RP.hw, edge = hw + 1.9, dx = rp.x - RP.x, dz = rp.z - RP.z, d2 = dx * dx + dz * dz;
      let want = 0;
      const hd = Math.atan2(-L.side * RP.nx, -L.side * RP.nz);      // always facing across the road
      if (L.state === 'rest') {                                     // wait at the verge until the rider has gone by
        L.t -= dt;
        if (d2 < 225 && L.gt <= now) { L.gt = now + 18; talkSay(T, p, uniq(T, CROSSWAIT), now); }
        if (L.endless) { const al = (rp.x - RP.x) * RP.tx + (rp.z - RP.z) * RP.tz, spd = Math.max(8, Math.abs(rp.speed || 16)); if (L.t <= 0 && (al > 14 || (-al) / spd > (hw * 2 + 4) / (L.v * p.sp) + 3)) L.state = 'go'; }   // Endless Run: set off only when the rider has passed, or is too far back to reach the road before they are across
        else if (L.t <= 0 && d2 > 576) L.state = 'go';
        turnTo(p, hd, dt, 4.5);
      } else if (L.state === 'settle') {                            // past the far verge: run out of momentum, then rest
        turnTo(p, hd, dt, 4.5);
      } else {
        const rush = d2 < 400 && Math.abs(L.lat) < hw + .6;          // rider close while on the road → sprint for it
        if (rush && !L.rushed) { L.rushed = true; talkSay(T, p, uniq(T, CROSSRUSH), now); }
        want = rush ? (kidSz ? 3.7 : 4.4) * p.sp : L.v * p.sp;
        want *= alignOf(turnTo(p, hd, dt, rush ? 9 : 5));
      }
      locoMove(p, want, dt, L.stM === 3, L.stP);
      if (L.state === 'go' || L.state === 'settle') {
        L.lat -= L.side * p.vc * dt;                                 // moves on by its own momentum, so it never stops dead
        if (L.state === 'go' && L.side * L.lat <= -edge) L.state = 'settle';
        else if (L.state === 'settle' && p.vc < .05) { p.vc = 0; L.side = -L.side; L.state = 'rest'; L.t = rr(4, 10); L.rushed = false; }
      }
      p.x = RP.x + RP.nx * L.lat; p.z = RP.z + RP.nz * L.lat; if (OBS) pushOut(p, .35);
      return;
    }
    let moving = true;
    if (L.pause > 0) { L.pause -= dt; moving = false; }
    roadAt(r, L.s);
    const hw = RP.hw, dx = rp.x - p.x, dz = rp.z - p.z, d2 = dx * dx + dz * dz;
    if (moving && L.hawk && (L.nextCall -= dt) <= 0) { L.pause = 4 + Math.random() * 2; L.nextCall = 11 + Math.random() * 7; talkSay(T, p, uniq(T, SOLO.hawker), now); moving = false; }
    const cruise = L.v * p.sp * (kidSz ? .85 : p.sc), dEnd = L.dir > 0 ? L.s1 - L.s : L.s - L.s0;
    let want = moving ? Math.min(cruise, Math.sqrt(2 * 2.6 * Math.max(dEnd, 0)) + .3) : 0;   // slow down into the end of the beat
    let tgt = L.lane * (hw * L.k + L.add) + (L.off || 0);
    if (d2 < 144) { const rl = (rp.x - RP.x) * RP.nx + (rp.z - RP.z) * RP.nz; if (Math.abs(rl - L.lat) < 3.2) tgt = (L.lat >= rl ? 1 : -1) * (hw + 1.5); }   // step aside for the rider
    if (OBS) {                                                    // detour around rocks, mounds and branches ahead
      gatherObs(p.x, p.z);
      if (OS.length) {
        const look = 2 + cruise * .9 + p.vc * .4, fx = RP.tx * L.dir, fz = RP.tz * L.dir, lim = hw + 3;
        for (let pass = 0; pass < 4; pass++) {
          let hit = false;
          for (let i = 0; i < OS.length; i++) {
            const o = OS[i], ox = o.x - RP.x, oz = o.z - RP.z, along = ox * fx + oz * fz, olat = ox * RP.nx + oz * RP.nz, clear = o.r + .5;
            if (along < -(o.r + .5) || along > look + o.r || Math.abs(olat - tgt) >= clear) continue;
            const c1 = olat + clear, c2 = olat - clear, a = Math.abs(c1) <= lim, b = Math.abs(c2) <= lim;
            tgt = a && b ? (Math.abs(c1 - L.lat) <= Math.abs(c2 - L.lat) ? c1 : c2) : a ? c1 : b ? c2 : tgt; hit = true; break;
          }
          if (!hit) break;
        }
      }
    }
    // sideways drift is a smooth, speed-limited glide (never a snap), and the body faces the way it is actually travelling
    const lv0 = L.lv || 0, lvMax = d2 < 144 ? 2.4 : 1.1 + .25 * p.vc;
    let lv = lv0 + (clamp((tgt - L.lat) * 2.2, -lvMax, lvMax) - lv0) * Math.min(1, dt * 5);
    lv = lv0 + clamp(lv - lv0, -6 * dt, 6 * dt); L.lv = lv;
    const fwd = Math.max(p.vc, .8), hd = Math.atan2(RP.tx * L.dir * fwd + RP.nx * lv, RP.tz * L.dir * fwd + RP.nz * lv);
    const e = turnTo(p, hd, dt, p.vc > 2.2 ? 7 : 4.5);
    if (moving) want *= alignOf(e);
    locoMove(p, want, dt, L.stM === 3, L.stP);
    if (L.pause <= 0 && dEnd <= .06 && p.vc < .8) { L.s = L.dir > 0 ? L.s1 : L.s0; L.dir = -L.dir; L.pause = L.endPause; }
    else L.s = clamp(L.s + L.dir * p.vc * dt, L.s0, L.s1);
    roadAt(r, L.s); L.lat += lv * dt;
    p.x = RP.x + RP.nx * L.lat; p.z = RP.z + RP.nz * L.lat; if (OBS) pushOut(p, .35);
    if (d2 < 324 && L.gt <= now) { L.gt = now + 26 + Math.random() * 12; if (!p.say) talkSay(T, p, uniq(T, GREET[p.k] || GREET.any), now); }   // greet the rider
  }

  /* ===================== NPC DIALOGUE (Stage 8b) =====================
     Speech bubbles for nearby villagers: paired NPCs hold short back-and-forth conversations, everyone else
     mutters random lines. Bubbles are DOM overlays projected from each speaker's head (max 5 at once). */
  const NAME = { vendor: 'Trader', woman: 'Villager', man: 'Villager', elder: 'Elder', guard: 'Palace Guard', farmer: 'Farmer', kid: 'Child', walker: 'Traveller' };
  const SOLO = {
    vendor: ['Fresh yams! Come and see!', 'Pepper and tomatoes, best price!', 'Buy two, I add one free!', 'Ẹ káàbọ̀! Come and buy!', 'Sweet oranges! Sweet oranges!', 'Cloth from Ilorin, very fine!', "Eh! Don't pass without buying!"],
    woman: ['The sun is hot today.', 'Ẹ káàbọ̀!', 'Have you eaten?', 'The market will be full today.', 'Where has that child run to again?', 'I think the rain will come soon.'],
    man: ['Ẹ kú àárọ̀!', 'The road to the palace is long.', 'Our horses are the best in the land.', 'I must reach the market before noon.', "The Alaafin's messengers ride fast."],
    elder: ['Patience is the father of good character.', 'A river that forgets its source will dry up.', 'The road does not forget a traveller.', 'In my day the road was longer!', 'Ẹ ṣé, my child.'],
    guard: ["Halt! This is the Alaafin's palace.", 'Move along, rider.', 'All is calm at the gate.', 'Messengers may pass.', 'Keep your horse off the palace ground.'],
    farmer: ['The yams are doing well.', 'Ẹ kú iṣẹ́!', 'The rains were kind this year.', 'Hard work feeds the household.', 'My hoe is tired today.'],
    kid: ['Catch me if you can!', 'Look, a horse!', 'Mama, I am hungry!', 'Race you to the tree!', 'Ẹ káàbọ̀, Messenger!', 'Can I ride your horse?'],
    walker: ['Going to the market.', 'Ẹ pẹ̀lẹ́ o, Messenger.', 'Heavy load today.', 'Is the road clear ahead?', 'Make way, please!']
  };
  const CONVO = {
    trade: [
      ['How much for this basket?', 'Forty cowries!', 'Ah! Reduce small.', 'For you, thirty. Last price.'],
      ['What do you have today?', 'Fresh pepper and sweet yams.', "I'll take both.", 'Ẹ ṣé! Come again.'],
      ['Is this cloth really from Ilorin?', 'Yes, woven by my own mother.', 'Then wrap me two.', 'May it serve you well.']
    ],
    chat: [
      ["Have you heard? The Alaafin's messenger rides today.", 'Ah! Then the road will be busy.', 'Let us hope the horses are fed.', 'May Ṣàngó guide him.'],
      ['Ẹ kú àárọ̀! How is the family?', 'We are well, thank God. And yours?', 'The harvest was kind to us.', 'Then we are blessed.'],
      ['Did you see the new horses at the palace?', 'Strong as lions, I hear.', 'The Alaafin spares nothing.', 'Long live the Alaafin!']
    ]
  };
  Object.assign(NAME, { hawker: 'Hawker', runner: 'Runner', traveller: 'Traveller' });
  SOLO.hawker = ['Kola nuts! Fresh kola nuts!', 'Roasted corn! Hot roasted corn!', 'Palm wine, sweet and cold!', 'Salt from the coast! Who will buy?', 'Bean cakes, still warm!', 'Clay pots! Strong pots for your kitchen!', 'Honey! Pure forest honey!', 'Dried fish! Twenty cowries a bundle!', 'Ẹ káàbọ̀! Come and see my wares!'];
  SOLO.traveller = SOLO.walker.concat(['The road to Ọ̀yọ́ is long.', 'My feet are tired, but the market waits.', 'I carry salt for the market.', 'Safe journey to you!']);
  SOLO.runner = ['Make way! Message for the chief!', 'I must reach the village before dark!', 'Run, run, run!', 'No time to talk!'];
  const GREET = {
    any: ['Ẹ pẹ̀lẹ́ o, Messenger!', 'Safe road, rider!', 'May Ṣàngó guide your horse!', 'The Alaafin’s rider! Make way!', 'Ẹ káàbọ̀, Messenger!'],
    hawker: ['Ẹ káàbọ̀, rider! Buy something for the road!', 'Messenger! Cold palm wine for your thirst?', 'Fresh kola, Messenger! Only for you!'],
    runner: ['Race you, Messenger!', 'You cannot outrun me!', 'Make way, make way!'],
    kid: ['Look, the Messenger! Ẹ káàbọ̀!', 'Can I ride your horse?', 'Faster, horse, faster!'],
    elder: ['Ride well, my child.', 'The road remembers every rider.', 'Ẹ ṣé, Messenger.'],
    traveller: ['Ẹ pẹ̀lẹ́ o, rider!', 'Is the road clear ahead?', 'Go well, Messenger!', 'Make way for the horse!']
  };
  const CROSSWAIT = ['After you, rider!', 'Ride on, I will wait.', 'Ẹ pẹ̀lẹ́ o! Go ahead.', 'Let the horse pass first.'];
  const CROSSRUSH = ['Ah! Watch the horse!', 'Ẹ jọ̀wọ́! I am crossing!', 'Eh! Mind me, Messenger!', 'Ṣé kí o rọra!'];
  CONVO.road = [
    ['Ẹ kú àárọ̀! Where are you going?', 'To the market, with these yams.', 'Then walk with me; the road is long.', 'Gladly! Good company makes it short.'],
    ['I heard thieves on the northern path.', "The Alaafin's guards will deal with them.", 'Still, keep your cowries close.', 'I tie them in my wrapper, always.'],
    ['Did you see the royal horse pass?', 'Fast as the wind! He did not stop.', 'The Alaafin must have urgent news.', 'May the road be kind to him.'],
    ['My feet are tired from this road.', 'Rest a little under that tree.', 'But the market will not wait.', 'Then let us go together.'],
    ['The rains are late this year.', 'Ṣàngó will send them in time.', 'Let us pray the yams hold.', 'Ẹ ṣé. We shall see.']
  ];
  NAME.smith = 'Blacksmith';
  SOLO.smith = ['Hot iron waits for no one.', 'A good hoe feeds a whole family.', 'Ògún guides my hammer.', 'Cutlasses, hoes, arrow-heads, I make them all.', 'Pass me the charcoal!', 'Strike while the iron glows.'];
  GREET.smith = ['Ẹ káàbọ̀, Messenger! Need your horse’s shoes… er, a new blade?', 'Ògún bless your road, rider!', 'Mind the sparks, Messenger!'];
  CONVO.smith = [
    ['Ẹ kú iṣẹ́! Is the hoe ready?', 'Almost. The iron must glow once more.', 'The rains are near; I need it soon.', 'Ògún willing, by tomorrow.'],
    ['How much for a new cutlass?', 'Twenty strings of cowries, no less.', 'Ah! The iron is dear this season.', 'Good iron, good price. Come back at dusk.'],
    ['These arrowheads are fine work.', 'The Alaafin’s hunters order them by the hundred.', 'Then your hammer will never rest.', 'May Ògún keep it so.']
  ];
  const TALK_R2 = 34 * 34, MAX_BUB = 5, rpick = a => a[(Math.random() * a.length) | 0], uniq = (T, a) => { const used = new Set(); T.talking.forEach(q => { if (q.say) used.add(q.say.text); }); T.events.forEach(e => used.add(e.text)); const f = a.filter(t => !used.has(t)); return rpick(f.length ? f : a); }, dur = t => 2.3 + t.length * .045;
  const nameOf = p => p.nm || (p.k === 'kid' ? NAME.kid : (p.w && !p.w.kid && p.k !== 'farmer' && p.k !== 'vendor') ? NAME.walker : NAME[p.k] || 'Villager');
  function makeTalk(scene) {
    const B = BABYLON, eng = scene.getEngine(), cv = eng.getRenderingCanvas();
    let root = document.getElementById('npcTalk');
    if (!root) { root = document.createElement('div'); root.id = 'npcTalk'; document.body.appendChild(root); }
    root.innerHTML = '';
    const pool = []; for (let i = 0; i < MAX_BUB; i++) {
      const d = document.createElement('div'); d.className = 'npc-bub'; d.innerHTML = '<b></b><span></span>'; root.appendChild(d);
      pool.push({ d, n: d.firstChild, t: d.lastChild, key: '' });
    }
    return { root, pool, B, eng, cv, scene, events: [], talking: [] };
  }
  const endlessOn = () => { const E = window.OYO && OYO.endless; return !!(E && E.on); };   // Endless Run: only SOME ambient NPCs (p.bub) talk; riders + passengers are always forced
  // Pause: every bubble is hidden while the game is paused (they come back, unchanged, on resume)
  const gamePaused = () => { const O = window.OYO, h = O && O.hud, E = O && O.endless, M = O && O.mission; return !!((h && h.screen === 'epause') || (E && E.on && E.paused) || (M && M.paused)); };
  function talkSay(T, p, text, now, force) {
    if (endlessOn() && !force && !p.bub) return;
    p.say = { text, until: now + dur(text) }; if (T.talking.indexOf(p) < 0) T.talking.push(p);
  }
  function talkTick(T, near, now) {
    // fire scheduled conversation lines
    for (let i = T.events.length - 1; i >= 0; i--) { const e = T.events[i]; if (e.at <= now) { talkSay(T, e.p, e.text, now); T.events.splice(i, 1); } }
    // expire finished lines
    for (let i = T.talking.length - 1; i >= 0; i--) { const p = T.talking[i]; if (!p.say || p.say.until <= now) { p.say = null; T.talking.splice(i, 1); } }
    // start new talk for nearby people
    for (let i = 0; i < near.length; i++) {
      const p = near[i]; if (p.busy > now) continue;
      if (endlessOn() && !p.bub) continue;                                 // Endless Run: only the chosen walkers / standers chat
      if (p.tk === undefined) p.tk = now + 1 + Math.random() * 8;
      if (p.tk > now) continue;
      if (T.talking.length + T.events.length > 7) { p.tk = now + 2; continue; }
      if (p.pr) {
        if (!p.lead) { p.tk = now + 4; continue; }
        const q = p.pr, cv = CONVO[p.pt] || CONVO.chat, usedL = new Set(); T.talking.forEach(x => { if (x.say) usedL.add(x.say.text); }); T.events.forEach(e => usedL.add(e.text)); const fr = cv.filter(c => !c.some(l => usedL.has(l))), sc = rpick(fr.length ? fr : cv); let t = now;
        sc.forEach((line, k) => { const who = k % 2 ? q : p; if (k === 0) talkSay(T, who, line, t); else T.events.push({ at: t, p: who, text: line }); t += dur(line) + .5; });
        p.busy = q.busy = t + 4 + Math.random() * 8; p.tk = q.tk = p.busy;
      } else {
        const pool = (p.w && !p.w.kid && p.k !== 'farmer' && p.k !== 'vendor') ? SOLO.walker : SOLO[p.k] || SOLO.man;
        talkSay(T, p, uniq(T, pool), now); p.tk = now + 7 + Math.random() * 9;
      }
    }
  }
  // Menu screens (title / mission select / briefing) play the cinematic Royal Road tour as a hero clip: no NPC bubbles there.
  const onMenu = () => { const h = window.OYO && OYO.hud; return !!h && (h.screen === 'title' || h.screen === 'select' || h.screen === 'brief' || h.screen === 'eover'); };
  function talkClear(T) {
    if (T.events.length) T.events.length = 0;
    for (let i = T.talking.length - 1; i >= 0; i--) T.talking[i].say = null;
    T.talking.length = 0;
    for (const slot of T.pool) if (slot.key) { slot.d.style.opacity = 0; slot.key = ''; }
  }
  function talkDraw(T, cp) {
    if (onMenu()) { talkClear(T); return; }
    const paused = gamePaused(); T.root.style.visibility = paused ? 'hidden' : 'visible';
    if (paused) return;                                                    // pause menu: no NPC bubbles on top of it
    const B = T.B, eng = T.eng, sc = T.scene, cam = sc.activeCamera; if (!cam) return;
    const RW = eng.getRenderWidth(), RH = eng.getRenderHeight(), k = T.cv.clientWidth / RW, vp = cam.viewport.toGlobal(RW, RH), tm = sc.getTransformMatrix();
    const list = [];
    for (const p of T.talking) {
      const dx = p.x - cp.x, dz = p.z - cp.z, d2 = dx * dx + dz * dz; if (d2 > TALK_R2) continue;
      const s = B.Vector3.Project(new B.Vector3(p.x, p.y + 2.05 * p.sc, p.z), B.Matrix.IdentityReadOnly, tm, vp);
      if (s.z < 0 || s.z > 1) continue; const X = s.x * k, Y = s.y * k; if (X < -40 || Y < -20 || X > T.cv.clientWidth + 40 || Y > T.cv.clientHeight) continue;
      list.push({ p, X, Y, d2 });
    }
    list.sort((a, b) => a.d2 - b.d2);
    const CW = T.cv.clientWidth, narrow = window.innerWidth <= 480, GAP = 5, placed = [];     // nearest speaker keeps its spot; anyone it would cover is lifted above it
    for (let i = 0; i < MAX_BUB; i++) {
      const slot = T.pool[i], it = list[i];
      if (!it) { if (slot.key) { slot.d.style.opacity = 0; slot.key = ''; } continue; }
      const key = it.p.say.text + '|' + nameOf(it.p);
      if (slot.key !== key) { slot.n.textContent = nameOf(it.p); slot.t.textContent = it.p.say.text; slot.key = key; slot.w = 0; }
      if (!slot.w || slot.nw !== narrow) { slot.w = slot.d.offsetWidth || 120; slot.h = slot.d.offsetHeight || 36; slot.nw = narrow; }
      const hw = slot.w / 2, X = Math.max(hw + 4, Math.min(CW - hw - 4, it.X)); let yb = it.Y - 6, ok = true;
      for (let n = 0; n < 14; n++) {                                       // bubble box = body + its 7px tail; slide up past every bubble it touches
        const t = yb - slot.h, b = yb + 7; let hit = null;
        for (const r of placed) if (X - hw < r.x1 + GAP && X + hw > r.x0 - GAP && t < r.b + GAP && b > r.t - GAP) { if (!hit || r.t < hit.t) hit = r; }
        if (!hit) break; yb = hit.t - GAP - 7; if (n === 13) ok = false;
      }
      if (yb - slot.h < 2) ok = false;                                     // no room left above on screen: stay hidden rather than cover another bubble
      const dist = Math.sqrt(it.d2), a = Math.max(0, Math.min(1, (34 - dist) / 12)), life = Math.min(1, (it.p.say.until - clockNow) * 4);
      slot.d.style.opacity = ok ? (a * Math.max(0, life)).toFixed(2) : 0;
      slot.d.style.transform = 'translate(' + X.toFixed(1) + 'px,' + yb.toFixed(1) + 'px) translate(-50%,-100%)';
      if (ok) placed.push({ x0: X - hw, x1: X + hw, t: yb - slot.h, b: yb + 7 });
    }
  }
  let clockNow = 0, TALK = null;   // TALK: shared speech-bubble system (roam-fare.js speaks through OYOVillagers.say)
  function build(scene, W) {
    World = W; H = (x, z) => W.height(x, z); const B = BABYLON, stats = { markets: markets.length, stalls: 0, people: 0, tris: 0, archetypes: ARCH.length };
    people = []; sd = 6061 + markets.length;
    const tex = paintBrush(scene), fogC = new B.Vector3(scene.fogColor.r, scene.fogColor.g, scene.fogColor.b);
    B.Effect.ShadersStore.oyoFolkVertexShader = FV; B.Effect.ShadersStore.oyoFolkFragmentShader = FF;
    const mkMat = (name, inst) => {
      const m = new B.ShaderMaterial(name, scene, { vertex: 'oyoFolk', fragment: 'oyoFolk' }, {
        attributes: inst ? ['position', 'normal', 'color', 'bone', 'inst'] : ['position', 'normal', 'color'],
        uniforms: ['world', 'viewProjection', 'time', 'camPos', 'toSun', 'sunCol', 'skyCol', 'gndCol', 'fogCol', 'hazeCol', 'fogD'], samplers: ['tex']
      });
      m.setTexture('tex', tex); m.setVector3('toSun', W.sunDir); m.setVector3('sunCol', new B.Vector3(.85, .73, .53)); m.setVector3('skyCol', new B.Vector3(.58, .54, .47));
      m.setVector3('gndCol', new B.Vector3(.42, .27, .2)); m.setVector3('fogCol', fogC); m.setVector3('hazeCol', new B.Vector3(.93, .84, .64)); m.setFloat('fogD', scene.fogDensity);
      m.setFloat('time', 0); m.setVector3('camPos', new B.Vector3(0, 0, 0)); m.backFaceCulling = false;
      m.onError = (e, errs) => console.warn('Folk shader error', errs); return m;
    };
    const mats = { stat: mkMat('folkStatic', false), inst: mkMat('folkInst', true) };

    buildMarkets(scene, mats, stats);
    const S = W.settlements;
    if (S && S.compounds) popCompounds(S);
    popPalace();
    try { popRoads(); } catch (e) { console.warn('Road life skipped:', e); }
    try { if (S && S.compounds) popCrafts(S); } catch (e) { console.warn('Daily-life pass skipped:', e); }   // Stage 16
    try { EL.reserve(); } catch (e) { console.warn('Endless pool skipped:', e); }   // Stage 24: spare villagers lent to Endless Run
    stats.people = people.length;

    // archetype meshes (thin-instanced, shader-animated)
    const cap = ARCH.map(() => 0); people.forEach(p => cap[p.a]++);
    const M = ARCH.map((a, i) => ({ arr: new Float32Array(Math.max(1, cap[i]) * 16), inst: new Float32Array(Math.max(1, cap[i]) * 4), mesh: null, n: 0 }));
    ARCH.forEach((a, i) => {
      if (!cap[i]) return;
      const G = person(a.o), mesh = new B.Mesh('folk_' + a.id, scene), vd = new B.VertexData();
      vd.positions = G.p; vd.normals = G.n; vd.colors = G.c; vd.indices = G.i; vd.applyToMesh(mesh); mesh.setVerticesData('bone', new Float32Array(G.b), false, 1);
      mesh.material = mats.inst; mesh.isPickable = false; mesh.alwaysSelectAsActiveMesh = true;
      mesh.thinInstanceSetBuffer('matrix', M[i].arr, 16, false); mesh.thinInstanceSetBuffer('inst', M[i].inst, 4, false); mesh.thinInstanceCount = 0;
      M[i].mesh = mesh; archTris[a.id] = G.i.length / 3; stats.tris += (G.i.length / 3) * Math.min(cap[i], 60);
    });
    // soft blob shadows under every person (1 draw call)
    const SD = { p: [0, 0, 0], c: [.1, .06, .12, .5], i: [] }; for (let k = 0; k < 10; k++) { const a = TAU * k / 10; SD.p.push(Math.cos(a), 0, Math.sin(a)); SD.c.push(.1, .06, .12, 0); SD.i.push(0, 1 + k, 1 + (k + 1) % 10); }
    const sm = new B.Mesh('folk_shadow', scene), sv = new B.VertexData(); sv.positions = SD.p; sv.colors = SD.c; sv.indices = SD.i; sv.normals = SD.p.map((v, i) => i % 3 === 1 ? 1 : 0); sv.applyToMesh(sm);
    const smat = new B.StandardMaterial('folkShadowMat', scene); smat.disableLighting = true; smat.emissiveColor = new B.Color3(1, 1, 1); smat.backFaceCulling = false; smat.disableDepthWrite = true; smat.zOffset = -4;
    sm.material = smat; sm.hasVertexAlpha = true; sm.alphaIndex = 9; sm.isPickable = false; sm.alwaysSelectAsActiveMesh = true;
    const SM = new Float32Array(Math.max(1, people.length) * 16); sm.thinInstanceSetBuffer('matrix', SM, 16, false); sm.thinInstanceCount = 0;

    // per-frame: advance walkers, cull by distance, write matrices
    const CULL2 = 240 * 240, near = []; let clock = 0, fr = 0; const T = makeTalk(scene); TALK = T;
    scene.onBeforeRenderObservable.add(() => {
      const paused = !!(window.OYO && OYO.mission && OYO.mission.paused), dt = paused ? 0 : Math.min(.05, scene.getEngine().getDeltaTime() / 1000), cam = scene.activeCamera; if (!cam) return; clock += dt; fr++;
      const pl = window.OYO && OYO.core && OYO.core.P, rp = pl && isFinite(pl.x) ? pl : cam.position;
      const cp = cam.position; mats.inst.setFloat('time', clock); mats.inst.setVector3('camPos', cp); mats.stat.setVector3('camPos', cp);
      for (let i = 0; i < M.length; i++) M[i].n = 0; let ns = 0; near.length = 0;
      for (let k = 0; k < people.length; k++) {
        const p = people[k]; if (p.hide) continue; const dx = p.x - cp.x, dz = p.z - cp.z; if (dx * dx + dz * dz > CULL2) continue;
        if (dx * dx + dz * dz < TALK_R2) near.push(p);
        if (p.cr) p.cr(p);   // roam-fare.js: carried passenger rides the horse
        else if ((p.rl || p.w) && dx * dx + dz * dz > 14400 && ((fr + k) % 3)) p.ac = (p.ac || 0) + dt;   // far away (>120 m): simulate every third frame only
        else if (p.rl) { const sdt = Math.min(.15, dt + (p.ac || 0)); p.ac = 0; roadStep(p, sdt, clock, rp, T); p.y = H(p.x, p.z); }
        else if (p.w) { const sdt = Math.min(.15, dt + (p.ac || 0)); p.ac = 0; step(p, sdt); if (p.rs && OBS) pushOut(p, .35); p.y = H(p.x, p.z); }
        const m = M[p.a], o = m.n++ * 16, c = Math.cos(p.yaw), s = Math.sin(p.yaw), sc = p.sc, a = m.arr;
        a[o] = sc * c; a[o + 1] = 0; a[o + 2] = -sc * s; a[o + 3] = 0; a[o + 4] = 0; a[o + 5] = sc; a[o + 6] = 0; a[o + 7] = 0;
        a[o + 8] = sc * s; a[o + 9] = 0; a[o + 10] = sc * c; a[o + 11] = 0; a[o + 12] = p.x; a[o + 13] = p.y; a[o + 14] = p.z; a[o + 15] = 1;
        const io = (m.n - 1) * 4, ia = m.inst; const lo = p.st > 6.5; ia[io] = lo ? p.gp : p.ph; ia[io + 1] = p.st; ia[io + 2] = lo ? p.vm : p.sp; ia[io + 3] = p.h;
        const so = ns++ * 16, r = p.cr && !p.cr.stand ? 0 : .5 * sc + .12;   // roam-fare.js: seated passengers have no shadow of their own SM[so] = r; SM[so + 1] = 0; SM[so + 2] = 0; SM[so + 3] = 0; SM[so + 4] = 0; SM[so + 5] = 1; SM[so + 6] = 0; SM[so + 7] = 0;
        SM[so + 8] = 0; SM[so + 9] = 0; SM[so + 10] = r; SM[so + 11] = 0; SM[so + 12] = p.x; SM[so + 13] = p.y + .06; SM[so + 14] = p.z; SM[so + 15] = 1;
      }
      for (let i = 0; i < M.length; i++) { const m = M[i]; if (!m.mesh) continue; m.mesh.thinInstanceCount = m.n; m.mesh.setEnabled(m.n > 0); if (m.n) { m.mesh.thinInstanceBufferUpdated('matrix'); m.mesh.thinInstanceBufferUpdated('inst'); } }
      sm.thinInstanceCount = ns; sm.setEnabled(ns > 0); if (ns) sm.thinInstanceBufferUpdated('matrix');
      clockNow = clock; if (onMenu()) talkClear(T); else if (!gamePaused()) talkTick(T, near, clock);
    });
    scene.onAfterRenderObservable.add(() => { const c = scene.activeCamera; if (c) talkDraw(T, c.position); });
    function step(p, dt) {
      const w = p.w;
      if (w.pause > 0) w.pause -= dt;
      const t = w.wp[w.i], dx = t[0] - p.x, dz = t[1] - p.z, d = Math.hypot(dx, dz);
      if (w.pause <= 0 && d < .3) {
        if (w.kid) w.i = (Math.random() * w.wp.length) | 0;
        else if (w.loop) w.i = (w.i + 1) % w.wp.length;
        else { if (w.i >= w.wp.length - 1) w.dir = -1; else if (w.i <= 0) w.dir = 1; w.i += w.dir; w.pause = 1.5 + Math.random() * 3.5; }
      }
      let want = 0;
      if (w.pause <= 0) {
        const e = turnTo(p, Math.atan2(dx, dz), dt, w.kid ? 9 : 5);
        want = w.v * alignOf(e);
        if (!w.loop && !w.kid) want = Math.min(want, Math.sqrt(2 * 2.6 * d) + .3);   // ease into the end of the beat
      }
      locoMove(p, want, dt, w.stM === 3, w.stP);
      p.x += Math.sin(p.yaw) * p.vc * dt; p.z += Math.cos(p.yaw) * p.vc * dt;
    }
    return stats;
  }

  function paintMap(g, k, half) {
    g.save(); g.lineWidth = 1.2;
    markets.forEach(m => { const X = (m.x + half) * k, Y = (half - m.z) * k, s = m.big ? 3.6 : 2.8; g.fillStyle = '#e0892c'; g.strokeStyle = '#2a170d'; g.beginPath(); g.arc(X, Y, s, 0, TAU); g.fill(); g.stroke(); });
    g.restore();
  }


  /* ===================== STAGE 24 · ENDLESS RUN SUPPORT =====================
     A reserve of ordinary villagers (same archetypes, shader animation, speech bubbles and road-crossing behaviour as Free Roam / missions) that
     endless.js borrows: spawn() takes one out of the pool, release() puts it back. Pool people are hidden (p.hide) until borrowed. */
  const EL = (function () {
    const IDS = ['wA', 'wB', 'wC', 'trdW', 'agA', 'agC', 'farmB', 'agB', 'boy', 'girl'], PER = 22, free = [], spk = []; let road = null;
    function reserve() { IDS.forEach(id => { for (let q = 0; q < PER; q++) { const p = addP(id, 1e5, 1e5, 0, 0); p.hide = true; p.pool = true; p.rs = false; free.push(p); } });
      ['guard', 'farmA', 'vndM', 'wVnd', 'trdM'].forEach(id => { for (let q = 0; q < 6; q++) { const p = addP(id, 1e5, 1e5, 0, 0); p.hide = true; p.pool = true; p.rs = false; free.push(p); } });      // Stage 40: palace guards, farmers and traders for the Oyo regions
      for (let q = 0; q < 20; q++) { const p = addP(IDS[q % 3], 1e5, 1e5, 0, 0); p.hide = true; p.pool = true; p.rs = false; p.sc = 1; spk.push(p); } }   // invisible speakers: 0-2 cart passengers, 3/4 the two NPC royal riders, 5 the rude rider, 6 the oncoming royal rider, 7 the starter-cart rider, 8-19 the extra road riders (and their pillion passengers) of npc riders
    function say(i, x, y, z, text, who) { const p = spk[i % spk.length]; if (!p || !TALK) return; p.x = x; p.y = y; p.z = z; p.nm = who || 'Passenger'; talkSay(TALK, p, text, clockNow, true); }
    function spkMove(i, x, y, z) { const p = spk[i % spk.length]; if (p) { p.x = x; p.y = y; p.z = z; } }
    function spawn(id, x, z, yaw, st) {
      const i = free.findIndex(p => p.a === IX[id]); if (i < 0) return null;
      const p = free.splice(i, 1)[0]; if (PROP[id] && (st === 2 || st === 4)) st = 0;
      Object.assign(p, { hide: false, x, z, yaw: yaw || 0, st: st || 0, y: H(x, z), vc: 0, vm: 0, rl: null, w: null, cr: null, rs: false, say: null, nm: null, bub: Math.random() < .3, k: kindOf(id, st || 0) }); p.gp = p.ph; return p;   // bub: ~30% of Endless roadside folk (walking or standing) get speech bubbles
    }
    function release(p) { if (!p || !p.pool || p.hide) return; p.hide = true; p.rl = p.w = p.cr = null; p.rs = false; p.say = null; p.x = p.z = 1e5; free.push(p); }
    // road: centreline of the WHOLE (double) corridor; f(z) -> [x, z, nx, nz, tx, tz]
    function setRoad(f, z0, z1, hw) {
      const n = Math.ceil((z1 - z0) / 8) + 1, r = { n, len: 0, s: new Float32Array(n), x: new Float32Array(n), z: new Float32Array(n), nx: new Float32Array(n), nz: new Float32Array(n), tx: new Float32Array(n), tz: new Float32Array(n), fixedHW: hw, cls: 'endless' };
      for (let i = 0; i < n; i++) { const q = f(z0 + i * 8); r.x[i] = q[0]; r.z[i] = q[1]; r.nx[i] = q[2]; r.nz[i] = q[3]; r.tx[i] = q[4]; r.tz[i] = q[5]; r.s[i] = i ? r.s[i - 1] + Math.hypot(r.x[i] - r.x[i - 1], r.z[i] - r.z[i - 1]) : 0; }
      r.len = r.s[n - 1]; road = r; return r;
    }
    function cross(zc, sd) {
      if (!road) return null; let lo = 0, hi = road.n - 1; if (zc < road.z[0] || zc > road.z[hi]) return null;
      while (hi - lo > 1) { const m = (lo + hi) >> 1; if (road.z[m] < zc) lo = m; else hi = m; }
      const s = road.s[lo], id = pick(['trdW', 'wA', 'wB', 'wC', 'farmB', 'agA', 'agC', 'boy', 'girl']);
      roadAt(road, s); const lat = sd * (road.fixedHW + 1.9), p = spawn(id, RP.x + RP.nx * lat, RP.z + RP.nz * lat, Math.atan2(-sd * RP.nx, -sd * RP.nz), 0); if (!p) return null;
      const carry = id === 'trdW' || id === 'farmB';
      p.rs = true; p.rl = { r: road, kind: 'cross', s, side: sd, state: 'rest', t: rr(0, 3), v: 1.25, stM: carry ? 3 : 1, stP: 0, gt: rr(0, 10), lat, rushed: false };   // exactly the Free Roam / mission crossing behaviour return p;
    }
    function walkTo(p, tx, tz, v, dt) {
      const dx = tx - p.x, dz = tz - p.z, d = Math.hypot(dx, dz);
      if (d < .3) { locoMove(p, 0, dt, false, 0); return d; }
      const e = turnTo(p, Math.atan2(dx, dz), dt, 7); locoMove(p, v * p.sp * alignOf(e), dt, false, 0);
      p.x += Math.sin(p.yaw) * p.vc * dt; p.z += Math.cos(p.yaw) * p.vc * dt; p.y = H(p.x, p.z); return d;
    }
    function patrol(p, x1, z1, x2, z2) { p.w = walker([[x1, z1], [x2, z2]], 1.0, 1, 0, {}); }
    return { reserve, say, spkMove, spawn, release, setRoad, cross, walkTo, patrol, get ready() { return free.length > 0 || people.some(p => p.pool); } };
  })();

  window.OYOVillagers = { endless: EL, say(p, text, secs, who) { if (!TALK || !p) return; if (who) p.nm = who; talkSay(TALK, p, text, clockNow, true); if (secs && p.say) p.say.until = clockNow + secs; }, plan, build, popRoads, setObstacles, get people() { return people; }, _road: { roadStep }, paintMap, get markets() { return markets; }, _t: { person, stall, pavilion, Buf, ARCH, FV, FF } };
})();
