/* EMPIRE DASH — cowrie-road.js  (Stage 12e: cowrie shell collection, Free Roam)
   Cowrie shells (the money of the Yoruba kingdoms, c. 1650) lie in little strings along the Royal Road, at varied spots weaving across the road.
   Drive the horse or the hitched cart over one and it is collected: the shell spins up and vanishes, a ring of light flashes, a cowrie chime
   plays and the balance on the HUD rises by COW_VAL. Each shell can be collected once (it stays gone for the session).
   The shell model is a natural cowrie (cream domed back + dark aperture slit); no coins or modern objects. Session balance = the game's 🐚 total
   (same as roam-fare / dropoff); nothing is written to the save. Mission cowries (missions.js) are untouched.
   Self-contained. To remove: delete this file, its <script> line in boot.js + sw.js, and the "cowrie-road.js" block in style.css. */
(function () {
  'use strict';
  const OYO = window.OYO, MS = OYO && OYO.mission, C = window.OYOCart; if (!MS) return;
  const B = window.BABYLON;
  const COW_VAL = 1, GROUP_IDX = 19, SCALE = .36, HOVER = .5, PICK_HORSE = 2.3, PICK_CART = 2.7, ANIM = .4, STREAK_WIN = 1.3;
  const snd = (f, a) => { try { window.OYOAudio && OYOAudio[f] && OYOAudio[f](a); } catch (e) { /* audio optional */ } };
  let cart = null, RD = null, World = null, scene = null, mesh = null, buf = null, cows = [], fx = [], t = 0, built = false, onB = false;
  let chip = null, chipN = null, lastBal = -1, lastPick = -9, streak = 0;
  if (C) ['spawnHitched', 'spawnParked'].forEach(k => { const f = C[k]; if (typeof f === 'function') C[k] = function () { const c = f.apply(this, arguments); if (c) cart = c; return c; }; });

  function build() {
    if (built || !B || !scene || !World) return; built = true;
    const paint = (m, c) => { const n = m.getTotalVertices(), a = new Float32Array(n * 4); for (let i = 0; i < n; i++) { a[i * 4] = c[0]; a[i * 4 + 1] = c[1]; a[i * 4 + 2] = c[2]; a[i * 4 + 3] = 1; } m.setVerticesData(B.VertexBuffer.ColorKind, a); };
    const body = B.MeshBuilder.CreateSphere('crBody', { diameter: 1, segments: 10 }, scene);       // domed, oval back
    body.scaling.set(.62, .4, .92); body.bakeCurrentTransformIntoVertices();
    const slit = B.MeshBuilder.CreateBox('crSlit', { width: .08, height: .06, depth: .66 }, scene);  // toothed aperture along the flat underside-line
    slit.position.y = .19; slit.bakeCurrentTransformIntoVertices();
    paint(body, [1, .93, .78]); paint(slit, [.32, .18, .1]);
    mesh = B.Mesh.MergeMeshes([body, slit], true, true); mesh.name = 'roadCowries';
    const mat = new B.StandardMaterial('crMat', scene); mat.diffuseColor = new B.Color3(1, 1, 1); mat.emissiveColor = new B.Color3(.36, .3, .2); mat.specularColor = new B.Color3(.55, .5, .38); mat.specularPower = 24;
    mesh.material = mat; mesh.isPickable = false; mesh.alwaysSelectAsActiveMesh = true; mesh.setEnabled(false);
    for (let i = 0; i < 6; i++) {
      const m = B.MeshBuilder.CreateTorus('crFx' + i, { diameter: 1, thickness: .06, tessellation: 28 }, scene), mt = new B.StandardMaterial('crFxMat' + i, scene);
      mt.disableLighting = true; mt.emissiveColor = new B.Color3(1, .86, .5); mt.diffuseColor = B.Color3.Black(); mt.specularColor = B.Color3.Black(); mt.alpha = 0; mt.fogEnabled = false;
      m.material = mt; m.isPickable = false; m.alphaIndex = 42; m.setEnabled(false); fx.push({ m, t: 9, x: 0, y: 0, z: 0 });
    }
    // lay the strings along the Royal Road (deterministic)
    const r = World.byId.royal; if (!r) return;
    let sd = 1650; const rnd = () => { sd = (sd * 16807) % 2147483647; return (sd - 1) / 2147483646; };
    const PA = window.OYOPalace && OYOPalace.site, o = RD && RD.obs;
    const bad = (x, z) => {
      if (PA && PA.a) { const dx = x - PA.x, dz = z - PA.z, sn = Math.sin(PA.yaw), cs = Math.cos(PA.yaw); if (Math.abs(dx * cs - dz * sn) < PA.a + 5 && Math.abs(dx * sn + dz * cs) < PA.b + 5) return true; }
      if (o && o.x) for (let k = 0; k < o.x.length; k++) { const q = o.r[k] + 1.6; if ((x - o.x[k]) ** 2 + (z - o.z[k]) ** 2 < q * q) return true; }
      return false;
    };
    let g = 0;
    for (let i = 14; i < r.n - 14; i += Math.round(GROUP_IDX * (.8 + rnd() * .5)), g++) {
      const hw = World.widthAt(r, i) * .5, base = Math.sin(g * 1.9) * Math.min(hw * .6, 3.2);       // each string sits at its own place across the road
      for (let j = -1; j <= 1; j++) {
        const k = Math.min(r.n - 1, Math.max(0, i + j)), lat = base + j * .5 * (rnd() - .5);
        const x = r.x[k] + r.nx[k] * lat, z = r.z[k] + r.nz[k] * lat; if (bad(x, z)) continue;
        cows.push({ x, z, y: World.height(x, z), ph: rnd() * 6.28, got: false, a: -1 });
      }
    }
    if (!cows.length) return;
    buf = new Float32Array(cows.length * 16); mesh.thinInstanceSetBuffer('matrix', buf, 16, false); mesh.thinInstanceRefreshBoundingInfo(true);
  }

  /* ---------- HUD balance chip (appended under the Free Roam title card) ---------- */
  function ui() {
    if (chip) return; const host = document.querySelector('.hud-tl') || document.getElementById('hud'); if (!host) return;
    chip = document.createElement('div'); chip.className = 'hud-card cr-bal'; chip.innerHTML = '<svg class="cwr" aria-hidden="true"><use href="#cwr-sym"/></svg> Cowries <b>0</b>';
    host.appendChild(chip); chipN = chip.querySelector('b');
  }
  function syncBal(h) {
    const v = h.score | 0; if (v === lastBal) return; lastBal = v; chipN.textContent = v;
    chip.classList.remove('bump'); void chip.offsetWidth; chip.classList.add('bump');
  }
  function floatPlus() {
    const r = chip.getBoundingClientRect(), f = document.createElement('div'); f.className = 'cr-plus'; f.textContent = '+' + COW_VAL;
    f.style.left = (r.right - 14) + 'px'; f.style.top = (r.top + 2) + 'px'; document.body.appendChild(f); setTimeout(() => f.remove(), 900);
  }

  const q = new B.Quaternion(), sc = new B.Vector3(), tr = new B.Vector3(), mx = new B.Matrix();
  function tick() {
    const h = OYO.hud, s = RD && RD.state; if (!h || !s) return; ui(); if (!chip) return;
    const live = h.screen === 'free' && h.mode === 'ride' && RD.built;
    if (chip.style.display !== (h.screen === 'free' ? '' : 'none')) chip.style.display = h.screen === 'free' ? '' : 'none';
    syncBal(h);
    if (!live) { if (mesh && mesh.isEnabled()) mesh.setEnabled(false); return; }
    build(); if (!mesh || !buf) return; if (!mesh.isEnabled()) mesh.setEnabled(true);
    const dt = Math.min(.05, scene.getEngine().getDeltaTime() / 1000); t += dt;
    const cs = cart && cart.hitched ? cart.state : null; let dirty = false;
    for (let k = 0; k < cows.length; k++) {
      const c = cows[k]; if (c.got && c.a < 0) continue;
      if (!c.got) {
        const d1 = (c.x - s.x) ** 2 + (c.z - s.z) ** 2, d2 = cs ? (c.x - cs.x) ** 2 + (c.z - cs.z) ** 2 : 1e9;
        if (d1 < PICK_HORSE * PICK_HORSE || d2 < PICK_CART * PICK_CART) {        // touched by horse or cart: collect once
          c.got = true; c.a = 0; h.score += COW_VAL; h.cow = COW_VAL; h.cowPop = true; setTimeout(() => { h.cowPop = false; }, 170);
          streak = (t - lastPick < STREAK_WIN) ? Math.min(streak + 1, 6) : 0; lastPick = t; snd('cowrie', streak);
          const f = fx.find(z => z.t >= .5); if (f) { f.t = 0; f.x = c.x; f.y = c.y + .6; f.z = c.z; f.m.setEnabled(true); }
          syncBal(h); floatPlus();
        }
      }
      let spin = t * 2.2 + c.ph, sk = SCALE, lift = Math.sin(t * 2.6 + c.ph) * .05;
      if (c.got) {                                                                // collection animation: spin up, shrink away
        c.a += dt; if (c.a >= ANIM) { c.a = -1; buf.fill(0, k * 16, k * 16 + 16); dirty = true; continue; }
        const u = c.a / ANIM; spin += u * 14; sk = SCALE * (1 - u * .85); lift = u * 1.6;
      } else if ((c.x - s.x) ** 2 + (c.z - s.z) ** 2 > 190 * 190) { buf.fill(0, k * 16, k * 16 + 16); dirty = true; continue; }   // far away: hidden
      B.Quaternion.RotationYawPitchRollToRef(spin, .45, 0, q); sc.set(sk, sk, sk); tr.set(c.x, c.y + HOVER + lift, c.z);
      B.Matrix.ComposeToRef(sc, q, tr, mx); buf.set(mx.m, k * 16); dirty = true;
    }
    if (dirty) mesh.thinInstanceBufferUpdated('matrix');
    fx.forEach(f => { if (f.t >= .5) return; f.t += dt; if (f.t >= .5) { f.m.setEnabled(false); return; } const u = f.t / .5; f.m.position.set(f.x, f.y + u * .7, f.z); f.m.scaling.setAll(.4 + u * 1.6); f.m.material.alpha = .75 * (1 - u); });
  }

  const prev = MS.init;
  MS.init = function (world, riding, scn) {
    const r = prev.apply(this, arguments); RD = riding; World = world; scene = scn;
    if (!onB) { onB = true; scene.onBeforeRenderObservable.add(tick); } return r;
  };
})();
