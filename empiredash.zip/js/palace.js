/* EMPIRE DASH — Stage 5 · palace.js
   The Aláàfin's royal palace (Aàfin): a walled royal compound with corner towers, a grand gatehouse with
   great wooden doors, an outer gathering courtyard, an inner royal court, a raised throne pavilion on carved
   pillars, long halls, queens' quarters and guard lodges, painted with Yoruba indigo / ochre / camwood / chalk patterns.
   Built on the Stage 4 geometry kit: merged static meshes (mud / thatch / wood / pattern) + one soft decal mesh. */
(function () {
  'use strict';
  const B = BABYLON, TAU = Math.PI * 2, A = 38, BB = 36, WALL = 3.4;
  let K = null, P = null;
  const sgn = v => v < 0 ? -1 : 1, clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const GOLD = [2.1, 1.55, .5], RED = [1.75, .38, .28], INDIGO = [.5, .6, 1.25];

  /* ---------------- site selection: flat, spacious, facing a road, visible ---------------- */
  function plan(kit) {
    K = kit; const H = K.H, rot = K.rot; let best = null;
    for (const thr of [1.2, 1.9, 2.8]) {
      for (let x = -330; x <= 330; x += 14) for (let z = -330; z <= 330; z += 14) {
        const nr = K.nearestRoad(x, z); if (!nr || nr.d < 52 || nr.d > 100) continue;
        const c = { x, z, yaw: Math.atan2(nr.x - x, nr.z - z), a: A, b: BB, kind: 'rect' };
        if (K.kops.some(k => Math.hypot(k.x - x, k.z - z) < k.R * 1.3 + 60)) continue;
        let lo = 1e9, hi = -1e9;
        for (let i = -4; i <= 4; i++) for (let j = -4; j <= 4; j++) { const w = rot(c, i / 4 * A * .97, j / 4 * BB * .97), h = H(w[0], w[1]); lo = Math.min(lo, h); hi = Math.max(hi, h); }
        if (hi - lo > thr) continue;
        let ok = true;
        for (let t = -1; t <= 1 && ok; t += .125) for (const p of [[t * (A + 6), BB + 6], [t * (A + 6), -BB - 6], [A + 6, t * (BB + 6)], [-A - 6, t * (BB + 6)]]) { const w = rot(c, p[0], p[1]); if (Math.abs(w[0]) > 400 || Math.abs(w[1]) > 400 || K.edgeR(w[0], w[1]) < 3) { ok = false; break; } }
        if (!ok) continue;
        const score = (hi - lo) * 10 + Math.pow(nr.d - 62, 2) * .003 + Math.hypot(x, z) * .02 - H(x, z) * .04;
        if (!best || score < best.score) best = { c, score, nr };
      }
      if (best) break;
    }
    if (!best) return null;
    const c = best.c, G = rot(c, 0, BB), ng = K.nearestRoad(G[0], G[1]), len = clamp(ng.d + 4, 16, 62), dx = Math.sin(c.yaw), dz = Math.cos(c.yaw);
    c.rc = Math.hypot(A, BB);
    // invisible reservations: a wide apron around the walls + the processional forecourt (keeps trees, boulders, houses away)
    K.comps.push({ x: c.x, z: c.z, yaw: c.yaw, kind: 'rect', a: A + 10, b: BB + 10, rc: Math.hypot(A + 10, BB + 10), hidden: true });
    K.comps.push({ x: G[0] + dx * len / 2, z: G[1] + dz * len / 2, yaw: c.yaw, kind: 'rect', a: 13, b: len / 2 + 2, rc: len / 2 + 15, hidden: true });
    P = { c, G, road: ng, x: c.x, z: c.z, yaw: c.yaw, a: A, b: BB };
    return P;
  }

  /* ---------------- painted pattern texture (indigo / ochre / camwood / chalk) ---------------- */
  function paintPat(g, W, Hh) {
    const rows = [['#27307a', '#f3ecd8'], ['#d79a2b', '#27307a'], ['#9c3a24', '#f3ecd8'], ['#efe3c4', '#8e2f1f']];
    rows.forEach(([bg, fg], r) => {
      const y0 = r * 64; g.fillStyle = bg; g.fillRect(0, y0, W, 64); g.strokeStyle = fg; g.fillStyle = fg; g.lineWidth = 6; g.lineJoin = 'round';
      if (r === 0) { g.beginPath(); g.moveTo(0, y0 + 52); for (let x = 0; x < W; x += 32) { g.lineTo(x + 16, y0 + 12); g.lineTo(x + 32, y0 + 52); } g.stroke(); }
      else if (r === 1) { for (let x = 0; x < W; x += 64) { g.beginPath(); g.moveTo(x + 32, y0 + 6); g.lineTo(x + 58, y0 + 32); g.lineTo(x + 32, y0 + 58); g.lineTo(x + 6, y0 + 32); g.closePath(); g.fillStyle = fg; g.fill(); g.fillStyle = '#f3ecd8'; g.beginPath(); g.arc(x + 32, y0 + 32, 5, 0, 6.3); g.fill(); } }
      else if (r === 2) { for (let x = 0; x < W; x += 32) { g.beginPath(); g.moveTo(x + 3, y0 + 58); g.lineTo(x + 16, y0 + 8); g.lineTo(x + 29, y0 + 58); g.closePath(); g.fill(); } }
      else { g.lineWidth = 5; g.beginPath(); g.moveTo(0, y0 + 9); g.lineTo(W, y0 + 9); g.moveTo(0, y0 + 55); g.lineTo(W, y0 + 55); g.stroke(); g.fillStyle = '#27307a'; for (let x = 0; x < W; x += 32) { g.beginPath(); g.arc(x + 16, y0 + 32, 7, 0, 6.3); g.fill(); } }
      g.fillStyle = '#1b1420'; g.fillRect(0, y0, W, 4);
    });
    for (let i = 0; i < 1400; i++) { const x = Math.random() * W, y = Math.random() * Hh, l = 3 + Math.random() * 8; g.strokeStyle = Math.random() < .5 ? 'rgba(255,248,230,.16)' : 'rgba(20,10,10,.16)'; g.lineWidth = 1 + Math.random() * 1.6; g.beginPath(); g.moveTo(x, y); g.lineTo(x + (Math.random() - .5) * 4, y + l); g.stroke(); }
  }

  /* ---------------- local geometry helpers ---------------- */
  const sets = () => { const S = K.newSet(); S.pat = K.buf(); return S; };
  function band(S, hx, hz, e, y0, y1, N) {   // painted pattern frieze wrapped round a wall
    const u = Math.max(4, Math.round(2 * (hx + hz) * 2 / 3.6));
    K.loft(S.pat, [{ y: y0, hx: hx * 1.045, hz: hz * 1.045, e, v: 0, col: [1, 1, 1] }, { y: y1, hx: hx * 1.045, hz: hz * 1.045, e, v: 1, col: [1, 1, 1] }], N, { uRep: u });
  }
  function pillar(S, x, z, y0, y1, k) {   // carved pillar painted with the pattern bands + mud capital & plinth
    k = k || 1; const cols = [1, 1, 1], rings = [], n = 6;
    for (let i = 0; i <= n; i++) { const t = i / n, r = (.2 + .03 * Math.sin(t * 9)) * k * (i === n ? 1.25 : 1); rings.push({ y: y0 + .35 + (y1 - y0 - .55) * t, hx: r, hz: r, e: 2, v: (y1 - y0) * t * .9, col: cols }); }
    const b0 = S.pat.p.length / 3; K.loft(S.pat, rings, 6, { uRep: 1, upBias: 1 });
    for (let q = b0; q < S.pat.p.length / 3; q++) { S.pat.p[q * 3] += x; S.pat.p[q * 3 + 2] += z; }
    const m0 = S.mud.p.length / 3;
    K.lathe(S.mud, [[.42 * k, y0 - .3, .6], [.36 * k, y0 + .22, .9], [.26 * k, y0 + .34, .85]], 7, [1.1, .98, .9], 1);
    K.lathe(S.mud, [[.24 * k, y1 - .3, .85], [.44 * k, y1 - .12, 1.05], [.4 * k, y1 + .06, .95]], 7, [1.1, .98, .9], 1);
    for (let q = m0; q < S.mud.p.length / 3; q++) { S.mud.p[q * 3] += x; S.mud.p[q * 3 + 2] += z; }
  }
  function gilded(S, x, y, z, r) { const m0 = S.mud.p.length / 3; K.lathe(S.mud, [[.04 * r, y, .8], [.5 * r, y + .5 * r, 1.05], [.62 * r, y + 1.1 * r, 1.1], [.4 * r, y + 1.8 * r, 1.05], [.05 * r, y + 2.2 * r, .9]], 7, GOLD, 1); for (let q = m0; q < S.mud.p.length / 3; q++) { S.mud.p[q * 3] += x; S.mud.p[q * 3 + 2] += z; } }
  function patBox(S, cx, cy, cz, sx, sy, sz, yaw, faces) { K.box(S.pat, cx, cy, cz, sx, sy, sz, yaw, [1, 1, 1], faces || 'f', .28, 1 / sy); }

  /* ---------------- prototypes ---------------- */
  function gatehouse() {
    const S = sets(), R = K.rngSeed(91), tone = [1.1, 1, .92];
    for (const s of [-1, 1]) {
      K.loft(S.mud, K.wallRings(1.9, 2.3, 6, 5.8, tone).map(r => Object.assign({}, r, { x: s * 4.7 })), 12, { uRep: 7 });
      patBox(S, s * 4.7, 3.3, 2.36, 3.6, .9, .06, 0, 'f'); patBox(S, s * 4.7, 3.3, -2.36, 3.6, .9, .06, Math.PI, 'f');
      patBox(S, s * (4.7 - 1.93), 3.3, 0, 4.4, .9, .06, s * Math.PI / 2, 'f'); patBox(S, s * (4.7 + 1.93), 3.3, 0, 4.4, .9, .06, -s * Math.PI / 2, 'f');
      K.box(S.mud, s * 4.7, 6.0, 0, 4.1, .35, 4.9, 0, [1.15, 1, .9], 'flrt');
      // great wooden door leaf, swung open against the pylon
      K.box(S.wood, s * 2.62, 1.75, 0, 2.9, 3.5, .3, Math.PI / 2, [1.25, .78, .56], 'flrt');
      for (const y of [.55, 1.75, 2.95]) K.box(S.wood, s * 2.46, y, 0, 2.9, .2, .36, Math.PI / 2, [.62, .44, .34], 'flrt');
      for (const z of [-.8, .8]) K.box(S.wood, s * 2.44, 1.75, z, .2, 3.5, .38, Math.PI / 2, [.62, .44, .34], 'flrt');
      // tall pennant pole
      const m0 = S.wood.p.length / 3; K.lathe(S.wood, [[.2, -.3, .8], [.13, 1, 1], [.1, 11, 1], [.14, 11.4, 1.05], [.05, 11.8, .9]], 5, [.8, .62, .5], 1);
      for (let q = m0; q < S.wood.p.length / 3; q++) { S.wood.p[q * 3] += s * 7.9; S.wood.p[q * 3 + 2] += 0; }
      // (the pennants themselves are animated cloth meshes built in build(), see buildFlags)
      gilded(S, s * 7.9, 11.6, 0, .45);
    }
    K.box(S.wood, 0, 4.5, 0, 11.4, .65, .9, 0, [.8, .6, .46], 'flrt'); patBox(S, 0, 4.5, .47, 11, .5, .05, 0, 'f'); patBox(S, 0, 4.5, -.47, 11, .5, .05, Math.PI, 'f');
    K.loft(S.thatch, K.roofRings(8.6, 3.9, 6, 5.6, 3.4, 3, true, 1), 14, { uRep: 14, upBias: 1 });
    K.loft(S.thatch, [{ y: 5.5, hx: 8.4, hz: 3.8, e: 6, v: 0, col: [.4, .31, .22] }, { y: 6.1, hx: 5.6, hz: 2.5, e: 6, v: 1, col: [.28, .22, .16] }], 14, { dir: 'down', uRep: 10 });
    gilded(S, 0, 9.0, 0, .55);
    return { S };
  }
  function hall(o) {   // large painted hall with great doors + carved verandah pillars
    const pro = K.house(Object.assign({ kind: 'hall', e: 7, N: 14, hipped: true, tiers: 4, oh: 1.2, veranda: false, wins: [] }, o));
    pro.S.pat = K.buf(); band(pro.S, o.w / 2, o.d / 2, 7, 1.15, 2.1, 14);
    if (o.doorBand) patBox(pro.S, 0, o.wallH - .55, o.d / 2 * 1.04 + .09, o.door[0] + 1.4, .55, .05, 0, 'f');
    if (o.pillars) { const pz = pro.hz0 - .3; o.pillars.forEach(px => pillar(pro.S, px, pz, -.3, o.wallH - .05, 1.15)); K.box(pro.S.wood, 0, o.wallH - .2, pz, o.w - .1, .3, .3, 0, [.8, .5, .38], 'flrt'); patBox(pro.S, 0, o.wallH - .2, pz + .16, o.w - .3, .26, .05, 0, 'f'); }
    return pro;
  }
  function tower() {
    const pro = K.house({ kind: 'tower', seed: 21, w: 5.6, d: 5.6, wallH: 5.6, e: 2, N: 12, hipped: false, doorX: 0, tiers: 3, roofH: 4.4, oh: .9, door: null, wins: [[0, 3.7, 'f'], [2.8, 3.7, 0, Math.PI / 2]] });
    pro.S.pat = K.buf(); band(pro.S, 2.8, 2.8, 2, 2.2, 3.1, 12); band(pro.S, 2.8, 2.8, 2, 4.4, 5.0, 12); return pro;
  }
  function pavilion() {   // raised open throne pavilion
    const S = sets(), W2 = 6.4, D2 = 3.3;
    K.box(S.mud, 0, .2, 0, W2 * 2, 1.4, D2 * 2, 0, [1.12, .98, .88], 'flrt'); patBox(S, 0, .3, D2 + .03, W2 * 2 - .2, .6, .05, 0, 'f');
    patBox(S, W2 + .03, .3, 0, D2 * 2 - .2, .6, .05, -Math.PI / 2, 'f'); patBox(S, -W2 - .03, .3, 0, D2 * 2 - .2, .6, .05, Math.PI / 2, 'f');
    K.box(S.mud, 0, .05, D2 + .6, 5.2, 1.1, 1.2, 0, [1.12, .98, .88], 'flrt'); K.box(S.mud, 0, -.12, D2 + 1.6, 5.8, .76, 1, 0, [1.1, .96, .86], 'flrt');
    for (const sx of [-5.3, -1.8, 1.8, 5.3]) { pillar(S, sx, D2 - .5, .9, 5.0, 1.15); pillar(S, sx, -D2 + .5, .9, 5.0, 1.15); }
    K.box(S.wood, 0, 4.85, D2 - .5, W2 * 2 - .2, .42, .38, 0, [.82, .52, .4], 'flrt'); patBox(S, 0, 4.85, D2 - .28, W2 * 2 - .4, .36, .05, 0, 'f');
    K.box(S.wood, 0, 4.85, -D2 + .5, W2 * 2 - .2, .42, .38, 0, [.82, .52, .4], 'flrt');
    K.loft(S.thatch, K.roofRings(7.6, 4.7, 6, 4.95, 4.4, 4, true, 1.05), 14, { uRep: 14, upBias: 1 });
    K.loft(S.thatch, [{ y: 4.85, hx: 7.4, hz: 4.6, e: 6, v: 0, col: [.42, .33, .24] }, { y: 5.4, hx: 6.4, hz: 3.4, e: 6, v: 1, col: [.3, .23, .17] }], 14, { dir: 'down', uRep: 10 });
    gilded(S, 0, 9.2, 0, .7); gilded(S, -2.9, 8.6, 0, .35); gilded(S, 2.9, 8.6, 0, .35);
    // painted back-screen, throne, royal staffs
    K.box(S.mud, 0, 2.7, -D2 + .2, W2 * 2 - .6, 3.6, .5, 0, [1.18, .95, .85], 'flrt'); patBox(S, 0, 2.2, -D2 + .47, W2 * 2 - 1, .9, .05, 0, 'f'); patBox(S, 0, 3.7, -D2 + .47, W2 * 2 - 1, .9, .05, 0, 'f');
    K.box(S.mud, 0, 1.2, -1.6, 2.8, .6, 1.9, 0, [1.4, .55, .42], 'flrt'); patBox(S, 0, 1.2, -.64, 2.6, .5, .05, 0, 'f');
    K.box(S.wood, 0, 1.78, -1.6, 1.9, .4, 1.4, 0, RED, 'flrt'); K.box(S.wood, 0, 2.7, -2.2, 1.9, 2.0, .3, 0, [1.5, 1.0, .4], 'flrt'); patBox(S, 0, 3.1, -2.04, 1.5, .55, .05, 0, 'f');
    K.box(S.wood, -1.15, 2.3, -1.6, .22, .9, 1.2, 0, GOLD, 'flrt'); K.box(S.wood, 1.15, 2.3, -1.6, .22, .9, 1.2, 0, GOLD, 'flrt');
    for (const s of [-1, 1]) { const m0 = S.wood.p.length / 3; K.lathe(S.wood, [[.12, .9, .9], [.08, 2.4, 1], [.1, 4.0, 1]], 5, [.9, .62, .4], 1); for (let q = m0; q < S.wood.p.length / 3; q++) { S.wood.p[q * 3] += s * 3.3; S.wood.p[q * 3 + 2] += .6; } gilded(S, s * 3.3, 4.0, .6, .3); }
    return { S, hx0: 7.6, hz0: 4.7, hgt: 7 };
  }
  function dais(r) {   // low round gathering platform with patterned rim
    const S = sets(), N = 20, c = [1.1, .96, .88];
    K.loft(S.mud, [{ y: -.8, hx: r * 1.03, hz: r * 1.03, e: 2, v: -.8, col: [c[0] * .6, c[1] * .6, c[2] * .6] }, { y: .5, hx: r, hz: r, e: 2, v: .5, col: c }, { y: .52, hx: r * .02, hz: r * .02, e: 2, v: 1, col: c }], N, { uRep: 12, upBias: 1 });
    K.loft(S.pat, [{ y: -.05, hx: r * 1.015, hz: r * 1.015, e: 2, v: 0, col: [1, 1, 1] }, { y: .45, hx: r * 1.015, hz: r * 1.015, e: 2, v: 1, col: [1, 1, 1] }], N, { uRep: Math.round(TAU * r / 3.6) });
    return { S, hx0: r, hz0: r, hgt: 1 };
  }

  /* ---------------- build ---------------- */

  /* ---------------- animated war pennants (Stage 8c) ----------------
     Cloth grid on each gatehouse pole, rippled on the CPU every frame (~190 verts total).
     Emblem: a gold round shield over two crossed war spears, spear-tip trim top and bottom. */
  function paintFlag(g, W, H, base, dark) {
    const GOLD_C = '#e8b840', WOOD = '#3b2412', cx = W / 2, cy = H / 2;
    g.fillStyle = base; g.fillRect(0, 0, W, H);
    const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, 'rgba(255,255,255,.10)'); gr.addColorStop(1, 'rgba(0,0,0,.2)'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
    g.strokeStyle = 'rgba(0,0,0,.07)'; g.lineWidth = 1; for (let x = 0; x < W; x += 6) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, H); g.stroke(); }
    g.strokeStyle = GOLD_C; g.lineWidth = 8; g.strokeRect(8, 8, W - 16, H - 16);
    g.strokeStyle = dark; g.lineWidth = 3; g.strokeRect(20, 20, W - 40, H - 40);
    g.fillStyle = GOLD_C;   // spear-tip trim
    for (let x = 36; x < W - 40; x += 26) { g.beginPath(); g.moveTo(x, 24); g.lineTo(x + 11, 24); g.lineTo(x + 5.5, 40); g.closePath(); g.fill(); g.beginPath(); g.moveTo(x, H - 24); g.lineTo(x + 11, H - 24); g.lineTo(x + 5.5, H - 40); g.closePath(); g.fill(); }
    const spear = a => {
      g.save(); g.translate(cx, cy); g.rotate(-Math.PI / 2 + a);
      g.strokeStyle = WOOD; g.lineWidth = 7; g.lineCap = 'round'; g.beginPath(); g.moveTo(-84, 0); g.lineTo(84, 0); g.stroke();
      g.fillStyle = GOLD_C; g.strokeStyle = '#6b4a12'; g.lineWidth = 2; g.beginPath(); g.moveTo(104, 0); g.lineTo(82, -13); g.lineTo(72, 0); g.lineTo(82, 13); g.closePath(); g.fill(); g.stroke();
      g.fillStyle = GOLD_C; g.beginPath(); g.arc(-84, 0, 5, 0, 6.3); g.fill(); g.restore();
    };
    spear(.62); spear(-.62);
    g.fillStyle = GOLD_C; g.strokeStyle = '#6b4a12'; g.lineWidth = 3; g.beginPath(); g.arc(cx, cy, 58, 0, 6.3); g.fill(); g.stroke();   // shield
    g.fillStyle = dark; g.beginPath(); g.arc(cx, cy, 47, 0, 6.3); g.fill();
    g.strokeStyle = GOLD_C; g.lineWidth = 5; g.beginPath(); g.moveTo(cx - 47, cy); g.lineTo(cx + 47, cy); g.moveTo(cx, cy - 47); g.lineTo(cx, cy + 47); g.stroke();
    g.fillStyle = GOLD_C; g.strokeStyle = '#6b4a12'; g.lineWidth = 2; g.beginPath(); g.arc(cx, cy, 15, 0, 6.3); g.fill(); g.stroke();   // boss
    g.fillStyle = dark; g.beginPath(); g.arc(cx, cy, 6, 0, 6.3); g.fill();
  }
  function buildFlags(scene, anchors) {   // anchors: [{x, y, z}] pole tops in world space
    const B = BABYLON, NU = 14, NV = 6, FL = 3.0, FH = 1.5, FA = .34, WIND_YAW = .9, sty = [['#b8402e', '#5c1a12'], ['#27357a', '#111a44']];
    const idx = []; for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const a = j * (NU + 1) + i, b = a + 1, c = a + NU + 1, d = c + 1; idx.push(a, c, b, b, c, d); }
    const uvs = []; for (let j = 0; j <= NV; j++) for (let i = 0; i <= NU; i++) uvs.push(i / NU, 1 - j / NV);
    const flags = anchors.map((an, k) => {
      const t = new B.DynamicTexture('palFlagT' + k, { width: 512, height: 256 }, scene, true); paintFlag(t.getContext(), 512, 256, sty[k % 2][0], sty[k % 2][1]); t.anisotropicFilteringLevel = 4; t.update();
      const m = new B.StandardMaterial('palFlagM' + k, scene); m.diffuseTexture = t; m.specularColor = B.Color3.Black(); m.emissiveColor = new B.Color3(.3, .26, .24); m.backFaceCulling = false; m.twoSidedLighting = true;
      const mesh = new B.Mesh('palaceFlag' + k, scene), pos = new Float32Array((NU + 1) * (NV + 1) * 3), nrm = new Float32Array(pos.length), vd = new B.VertexData();
      vd.positions = pos; vd.normals = nrm; vd.uvs = uvs; vd.indices = idx; vd.applyToMesh(mesh, true);
      mesh.material = m; mesh.isPickable = false; mesh.alwaysSelectAsActiveMesh = true;
      return { an, k, mesh, pos, nrm };
    });
    let ft = 0;
    scene.onBeforeRenderObservable.add(() => {
      const cam = scene.activeCamera; if (!cam) return;
      ft += Math.min(.05, scene.getEngine().getDeltaTime() / 1000);
      for (const f of flags) {
        const dx = cam.position.x - f.an.x, dz = cam.position.z - f.an.z, near = dx * dx + dz * dz < 260 * 260;
        if (f.mesh.isEnabled() !== near) f.mesh.setEnabled(near); if (!near) continue;
        const gust = .8 + .2 * Math.sin(ft * .45) + .12 * Math.sin(ft * 1.3 + f.k), yaw = WIND_YAW + .26 * Math.sin(ft * .31 + f.k * 1.7);
        const fx = Math.sin(yaw), fz = Math.cos(yaw), nx = fz, nz = -fx, P = f.pos; let o = 0;
        for (let j = 0; j <= NV; j++) { const v = j / NV; for (let i = 0; i <= NU; i++) {
          const u = i / NU, ph = u * 5.4 - ft * (5 + 2 * gust) + f.k * 1.9 + v * .8;
          const lat = FA * gust * u * (Math.sin(ph) + .3 * Math.sin(2.2 * ph + 1.1)) * (1 + .3 * v), along = .12 + u * FL * (1 - .05 * gust * u);
          const y = f.an.y - v * FH - (1.15 - gust) * .5 * u * u + .06 * u * Math.sin(ph * 1.3 + v * 2);
          P[o++] = f.an.x + fx * along + nx * lat; P[o++] = y; P[o++] = f.an.z + fz * along + nz * lat;
        } }
        B.VertexData.ComputeNormals(P, idx, f.nrm);
        f.mesh.updateVerticesData(B.VertexBuffer.PositionKind, P, false, false); f.mesh.updateVerticesData(B.VertexBuffer.NormalKind, f.nrm, false, false);
      }
    });
    return flags.length;
  }
  function build(scene, W, kit, env) {
    K = kit; if (!P) return { meshes: 0, tris: 0 };
    const c = P.c, H = K.H, rot = K.rot, S = sets(), D = K.dbuf(), pr = K.protos(), sun = W.sunDir, sx = -sun.x / sun.y, sz = -sun.z / sun.y;
    const tint = [1.1, 1.0, .9], tintT = [1.12, 1.06, .94], rnd = K.rnd;
    const put = (pro, lx, lz, yawL, sc, shadow) => {
      sc = sc || 1; const wp = rot(c, lx, lz), yaw = c.yaw + yawL, cs = Math.cos(yaw), sn = Math.sin(yaw), ex = pro.hx0 * .85 * sc, ez = pro.hz0 * .85 * sc;
      let hi = -1e9; for (const q of [[0, 0], [ex, ez], [-ex, ez], [ex, -ez], [-ex, -ez]]) hi = Math.max(hi, H(wp[0] + q[0] * cs + q[1] * sn, wp[1] - q[0] * sn + q[1] * cs));
      K.stamp(S, pro, wp[0], hi - .1, wp[1], yaw, sc, tint, tintT);
      if (shadow !== false) {
        const hh = (pro.hgt || 4) * sc * .9, fp = [], round = pro.kind === 'round' || pro.kind === 'oval' || pro.kind === 'tower';
        for (let k = 0; k < 8; k++) { const th = k / 8 * TAU, ct = Math.cos(th), st = Math.sin(th), e3 = round ? 2 : 6, q = [pro.hx0 * sc * sgn(ct) * Math.pow(Math.abs(ct), 2 / e3), pro.hz0 * sc * sgn(st) * Math.pow(Math.abs(st), 2 / e3)]; fp.push([wp[0] + q[0] * cs + q[1] * sn, wp[1] - q[0] * sn + q[1] * cs]); }
        K.softPoly(D, K.hull(fp.concat(fp.map(p => [p[0] + sx * hh, p[1] + sz * hh]))), [.16, .1, .2], .4, 1.12);
      }
      return wp;
    };
    const face = (x, z, tx, tz) => Math.atan2(tx - x, tz - z);

    /* walls: outer perimeter (gate gap in front) + inner partition with its own gate */
    const e = 8, ex = 2 / e, dense = [], M = 360;
    for (let k = 0; k <= M; k++) { const th = Math.PI / 2 + k / M * TAU, ct = Math.cos(th), st = Math.sin(th); dense.push([A * sgn(ct) * Math.pow(Math.abs(ct), ex), BB * sgn(st) * Math.pow(Math.abs(st), ex)]); }
    const cum = [0]; for (let k = 1; k <= M; k++) cum.push(cum[k - 1] + Math.hypot(dense[k][0] - dense[k - 1][0], dense[k][1] - dense[k - 1][1]));
    const Lt = cum[M], gap = 9.2, s0 = gap / 2, s1 = Lt - gap / 2, nseg = Math.round((s1 - s0) / 2.8), path = []; let j = 0;
    for (let k = 0; k <= nseg; k++) {
      const s = s0 + (s1 - s0) * k / nseg; while (j < M - 1 && cum[j + 1] < s) j++;
      const f = (s - cum[j]) / Math.max(1e-6, cum[j + 1] - cum[j]), lx = dense[j][0] + (dense[j + 1][0] - dense[j][0]) * f, lz = dense[j][1] + (dense[j + 1][1] - dense[j][1]) * f, w = rot(c, lx, lz);
      path.push([w[0], H(w[0], w[1]), w[1], WALL * (.97 + .06 * rnd()), .9 + .14 * rnd()]);
    }
    const wallProf = [[-.8, -.5, .5], [-.45, 0, .62], [-.3, .95, .95], [.3, .95, 1.02], [.45, 0, .62], [.8, -.5, .5]];
    const capProf = [[-.75, .88, .85], [-.48, 1.1, 1], [0, 1.18, 1.08], [.48, 1.1, 1], [.75, .88, .85]];
    const runWall = (pth, hsMul) => {
      K.sweep(S.mud, pth, wallProf, tint, {}); K.sweep(S.thatch, pth.map(p => [p[0], p[1], p[2], p[3], 1]), capProf, tintT, {});
      for (const sd of [-1, 1]) K.sweep(S.pat, pth.map(p => [p[0], p[1], p[2], p[3], 1]), [[sd * (.396 + .0), .4, 1], [sd * (.36 + .0), .62, 1]].map(q => [q[0], q[1], q[2]]), [1, 1, 1], { us: 1 / 3.6, vs: 1 });
      for (let k = 0; k < pth.length - 1; k++) { const a = pth[k], b = pth[k + 1], l = a[3] * 1.1, ca = [.16, .1, .2], i0 = K.dvert(D, a[0], a[2], ca, .34), i1 = K.dvert(D, b[0], b[2], ca, .34), i2 = K.dvert(D, a[0] + sx * l, a[2] + sz * l, ca, 0), i3 = K.dvert(D, b[0] + sx * l, b[2] + sz * l, ca, 0); D.i.push(i0, i1, i2, i1, i3, i2); }
    };
    runWall(path);
    for (const side of [-1, 1]) {   // partition wall between outer and inner courts, gap in the middle
      const pth = [], x0 = side * 3.6, x1 = side * (A - 1.0), n = Math.round(Math.abs(x1 - x0) / 2.8);
      for (let k = 0; k <= n; k++) { const w = rot(c, x0 + (x1 - x0) * k / n, 0); pth.push([w[0], H(w[0], w[1]), w[1], 2.6 * (.96 + .08 * rnd()), .9 + .12 * rnd()]); }
      K.sweep(S.mud, pth, wallProf, tint, {}); K.sweep(S.thatch, pth.map(p => [p[0], p[1], p[2], p[3], 1]), capProf, tintT, {});
    }

    /* grand gatehouse + inner gate */
    const gw = rot(c, 0, BB); let gy = -1e9; for (let i = -3; i <= 3; i++) for (let q = -1; q <= 1; q++) { const w = rot(c, i * 2.3, BB + q * 2.4); gy = Math.max(gy, H(w[0], w[1])); }
    K.stamp(S, gatehouse(), gw[0], gy - .1, gw[1], c.yaw, 1, tint, tintT);
    try { buildFlags(scene, [-1, 1].map(s => { const w = rot({ x: gw[0], z: gw[1], yaw: c.yaw }, s * 7.9, 0); return { x: w[0], y: gy - .1 + 10.9, z: w[1] }; })); } catch (e) { console.warn('Palace flags skipped:', e); }
    K.softPoly(D, K.hull([[-8.6, -3.9], [8.6, -3.9], [8.6, 3.9], [-8.6, 3.9]].map(q => rot({ x: gw[0], z: gw[1], yaw: c.yaw }, q[0], q[1])).flatMap(p => [p, [p[0] + sx * 5, p[1] + sz * 5]])), [.16, .1, .2], .4, 1.1);
    const ig = rot(c, 0, 0); let iy = -1e9; for (const x of [-3, 3]) { const w = rot(c, x, 0); iy = Math.max(iy, H(w[0], w[1])); }
    K.stamp(S, pr.gate, ig[0], iy - .1, ig[1], c.yaw, 2.0, tint, tintT);

    /* corner towers */
    const tw = tower(); for (const sx2 of [-1, 1]) for (const sz2 of [-1, 1]) { const lx = sx2 * A * .915, lz = sz2 * BB * .915; put(tw, lx, lz, face(lx, lz, 0, 0), 1); }

    /* throne pavilion, great hall, flanking halls, queens' quarters */
    const hallBack = hall({ seed: 11, w: 17, d: 8, wallH: 4.3, door: [3.2, 3.3], doorBand: true, roofH: 5.2, tiers: 4, pillars: [-6.5, -3.2, 3.2, 6.5] });
    put(hallBack, 0, -BB + 1.4 + hallBack.hz0, 0, 1);
    put(pavilion(), 0, -19.2, 0, 1);
    const side = hall({ seed: 12, w: 12.5, d: 5.4, wallH: 3.4, door: [1.6, 2.4], roofH: 3.6, tiers: 3, pillars: [-3, 3] });
    for (const s of [-1, 1]) put(side, s * (A - 1.4 - side.hz0), -9, -s * Math.PI / 2, 1);
    for (const s of [-1, 1]) {
      const q1 = [s * 27, -27.5], q2 = [s * 19.5, -31];
      put(pr.round[2], q1[0], q1[1], face(q1[0], q1[1], 0, -9), 1.1); put(pr.oval[0], q2[0], q2[1], face(q2[0], q2[1], 0, -9), 1.05);
      put(pr.rect[0], s * (A - 7), BB - 10, -s * Math.PI / 2, 1.05);                 // guard lodges by the great gate
    }

    /* outer royal gathering courtyard: patterned platform, elders' shade sheds */
    put(dais(6.2), -17, 17, 0, 1, false);
    { const wp = rot(c, -17, 17); K.softPoly(D, Array.from({ length: 12 }, (_, k) => [wp[0] + Math.cos(k / 12 * TAU) * 6.4 + sx * .8, wp[1] + Math.sin(k / 12 * TAU) * 6.4 + sz * .8]), [.16, .1, .2], .3, 1.2); }
    for (const x of [16, 24]) for (const z of [14, 23]) put(pr.shed, x, z, Math.PI + (x === 16 ? .0 : .0), 1, false);

    /* clay floors, patterned frames, ceremonial pots */
    const grid = (lx0, lz0, lx1, lz1, col, a, fade) => {   // soft rectangular clay decal, terrain-conforming grid
      const nx = Math.max(2, Math.ceil((lx1 - lx0) / 4)), nz = Math.max(2, Math.ceil((lz1 - lz0) / 4)), ids = [];
      for (let i = 0; i <= nx; i++) for (let k = 0; k <= nz; k++) {
        const lx = lx0 + (lx1 - lx0) * i / nx, lz = lz0 + (lz1 - lz0) * k / nz, ed = Math.min(lx - lx0, lx1 - lx, lz - lz0, lz1 - lz) / fade, w = rot(c, lx, lz), jt = .94 + .1 * rnd();
        ids.push(K.dvert(D, w[0], w[1], [col[0] * jt, col[1] * jt, col[2] * jt], a * clamp(ed, 0, 1)));
      }
      for (let i = 0; i < nx; i++) for (let k = 0; k < nz; k++) { const q = i * (nz + 1) + k; D.i.push(ids[q], ids[q + 1], ids[q + nz + 1], ids[q + 1], ids[q + nz + 2], ids[q + nz + 1]); }
    };
    grid(-A + 1.5, 1.5, A - 1.5, BB - 1.5, [.74, .47, .31], .8, 4);
    grid(-A + 1.5, -BB + 1.5, A - 1.5, -1.5, [.68, .42, .28], .85, 4);
    const strip = (x0, z0, x1, z1, w, col, a) => {
      const L = Math.hypot(x1 - x0, z1 - z0), n = Math.max(1, Math.ceil(L / 2.5)), dx = (x1 - x0) / L, dz = (z1 - z0) / L, nx = -dz * w / 2, nz = dx * w / 2; let prev = null;
      for (let k = 0; k <= n; k++) { const px = x0 + (x1 - x0) * k / n, pz = z0 + (z1 - z0) * k / n, cur = [K.dvert(D, px + nx, pz + nz, col, a), K.dvert(D, px - nx, pz - nz, col, a)]; if (prev) D.i.push(prev[0], prev[1], cur[0], prev[1], cur[1], cur[0]); prev = cur; }
    };
    const frame = (cx, cz, hx, hz, w, col) => { const q = [[-hx, -hz], [hx, -hz], [hx, hz], [-hx, hz]].map(p => rot(c, cx + p[0], cz + p[1])); for (let k = 0; k < 4; k++) strip(q[k][0], q[k][1], q[(k + 1) % 4][0], q[(k + 1) % 4][1], w, col, .92); };
    frame(0, -7.2, 11.5, 5.6, .8, [.16, .2, .48]); frame(0, -7.2, 10.6, 4.7, .4, [.86, .62, .2]); frame(0, -7.2, 9.9, 4.0, .25, [.93, .9, .82]);
    frame(0, 18, 7.5, 12, .6, [.16, .2, .48]); frame(0, 18, 6.9, 11.4, .3, [.86, .62, .2]);
    for (const q of [[-4.6, -13.2], [4.6, -13.2], [-9.5, -4], [9.5, -4]]) { const w = rot(c, q[0], q[1]); K.stamp(S, pr.potL, w[0], H(w[0], w[1]) - .02, w[1], rnd() * 6, 1.45, [1.05, .95, .85]); }

    /* processional approach to the road + carved standards */
    const G = P.G, rd = K.nearestRoad(G[0], G[1]), dd = Math.hypot(rd.x - G[0], rd.z - G[1]), ux = (rd.x - G[0]) / dd, uz = (rd.z - G[1]) / dd, pc = [.66, .4, .25], nn = Math.max(2, Math.round(dd / 3)); let prev = null;
    const sx0 = G[0] + Math.sin(c.yaw) * 3, sz0 = G[1] + Math.cos(c.yaw) * 3;
    for (let k = 0; k <= nn; k++) {
      const t = k / nn, px = sx0 + (rd.x - sx0) * t, pz = sz0 + (rd.z - sz0) * t, w = 4.2 * (1 + .6 * t), a = k === nn ? 0 : .88, cur = [K.dvert(D, px - uz * w, pz + ux * w, pc, 0), K.dvert(D, px - uz * w * .55, pz + ux * w * .55, pc, a), K.dvert(D, px + uz * w * .55, pz - ux * w * .55, pc, a), K.dvert(D, px + uz * w, pz - ux * w, pc, 0)];
      if (prev) for (let q = 0; q < 3; q++) D.i.push(prev[q], prev[q + 1], cur[q], prev[q + 1], cur[q + 1], cur[q]); prev = cur;
    }
    for (let d = 8; d < Math.min(dd - 6, 40); d += 9) for (const s of [-1, 1]) {
      const px = G[0] + (rd.x - G[0]) * d / dd - uz * s * 5.6, pz = G[1] + (rd.z - G[1]) * d / dd + ux * s * 5.6, y = H(px, pz);
      const S2 = sets(); pillar(S2, 0, 0, 0, 2.8, .7); gilded(S2, 0, 2.7, 0, .3); K.stamp(S, { S: S2 }, px, y - .02, pz, 0, 1, tint, tintT);
    }

    /* meshes */
    const pat = env.pat || (() => {
      const t = new B.DynamicTexture('palPatT', { width: 1024, height: 256 }, scene, true), g = t.getContext(); paintPat(g, 1024, 256); t.wrapU = t.wrapV = B.Texture.WRAP_ADDRESSMODE; t.anisotropicFilteringLevel = 4; t.update(); return env.mk('palPat', t);
    })();
    const mats = { mud: env.mats.mud, thatch: env.mats.thatch, wood: env.mats.wood, pat }; let meshes = 0, tris = 0;
    for (const k of ['mud', 'thatch', 'wood', 'pat']) {
      const b = S[k]; if (!b.i.length) continue; tris += b.i.length / 3;
      const m = new B.Mesh('palace_' + k, scene), vd = new B.VertexData(); vd.positions = b.p; vd.normals = b.n; vd.colors = b.c; vd.uvs = b.u; vd.indices = b.i; vd.applyToMesh(m);
      m.material = mats[k]; m.isPickable = false; m.freezeWorldMatrix(); m.doNotSyncBoundingInfo = true; meshes++;
    }
    const m = new B.Mesh('palace_decal', scene), vd = new B.VertexData(); vd.positions = D.p; vd.colors = D.c; vd.indices = D.i; vd.applyToMesh(m); m.material = env.dm; m.hasVertexAlpha = true; m.alphaIndex = 7; m.isPickable = false; m.freezeWorldMatrix(); meshes++;
    P.built = true; return { meshes, tris, x: P.x, z: P.z, yaw: P.yaw, gate: [gw[0], gw[1]], approach: [rd.x, rd.z] };
  }
  function paintMap(g, k, half) {
    if (!P) return; const X = (P.x + half) * k, Y = (half - P.z) * k;
    g.save(); g.translate(X, Y); g.rotate(-P.yaw); g.fillStyle = '#ffd27a'; g.strokeStyle = '#2a170d'; g.lineWidth = 2; g.beginPath(); g.rect(-P.a * k, -P.b * k, P.a * 2 * k, P.b * 2 * k); g.fill(); g.stroke();
    g.fillStyle = '#9c3a24'; g.fillRect(-P.a * k * .5, -P.b * k * .5, P.a * k, P.b * k * .5); g.restore();
  }
  window.OYOPalace = { plan, build, paintMap, get site() { return P; } };
})();
