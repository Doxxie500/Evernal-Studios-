/* EMPIRE DASH — cart-guard.js
   Keeps the horse, the cart and the rider together, whatever happens (a slow frame, a failed cart swap, a hiccup in a shader, a cart left disabled).
   It does NOT touch the per-frame work: the cart still follows the horse exactly as before (cart.js). This file only looks four times a second
   (a handful of property reads, no allocation) and repairs what it finds:
     • no cart / a disposed cart  → builds a fresh one and hitches it (ALWAYS the model the player owns and selected, e.g. the 4-seat starter cart; it never swaps to another model, it just retries)
     • cart not hitched to the horse that is on screen → hitches it again and snaps it straight behind the horse
     • cart (or its harness) disabled, hidden, scaled to nothing or sitting on a broken (NaN) pose → shown / reset
     • rider not on the driver bench during Endless Run and the start-menu clip → seated again
     • cart shader failed to compile on this phone → plain vertex-coloured material so the cart is still drawn
     • horse position broken (NaN) → put back where it last was fine
   Add ?cartguard=0 to the address to switch it off while testing. */
(function () {
  'use strict';
  const OYO = window.OYO, C = window.OYOCart, B = window.BABYLON;
  if (!OYO || !OYO.core || !C || !B) return;
  try { if (/[?&](cart|cartguard)=0(&|$)/.test(window.location.search)) return; } catch (e) { /* no location */ }

  const core = OYO.core;
  let fails = 0, nextTry = 0, good = null, fb = null;
  const finite = (a, b, c, d) => Number.isFinite(a) && Number.isFinite(b) && Number.isFinite(c) && Number.isFinite(d);
  const warn = (m, e) => { try { console.warn('Cart guard: ' + m, e || ''); } catch (x) { /* ok */ } };
  const alive = c => { try { return !!(c && c.root && c.state && c.hitch && !(c.root.isDisposed && c.root.isDisposed())); } catch (e) { return false; } };

  function rebuild(S, RD) {
    const now = performance.now(); if (now < nextTry) return null;
    nextTry = now + (fails < 4 ? 300 : 2000);                       // never hammer a failing build: it is retried at a calm pace
    let c = null;                                                    // never a different model: whatever OYOCartSel says the player owns is what gets rebuilt
    try { c = C.spawnHitched(S.scene, S.world, RD); }
    catch (e) { warn('rebuild failed', e); }
    if (c) { fails = 0; try { c.snapToHorse && c.snapToHorse(); } catch (e) { /* ok */ } } else fails++;
    return c;
  }

  function fallbackMat(S) {
    if (fb) return fb;
    fb = new B.StandardMaterial('cartGuardMat', S.scene);
    fb.diffuseColor = new B.Color3(1, 1, 1); fb.emissiveColor = new B.Color3(.2, .14, .08); fb.specularColor = new B.Color3(0, 0, 0); fb.backFaceCulling = false;
    return fb;
  }

  function check() {
    if (document.hidden) return;
    const S = core.S; if (!S || !S.scene || !S.world) return;
    const RD = S.riding; if (!RD || !RD.built || !RD.state) return;
    let c = S.cart;
    if (!RD.active) {                                                // horse not on screen: only make sure a cart exists for the next time it is
      if (!alive(c)) { try { if (c && c.hitched) c.unhitch(); } catch (e) { /* ok */ } S.cart = rebuild(S, RD); }
      return;
    }
    const h = OYO.hud || {}, endless = !!(OYO.endless && OYO.endless.on), title = !!(h.tour && h.screen === 'title'), rs = RD.state;

    // horse position broken → back to the last good spot
    if (finite(rs.x, rs.y, rs.z, rs.yaw)) good = { x: rs.x, z: rs.z, yaw: rs.yaw };
    else if (good) { try { RD.place(good.x, good.z, good.yaw); } catch (e) { warn('horse reset', e); } }

    // a cart must exist
    if (!alive(c)) {
      try { if (c && c.hitched) c.unhitch(); } catch (e) { /* ok */ }
      c = S.cart = rebuild(S, RD); if (!c) return;
      if (endless) c.rigid = true;
    }
    // …and be hitched to the horse that is on screen
    if (!c.hitched || c.horse !== RD) {
      try { c.hitch(RD); if (endless) c.rigid = true; c.snapToHorse && c.snapToHorse(); } catch (e) { warn('re-hitch', e); return; }
    }
    // …and be drawn
    try {
      const s = c.state;
      if (!c.enabled || !c.root.isEnabled(false)) c.setVisible(true);
      const sc = c.root.scaling; if (!(sc.x > .01 && sc.y > .01 && sc.z > .01)) sc.setAll(1);
      if (!finite(s.x, s.y, s.z, s.yaw) || !Number.isFinite(s.pitch) || !Number.isFinite(s.roll) || Math.hypot(s.x - rs.x, s.z - rs.z) > 14) { s.pitch = 0; s.roll = 0; c.snapToHorse && c.snapToHorse(); }
      const broken = c._fb || (() => { const e = c.mat && c.mat.getEffect && c.mat.getEffect(); return !!(e && typeof e.isSupported === 'function' && !e.isSupported()); })();
      if (broken && !c._fb) { c._fb = 1; warn('cart shader did not compile here; using the plain material'); }
      const fix = m => { if (!m) return; if (!m.isEnabled(false)) m.setEnabled(true); if (!m.isVisible) m.isVisible = true; if (m.visibility !== 1) m.visibility = 1; if (broken && m.material !== fb) m.material = fallbackMat(S); };
      for (const k in c.meshes) fix(c.meshes[k]);
      if (c.harness) c.harness.forEach(fix);
    } catch (e) { warn('show', e); }
    // …and the rider sits on the driver bench when the game wants him there
    try { if ((endless || title) && (!RD.driver || RD.driver.cart !== c)) RD.setDriver(c); } catch (e) { warn('driver seat', e); }
    try { if (RD.mesh && !RD.mesh.isEnabled(false)) RD.mesh.setEnabled(true); if (RD.shadow && !RD.shadow.isEnabled(false) && !(window.OYO && OYO.endless && OYO.endless.on)) RD.shadow.setEnabled(true); } catch (e) { /* ok */ }
  }

  setInterval(function () { try { check(); } catch (e) { warn('check', e); } }, 250);
  window.OYOCartGuard = { check };
})();
