/* EMPIRE DASH — Stage 4 · buildings.js
   Traditional Yoruba mud-walled compounds: rectangular, oval and round houses with tiered thatch,
   wooden verandah posts, doors and windows, walled courtyards, clay pots, gates, drying racks.
   Villages along the paths, larger towns at road junctions, isolated farmsteads.
   Geometry is baked per settlement into 3 merged meshes (mud / thatch / wood) + 1 soft decal mesh,
   walls follow the terrain, and every house model is a reused prototype (low draw-call count). */
(function () {
  'use strict';
  const B = BABYLON, TAU = Math.PI * 2, HALF = 450;
  let sd = 4477031; const rnd = () => { sd = (sd * 16807) % 2147483647; return (sd - 1) / 2147483646; };
  const rr = (a, b) => a + (b - a) * rnd(), pick = a => a[(rnd() * a.length) | 0];
  const rngSeed = seed => { let s = (seed * 7919 + 4411) % 2147483647; return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; };
  const sgn = v => v < 0 ? -1 : 1, clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  /* ======================= geometry kit ======================= */
  const buf = () => ({ p: [], n: [], c: [], u: [], i: [] });
  const newSet = () => ({ mud: buf(), thatch: buf(), wood: buf() });
  const setTris = s => (s.mud.i.length + s.thatch.i.length + s.wood.i.length) / 3;

  function orient(I, P, a, b, c, wx, wy, wz) {
    const A = P[a], Q = P[b], C = P[c], ux = Q[0] - A[0], uy = Q[1] - A[1], uz = Q[2] - A[2], vx = C[0] - A[0], vy = C[1] - A[1], vz = C[2] - A[2];
    const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    if (nx * nx + ny * ny + nz * nz < 1e-12) return;
    if (nx * wx + ny * wy + nz * wz < 0) I.push(a, c, b); else I.push(a, b, c);
  }
  // normals from oriented triangles; `smooth` welds coincident positions (seams, apex)
  function commit(b, P, U, C, I, smooth) {
    const n = P.length, N = []; for (let k = 0; k < n; k++) N.push([0, 0, 0]);
    for (let t = 0; t < I.length; t += 3) {
      const a = I[t], q = I[t + 1], c = I[t + 2], A = P[a], Bp = P[q], Cp = P[c];
      const ux = Bp[0] - A[0], uy = Bp[1] - A[1], uz = Bp[2] - A[2], vx = Cp[0] - A[0], vy = Cp[1] - A[1], vz = Cp[2] - A[2];
      const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      for (const k of [a, q, c]) { N[k][0] += nx; N[k][1] += ny; N[k][2] += nz; }
    }
    if (smooth) {
      const m = new Map();
      for (let k = 0; k < n; k++) { const key = Math.round(P[k][0] * 400) + '|' + Math.round(P[k][1] * 400) + '|' + Math.round(P[k][2] * 400); let a = m.get(key); if (!a) m.set(key, a = [0, 0, 0]); a[0] += N[k][0]; a[1] += N[k][1]; a[2] += N[k][2]; }
      for (let k = 0; k < n; k++) { const key = Math.round(P[k][0] * 400) + '|' + Math.round(P[k][1] * 400) + '|' + Math.round(P[k][2] * 400); N[k] = m.get(key); }
    }
    const o = b.p.length / 3;
    for (let k = 0; k < n; k++) {
      const l = Math.hypot(N[k][0], N[k][1], N[k][2]) || 1;
      b.p.push(P[k][0], P[k][1], P[k][2]); b.n.push(N[k][0] / l, N[k][1] / l, N[k][2] / l);
      b.c.push(C[k][0], C[k][1], C[k][2], 1); b.u.push(U[k][0], U[k][1]);
    }
    for (let t = 0; t < I.length; t++) b.i.push(I[t] + o);
  }

  // Ring loft: rings = [{y,x,z,hx,hz,e,col:[r,g,b],v}] ; superellipse cross-section (e=2 circle, e~7 rounded rectangle)
  function loft(b, rings, N, o) {
    o = o || {}; const dir = o.dir || 'out', uRep = o.uRep || 8, P = [], U = [], C = [], I = [], W = N + 1;
    rings.forEach(r => {
      const ex = 2 / (r.e || 2);
      for (let k = 0; k <= N; k++) {
        const th = k / N * TAU, c = Math.cos(th), s = Math.sin(th);
        P.push([(r.x || 0) + r.hx * sgn(c) * Math.pow(Math.abs(c), ex), r.y, (r.z || 0) + r.hz * sgn(s) * Math.pow(Math.abs(s), ex)]);
        U.push([k / N * uRep, r.v || 0]); C.push(r.col);
      }
    });
    for (let j = 0; j < rings.length - 1; j++) for (let k = 0; k < N; k++) {
      const a = j * W + k, q = a + 1, c = a + W, d = c + 1, ra = rings[j];
      for (const t of [[a, c, q], [q, c, d]]) {
        let wx = 0, wy = 0, wz = 0;
        if (dir === 'up') wy = 1; else if (dir === 'down') wy = -1;
        else {
          const mx = (P[t[0]][0] + P[t[1]][0] + P[t[2]][0]) / 3 - (ra.x || 0), mz = (P[t[0]][2] + P[t[1]][2] + P[t[2]][2]) / 3 - (ra.z || 0);
          const s = dir === 'in' ? -1 : 1; wx = mx * s; wz = mz * s; wy = (o.upBias || 0) * s;
          if (wx * wx + wz * wz < 1e-8) wy = s;
        }
        orient(I, P, t[0], t[1], t[2], wx, wy, wz);
      }
    }
    commit(b, P, U, C, I, o.smooth !== false);
  }
  const lathe = (b, prof, N, col, uRep, tint) => loft(b, prof.map((q, k) => ({ y: q[1], hx: q[0], hz: q[0], e: 2, v: q[1] * .6, col: [col[0] * q[2] * (tint ? tint[0] : 1), col[1] * q[2] * (tint ? tint[1] : 1), col[2] * q[2] * (tint ? tint[2] : 1)] })), N, { uRep: uRep || 2, upBias: 1 });

  function box(b, cx, cy, cz, sx, sy, sz, yaw, col, faces, uvs, uvsV) {
    faces = faces || 'flrt'; uvs = uvs || .8; const uv2 = uvsV || uvs;
    const hx = sx / 2, hy = sy / 2, hz = sz / 2, cs = Math.cos(yaw), sn = Math.sin(yaw), R = (x, z) => [x * cs + z * sn, -x * sn + z * cs];
    const D = {
      f: { n: [0, 0, 1], v: [[-hx, -hy, hz], [hx, -hy, hz], [hx, hy, hz], [-hx, hy, hz]], w: sx, h: sy, s: 1 },
      b: { n: [0, 0, -1], v: [[hx, -hy, -hz], [-hx, -hy, -hz], [-hx, hy, -hz], [hx, hy, -hz]], w: sx, h: sy, s: .8 },
      l: { n: [-1, 0, 0], v: [[-hx, -hy, -hz], [-hx, -hy, hz], [-hx, hy, hz], [-hx, hy, -hz]], w: sz, h: sy, s: .85 },
      r: { n: [1, 0, 0], v: [[hx, -hy, hz], [hx, -hy, -hz], [hx, hy, -hz], [hx, hy, hz]], w: sz, h: sy, s: .9 },
      t: { n: [0, 1, 0], v: [[-hx, hy, hz], [hx, hy, hz], [hx, hy, -hz], [-hx, hy, -hz]], w: sx, h: sz, s: 1.12 },
      u: { n: [0, -1, 0], v: [[-hx, -hy, -hz], [hx, -hy, -hz], [hx, -hy, hz], [-hx, -hy, hz]], w: sx, h: sz, s: .6 }
    };
    const P = [], U = [], C = [], I = [];
    for (const f of faces) {
      const d = D[f], o = P.length, rn = R(d.n[0], d.n[2]);
      d.v.forEach(q => { const r = R(q[0], q[2]); P.push([cx + r[0], cy + q[1], cz + r[1]]); C.push([col[0] * d.s, col[1] * d.s, col[2] * d.s]); });
      U.push([0, 0], [d.w * uvs, 0], [d.w * uvs, d.h * uv2], [0, d.h * uv2]);
      orient(I, P, o, o + 1, o + 2, rn[0], d.n[1], rn[1]); orient(I, P, o, o + 2, o + 3, rn[0], d.n[1], rn[1]);
    }
    commit(b, P, U, C, I, false);
  }

  // Sweep a cross-section along a ground-following path. path=[[x,y,z,hs]], prof=[[lateral, up, shade]]
  function sweep(b, path, prof, col, o) {
    o = o || {}; const P = [], U = [], C = [], I = [], m = prof.length, n = path.length; let s = 0;
    for (let i = 0; i < n; i++) {
      const a = path[Math.max(0, i - 1)], c = path[Math.min(n - 1, i + 1)], tx = c[0] - a[0], tz = c[2] - a[2], l = Math.hypot(tx, tz) || 1, nx = tz / l, nz = -tx / l, p = path[i];
      if (i) s += Math.hypot(p[0] - path[i - 1][0], p[2] - path[i - 1][2]);
      prof.forEach((q, j) => { const up = q[1] > 0 ? q[1] * p[3] : q[1]; P.push([p[0] + nx * q[0], p[1] + up, p[2] + nz * q[0]]); U.push([s * (o.us || 1 / 2.4), j * (o.vs || .35)]); const sh = q[2] * (p[4] || 1); C.push([col[0] * sh, col[1] * sh, col[2] * sh]); });
    }
    for (let i = 0; i < n - 1; i++) for (let j = 0; j < m - 1; j++) {
      const a = i * m + j, q = a + 1, c = a + m, d = c + 1, p = path[i], mx = (P[a][0] + P[d][0]) / 2 - p[0], my = (P[a][1] + P[d][1]) / 2 - (p[1] + .5), mz = (P[a][2] + P[d][2]) / 2 - p[2];
      orient(I, P, a, c, q, mx, my, mz); orient(I, P, q, c, d, mx, my, mz);
    }
    commit(b, P, U, C, I, true);
  }

  /* ======================= prototypes ======================= */
  const DARK = [.14, .09, .07];
  function roofRings(hx0, hz0, e, y0, Hh, tiers, hipped, tone) {
    const rings = [], ridge = hipped ? Math.max(0, hx0 - hz0) : 0; let v = 0, last = null;
    const prm = t => ({ hx: ridge + (hx0 - ridge) * (1 - t), hz: hz0 * (1 - t), y: y0 + Hh * (1 - Math.pow(1 - t, 1.4)) });
    const add = (t, f, sh) => {
      const q = prm(t), r = { y: q.y, hx: Math.max(.03, q.hx * f), hz: Math.max(.03, q.hz * f), e };
      if (last) v += Math.hypot(r.y - last.y, (r.hz - last.hz) * 1.0, (r.hx - last.hx) * .3) / 1.7;
      r.v = v; const k = sh * (.9 + .16 * t) * tone; r.col = [k, k * .97, k * .9]; rings.push(r); last = r;
    };
    for (let j = 0; j < tiers; j++) { add(j / tiers, 1, 1.0); add((j + 1) / tiers, .91, .88); }
    return rings;
  }
  function wallRings(hx, hz, e, H, tone) {
    const c = (y, f, sh, v) => ({ y, hx: hx * f, hz: hz * f, e, v, col: [sh * tone[0], sh * tone[1], sh * tone[2]] });
    return [c(-1.2, 1.05, .5, -1.2), c(0, 1.04, .62, 0), c(.55, 1.015, .88, .55), c(H - .38, 1.0, 1.0, H - .38), c(H - .28, 1.045, 1.0, H - .28), c(H, 1.02, .72, H)];
  }
  function door(S, x, zf, wd, ht, R, yaw) {
    const W = S.wood, cs = Math.cos(yaw || 0), sn = Math.sin(yaw || 0), at = (dx, dz) => [x + dx * cs + dz * sn, zf - dx * sn + dz * cs];
    let q = at(0, -.02); box(W, q[0], ht / 2, q[1], wd + .1, ht + .02, .14, yaw || 0, DARK, 'f');
    const bw = wd / 4;
    for (let i = 0; i < 4; i++) { q = at(-wd / 2 + bw * (i + .5), .03); const k = .85 + R() * .3; box(W, q[0], (ht - .05) / 2, q[1], bw - .03, ht - .05, .07, yaw || 0, [k, k * .95, k * .9], 'flt'); }
    q = at(0, .06); box(W, q[0], ht + .12, q[1], wd + .5, .22, .3, yaw || 0, [.8, .74, .68], 'flrt');
    for (const sx of [-1, 1]) { q = at(sx * (wd / 2 + .13), .05); box(W, q[0], ht / 2 + .05, q[1], .16, ht + .1, .22, yaw || 0, [.78, .72, .66], 'flrt'); }
  }
  function win(S, lx, ly, lz, yaw) {
    const W = S.wood, cs = Math.cos(yaw), sn = Math.sin(yaw), at = (dx, dz) => [lx + dx * cs + dz * sn, lz - dx * sn + dz * cs];
    let q = at(0, -.02); box(W, q[0], ly, q[1], .5, .56, .12, yaw, DARK, 'f');
    q = at(0, .06); box(W, q[0], ly + .36, q[1], .72, .12, .24, yaw, [.8, .74, .68], 'flrt');
    q = at(0, .06); box(W, q[0], ly - .34, q[1], .72, .1, .24, yaw, [.7, .62, .56], 'flrt');
    q = at(.12, .04); box(W, q[0], ly, q[1], .07, .56, .08, yaw, [.8, .74, .68], 'flt');
  }
  function post(S, x, z, y0, y1, k) {
    k = k || 1;
    lathe(S.wood, [[.15 * k, y0, .8], [.11 * k, y0 + .4, .95], [.14 * k, y1 - .1, 1.05], [.09 * k, y1, .85]], 5, [.74, .6, .5], 1);
    lathe(S.mud, [[.26 * k, y0 - .1, .55], [.2 * k, y0 + .22, .85]], 6, [1, .95, .9], 1);
    // translate the last two prims from origin to (x,z)
    for (const k of ['wood', 'mud']) { const b = S[k], cnt = k === 'wood' ? 4 * 6 : 2 * 7; for (let q = b.p.length / 3 - cnt; q < b.p.length / 3; q++) { b.p[q * 3] += x; b.p[q * 3 + 2] += z; } }
  }

  // oh = eave overhang. Returns prototype {S, hx0, hz0, hgt, wallH, kind}
  function house(o) {
    const S = newSet(), R = rngSeed(o.seed), oh = o.oh || .8, hx = o.w / 2, hz = o.d / 2, H = o.wallH, e = o.e, N = o.N || 14;
    const tone = [1, 1, 1];
    loft(S.mud, wallRings(hx, hz, e, H, tone), N, { uRep: Math.max(4, Math.round(2 * (o.w + o.d) / 2.4 / 1)) });
    const hx0 = hx + oh, hz0 = hz + oh, Hh = o.roofH || hz0 * .88 + .25, y0 = H - .1, hipped = o.hipped;
    loft(S.thatch, roofRings(hx0, hz0, e, y0, Hh, o.tiers || 3, hipped, 1), N, { uRep: Math.max(5, Math.round(2 * (hx0 + hz0) / 1.6)), upBias: 1 });
    loft(S.thatch, [{ y: y0, hx: hx0 * .97, hz: hz0 * .97, e, v: 0, col: [.42, .33, .24] }, { y: H + .12, hx: hx * 1.02, hz: hz * 1.02, e, v: 1, col: [.3, .23, .17] }], N, { dir: 'down', uRep: 8 });
    const zf = hz * 1.04 + .01, dx = o.doorX || 0;
    if (o.door !== null) { const dd = o.door || [1, 1.85]; door(S, dx, zf, dd[0], dd[1], R); }
    (o.wins || []).forEach(w => win(S, w[0], w[1], w[2] === 'f' ? zf : w[2], w[3] || 0));
    if (o.veranda) {
      const pz = hz0 - .2, pxs = o.postsX || (hx >= 3 ? [-hx + .35, -1.7, 1.7, hx - .35] : [-hx + .35, hx - .35]);
      pxs.forEach(px => post(S, px, pz, -.35, H - .12, o.postK));
      box(S.wood, 0, H - .2, pz, hx * 2 - .1, .22, .22, 0, [.72, .58, .46], 'flrt');
    }
    if (hipped) { const rl = Math.max(0, hx0 - hz0); for (const s of [-1, 1]) box(S.wood, s * rl, y0 + Hh + .3, 0, .09, .8, .09, 0, [.75, .6, .48], 'flrt'); }
    else lathe(S.mud, [[.1, y0 + Hh - .1, .8], [.28, y0 + Hh + .05, 1], [.22, y0 + Hh + .3, .95], [.07, y0 + Hh + .45, .8]], 6, [1.1, .95, .85], 1);
    return { S, hx0, hz0, hgt: H + Hh * .5, wallH: H, Hh, kind: o.kind, w: o.w, d: o.d, front: hz, doorX: dx, oh };
  }
  function shed() {
    const S = newSet(), hx0 = 2.3, hz0 = 1.9;
    [[-1.5, -1.1], [1.5, -1.1], [-1.5, 1.1], [1.5, 1.1]].forEach(p => post(S, p[0], p[1], -.35, 2.05));
    loft(S.thatch, roofRings(hx0, hz0, 6, 1.95, 1.05, 2, true, 1), 12, { uRep: 7, upBias: 1 });
    loft(S.thatch, [{ y: 1.95, hx: hx0 * .97, hz: hz0 * .97, e: 6, v: 0, col: [.4, .31, .22] }, { y: 2.1, hx: 1.3, hz: .9, e: 6, v: 1, col: [.28, .22, .16] }], 12, { dir: 'down', uRep: 6 });
    box(S.mud, 0, .22, -1.0, 2.6, .44, .5, 0, [1, .92, .86], 'flrt');
    return { S, hx0, hz0, hgt: 2.7, wallH: 2, kind: 'shed', front: 1.1 };
  }
  function rack() {
    const S = newSet();
    for (const s of [-1, 1]) { box(S.wood, s * 1.2, .8, 0, .12, 1.7, .12, 0, [.72, .56, .42], 'flrt'); box(S.wood, s * 1.2, 1.62, 0, .3, .08, .1, .3, [.7, .55, .4], 'flrt'); }
    box(S.wood, 0, 1.52, 0, 2.7, .07, .08, 0, [.74, .6, .46], 'flrt'); box(S.wood, 0, 1.0, 0, 2.5, .06, .07, 0, [.7, .56, .42], 'flrt');
    return { S, hx0: 1.5, hz0: .5, hgt: 1.7, kind: 'rack' };
  }
  function gateRoof(farm) {
    const S = newSet();
    for (const s of [-1, 1]) { post(S, s * 1.55, 0, -.35, 2.3); }
    box(S.wood, 0, 2.25, 0, 3.5, .2, .24, 0, [.72, .58, .46], 'flrt');
    if (!farm) { loft(S.thatch, roofRings(2.05, .95, 6, 2.35, .7, 2, true, 1), 10, { uRep: 5, upBias: 1 }); }
    return { S };
  }
  function pot(kind) {
    const S = newSet(), cl = [1.28, .95, .72];
    const pr = kind === 'L' ? [[0, 0, .6], [.22, .02, .7], [.38, .28, 1], [.47, .58, 1.06], [.38, .88, .95], [.22, 1.05, .8], [.27, 1.13, .7], [.24, 1.15, .55], [0, 1.0, .35]]
      : kind === 'M' ? [[0, 0, .6], [.2, .02, .7], [.34, .3, 1.02], [.4, .5, 1.05], [.27, .72, .9], [.3, .8, .7], [.26, .82, .5], [0, .7, .35]]
        : [[0, 0, .6], [.2, .02, .75], [.3, .2, 1.03], [.2, .4, .85], [.24, .46, .65], [0, .4, .35]];
    lathe(S.mud, pr, kind === 'L' ? 7 : 6, cl, 1);
    return { S };
  }

  let PRO = null;
  function protos() {
    if (PRO) return PRO;
    PRO = {
      main: [house({ kind: 'main', seed: 1, w: 7.4, d: 4.4, wallH: 2.5, e: 7, N: 12, hipped: true, veranda: true, doorX: 0, tiers: 3, wins: [[-2.5, 1.45, 'f'], [2.5, 1.45, 'f'], [3.55, 1.4, 0, Math.PI / 2]] }),
      house({ kind: 'main', seed: 2, w: 6.4, d: 4.2, wallH: 2.4, e: 7, N: 12, hipped: true, veranda: true, doorX: .6, tiers: 3, wins: [[-2.0, 1.45, 'f']] })],
      rect: [house({ kind: 'rect', seed: 3, w: 5, d: 3.8, wallH: 2.3, e: 7, N: 12, hipped: true, doorX: 0, tiers: 2, wins: [[-1.7, 1.4, 'f']] }),
      house({ kind: 'rect', seed: 4, w: 4.6, d: 3.6, wallH: 2.2, e: 6, N: 12, hipped: true, doorX: -.5, tiers: 2, wins: [[1.4, 1.4, 'f']] })],
      round: [house({ kind: 'round', seed: 5, w: 4.6, d: 4.6, wallH: 2.2, e: 2, N: 12, hipped: false, doorX: 0, tiers: 3, roofH: 3.3, wins: [[-1.5, 1.4, 'f']] }),
      house({ kind: 'round', seed: 6, w: 4.0, d: 4.0, wallH: 2.1, e: 2, N: 12, hipped: false, doorX: 0, tiers: 3, roofH: 3.0, wins: [] }),
      house({ kind: 'round', seed: 7, w: 5.0, d: 5.0, wallH: 2.3, e: 2, N: 12, hipped: false, doorX: 0, tiers: 4, roofH: 3.6, wins: [[1.6, 1.4, 'f']] })],
      oval: [house({ kind: 'oval', seed: 8, w: 5.2, d: 4.2, wallH: 2.3, e: 2.6, N: 12, hipped: false, doorX: 0, tiers: 3, roofH: 3.1, wins: [[-1.6, 1.4, 'f']] })],
      shed: shed(), rack: rack(), gate: gateRoof(false), gateLow: gateRoof(true), potL: pot('L'), potM: pot('M'), potS: pot('S')
    };
    return PRO;
  }

  // copy a prototype into a settlement set
  function stamp(dst, pro, wx, wy, wz, yaw, sc, tint, tintT) {
    const cs = Math.cos(yaw), sn = Math.sin(yaw);
    for (const k of ['mud', 'thatch', 'wood', 'pat']) {
      const s = pro.S ? pro.S[k] : pro[k], d = dst[k]; if (!s || !d || !s.i.length) continue;
      const o = d.p.length / 3, tn = k === 'thatch' ? (tintT || tint) : (k === 'wood' || k === 'pat') ? [1, 1, 1] : tint;
      for (let q = 0; q < s.p.length / 3; q++) {
        const x = s.p[q * 3] * sc, y = s.p[q * 3 + 1] * sc, z = s.p[q * 3 + 2] * sc;
        d.p.push(wx + x * cs + z * sn, wy + y, wz - x * sn + z * cs);
        const nx = s.n[q * 3], nz = s.n[q * 3 + 2]; d.n.push(nx * cs + nz * sn, s.n[q * 3 + 1], -nx * sn + nz * cs);
        d.c.push(s.c[q * 4] * tn[0], s.c[q * 4 + 1] * tn[1], s.c[q * 4 + 2] * tn[2], 1); d.u.push(s.u[q * 2], s.u[q * 2 + 1]);
      }
      for (let t = 0; t < s.i.length; t++) d.i.push(s.i[t] + o);
    }
  }

  /* ======================= compound layout (local frame: +z = gate side) ======================= */
  function layout(kind, a, b, cls) {
    const P = protos(), L = [], ok = (x, z, r) => L.every(q => Math.hypot(q.x - x, q.z - z) >= (q.r + r) * .82 + .3);
    const add = (t, v, x, z, yaw, r, sc) => { const pro = P[t][v] || P[t]; L.push({ t, v, x, z, yaw, r, sc: sc || 1, pro }); };
    const R0 = pro => (pro.hx0 + pro.hz0) / 2;
    if (kind === 'round') {
      const m = Math.min(a, b), rho = m - .8 - 3.3, angs = [0, rnd() < .5 ? 1.35 : -1.35, rnd() < .5 ? -1.35 : 1.35, 2.5 * sgn(rnd() - .5)];
      const n = cls === 'small' ? 2 : cls === 'medium' ? 3 : 4;
      for (let k = 0; k < n; k++) {
        const ph = angs[k], x = rho * Math.sin(ph) * (a / m), z = -rho * Math.cos(ph) * (b / m), t = k === 0 && rnd() < .5 ? 'oval' : 'round', v = (rnd() * P[t].length) | 0, pro = P[t][v];
        if (ok(x, z, R0(pro))) add(t, v, x, z, -ph, R0(pro), rr(.95, 1.06));
      }
      return L;
    }
    const mainT = cls === 'small' ? pick(['rect', 'oval']) : 'main', mv = (rnd() * P[mainT].length) | 0, mp = P[mainT][mv], zb = -b + .8 + mp.hz0;
    const mx = clamp(rr(-a * .25, a * .25), -(a - .8 - mp.hx0), a - .8 - mp.hx0);
    add(mainT, mv, mx, zb, 0, R0(mp));
    const sides = cls === 'small' ? 1 : 2, types = ['round', 'rect', 'oval', 'round'];
    for (const s of (rnd() < .5 ? [-1, 1] : [1, -1]).slice(0, sides)) {
      const t = pick(types), v = (rnd() * P[t].length) | 0, p = P[t][v], inner = a - .8 - 2 * p.hz0;
      const overlapBack = (inner < Math.abs(mx) + mp.hx0 + .4) || (s * mx > 0 && inner < mx * s + mp.hx0 + .4);
      const zMin = (overlapBack ? zb + mp.hz0 + .6 : -b + .8) + p.hx0, zMax = b - 3.2 - p.hx0;
      if (zMin > zMax) continue;
      const other = L.find(q => q.side === -s), x = s * (a - .8 - p.hz0), z = rr(zMin, zMax);
      if (other && Math.abs(x - other.x) < 7 + .5) continue;
      if (!ok(x, z, R0(p))) continue;
      const q = { t, v, x, z, yaw: -s * Math.PI / 2, r: R0(p), sc: 1, pro: p, side: s }; L.push(q);
    }
    if (cls === 'large') { const s = rnd() < .5 ? -1 : 1, x = s * (a - 2.8), z = b - 2.6; if (ok(x, z, 2.2)) add('shed', 0, x, z, -s * Math.PI / 2, 2.2); }
    return L;
  }

  /* ======================= terrain helpers / planning ======================= */
  let World = null, comps = [], roadsAll = [], sites = [], kops = [], PAL = null;
  const H = (x, z) => World.height(x, z);
  const rot = (c, lx, lz) => { const cs = Math.cos(c.yaw), sn = Math.sin(c.yaw); return [c.x + lx * cs + lz * sn, c.z - lx * sn + lz * cs]; };
  const toLocal = (c, x, z) => { const cs = Math.cos(c.yaw), sn = Math.sin(c.yaw), dx = x - c.x, dz = z - c.z; return [dx * cs - dz * sn, dx * sn + dz * cs]; };
  function inside(c, x, z, m) { const l = toLocal(c, x, z); return c.kind === 'round' ? (l[0] / (c.a + m)) ** 2 + (l[1] / (c.b + m)) ** 2 < 1 : Math.abs(l[0]) < c.a + m && Math.abs(l[1]) < c.b + m; }
  function sdist(c, x, z) {
    const l = toLocal(c, x, z);
    if (c.kind === 'round') return (Math.sqrt((l[0] / c.a) ** 2 + (l[1] / c.b) ** 2) - 1) * Math.min(c.a, c.b);
    const dx = Math.abs(l[0]) - c.a, dz = Math.abs(l[1]) - c.b; return Math.hypot(Math.max(dx, 0), Math.max(dz, 0)) + Math.min(Math.max(dx, dz), 0);
  }
  function siteEdge(x, z) {
    let best = 1e9;
    for (let k = 0; k < comps.length; k++) { const c = comps[k], dx = x - c.x, dz = z - c.z, lim = c.rc + 60; if (dx * dx + dz * dz > lim * lim) continue; const d = sdist(c, x, z); if (d < best) best = d; }
    return best;
  }
  const edgeR = (x, z) => { const q = World.queryRoad(x, z); return q ? q.d - q.hw : 99; };
  function nearestRoad(x, z) {
    let best = null, bd = 1e12;
    for (const r of roadsAll) for (let i = 0; i < r.n; i += 2) { const d = (r.x[i] - x) ** 2 + (r.z[i] - z) ** 2; if (d < bd) { bd = d; best = [r.x[i], r.z[i], r, i]; } }
    return best && { x: best[0], z: best[1], d: Math.sqrt(bd), r: best[2], i: best[3] };
  }
  function perimeter(c, step) {   // world-space points around the compound boundary
    const pts = [], e = c.kind === 'round' ? 2 : 8, ex = 2 / e, n = Math.max(24, Math.round((c.a + c.b) * 2 * Math.PI / step));
    for (let k = 0; k < n; k++) { const th = k / n * TAU, ct = Math.cos(th), st = Math.sin(th); pts.push(rot(c, c.a * sgn(ct) * Math.pow(Math.abs(ct), ex), c.b * sgn(st) * Math.pow(Math.abs(st), ex))); }
    return pts;
  }
  function fits(c) {
    if (Math.abs(c.x) > 392 || Math.abs(c.z) > 392) return false;
    for (const k of kops) if (Math.hypot(k.x - c.x, k.z - c.z) < k.R * 1.3 + c.rc + 4) return false;
    let lo = 1e9, hi = -1e9; const pts = perimeter(c, 3);
    for (const p of pts) { if (edgeR(p[0], p[1]) < 4.2) return false; const h = H(p[0], p[1]); lo = Math.min(lo, h); hi = Math.max(hi, h); }
    for (const q of [[0, 0], [c.a * .5, c.b * .5], [-c.a * .5, c.b * .5], [c.a * .5, -c.b * .5], [-c.a * .5, -c.b * .5]]) { const w = rot(c, q[0], q[1]), h = H(w[0], w[1]); lo = Math.min(lo, h); hi = Math.max(hi, h); }
    if (hi - lo > (c.farm ? 1.5 : 1.9)) return false;
    for (const o of comps) {
      if (Math.hypot(o.x - c.x, o.z - c.z) > o.rc + c.rc + 8) continue;
      if (inside(o, c.x, c.z, 3.5) || inside(c, o.x, o.z, 3.5)) return false;
      for (const p of pts) if (inside(o, p[0], p[1], 3.5)) return false;
      for (const p of perimeter(o, 3)) if (inside(c, p[0], p[1], 3.5)) return false;
    }
    return true;
  }
  function makeSpec(farm, big) {
    const kind = farm ? 'rect' : rnd() < (big ? .3 : .38) ? 'round' : 'rect';
    const cls = farm ? 'small' : (big ? pick(['medium', 'medium', 'large', 'large', 'small']) : pick(['small', 'medium', 'medium', 'large']));
    let a, b;
    if (kind === 'round') { a = b = cls === 'small' ? rr(7.8, 8.8) : cls === 'medium' ? rr(9.2, 10.2) : rr(10.6, 11.6); }
    else if (farm) { a = rr(7.4, 8.4); b = rr(6.6, 7.4); }
    else if (cls === 'small') { a = rr(7.6, 8.8); b = rr(6.8, 7.6); }
    else if (cls === 'medium') { a = rr(9, 10.4); b = rr(7.4, 8.4); }
    else { a = rr(10.6, 12); b = rr(8.6, 9.6); }
    const L = layout(kind, a, b, cls);
    if (L.length < (farm ? 1 : 2)) return null;
    return { kind, a, b, cls, L, rc: Math.hypot(a, b) * (kind === 'round' ? .75 : 1), wallH: farm ? 1.0 : rr(1.55, 1.9), farm: !!farm };
  }
  function roadPointsNear(cx, cz, R) {
    const out = [];
    for (const r of roadsAll) for (let i = 3; i < r.n - 2; i += 3) if (Math.hypot(r.x[i] - cx, r.z[i] - cz) < R) out.push([r, i]);
    return out;
  }
  function grow(site) {
    const rp = roadPointsNear(site.x, site.z, site.R * 1.05);
    let guard = 0;
    while (site.comps.length < site.want && guard++ < site.tries) {
      const sp = makeSpec(false, site.big); if (!sp) continue;
      let cx, cz;
      if (rp.length && rnd() < .72) {
        const [r, i] = pick(rp), side = rnd() < .5 ? -1 : 1, off = side * (World.widthAt(r, i) * .5 + rr(4.6, 8.5) + sp.b);
        cx = r.x[i] + r.nx[i] * off; cz = r.z[i] + r.nz[i] * off;
      } else { const an = rnd() * TAU, d = Math.sqrt(rnd()) * site.R; cx = site.x + Math.cos(an) * d; cz = site.z + Math.sin(an) * d; }
      if (Math.hypot(cx - site.x, cz - site.z) > site.R * 1.1) continue;
      const q = World.queryRoad(cx, cz); if (!q || q.d > 34) continue;
      const dx = q.road.x[q.i] - cx, dz = q.road.z[q.i] - cz, c = Object.assign({ x: cx, z: cz, yaw: Math.atan2(dx, dz), site, gx: q.road.x[q.i], gz: q.road.z[q.i] }, sp);
      if (!fits(c)) continue;
      comps.push(c); site.comps.push(c);
    }
  }
  function plan() {
    comps = []; sites = []; roadsAll = World.roads; kops = (OYOTerrain._t && OYOTerrain._t.kop || []).filter(k => Math.max(Math.abs(k.x), Math.abs(k.z)) < 500);
    const at = (id, t) => { const r = World.byId[id], f = t * (r.n - 1), i = Math.min(r.n - 2, Math.floor(f)), k = f - i; return [r.x[i] + (r.x[i + 1] - r.x[i]) * k, r.z[i] + (r.z[i + 1] - r.z[i]) * k]; };
    const dirOf = (id, t) => { const r = World.byId[id], i = Math.min(r.n - 1, Math.floor(t * (r.n - 1))); return [r.tx[i], r.tz[i]]; };
    PAL = window.OYOPalace ? OYOPalace.plan(kit) : null;   // the palace claims its ground first
    // larger settlements at the four royal-road junctions
    [['s1', .30], ['s2', .42], ['s3', .66], ['s4', .80]].forEach(([id, t0]) => {
      const rt = World.byId[id], j = [rt.x[0], rt.z[0]], d = dirOf(id, .05);
      sites.push({ type: 'town', id, x: j[0] + d[0] * 30, z: j[1] + d[1] * 30, R: 62, want: 7, tries: 700, big: true, comps: [] });
    });
    // medium settlements where the ring links meet the caravan roads
    [['s1', .58], ['s2', .5]].forEach(([id, t]) => { const p = at(id, t); sites.push({ type: 'town', id: id + 'b', x: p[0], z: p[1], R: 52, want: 4, tries: 500, big: true, comps: [] }); });
    // villages where each village path ends
    ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9'].forEach(id => {
      const r = World.byId[id], n = r.n - 1; sites.push({ type: 'village', id, x: r.x[n] + r.tx[n] * 16, z: r.z[n] + r.tz[n] * 16, R: 44, want: 3, tries: 400, big: false, comps: [] });
    });
    sites.forEach(grow);
    // isolated farmsteads out in the countryside
    const farms = [];
    for (let t = 0; t < 900 && farms.length < 8; t++) {
      const x = rr(-370, 370), z = rr(-370, 370), nr = nearestRoad(x, z); if (!nr || nr.d < 24 || nr.d > 85) continue;
      if (comps.some(c => Math.hypot(c.x - x, c.z - z) < 75)) continue;
      const sp = makeSpec(true, false); if (!sp) continue;
      const c = Object.assign({ x, z, yaw: Math.atan2(nr.x - x, nr.z - z), gx: nr.x, gz: nr.z }, sp);
      if (!fits(c)) continue;
      const s = { type: 'farm', id: 'farm' + farms.length, x, z, comps: [c] }; c.site = s; farms.push(s); sites.push(s); comps.push(c);
    }
    // Stage 14: the royal quarter — ordinary Yoruba compounds gather along the palace's approach (grown last; rng state restored so every earlier layout is unchanged)
    if (PAL && window.OYORoyal) { const keep = sd, rq = { type: 'town', id: 'royal', x: PAL.x, z: PAL.z, R: 92, want: 9, tries: 900, big: true, comps: [] }; sites.push(rq); grow(rq); sd = keep; }
    World.siteEdge = siteEdge;
  }

  /* ======================= textures & shaders ======================= */
  function paintTex(scene, name, S, fn) {
    const t = new B.DynamicTexture(name, { width: S, height: S }, scene, true), g = t.getContext(); g.lineCap = 'round'; fn(g, S);
    t.wrapU = t.wrapV = B.Texture.WRAP_ADDRESSMODE; t.anisotropicFilteringLevel = 4; t.update(); return t;
  }
  const tiled = (g, S, x, y, m, f) => { const xs = [0], ys = [0]; if (x < m) xs.push(S); else if (x > S - m) xs.push(-S); if (y < m) ys.push(S); else if (y > S - m) ys.push(-S); for (const dx of xs) for (const dy of ys) { g.save(); g.translate(dx, dy); f(); g.restore(); } };
  const dab = (g, S, x, y, rx, ry, col) => tiled(g, S, x, y, 24, () => { g.fillStyle = col; g.beginPath(); g.ellipse(x, y, rx, ry, 0, 0, 6.3); g.fill(); });
  const line = (g, S, x, y, a, l, w, col, m) => tiled(g, S, x, y, m || 40, () => { g.strokeStyle = col; g.lineWidth = w; g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke(); });
  function paintMud(g, S) {
    g.fillStyle = '#a65b39'; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 90; i++) dab(g, S, rnd() * S, rnd() * S, 18 + rnd() * 40, 10 + rnd() * 24, rnd() < .5 ? 'rgba(206,134,92,.2)' : 'rgba(104,52,32,.2)');
    for (let i = 0; i < 380; i++) { const x = rnd() * S, y = rnd() * S, l = 20 + rnd() * 60, c = rnd() < .5 ? 'rgba(226,160,112,.2)' : 'rgba(86,42,26,.22)'; tiled(g, S, x, y, 80, () => { g.strokeStyle = c; g.lineWidth = 3 + rnd() * 7; g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + l * .5, y + (rnd() - .5) * 14, x + l, y + (rnd() - .5) * 8); g.stroke(); }); }
    for (let i = 0; i < 320; i++) line(g, S, rnd() * S, rnd() * S, rnd() * 6.28, 4 + rnd() * 9, 1.1, 'rgba(234,196,134,.5)');
    for (let i = 0; i < 14; i++) { let x = rnd() * S, y = rnd() * S; for (let k = 0; k < 6; k++) { const a = 1.2 + (rnd() - .5) * 1.4; line(g, S, x, y, a, 14 + rnd() * 16, 1.4, 'rgba(52,24,14,.45)', 60); x += Math.cos(a) * 16; y += Math.sin(a) * 16; } }
    for (let i = 0; i < 150; i++) { const x = rnd() * S, y = rnd() * S, r = 1 + rnd() * 2.6; dab(g, S, x + 1, y + 1, r, r * .8, 'rgba(60,28,16,.4)'); dab(g, S, x, y, r, r * .8, rnd() < .5 ? '#d5a07a' : '#bd825b'); }
  }
  function paintThatch(g, S) {
    g.fillStyle = '#b8903f'; g.fillRect(0, 0, S, S);
    const pal = ['rgba(236,206,120,.6)', 'rgba(196,150,66,.6)', 'rgba(150,104,46,.55)', 'rgba(244,226,160,.55)', 'rgba(110,78,36,.5)', 'rgba(176,160,96,.5)'];
    for (let i = 0; i < 3600; i++) line(g, S, rnd() * S, rnd() * S, 1.57 + (rnd() - .5) * .22, 30 + rnd() * 70, 1.2 + rnd() * 2, pal[(rnd() * 6) | 0], 100);
    for (let y = 0; y < S; y += 128) {
      g.fillStyle = 'rgba(54,30,14,.38)'; g.fillRect(0, y + 100, S, 12); g.fillStyle = 'rgba(40,22,10,.25)'; g.fillRect(0, y + 112, S, 16); g.fillStyle = 'rgba(240,214,140,.28)'; g.fillRect(0, y + 94, S, 5);
      for (let x = 0; x < S; x += 5) line(g, S, x + rnd() * 4, y + 112, 1.57 + (rnd() - .5) * .3, 6 + rnd() * 14, 1.6, rnd() < .5 ? 'rgba(160,112,50,.7)' : 'rgba(120,84,38,.7)', 4);
    }
  }
  function paintWood(g, S) {
    g.fillStyle = '#7c4b2b'; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 520; i++) line(g, S, rnd() * S, rnd() * S, 1.57 + (rnd() - .5) * .06, 30 + rnd() * 90, 1 + rnd() * 2, rnd() < .5 ? 'rgba(54,28,14,.4)' : 'rgba(184,128,80,.3)', 100);
    for (let x = 0; x < S; x += 64) { g.fillStyle = 'rgba(30,14,8,.55)'; g.fillRect(x, 0, 3, S); }
    for (let i = 0; i < 18; i++) { const x = rnd() * S, y = rnd() * S; dab(g, S, x, y, 4 + rnd() * 5, 7 + rnd() * 8, 'rgba(40,20,10,.5)'); }
  }
  const BV = `precision highp float;attribute vec3 position;attribute vec3 normal;attribute vec4 color;attribute vec2 uv;
uniform mat4 worldViewProjection;uniform mat4 worldView;varying vec3 vN;varying vec3 vC;varying vec2 vUV;varying float vD;
void main(){vN=normal;vC=color.rgb;vUV=uv;vD=length((worldView*vec4(position,1.)).xyz);gl_Position=worldViewProjection*vec4(position,1.);}`;
  const BF = `precision highp float;varying vec3 vN;varying vec3 vC;varying vec2 vUV;varying float vD;
uniform sampler2D tex;uniform vec3 toSun;uniform vec3 sunCol;uniform vec3 skyCol;uniform vec3 gndCol;uniform vec3 fogCol;uniform vec3 hazeCol;uniform float fogD;
void main(){
  vec3 alb=texture2D(tex,vUV).rgb*vC;
  vec3 N=normalize(vN);float ndl=dot(N,toSun);
  float band=.5*smoothstep(-.02,.08,ndl)+.5*smoothstep(.30,.42,ndl);
  float lit=mix(band,clamp(ndl,0.,1.),.3);
  vec3 hemi=mix(gndCol,skyCol,N.y*.5+.5);
  vec3 col=alb*(hemi+sunCol*lit);
  col=mix(col,col*vec3(.80,.74,1.),(1.-lit)*.45);
  col=mix(col,hazeCol,smoothstep(300.,1500.,vD)*.55);
  float f=1.-exp(-fogD*fogD*vD*vD);
  gl_FragColor=vec4(mix(col,fogCol,f),1.);
}`;
  const DV = `precision highp float;attribute vec3 position;attribute vec4 color;uniform mat4 worldViewProjection;uniform mat4 worldView;varying vec4 vC;varying float vD;
void main(){vC=color;vD=length((worldView*vec4(position,1.)).xyz);gl_Position=worldViewProjection*vec4(position,1.);}`;
  const DF = `precision highp float;varying vec4 vC;varying float vD;uniform vec3 fogCol;uniform float fogD;
void main(){float f=1.-exp(-fogD*fogD*vD*vD);gl_FragColor=vec4(mix(vC.rgb,fogCol,f),vC.a);}`;

  /* ======================= decals ======================= */
  const dbuf = () => ({ p: [], c: [], i: [] });
  function dvert(d, x, z, col, a) { d.p.push(x, H(x, z) + .1, z); d.c.push(col[0], col[1], col[2], a); return d.p.length / 3 - 1; }
  function hull(pts) {
    pts = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]); const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]), lo = [], up = [];
    for (const p of pts) { while (lo.length > 1 && cr(lo[lo.length - 2], lo[lo.length - 1], p) <= 0) lo.pop(); lo.push(p); }
    for (let k = pts.length - 1; k >= 0; k--) { const p = pts[k]; while (up.length > 1 && cr(up[up.length - 2], up[up.length - 1], p) <= 0) up.pop(); up.push(p); }
    lo.pop(); up.pop(); return lo.concat(up);
  }
  function softPoly(d, poly, col, a, grow) {   // filled soft-edged polygon
    let cx = 0, cz = 0; poly.forEach(p => { cx += p[0]; cz += p[1]; }); cx /= poly.length; cz /= poly.length;
    const c0 = dvert(d, cx, cz, col, a), n = poly.length, ring = (s, al) => poly.map(p => dvert(d, cx + (p[0] - cx) * s, cz + (p[1] - cz) * s, col, al));
    const r1 = ring(.62, a), r2 = ring(1, a * .92), r3 = ring(grow, 0);
    for (let k = 0; k < n; k++) { const k2 = (k + 1) % n; d.i.push(c0, r1[k], r1[k2], r1[k], r2[k], r1[k2], r1[k2], r2[k], r2[k2], r2[k], r3[k], r2[k2], r2[k2], r3[k], r3[k2]); }
  }

  /* ======================= build ======================= */
  function buildCompound(site, c, sh, mats) {
    const P = protos(), S = site.set, D = site.decal, sun = World.sunDir, sx = -sun.x / sun.y, sz = -sun.z / sun.y;
    const tint = [rr(.94, 1.1), rr(.93, 1.03), rr(.9, 1.0)], tintT = [rr(.92, 1.1), rr(.92, 1.08), rr(.86, 1.06)];
    // ---- perimeter wall (follows terrain, gate gap at the front)
    const e = c.kind === 'round' ? 2 : 8, ex = 2 / e, dense = [], M = 240;
    for (let k = 0; k <= M; k++) { const th = Math.PI / 2 + k / M * TAU, ct = Math.cos(th), st = Math.sin(th); dense.push([c.a * sgn(ct) * Math.pow(Math.abs(ct), ex), c.b * sgn(st) * Math.pow(Math.abs(st), ex)]); }
    const cum = [0]; for (let k = 1; k <= M; k++) cum.push(cum[k - 1] + Math.hypot(dense[k][0] - dense[k - 1][0], dense[k][1] - dense[k - 1][1]));
    const Ltot = cum[M], gap = c.farm ? 3.2 : 3.0, s0 = gap / 2, s1 = Ltot - gap / 2, nseg = Math.max(6, Math.round((s1 - s0) / 3.0)), path = [], cap = [], wall = [];
    let j = 0;
    for (let k = 0; k <= nseg; k++) {
      const s = s0 + (s1 - s0) * k / nseg; while (j < M - 1 && cum[j + 1] < s) j++;
      const f = (s - cum[j]) / Math.max(1e-6, cum[j + 1] - cum[j]), lx = dense[j][0] + (dense[j + 1][0] - dense[j][0]) * f + (rnd() - .5) * .22, lz = dense[j][1] + (dense[j + 1][1] - dense[j][1]) * f + (rnd() - .5) * .22, w = rot(c, lx, lz), g = H(w[0], w[1]), hs = c.wallH * (.9 + .2 * rnd());
      path.push([w[0], g, w[1], hs, .86 + .18 * rnd()]); wall.push(w);
    }
    const prof = [[-.6, -.4, .5], [-.34, 0, .62], [-.2, .95, .95], [.2, .95, 1.02], [.34, 0, .62], [.6, -.4, .5]];
    // path entries are [x,y,z,hs,shade]
    sweep(S.mud, path, prof, tint, {});
    if (!c.farm) sweep(S.thatch, path.map(p => [p[0], p[1], p[2], p[3], 1]), [[-.5, .82, .85], [-.32, 1.1, 1], [0, 1.2, 1.08], [.32, 1.1, 1], [.5, .82, .85]], tintT, {});
    // shadow strips
    for (let k = 0; k < path.length - 1; k++) {
      const A = path[k], Bq = path[k + 1], l = c.wallH * 1.1, ca = [.16, .1, .2], i0 = dvert(D, A[0], A[2], ca, .34), i1 = dvert(D, Bq[0], Bq[2], ca, .34), i2 = dvert(D, A[0] + sx * l, A[2] + sz * l, ca, .0), i3 = dvert(D, Bq[0] + sx * l, Bq[2] + sz * l, ca, .0);
      D.i.push(i0, i1, i2, i1, i3, i2);
    }
    // ---- gate
    const gp = P[c.farm ? 'gateLow' : 'gate'], gw = rot(c, 0, c.b), gl = rot(c, -1.5, c.b), gr = rot(c, 1.5, c.b);
    for (const q of [gl, gr]) { const hy = H(q[0], q[1]); stamp(S, P.potS, q[0], hy - .02, q[1], 0, 1.2, [1, 1, 1]); }
    const gy = Math.max(H(gl[0], gl[1]), H(gr[0], gr[1])) - .05; stamp(S, gp, gw[0], gy, gw[1], c.yaw, 1, tint, tintT);
    // ---- courtyard clay + path to the road
    const yard = perimeter(c, 4).map(p => [c.x + (p[0] - c.x) * .94, c.z + (p[1] - c.z) * .94]);
    softPoly(D, yard, [.74, .46, .3], .72, 1.12);
    const gx = gw[0] + Math.sin(c.yaw) * 1.5, gz = gw[1] + Math.cos(c.yaw) * 1.5, dd = Math.hypot(c.gx - gx, c.gz - gz), nn = Math.max(2, Math.round(dd / 2.5)), pc = [.66, .4, .25];
    let prev = null; const dx = (c.gx - gx) / dd, dz = (c.gz - gz) / dd;
    for (let k = 0; k <= nn && dd < 40; k++) {
      const t = k / nn, px = gx + (c.gx - gx) * t, pz = gz + (c.gz - gz) * t, w = 1.5 * (1 + .5 * t), a = k === nn ? 0 : .8, cur = [dvert(D, px - dz * w, pz + dx * w, pc, 0), dvert(D, px, pz, pc, a), dvert(D, px + dz * w, pz - dx * w, pc, 0)];
      if (prev) for (let q = 0; q < 2; q++) D.i.push(prev[q], prev[q + 1], cur[q], prev[q + 1], cur[q + 1], cur[q]); prev = cur;
    }
    // ---- buildings
    c.L.forEach(bd => {
      const sc = bd.sc, wp = rot(c, bd.x, bd.z), yaw = c.yaw + bd.yaw, pro = bd.pro, ex2 = pro.hx0 * .85 * sc, ez2 = pro.hz0 * .85 * sc;
      let lo = 1e9, hi = -1e9; for (const q of [[0, 0], [ex2, ez2], [-ex2, ez2], [ex2, -ez2], [-ex2, -ez2]]) { const cs = Math.cos(yaw), sn = Math.sin(yaw), h = H(wp[0] + q[0] * cs + q[1] * sn, wp[1] - q[0] * sn + q[1] * cs); lo = Math.min(lo, h); hi = Math.max(hi, h); }
      if (hi - lo > 1.0) { bd.skip = true; return; }
      stamp(S, pro, wp[0], hi - .12, wp[1], yaw, sc, tint, tintT); site.houses++;
      // soft cast shadow
      const cs = Math.cos(yaw), sn = Math.sin(yaw), hh = (pro.hgt || 3) * sc * .9, fp = [];
      for (let k = 0; k < 8; k++) { const th = k / 8 * TAU, ct = Math.cos(th), st = Math.sin(th), e3 = pro.kind === 'round' || pro.kind === 'oval' ? 2 : 6, q = [pro.hx0 * sc * sgn(ct) * Math.pow(Math.abs(ct), 2 / e3), pro.hz0 * sc * sgn(st) * Math.pow(Math.abs(st), 2 / e3)]; fp.push([wp[0] + q[0] * cs + q[1] * sn, wp[1] - q[0] * sn + q[1] * cs]); }
      softPoly(D, hull(fp.concat(fp.map(p => [p[0] + sx * hh, p[1] + sz * hh]))), [.16, .1, .2], .4, 1.16);
      // clay pots by the door
      if (pro.kind !== 'shed' && pro.kind !== 'rack' && rnd() < .6) {
        const fz = (pro.front || pro.hz0 - .8) + .55, n = 1 + (rnd() < .3 ? 1 : 0);
        for (let k = 0; k < n; k++) { const lx = (k ? -1 : 1) * rr(1.3, 1.9), p2 = rot({ x: wp[0], z: wp[1], yaw }, lx, fz * sc), hy = H(p2[0], p2[1]); stamp(S, pick([P.potL, P.potM, P.potS]), p2[0], hy - .02, p2[1], rnd() * 6.28, rr(.85, 1.15), [rr(.9, 1.08), rr(.9, 1.05), rr(.9, 1.05)]); site.pots++; }
      }
    });
    // courtyard details: drying rack + pot cluster
    if (c.cls !== 'small' && !c.farm && rnd() < .7) {
      const q = rot(c, rr(-1, 1) * c.a * .3, c.b * .15 + rr(-1, 1)), ok = c.L.every(bd => { const w = rot(c, bd.x, bd.z); return Math.hypot(w[0] - q[0], w[1] - q[1]) > bd.r + 2.2; });
      if (ok) stamp(S, P.rack, q[0], H(q[0], q[1]) - .02, q[1], c.yaw + rr(-.3, .3), 1, [1, 1, 1]);
    }
    const q = rot(c, rr(-2, 2), rr(0, c.b * .5));
    if (c.L.every(bd => { const w = rot(c, bd.x, bd.z); return Math.hypot(w[0] - q[0], w[1] - q[1]) > bd.r + 1.5; })) {
      stamp(S, P.potL, q[0], H(q[0], q[1]) - .02, q[1], rnd() * 6, 1.1, [1, .95, .9]); stamp(S, P.potM, q[0] + .8, H(q[0] + .8, q[1] + .3) - .02, q[1] + .3, rnd() * 6, 1, [1, .95, .9]); site.pots += 2;
    }
  }
  function toMesh(scene, name, b, mat) {
    if (!b.i.length) return null;
    const m = new B.Mesh(name, scene), vd = new B.VertexData();
    vd.positions = b.p; vd.normals = b.n; vd.colors = b.c; vd.uvs = b.u; vd.indices = b.i; vd.applyToMesh(m);
    m.material = mat; m.isPickable = false; m.freezeWorldMatrix(); m.doNotSyncBoundingInfo = true; return m;
  }
  function build(scene, W) {
    World = W; plan();
    const sun = W.sunDir, fogC = new B.Vector3(scene.fogColor.r, scene.fogColor.g, scene.fogColor.b);
    B.Effect.ShadersStore.oyoBuildVertexShader = BV; B.Effect.ShadersStore.oyoBuildFragmentShader = BF;
    B.Effect.ShadersStore.oyoDecalVertexShader = DV; B.Effect.ShadersStore.oyoDecalFragmentShader = DF;
    const mk = (name, tex) => {
      const m = new B.ShaderMaterial(name, scene, { vertex: 'oyoBuild', fragment: 'oyoBuild' }, { attributes: ['position', 'normal', 'color', 'uv'], uniforms: ['worldViewProjection', 'worldView', 'toSun', 'sunCol', 'skyCol', 'gndCol', 'fogCol', 'hazeCol', 'fogD'], samplers: ['tex'] });
      m.setTexture('tex', tex); m.setVector3('toSun', sun); m.setVector3('sunCol', new B.Vector3(.85, .73, .53)); m.setVector3('skyCol', new B.Vector3(.58, .54, .47));
      m.setVector3('gndCol', new B.Vector3(.42, .27, .2)); m.setVector3('fogCol', fogC); m.setVector3('hazeCol', new B.Vector3(.93, .84, .64)); m.setFloat('fogD', scene.fogDensity); m.backFaceCulling = false; return m;
    };
    const mats = { mud: mk('bMud', paintTex(scene, 'bMudT', 512, paintMud)), thatch: mk('bThatch', paintTex(scene, 'bThatchT', 512, paintThatch)), wood: mk('bWood', paintTex(scene, 'bWoodT', 256, paintWood)) };
    const dm = new B.ShaderMaterial('bDecal', scene, { vertex: 'oyoDecal', fragment: 'oyoDecal' }, { attributes: ['position', 'color'], uniforms: ['worldViewProjection', 'worldView', 'fogCol', 'fogD'] });
    dm.setVector3('fogCol', fogC); dm.setFloat('fogD', scene.fogDensity); dm.backFaceCulling = false; dm.disableDepthWrite = true; dm.zOffset = -3; dm.alphaMode = B.Engine.ALPHA_COMBINE; dm.needAlphaBlending = () => true;
    let tris = 0, meshes = 0, houses = 0, pots = 0;
    sites.forEach(site => {
      site.set = newSet(); site.decal = dbuf(); site.houses = 0; site.pots = 0;
      site.comps.forEach(c => buildCompound(site, c, null, mats));
      for (const k of ['mud', 'thatch', 'wood']) { const m = toMesh(scene, 'yoruba_' + site.id + '_' + k, site.set[k], mats[k]); if (m) meshes++; }
      if (site.decal.i.length) { const d = site.decal, m = new B.Mesh('yoruba_' + site.id + '_decal', scene), vd = new B.VertexData(); vd.positions = d.p; vd.colors = d.c; vd.indices = d.i; vd.applyToMesh(m); m.material = dm; m.hasVertexAlpha = true; m.alphaIndex = 7; m.isPickable = false; m.freezeWorldMatrix(); meshes++; }
      tris += setTris(site.set); houses += site.houses; pots += site.pots; site.set = null; site.decal = null;
    });
    if (PAL) { try { const r = OYOPalace.build(scene, W, kit, { mats, dm, mk }); meshes += r.meshes; tris += r.tris; PAL.stats = r; } catch (e) { console.warn('Palace skipped:', e); } }
    const stats = { palaceTris: PAL && PAL.stats ? PAL.stats.tris : 0, sites: sites.length, compounds: comps.length, houses, pots, triangles: tris, meshes };
    return { sites, compounds: comps, stats, palace: PAL };
  }
  function paintMap(g, k, half) {
    g.save(); g.lineWidth = 1;
    comps.forEach(c => { if (c.hidden) return; const X = (c.x + half) * k, Y = (half - c.z) * k, s = c.site && c.site.type === 'farm' ? 2.2 : 3.2; g.fillStyle = '#f3dcae'; g.strokeStyle = '#2a170d'; g.beginPath(); g.rect(X - s, Y - s, s * 2, s * 2); g.fill(); g.stroke(); });
    g.restore();
    if (PAL && window.OYOPalace) OYOPalace.paintMap(g, k, half);
  }

  const kit = { H, rot, edgeR, nearestRoad, perimeter, inside, toLocal, loft, box, sweep, lathe, commit, buf, newSet, stamp, house, shed, pot, protos, roofRings, wallRings, door, win, post, hull, softPoly, dvert, dbuf, rngSeed, rnd, rr, pick, TAU, sgn, clamp, DARK, setTris, get comps() { return comps; }, get kops() { return kops; }, get World() { return World; } };
  window.OYOBuildings = { build, paintMap, plan: (W) => { World = W; plan(); return { sites, compounds: comps }; }, _t: { protos, layout, setTris, stamp, newSet } };
})();
