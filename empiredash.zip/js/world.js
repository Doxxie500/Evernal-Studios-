/* EMPIRE DASH — Stage 1 · world.js
   Terrain, painted sky, road network, stones, minimap data. */
(function () {
  'use strict';
  const B = BABYLON;
  const WORLD = 900, HALF = WORLD / 2, SP = 2.0;

  /* ---------- noise ---------- */
  function hash(x, y) { const h = Math.sin(x * 127.1 + y * 311.7) * 43758.5453; return h - Math.floor(h); }
  function vnoise(x, y) {
    const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
    const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
    const a = hash(xi, yi), b = hash(xi + 1, yi), c = hash(xi, yi + 1), d = hash(xi + 1, yi + 1);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }
  function fbm(x, y, o) { let s = 0, a = 0.5, f = 1; for (let i = 0; i < o; i++) { s += a * vnoise(x * f, y * f); f *= 2; a *= 0.5; } return s; }
  const sm = (a, b, x) => { x = Math.min(1, Math.max(0, (x - a) / (b - a))); return x * x * (3 - 2 * x); };
  let seed = 20261112;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };

  /* ---------- terrain height (gentle rolling land, hills rim the world) ---------- */
  // Stage 2: the landform lives in terrain.js; once the terrain mesh exists, height() reads
  // the exact rendered surface (roads, player and future horse all share it).
  let curH = function (x, z) { return window.OYOTerrain.baseHeight(x, z); };
  function height(x, z) { return curH(x, z); }

  /* ---------- road definitions ---------- */
  const DEFS = [
    { id: 'royal', cls: 'royal', w: 11, name: 'The Royal Road · Ọ̀nà Ọba', pts: [[-385, -40], [-300, -12], [-212, 38], [-122, 30], [-40, -16], [40, -42], [130, -22], [222, 24], [312, 8], [385, -32]] },
    { id: 's1', cls: 'secondary', w: 6, name: 'Northern Caravan Way', pts: [{ on: 'royal', t: .30 }, [-150, 120], [-92, 200], [-112, 292], [-40, 372]] },
    { id: 's2', cls: 'secondary', w: 6, name: 'Southern Salt Road', pts: [{ on: 'royal', t: .42 }, [-70, -112], [-18, -190], [52, -250], [28, -338], [110, -384]] },
    { id: 's3', cls: 'secondary', w: 6, name: 'Northeast Kola Road', pts: [{ on: 'royal', t: .66 }, [152, 62], [202, 132], [282, 172], [372, 250]] },
    { id: 's4', cls: 'secondary', w: 6, name: 'Southeast Cattle Road', pts: [{ on: 'royal', t: .80 }, [252, -52], [292, -132], [242, -212], [302, -292], [380, -342]] },
    { id: 's5', cls: 'secondary', w: 5.4, name: 'Northern Ring Link', pts: [{ on: 's1', t: .58 }, [-30, 226], [60, 196], [140, 160], { on: 's3', t: .22 }] },
    { id: 's6', cls: 'secondary', w: 5.4, name: 'Southern Ring Link', pts: [{ on: 's2', t: .5 }, [100, -200], [170, -160], { on: 's4', t: .55 }] },
    { id: 'p1', cls: 'path', w: 3.2, plaza: 1, name: 'Farmers’ Village Path', pts: [{ on: 's1', t: .35 }, [-230, 150], [-292, 190]] },
    { id: 'p2', cls: 'path', w: 3.2, plaza: 1, name: 'Potters’ Path', pts: [{ on: 's1', t: .80 }, [-170, 300], [-222, 350]] },
    { id: 'p3', cls: 'path', w: 3.2, plaza: 1, name: 'Weavers’ Path', pts: [{ on: 's2', t: .30 }, [-130, -170], [-200, -212], [-270, -190]] },
    { id: 'p4', cls: 'path', w: 3.2, plaza: 1, name: 'Well Path', pts: [{ on: 's2', t: .80 }, [110, -290], [172, -340]] },
    { id: 'p5', cls: 'path', w: 3.2, plaza: 1, name: 'Hunters’ Path', pts: [{ on: 's3', t: .50 }, [210, 215], [168, 290], [120, 330]] },
    { id: 'p6', cls: 'path', w: 3.2, plaza: 1, name: 'Herders’ Path', pts: [{ on: 's4', t: .40 }, [330, -170], [385, -118]] },
    { id: 'p7', cls: 'path', w: 3.2, plaza: 1, name: 'Shrine Path', pts: [{ on: 'royal', t: .12 }, [-300, -90], [-342, -152]] },
    { id: 'p8', cls: 'path', w: 3.2, plaza: 1, name: 'Dyers’ Path', pts: [{ on: 'royal', t: .90 }, [332, 72], [382, 112]] },
    { id: 'p9', cls: 'path', w: 3.2, plaza: 1, name: 'Hamlet Path', pts: [{ on: 's5', t: .50 }, [40, 262], [14, 326]] }
  ];
  const roads = [];
  const byId = {};

  function pointOn(id, t) {
    const r = byId[id], f = t * (r.n - 1), i = Math.min(r.n - 2, Math.floor(f)), k = f - i;
    return [r.x[i] + (r.x[i + 1] - r.x[i]) * k, r.z[i] + (r.z[i + 1] - r.z[i]) * k];
  }

  function buildRoad(def, k) {
    let c = def.pts.map(p => Array.isArray(p) ? p.slice() : pointOn(p.on, p.t));
    if (def.cls !== 'royal') {
      const o = [c[0]];
      for (let i = 1; i < c.length; i++) {
        const a = c[i - 1], b = c[i], dx = b[0] - a[0], dz = b[1] - a[1], L = Math.hypot(dx, dz), q = (rnd() - .5) * .34 * L;
        o.push([(a[0] + b[0]) / 2 - dz / L * q, (a[1] + b[1]) / 2 + dx / L * q], b);
      }
      c = o;
    }
    // Catmull-Rom dense polyline
    const dense = [];
    for (let i = 0; i < c.length - 1; i++) {
      const p0 = c[Math.max(i - 1, 0)], p1 = c[i], p2 = c[i + 1], p3 = c[Math.min(i + 2, c.length - 1)];
      const steps = Math.ceil(Math.hypot(p2[0] - p1[0], p2[1] - p1[1]) / 1.5);
      for (let s = 0; s < steps; s++) {
        const t = s / steps, t2 = t * t, t3 = t2 * t, q = [0, 0];
        for (let a = 0; a < 2; a++) q[a] = .5 * (2 * p1[a] + (-p0[a] + p2[a]) * t + (2 * p0[a] - 5 * p1[a] + 4 * p2[a] - p3[a]) * t2 + (-p0[a] + 3 * p1[a] - 3 * p2[a] + p3[a]) * t3);
        dense.push(q);
      }
    }
    dense.push(c[c.length - 1]);
    const cum = [0];
    for (let i = 1; i < dense.length; i++) cum.push(cum[i - 1] + Math.hypot(dense[i][0] - dense[i - 1][0], dense[i][1] - dense[i - 1][1]));
    const total = cum[cum.length - 1], N = Math.max(3, Math.round(total / SP));
    const r = { id: def.id, name: def.name, cls: def.cls, w: def.w, k: k * 5.7 + 1.3, n: N + 1, len: total, plaza: !!def.plaza,
      pa: def.pts[0].on ? def.pts[0] : null, pb: def.pts[def.pts.length - 1].on ? def.pts[def.pts.length - 1] : null, joinA: !!def.pts[0].on, joinB: !!def.pts[def.pts.length - 1].on, x: [], z: [], y: [], s: [], tx: [], tz: [], nx: [], nz: [] };
    let j = 0;
    for (let i = 0; i <= N; i++) {
      const tg = total * i / N;
      while (j < dense.length - 2 && cum[j + 1] < tg) j++;
      const f = (tg - cum[j]) / Math.max(1e-6, cum[j + 1] - cum[j]);
      r.x.push(dense[j][0] + (dense[j + 1][0] - dense[j][0]) * f);
      r.z.push(dense[j][1] + (dense[j + 1][1] - dense[j][1]) * f);
      r.s.push(tg);
    }
    const tangents = () => {
      for (let i = 0; i < r.n; i++) {
        const a = Math.max(0, i - 1), b = Math.min(r.n - 1, i + 1);
        let dx = r.x[b] - r.x[a], dz = r.z[b] - r.z[a]; const L = Math.hypot(dx, dz) || 1;
        r.tx[i] = dx / L; r.tz[i] = dz / L; r.nx[i] = -dz / L; r.nz[i] = dx / L;
      }
    };
    tangents();
    // natural meander wobble (zero at both ends so junctions stay exact)
    const amp = def.cls === 'royal' ? 0.35 : 0.55;
    for (let i = 0; i < r.n; i++) {
      const s = r.s[i], o = (vnoise(s / 45 + r.k, r.k * 7.3) - .5) * def.w * amp * Math.sqrt(Math.max(0, Math.sin(Math.PI * Math.min(1, s / total))));
      r.x[i] += r.nx[i] * o; r.z[i] += r.nz[i] * o;
    }
    tangents();
    for (let i = 0; i < r.n; i++) r.y[i] = height(r.x[i], r.z[i]);
    return r;
  }

  const widthAt = (r, i) => {
    const s = r.s[i];
    let w = r.w * (1 + .18 * (vnoise(s / 37 + r.k, r.k * 3.1) - .5));
    if (r.joinA) w *= 1 + .75 * Math.exp(-s / 7);
    if (r.joinB) w *= 1 + .75 * Math.exp(-(r.len - s) / 7);
    if (r.plaza) w *= 1 + 1.1 * Math.exp(-(r.len - s) / 5);
    return w;
  };
  const endAlpha = (r, s) => {
    const a = r.joinA ? sm(0, 7, s) : sm(0, 22, s);
    return a * (r.joinB ? sm(0, 7, r.len - s) : (r.plaza ? sm(0, 3, r.len - s) : sm(0, 22, r.len - s)));
  };

  /* ---------- spatial grid for road queries ---------- */
  const CELL = 24, grid = new Map();
  const gk = (ix, iz) => (ix + 100) * 1000 + (iz + 100);
  function indexRoads() {
    roads.forEach((r, ri) => { for (let i = 0; i < r.n; i++) {
      const key = gk(Math.floor(r.x[i] / CELL), Math.floor(r.z[i] / CELL));
      (grid.get(key) || grid.set(key, []).get(key)).push(ri, i);
    } });
  }
  function queryRoad(x, z) {
    const cx = Math.floor(x / CELL), cz = Math.floor(z / CELL);
    let best = null, bs = 1e9;
    for (let ix = cx - 1; ix <= cx + 1; ix++) for (let iz = cz - 1; iz <= cz + 1; iz++) {
      const l = grid.get(gk(ix, iz)); if (!l) continue;
      for (let q = 0; q < l.length; q += 2) {
        const r = roads[l[q]], i = l[q + 1], d = Math.hypot(x - r.x[i], z - r.z[i]), hw = widthAt(r, i) * .5, sc = d - hw;
        if (sc < bs) { bs = sc; best = { road: r, i, d, hw, s: r.s[i] }; }
      }
    }
    return best;
  }

  /* ---------- painted textures ---------- */
  function paintGround(scene) {
    const S = 1024, tex = new B.DynamicTexture('groundTex', { width: S, height: S }, scene, true), g = tex.getContext();
    g.fillStyle = '#f1e4cc'; g.fillRect(0, 0, S, S);
    const wrap = fn => { for (const dx of [-S, 0, S]) for (const dy of [-S, 0, S]) { g.save(); g.translate(dx, dy); fn(); g.restore(); } };
    g.lineCap = 'round';
    for (let i = 0; i < 2600; i++) {
      const x = rnd() * S, y = rnd() * S, a = rnd() * Math.PI, l = 8 + rnd() * 34, wd = 2 + rnd() * 8, v = 205 + rnd() * 50 | 0, tn = rnd();
      const col = tn < .5 ? `rgba(${v},${v - 18},${v - 52},.20)` : `rgba(${v - 70},${v - 96},${v - 120},.13)`;
      wrap(() => { g.strokeStyle = col; g.lineWidth = wd; g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke(); });
    }
    for (let i = 0; i < 380; i++) {
      const x = rnd() * S, y = rnd() * S, r = 1 + rnd() * 3;
      wrap(() => { g.fillStyle = 'rgba(120,80,50,.28)'; g.beginPath(); g.arc(x + 1, y + 1, r, 0, 6.3); g.fill(); g.fillStyle = 'rgba(255,244,222,.55)'; g.beginPath(); g.arc(x, y, r, 0, 6.3); g.fill(); });
    }
    tex.wrapU = tex.wrapV = B.Texture.WRAP_ADDRESSMODE; tex.anisotropicFilteringLevel = 4; tex.update();
    return tex;
  }

  function paintRoad(scene, kind) {
    /* Tiny 128px flat-colour road (was 512px with 1,800+ painted strokes). u runs across the road, v along it (one tile = ~10 m).
       Camwood-red bed, darker wheel lanes, brass edge lines, and a row of ivory adire diamonds down the middle of the royal road. */
    const S = 128, tex = new B.DynamicTexture('roadTex_' + kind, { width: S, height: S }, scene, true), g = tex.getContext();
    g.fillStyle = kind === 'royal' ? '#b4532f' : kind === 'secondary' ? '#a4522f' : '#9a5a38'; g.fillRect(0, 0, S, S);
    const lanes = kind === 'royal' ? [.2, .31, .69, .8] : kind === 'secondary' ? [.3, .7] : [];
    g.fillStyle = 'rgba(70,24,12,.28)'; lanes.forEach(u => g.fillRect((u - .03) * S, 0, .06 * S, S));
    if (kind !== 'path') { g.fillStyle = '#e2b13c'; g.fillRect(.085 * S, 0, .02 * S, S); g.fillRect(.895 * S, 0, .02 * S, S); }
    if (kind === 'royal') {
      g.fillStyle = '#fbf3dc';
      for (let k = 0; k < 4; k++) { const cx = S * .5, cy = S * (k + .5) / 4, r = S * .035; g.beginPath(); g.moveTo(cx, cy - r * 1.5); g.lineTo(cx + r, cy); g.lineTo(cx, cy + r * 1.5); g.lineTo(cx - r, cy); g.closePath(); g.fill(); }
    }
    if (kind === 'path') { g.fillStyle = 'rgba(224,170,110,.22)'; g.fillRect(S * .34, 0, S * .32, S); }
    tex.wrapU = tex.wrapV = B.Texture.WRAP_ADDRESSMODE; tex.anisotropicFilteringLevel = 2; tex.update();
    return tex;
  }

  /* ---------- sky ---------- */
  const SKY_V = 'precision highp float;attribute vec3 position;uniform mat4 worldViewProjection;varying vec3 vDir;void main(){vDir=position;gl_Position=worldViewProjection*vec4(position,1.);}';
  /* Simple Yoruba sky: adire-indigo overhead fading to brass-ivory at the horizon, a flat sun and a few flat ivory clouds.
     No noise loops (the old painted cloud shader ran 40+ sin() calls on every pixel and was a main cause of slow frames). */
  const SKY_F = `precision highp float;varying vec3 vDir;uniform float time;uniform vec3 sunDir;uniform vec3 skyZen;uniform vec3 skyMid;uniform vec3 skyHor;uniform vec3 sunGlow;uniform vec3 sunDisc;uniform vec3 cloudCol;uniform float starAmt;
void main(){
  vec3 d=normalize(vDir);float y=clamp(d.y,0.,1.);
  vec3 zen=skyZen,mid=skyMid,hor=skyHor;
  vec3 col=mix(hor,mid,smoothstep(0.,.24,y));col=mix(col,zen,smoothstep(.2,.9,y));
  vec3 sd=normalize(sunDir);float s=max(dot(d,sd),0.);float s2=s*s;
  col+=sunGlow*s2*s2*.20;
  col=mix(col,sunDisc,smoothstep(.9985,.9993,s));
  float stH=fract(sin(dot(floor(d.xz/(d.y+.35)*70.),vec2(12.9898,78.233)))*43758.5453);
  col+=vec3(1.,.97,.9)*step(.9965,stH)*starAmt*smoothstep(.1,.45,d.y)*(.65+.35*sin(time*2.+stH*60.));
  vec2 uv=d.xz/(max(d.y,0.)+.28)*1.15+vec2(time*.012,0.);
  float c=sin(uv.x*1.9+sin(uv.y*1.4)*1.7)*sin(uv.y*1.15+1.3+sin(uv.x*.8)*.9);
  float cloud=smoothstep(.42,.5,c)*smoothstep(.05,.28,d.y);
  col=mix(col,cloudCol,cloud*.88);
  gl_FragColor=vec4(col,1.);
}`;
  B.Effect.ShadersStore.oyoSkyVertexShader = SKY_V;
  B.Effect.ShadersStore.oyoSkyFragmentShader = SKY_F;

  /* ---------- build ---------- */
  const World = { WORLD, HALF, roads, byId, height, widthAt, queryRoad, fbm, vnoise,
    setHeightFn(f) { curH = f; },
    buildRoads() { DEFS.forEach((d, k) => { const r = buildRoad(d, k); roads.push(r); byId[r.id] = r; }); indexRoads(); }, sunDir: new B.Vector3(.55, .55, -.5).normalize(), mapCanvas: null, mapK: 600 / WORLD, paintRoad };

  World.build = async function (scene, progress) {
    const tick = (f, t) => { progress && progress(f, t); return window.OYOBoot && OYOBoot.yield ? OYOBoot.yield() : new Promise(r => setTimeout(r, 0)); };   // one repaint between steps, no fixed delay
    const dir = World.sunDir.scale(-1);

    await tick(.05, 'Painting the sky…');
    scene.clearColor = new B.Color4(.95, .86, .66, 1);
    scene.fogMode = B.Scene.FOGMODE_EXP2; scene.fogDensity = .0011; scene.fogColor = new B.Color3(.95, .86, .66);
    const hemi = new B.HemisphericLight('hemi', new B.Vector3(0, 1, 0), scene);
    hemi.diffuse = new B.Color3(1, .96, .86); hemi.groundColor = new B.Color3(.56, .44, .42); hemi.specular = B.Color3.Black(); hemi.intensity = .78;
    const sun = new B.DirectionalLight('sun', dir, scene);
    sun.diffuse = new B.Color3(1, .90, .68); sun.specular = B.Color3.Black(); sun.intensity = 1.15;
    sun.autoUpdateExtends = false; sun.autoCalcShadowZBounds = false;
    sun.orthoLeft = -65; sun.orthoRight = 65; sun.orthoTop = 65; sun.orthoBottom = -65; sun.shadowMinZ = 1; sun.shadowMaxZ = 340;
    const sg = new B.ShadowGenerator(512, sun); sg.setDarkness(.34); sg.bias = .0012;   // 512 map, hard-edged: ~4x cheaper than the old 1024 + Poisson soft shadows
    const skyMat = new B.ShaderMaterial('sky', scene, { vertex: 'oyoSky', fragment: 'oyoSky' }, { attributes: ['position'], uniforms: ['worldViewProjection', 'time', 'sunDir', 'skyZen', 'skyMid', 'skyHor', 'sunGlow', 'sunDisc', 'cloudCol', 'starAmt'] });
    skyMat.setVector3('skyZen', new B.Vector3(.10, .20, .47)); skyMat.setVector3('skyMid', new B.Vector3(.28, .45, .78)); skyMat.setVector3('skyHor', new B.Vector3(.95, .86, .66)); skyMat.setVector3('sunGlow', new B.Vector3(1, .80, .46)); skyMat.setVector3('sunDisc', new B.Vector3(1, .95, .76)); skyMat.setVector3('cloudCol', new B.Vector3(.99, .96, .86)); skyMat.setFloat('starAmt', 0);
    skyMat.backFaceCulling = false; skyMat.disableDepthWrite = true; skyMat.setVector3('sunDir', World.sunDir); skyMat.setFloat('time', 0);
    const sky = B.MeshBuilder.CreateSphere('sky', { diameter: 2000, segments: 16 }, scene);
    sky.material = skyMat; sky.infiniteDistance = true; sky.applyFog = false; sky.isPickable = false;

    await tick(.15, 'Surveying the road network…');
    World.buildRoads();

    await tick(.25, 'Surveying the savanna…');
    OYOTerrain.prepare(World);                       // kopjes + graded road beds
    await tick(.35, 'Grading the land to the roads…');
    OYOTerrain.computeHeights();                     // from here on height() == rendered surface
    await tick(.45, 'Painting the soil and dry grass…');
    const land = OYOTerrain.buildMeshes(scene, World);
    const ground = land.ground;

    await tick(.50, 'Laying the roads…');
    const buckets = { royal: null, secondary: null, path: null, verge: null };
    Object.keys(buckets).forEach(k => buckets[k] = { pos: [], idx: [], uv: [], col: [] });
    const ribbon = (bk, r, NC, wm, yoff, isRoad) => {
      const base = bk.pos.length / 3;
      for (let i = 0; i < r.n; i++) {
        const s = r.s[i], w = widthAt(r, i) * wm * .5, a = endAlpha(r, s);
        const jl = 1 + (vnoise(s / 5 + r.k * 3, 1.7) - .5) * .28, jr = 1 + (vnoise(s / 5 + r.k * 3 + 40, 8.1) - .5) * .28;
        const tint = .92 + .14 * vnoise(s / 9 + r.k, r.k * 2.2);
        for (let j = 0; j < NC; j++) {
          const v = -1 + 2 * j / (NC - 1), av = Math.abs(v), lat = v * w * (1 + ((v < 0 ? jl : jr) - 1) * av * av);
          const x = r.x[i] + r.nx[i] * lat, z = r.z[i] + r.nz[i] * lat;
          let y = height(x, z) + yoff;
          if (isRoad) {
            y += .06 * (1 - v * v) + (vnoise(x * .8, z * .8) - .5) * .08;
            y -= r.cls === 'path' ? .03 * Math.exp(-Math.pow(av / .25, 2)) : .05 * Math.exp(-Math.pow((av - .45) / .13, 2));
          }
          bk.pos.push(x, y, z); bk.uv.push((v + 1) / 2, s / (r.w * .95));
          if (isRoad) { const sh = tint * (1 - .22 * av * av); bk.col.push(sh, sh * .97, sh * .93, a * (1 - sm(.8, 1, av))); }
          else bk.col.push(.80 * tint, .60 * tint, .34 * tint, a * .8 * (1 - sm(.2, 1, av)));
        }
      }
      for (let i = 0; i < r.n - 1; i++) for (let j = 0; j < NC - 1; j++) {
        const a = base + i * NC + j, b = a + 1, c = a + NC, d = c + 1; bk.idx.push(a, c, b, b, c, d);
      }
    };
    roads.forEach(r => { ribbon(buckets.verge, r, 5, 1.9, .03, false); ribbon(buckets[r.cls], r, 7, 1, .06, true); });
    const mk = (name, bk, mat, ai, zo) => {
      const m = new B.Mesh(name, scene), vd = new B.VertexData(), nrm = [];
      B.VertexData.ComputeNormals(bk.pos, bk.idx, nrm);
      vd.positions = bk.pos; vd.indices = bk.idx; vd.uvs = bk.uv; vd.colors = bk.col; vd.normals = nrm; vd.applyToMesh(m);
      mat.backFaceCulling = false; mat.specularColor = B.Color3.Black(); mat.emissiveColor = new B.Color3(.1, .06, .04); mat.disableDepthWrite = true; mat.zOffset = zo;
      m.material = mat; m.hasVertexAlpha = true; m.receiveShadows = true; m.alphaIndex = ai; m.isPickable = false; return m;
    };
    const vMat = new B.StandardMaterial('vergeMat', scene);
    mk('verge', buckets.verge, vMat, 1, -1);
    ['royal', 'secondary', 'path'].forEach((k, n) => {
      const m = new B.StandardMaterial('roadMat_' + k, scene); m.diffuseTexture = paintRoad(scene, k); mk('road_' + k, buckets[k], m, 2 + n, -2);
    });

    await tick(.75, 'Scattering gravel and stones…');
    const chunks = new Map(), pal = [[.93, .86, .68], [.70, .38, .26], [.36, .42, .70], [.86, .70, .42]];
    const q = new B.Quaternion(), sc = new B.Vector3(), tr = new B.Vector3(), mtx = new B.Matrix();
    const addStone = (x, z, size) => {
      const ci = Math.floor((x + HALF) / 150), cj = Math.floor((z + HALF) / 150), key = ci * 10 + cj;
      let ch = chunks.get(key); if (!ch) chunks.set(key, ch = { m: [], c: [] });
      B.Quaternion.RotationYawPitchRollToRef(rnd() * 6.28, (rnd() - .5) * .5, (rnd() - .5) * .5, q);
      sc.set(size * (.8 + rnd() * .6), size * (.45 + rnd() * .3), size * (.8 + rnd() * .6)); tr.set(x, height(x, z) + size * .12, z);
      B.Matrix.ComposeToRef(sc, q, tr, mtx); ch.m.push(...mtx.m);
      const p = pal[Math.floor(rnd() * 4)], l = .88 + rnd() * .22; ch.c.push(p[0] * l, p[1] * l, p[2] * l, 1);
    };
    roads.forEach(r => {
      for (let i = 1; i < r.n - 1; i++) {
        const hw = widthAt(r, i) * .5, a = endAlpha(r, r.s[i]); if (a < .5) continue;
        const side = () => (rnd() < .5 ? -1 : 1);
        const put = (lo, hi, size) => { const l = side() * hw * (lo + rnd() * (hi - lo)); addStone(r.x[i] + r.nx[i] * l, r.z[i] + r.nz[i] * l, size); };
        const ne = Math.round(rnd() * 2.2); for (let e = 0; e < ne; e++) put(.85, 1.4, .08 + Math.pow(rnd(), 3) * .5);
        if (rnd() < .5) put(0, .85, .04 + rnd() * .08);
        if (rnd() < .07) { const l = side() * hw * (1 + rnd() * .3), cx = r.x[i] + r.nx[i] * l, cz = r.z[i] + r.nz[i] * l; for (let k = 0; k < 5; k++) addStone(cx + (rnd() - .5) * 1.6, cz + (rnd() - .5) * 1.6, .07 + rnd() * .22); }
      }
    });
    const rMat = new B.StandardMaterial('rockMat', scene); rMat.specularColor = B.Color3.Black(); rMat.emissiveColor = new B.Color3(.08, .05, .035);
    chunks.forEach((ch, key) => {
      const m = B.MeshBuilder.CreatePolyhedron('rocks_' + key, { type: 2, size: .5 }, scene); m.convertToFlatShadedMesh();
      m.material = rMat; m.thinInstanceSetBuffer('matrix', new Float32Array(ch.m), 16, true); m.thinInstanceSetBuffer('color', new Float32Array(ch.c), 4, true);
      m.thinInstanceRefreshBoundingInfo(true); m.isPickable = false; m.receiveShadows = true; sg.getShadowMap().renderList.push(m);
    });

    await tick(.80, 'Raising the Aláàfin’s palace and Yoruba compounds…');
    try { World.settlements = OYOBuildings.build(scene, World, sg); }
    catch (e) { console.warn('Settlements skipped:', e); World.siteEdge = null; }
    try { OYOVillagers.plan(World); }                 // Stage 6: reserve ground for the marketplaces (before trees/rocks)
    catch (e) { console.warn('Market planning skipped:', e); }

    await tick(.82, 'Placing boulders and dry grass…');
    OYOTerrain.scatter(scene, World, sg);

    await tick(.88, 'Planting baobabs, palms and savanna trees…');
    World.vegetation = OYOVegetation.build(scene, World);

    await tick(.89, 'Opening the markets and gathering the villagers…');
    try { World.villagers = OYOVillagers.build(scene, World); }
    catch (e) { console.warn('Villagers skipped:', e); }

    await tick(.895, 'Raising Oyo’s farms, shrines and village palms…');
    try { World.oyo = window.OYOWorlds && OYOWorlds.buildCurrent(scene, World); }   // Stage 13: Oyo Kingdom world pack (oyo-world.js)
    catch (e) { console.warn('Oyo world pack skipped:', e); }

    await tick(.9, 'Drawing the map…');
    const mc = document.createElement('canvas'); mc.width = mc.height = 600; const g = mc.getContext('2d'), k = World.mapK;
    g.fillStyle = '#4a2a18'; g.fillRect(0, 0, 600, 600); OYOTerrain.paintMap(g, 600); g.lineCap = g.lineJoin = 'round';
    const trace = r => { g.beginPath(); for (let i = 0; i < r.n; i++) { const X = (r.x[i] + HALF) * k, Y = (HALF - r.z[i]) * k; i ? g.lineTo(X, Y) : g.moveTo(X, Y); } g.stroke(); };
    const sty = { royal: ['#ffd27a', 6], secondary: ['#f0a35e', 3.6], path: ['#e9cfae', 2.2] };
    roads.forEach(r => { g.strokeStyle = '#1f0f07'; g.lineWidth = sty[r.cls][1] + 2.4; trace(r); });
    roads.forEach(r => { g.strokeStyle = sty[r.cls][0]; g.lineWidth = sty[r.cls][1]; trace(r); });
    try { OYOBuildings.paintMap(g, k, HALF); } catch (e) { /* optional */ }
    try { OYOVillagers.paintMap(g, k, HALF); } catch (e) { /* optional */ }
    World.mapCanvas = mc;

    World.sky = skyMat; World.sun = sun; World.ground = ground; World.hemi = hemi;
    World.updateSun = (p) => { const s = 2; sun.position.set(Math.round((p.x - dir.x * 150) / s) * s, p.y - dir.y * 150, Math.round((p.z - dir.z * 150) / s) * s); };
    await tick(1, 'Ready');
    return World;
  };

  window.OYOWorld = World;
})();
