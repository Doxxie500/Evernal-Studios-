/* POST /api/redeem  { name, sig, dev }
   A paid cart link (?cart=NAME&k=SIGNATURE) is checked here with the PUBLIC key, and then LIMITED TO 3 DEVICES: the first devices that use it keep it, a 4th is refused.
   So a forwarded link stops working for strangers, while the real owner can still use a new phone or a reinstall.
   200 = ok · 403 = bad signature · 409 = link already used on its 3 devices · 429 = too many tries.  Storage trouble → 503 (the game then lets the link through). */
'use strict';
const { redis, limited, send, body } = require('./_lib');
const PUB = { kty: 'EC', crv: 'P-256', x: '_H2X0jNFio8GAdcxexVyLFtAWHQ2HS3OmvIOCWB5a6A', y: '2RatVkUymIxQp6BebXEUAxVPmV81YIb-cuZ2KWV5HpY' };
const MAX_DEVICES = 3;
const clean = s => String(s || '').replace(/[^\p{L}\p{M}\p{N} '’.\-]/gu, '').replace(/\s+/g, ' ').trim().slice(0, 14);
const b64u = t => { t = t.replace(/-/g, '+').replace(/_/g, '/'); while (t.length % 4) t += '='; return Uint8Array.from(Buffer.from(t, 'base64')); };

async function valid(name, sig) {
  try {
    const key = await crypto.subtle.importKey('jwk', PUB, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    return await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, b64u(sig), new TextEncoder().encode('jagun-cart:' + name));
  } catch (e) { return false; }
}
module.exports = async (req, res) => {
  if (req.method !== 'POST') return send(res, 405, { ok: false });
  if (await limited(req, 'redeem', 20, 600)) return send(res, 429, { ok: false });
  const b = await body(req), name = clean(b.name), sig = String(b.sig || ''), dev = String(b.dev || '');
  if (!name || name === '0' || sig.length < 20 || sig.length > 200 || !/^[a-z0-9]{16,40}$/.test(dev)) return send(res, 400, { ok: false });
  if (!(await valid(name, sig))) return send(res, 403, { ok: false });
  try {
    const k = 'cart:' + name; await redis(['SADD', 'carts:names', name]);
    if (await redis(['SISMEMBER', k, dev])) return send(res, 200, { ok: true });
    await redis(['SADD', k, dev]);
    if ((await redis(['SCARD', k])) > MAX_DEVICES) { await redis(['SREM', k, dev]); return send(res, 409, { ok: false }); }
    return send(res, 200, { ok: true });
  } catch (e) { return send(res, 503, { ok: false }); }
};
