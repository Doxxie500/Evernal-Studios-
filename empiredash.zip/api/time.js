/* GET /api/time → { now: <server time in ms> }.  The game uses it instead of the phone's clock for the launch window, daily bags, streaks and the Ose gate. */
'use strict';
const { send } = require('./_lib');
module.exports = (req, res) => send(res, 200, { now: Date.now() });
