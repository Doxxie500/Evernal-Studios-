/* POST /api/stats { ts, sig } — admin only. sig = ECDSA signature of "jagun-stats:<ts>" made by the admin file's private key (ts within 5 min). */
'use strict';
const { redis, limited, send, body } = require('./_lib');
const PUB = { kty: 'EC', crv: 'P-256', x: '_H2X0jNFio8GAdcxexVyLFtAWHQ2HS3OmvIOCWB5a6A', y: '2RatVkUymIxQp6BebXEUAxVPmV81YIb-cuZ2KWV5HpY' };
const b64u = t => { t = t.replace(/-/g, '+').replace(/_/g, '/'); while (t.length % 4) t += '='; return Uint8Array.from(Buffer.from(t, 'base64')); };
const day = o => new Date(Date.now() - o * 864e5).toISOString().slice(0, 10);
const kv = a => { const o = {}; for (let i = 0; i < (a || []).length; i += 2) o[a[i]] = +a[i + 1]; return o; };
module.exports = async (req, res) => {
  if (req.method !== 'POST') return send(res, 405, { ok: false });
  if (await limited(req, 'stats', 30, 600)) return send(res, 429, { ok: false });
  const b = await body(req), ts = +b.ts, sig = String(b.sig || '');
  if (!ts || Math.abs(Date.now() - ts) > 3e5 || sig.length < 20 || sig.length > 200) return send(res, 403, { ok: false });
  try {
    const key = await crypto.subtle.importKey('jwk', PUB, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    if (!(await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, b64u(sig), new TextEncoder().encode('jagun-stats:' + ts)))) return send(res, 403, { ok: false });
  } catch (e) { return send(res, 403, { ok: false }); }
  try {
    const days = [];
    for (let i = 29; i >= 0; i--) { const d = day(i); const [h, a] = await Promise.all([redis(['HGETALL', 'd:' + d]), redis(['SCARD', 'p:' + d])]); days.push({ d, active: +a || 0, ...kv(h) }); }
    const [players, linkers, top, names, carts] = await Promise.all([redis(['SCARD', 'p:all']), redis(['SCARD', 'lk:all']), redis(['ZREVRANGE', 'lb', '0', '9', 'WITHSCORES']), redis(['HGETALL', 'lk:names']), redis(['SMEMBERS', 'carts:names'])]);
    const paid = []; for (const n of (carts || []).slice(0, 60)) paid.push({ name: n, devices: await redis(['SCARD', 'cart:' + n]), clicks: kv(names)[n] || 0 });
    const lb = []; for (let i = 0; i < (top || []).length; i += 2) lb.push({ id: String(top[i]).slice(0, 6), score: +top[i + 1] });
    return send(res, 200, { ok: true, players, linkers, days, lb, paid, links: kv(names) });
  } catch (e) { return send(res, 503, { ok: false, error: 'storage' }); }
};
