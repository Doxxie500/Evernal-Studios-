/* POST /api/track { t:'visit'|'run', dev, cart?, sc?, km?, pax?, cow? } — anonymous game analytics (counts only, no personal data). */
'use strict';
const { redis, limited, send, body } = require('./_lib');
const day = (o = 0) => new Date(Date.now() - o * 864e5).toISOString().slice(0, 10);
module.exports = async (req, res) => {
  if (req.method !== 'POST') return send(res, 405, { ok: false });
  if (await limited(req, 'track', 120, 600)) return send(res, 429, { ok: false });
  const b = await body(req), dev = String(b.dev || ''), n = (v, m) => Math.max(0, Math.min(m, Math.round(+v || 0)));
  if (!/^[a-z0-9]{16,40}$/.test(dev)) return send(res, 400, { ok: false });
  const d = day(), H = 'd:' + d;
  try {
    const first = await redis(['SADD', 'p:all', dev]);                       // 1 = brand-new player
    await redis(['SADD', 'p:' + d, dev]);
    if (b.t === 'visit') {
      await redis(['HINCRBY', H, 'visits', '1']); if (first) await redis(['HINCRBY', H, 'new', '1']);
      const nm = String(b.cart || '').replace(/[^\p{L}\p{N} '’.\-]/gu, '').slice(0, 14);
      if (nm) { await redis(['HINCRBY', H, 'links', '1']); await redis(['SADD', 'lk:all', dev]); await redis(['HINCRBY', 'lk:names', nm, '1']); }
    } else if (b.t === 'run') {
      const sc = n(b.sc, 99999999);
      await redis(['HINCRBY', H, 'runs', '1']); await redis(['HINCRBY', H, 'score', String(sc)]); await redis(['HINCRBY', H, 'km', String(n(b.km, 5e6))]);
      await redis(['HINCRBY', H, 'pax', String(n(b.pax, 1500))]); await redis(['HINCRBY', H, 'cow', String(n(b.cow, 99999))]);
      await redis(['ZADD', 'lb', 'GT', String(sc), dev]);
    }
    for (const k of [H, 'p:' + d]) await redis(['EXPIRE', k, String(86400 * 120)]);
    return send(res, 200, { ok: true });
  } catch (e) { return send(res, 503, { ok: false }); }
};
