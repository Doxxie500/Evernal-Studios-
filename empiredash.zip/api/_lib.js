/* Shared helpers for the Empire Dash serverless functions (Vercel, Node 18+, no npm packages needed).
   Storage: Upstash Redis through its REST API. In Vercel: Storage → Marketplace → Upstash Redis → connect to this project.
   It adds KV_REST_API_URL + KV_REST_API_TOKEN (or UPSTASH_REDIS_REST_URL + UPSTASH_REDIS_REST_TOKEN); both names are accepted. */
'use strict';
const URL_ = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL || '';
const TOKEN = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN || '';

async function redis(cmd) {                                   // one Redis command, e.g. ['SADD','key','value'] → result
  if (!URL_ || !TOKEN) throw new Error('storage not configured');
  const r = await fetch(URL_, { method: 'POST', headers: { Authorization: 'Bearer ' + TOKEN, 'Content-Type': 'application/json' }, body: JSON.stringify(cmd) });
  if (!r.ok) throw new Error('storage ' + r.status);
  const j = await r.json(); if (j.error) throw new Error(j.error); return j.result;
}
const ip = req => String((req.headers['x-forwarded-for'] || req.headers['x-real-ip'] || 'x')).split(',')[0].trim().slice(0, 64);
async function limited(req, bucket, max, windowSec) {          // true when this IP has used up its quota; fails OPEN if storage is down
  try { const k = 'rl:' + bucket + ':' + ip(req); const n = await redis(['INCR', k]); if (n === 1) await redis(['EXPIRE', k, String(windowSec)]); return n > max; } catch (e) { return false; }
}
function send(res, code, obj) { res.statusCode = code; res.setHeader('Content-Type', 'application/json'); res.setHeader('Cache-Control', 'no-store'); res.end(JSON.stringify(obj)); }
async function body(req) {
  if (req.body && typeof req.body === 'object') return req.body;
  let t = ''; for await (const c of req) { t += c; if (t.length > 4096) break; }
  try { return JSON.parse(t || '{}'); } catch (e) { return {}; }
}
module.exports = { redis, limited, send, body };
